# Paper tables

LaTeX tables are generated into **`paper/results/tables/`** (single source of truth).

From `paper/tmlr.tex`:

```latex
\input{results/tables/primary_results.tex}
```

Do not edit generated `.tex` files by hand; regenerate with `make evaluate`.
