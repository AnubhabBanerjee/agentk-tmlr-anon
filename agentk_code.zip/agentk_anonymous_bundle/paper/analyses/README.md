# Phase 7 §7.3 — VRAM ↔ Correctness analyses

Three self-contained markdown reports (guide §7.3). Each answers a distinct
reviewer question using Phase 3 trace outputs only — no additional tracing.

| File | Topic |
|------|--------|
| `7.3a_joint_distribution_vram_correctness.md` | Peak VRAM vs correctness; point-biserial & partial correlations |
| `7.3b_proxy_calibration_by_correctness_stratum.md` | B2/B4/B5 MAPE/OOM/OAW by correct vs incorrect stratum |
| `7.3c_cost_quality_pareto.md` | Admission-control throughput vs correctness under VRAM budgets |

Machine-readable metrics are also written to `paper/results/metrics/`:

- `correctness_joint.parquet`
- `correctness_strata.parquet`
- `cost_quality_pareto.parquet`

## Regenerate

```bash
make analyses
```

Optional supporting figures: `paper/figures/fig7a_*.pdf`, `fig7c_*.pdf`.
