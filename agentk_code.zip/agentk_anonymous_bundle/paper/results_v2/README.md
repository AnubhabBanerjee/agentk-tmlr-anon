# v2 dataset release

**Frozen at git commit:** `3d4dee6c7071e3881335306e5dd876ee71c95d6f` (matches `data/dataset_release_manifest_v2.md`).
**License:** Apache-2.0.

## Bundles

| Bundle | Contents | Size | SHA256 | Mirror URL |
|---|---|--:|---|---|
| Derived | index, labels, correctness, prompts, configs, README, manifest | 1.2M | `8e78723e549c2550ea0df74f3baf091ba843d03f24160c9cb4f134689533c5f6` | TBD (uploaded at anonymization audit, §7.3 step 40) |
| Raw traces | `data/traces_v2/{agent_llm}/*.jsonl.zst` + `data/traces/cuda/` sidecars | 4.0M | `51d3475b5a8d441bfd4dc3c420d6c7a2f1950a46089e8dd0aaaace04131c3019` | TBD (uploaded at anonymization audit, §7.3 step 40) |

Bundle paths (local build artifacts, not committed):

- `artifacts_v2/dataset_release_v2_derived.tar.zst`
- `artifacts_v2/dataset_release_v2_raw_traces.tar.zst`

## Reproducibility

See `dataset_release_manifest_v2.md` for per-file hashes and row counts, and `data/traces_v2/README.md` for schema.
