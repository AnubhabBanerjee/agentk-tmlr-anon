"""F5 Tier-2 counterfactual budget grid for §7.3.c cost–quality Pareto."""

from __future__ import annotations

import numpy as np
import pandas as pd

from src.eval.cost_quality_pareto import (
    BUDGET_GB,
    COUNTERFACTUAL_BUDGET_GB,
    admission_metrics_at_budget,
    counterfactual_metrics_at_budget,
)


def test_counterfactual_budget_grid_matches_guide() -> None:
    assert COUNTERFACTUAL_BUDGET_GB == (2, 4, 6, 8, 10, 12, 16, 24, 40)
    assert BUDGET_GB == COUNTERFACTUAL_BUDGET_GB


def test_counterfactual_oom_rate_at_6gb() -> None:
    # Three prompts: 5 GB, 7 GB, 9 GB true peaks → 2/3 over a 6 GB cap.
    peaks_mb = np.array([5 * 1024.0, 7 * 1024.0, 9 * 1024.0])
    out = counterfactual_metrics_at_budget(peaks_mb, 6 * 1024.0, m_ceiling_mb=80 * 1024.0)
    assert out["n_over_budget"] == 2
    assert abs(out["counterfactual_oom_rate"] - 2 / 3) < 1e-9


def test_admission_metrics_partition_throughput() -> None:
    merged = pd.DataFrame(
        {
            "M_peak_true": [4 * 1024.0, 7 * 1024.0, 5 * 1024.0],
            "Mupper_pred": [5 * 1024.0, 5 * 1024.0, 8 * 1024.0],
            "compile_success": [True, False, True],
        }
    )
    out = admission_metrics_at_budget(merged, 6 * 1024.0, m_ceiling_mb=80 * 1024.0)
    assert out["n_total"] == 3
    assert out["n_admitted"] == 2
    assert abs(out["throughput"] - 2 / 3) < 1e-9
    assert out["correctness_rate"] == 0.5
    assert out["admission_oom_rate"] == 0.5


def test_build_table_schema_includes_counterfactual_columns() -> None:
    # Smoke the public column contract without loading traces / proxies.
    expected = {
        "budget_gb",
        "counterfactual_oom_rate",
        "counterfactual_oaw_pct_ceiling",
        "admission_oom_rate",
        "oaw_pct_ceiling",
        "throughput",
        "correctness_rate",
    }
    # Document the nine-point primary axis explicitly.
    assert len(BUDGET_GB) == 9
    assert set(BUDGET_GB) == {2, 4, 6, 8, 10, 12, 16, 24, 40}
    assert expected  # keeps linters happy that the set is used
