"""F6 Tier-2 — stratified peak-VRAM MAPE bucket tests."""

from __future__ import annotations

import numpy as np
import pandas as pd

from src.eval.metrics import (
    PEAK_VRAM_BUCKET_LABELS,
    assign_peak_vram_buckets,
    macro_averaged_mape,
    peak_vram_bucket_mb,
)
from src.eval.vram_strata import _per_bucket_mape


def test_peak_vram_bucket_edges():
    assert peak_vram_bucket_mb(0.0) == "<1 GB"
    assert peak_vram_bucket_mb(1023.9) == "<1 GB"
    assert peak_vram_bucket_mb(1024.0) == "1–5 GB"
    assert peak_vram_bucket_mb(5119.9) == "1–5 GB"
    assert peak_vram_bucket_mb(5120.0) == "5–20 GB"
    assert peak_vram_bucket_mb(20479.9) == "5–20 GB"
    assert peak_vram_bucket_mb(20480.0) == ">20 GB"
    assert peak_vram_bucket_mb(50000.0) == ">20 GB"


def test_macro_averaged_mape_skips_empty_and_nan():
    avg = macro_averaged_mape(
        {
            "<1 GB": float("nan"),
            "1–5 GB": 10.0,
            "5–20 GB": 20.0,
            ">20 GB": float("nan"),
        }
    )
    assert avg == 15.0


def test_per_bucket_mape_isolated():
    # Two prompts in different buckets with known errors.
    frame = pd.DataFrame(
        {
            "M_peak_true": [500.0, 6000.0],
            "Mpeak_pred": [550.0, 6300.0],
        }
    )
    bucket_map = _per_bucket_mape(frame)
    # <1 GB: |500-550|/500 = 10%
    assert bucket_map["<1 GB"] == 10.0
    # 5–20 GB: |6000-6300|/6000 = 5%
    assert bucket_map["5–20 GB"] == 5.0
    assert np.isnan(bucket_map["1–5 GB"])
    assert np.isnan(bucket_map[">20 GB"])
    assert macro_averaged_mape(bucket_map) == 7.5


def test_assign_peak_vram_buckets_series():
    labels = assign_peak_vram_buckets(pd.Series([100.0, 2000.0, 10000.0]))
    assert list(labels) == ["<1 GB", "1–5 GB", "5–20 GB"]
    assert list(PEAK_VRAM_BUCKET_LABELS) == ["<1 GB", "1–5 GB", "5–20 GB", ">20 GB"]
