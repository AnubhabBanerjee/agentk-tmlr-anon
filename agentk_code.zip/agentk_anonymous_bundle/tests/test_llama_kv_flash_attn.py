"""Quantized KV cache types require flash_attn in llama-cpp-python."""

from __future__ import annotations

from pathlib import Path

import pytest


@pytest.mark.parametrize(
    "type_k,type_v",
    [(8, 8), (2, 2)],
)
def test_quantized_kv_cache_requires_flash_attn(type_k: int, type_v: int) -> None:
    gguf = Path("[REDACTED_PATH]")
    if not gguf.is_file():
        pytest.skip(f"missing GGUF fixture: {gguf}")

    from llama_cpp import Llama

    with pytest.raises(ValueError, match="Failed to create llama_context"):
        Llama(
            model_path=str(gguf),
            n_ctx=2048,
            n_gpu_layers=-1,
            verbose=False,
            type_k=type_k,
            type_v=type_v,
            flash_attn=False,
        )

    model = Llama(
        model_path=str(gguf),
        n_ctx=2048,
        n_gpu_layers=-1,
        verbose=False,
        type_k=type_k,
        type_v=type_v,
        flash_attn=True,
    )
    del model
