"""Tests for Part-2 v2 sweep run planning."""

from __future__ import annotations

from pathlib import Path

import yaml

from src.tracing.sweep_plan import (
    count_v2_trace_runs,
    enumerate_v2_trace_runs,
    load_v2_sweep_config,
    reject_legacy_sweep_keys,
    sweep_subset_prompt_ids,
    uses_v2_sweep_schema,
)


def test_v2_schema_detection() -> None:
    cfg = yaml.safe_load(
        (Path(__file__).resolve().parents[1] / "configs" / "tracing_v2.yaml").read_text()
    )
    assert uses_v2_sweep_schema(cfg)
    reject_legacy_sweep_keys(cfg)


def test_legacy_keys_raise() -> None:
    cfg = {"cache_type_sweep": [["f16", "f16"]], "cache_type_k_sweep": ["f16"]}
    try:
        reject_legacy_sweep_keys(cfg)
        raise AssertionError("expected KeyError")
    except KeyError as exc:
        assert "cache_type_k_sweep" in str(exc)


def test_v2_full_batch_is_1920() -> None:
    repo = Path(__file__).resolve().parents[1]
    tracing_cfg = yaml.safe_load((repo / "configs" / "tracing_v2.yaml").read_text())
    prompts_path = repo / "data" / "prompts_v2" / "all.jsonl"
    rows = [
        __import__("json").loads(line)
        for line in prompts_path.read_text().splitlines()
        if line.strip()
    ]
    agent_cfg = yaml.safe_load((repo / "configs" / "agent_llms_v2.yaml").read_text())
    model_ids = list(agent_cfg["models"].keys())
    sweep_cfg = load_v2_sweep_config(tracing_cfg)
    subset_ids = sweep_subset_prompt_ids(
        rows,
        total=sweep_cfg.sweep_subset_prompts,
        seed=int(tracing_cfg["split"]["seed"]),
    )
    runs = enumerate_v2_trace_runs(
        model_ids=model_ids,
        prompt_rows=rows,
        sweep_cfg=sweep_cfg,
        sweep_prompt_ids=subset_ids,
    )
    base, sweep, total = count_v2_trace_runs(
        n_agents=len(model_ids),
        n_prompts=len(rows),
        sweep_cfg=sweep_cfg,
    )
    assert base == 1200
    assert sweep == 720
    assert total == 1920
    assert len(runs) == 1920
