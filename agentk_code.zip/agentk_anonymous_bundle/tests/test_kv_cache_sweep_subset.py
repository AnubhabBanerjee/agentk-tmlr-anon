"""Part 2 A1 — stratified KV-cache sweep subset selection."""

from __future__ import annotations

import json
from pathlib import Path

from src.prompts.stratified_split import (
    PromptRecord,
    SPLIT_SEED,
    stratified_kv_cache_sweep_subset,
)


def _load_prompt_records(repo_root: Path) -> list[PromptRecord]:
    rows = [
        json.loads(line)
        for line in (repo_root / "data/prompts/all.jsonl").read_text().splitlines()
        if line.strip()
    ]
    return [
        PromptRecord(
            id=str(row["id"]),
            source=str(row["source"]),
            family=str(row["family"]),
            complexity=str(row["complexity"]),
            precision=str(row.get("precision", "")),
            prompt=str(row["prompt"]),
        )
        for row in rows
    ]


def test_kv_cache_sweep_subset_size_and_stability() -> None:
    repo = Path(__file__).resolve().parents[1]
    records = _load_prompt_records(repo)
    first = stratified_kv_cache_sweep_subset(records, total=100, seed=SPLIT_SEED)
    second = stratified_kv_cache_sweep_subset(records, total=100, seed=SPLIT_SEED)
    assert len(records) == 600
    assert len(first) == 100
    assert len(records) - len(first) == 500
    assert first == second
