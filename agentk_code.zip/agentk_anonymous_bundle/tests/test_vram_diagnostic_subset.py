"""Tests for released v2 VRAM diagnostic subset cadence selection."""

from __future__ import annotations

import json
from pathlib import Path

import yaml

from src.tracing.vram_factory import build_vram_sampler
from src.tracing.vram_sampler import (
    diagnostic_subset_prompt_ids,
    load_diagnostic_prompt_ids,
    resolve_vram_interval_ms,
)


def _load_prompt_rows(repo: Path) -> list[dict]:
    path = repo / "data" / "prompts_v2" / "all.jsonl"
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def test_diagnostic_subset_is_val_only_and_size_30() -> None:
    repo = Path(__file__).resolve().parents[1]
    rows = _load_prompt_rows(repo)
    tracing_cfg = yaml.safe_load((repo / "configs" / "tracing_v2.yaml").read_text())
    seed = int(tracing_cfg["split"]["seed"])
    subset_size = int(tracing_cfg["vram_sampling"]["diagnostic_subset_size"])

    ids = diagnostic_subset_prompt_ids(rows, total=subset_size, seed=seed)
    assert len(ids) == 30
    row_by_id = {str(row["id"]): row for row in rows}
    assert all(row_by_id[pid]["split"] == "val" for pid in ids)


def test_diagnostic_subset_is_deterministic() -> None:
    repo = Path(__file__).resolve().parents[1]
    rows = _load_prompt_rows(repo)
    tracing_cfg = yaml.safe_load((repo / "configs" / "tracing_v2.yaml").read_text())
    seed = int(tracing_cfg["split"]["seed"])

    first = diagnostic_subset_prompt_ids(rows, total=30, seed=seed)
    second = diagnostic_subset_prompt_ids(rows, total=30, seed=seed)
    assert first == second


def test_resolve_vram_interval_ms_switches_cadence() -> None:
    repo = Path(__file__).resolve().parents[1]
    tracing_cfg = yaml.safe_load((repo / "configs" / "tracing_v2.yaml").read_text())
    rows = _load_prompt_rows(repo)
    seed = int(tracing_cfg["split"]["seed"])
    vram_cfg = tracing_cfg["vram_sampling"]
    diagnostic_ids = load_diagnostic_prompt_ids(vram_cfg, rows, seed=seed)
    assert diagnostic_ids is not None

    diag_id = sorted(diagnostic_ids)[0]
    non_diag_id = next(
        pid for pid in (str(row["id"]) for row in rows) if pid not in diagnostic_ids
    )
    assert resolve_vram_interval_ms(
        vram_cfg, prompt_id=diag_id, diagnostic_prompt_ids=diagnostic_ids
    ) == 100
    assert resolve_vram_interval_ms(
        vram_cfg, prompt_id=non_diag_id, diagnostic_prompt_ids=diagnostic_ids
    ) == 500


def test_build_vram_sampler_uses_diagnostic_interval() -> None:
    repo = Path(__file__).resolve().parents[1]
    tracing_cfg = yaml.safe_load((repo / "configs" / "tracing_v2.yaml").read_text())
    rows = _load_prompt_rows(repo)
    seed = int(tracing_cfg["split"]["seed"])
    vram_cfg = tracing_cfg["vram_sampling"]
    diagnostic_ids = load_diagnostic_prompt_ids(vram_cfg, rows, seed=seed)
    assert diagnostic_ids is not None

    diag_sampler = build_vram_sampler(
        vram_cfg,
        prompt_id=sorted(diagnostic_ids)[0],
        diagnostic_prompt_ids=diagnostic_ids,
    )
    other_sampler = build_vram_sampler(
        vram_cfg,
        prompt_id="definitely-not-in-subset",
        diagnostic_prompt_ids=diagnostic_ids,
    )
    assert diag_sampler._interval_ms == 100
    assert other_sampler._interval_ms == 500
