"""Round-trip tests for v1 JSONL and v2 ZSTD-compressed trace I/O."""

from __future__ import annotations

import json
from pathlib import Path

import zstandard

from src.tracing.llm_recorder import (
    TRACE_JSONL_SUFFIX,
    TRACE_JSONL_ZST_SUFFIX,
    is_compressed_trace_path,
    nvidia_smi_sidecar_path,
    trace_path_stem,
    write_trace_jsonl_file,
)
from src.tracing.vram_join import iter_trace_jsonl, load_trace_jsonl, resolve_trace_jsonl_path


def _sample_rows() -> list[dict]:
    return [
        {"record": "metadata", "prompt_id": "p001"},
        {"record": "summary", "compile_success": False},
    ]


def test_write_and_read_plain_jsonl(tmp_path: Path) -> None:
    path = tmp_path / f"p001{TRACE_JSONL_SUFFIX}"
    rows = _sample_rows()
    write_trace_jsonl_file(path, rows)
    assert not is_compressed_trace_path(path)
    assert load_trace_jsonl(path) == rows


def test_write_and_read_zstd_jsonl(tmp_path: Path) -> None:
    path = tmp_path / f"p001{TRACE_JSONL_ZST_SUFFIX}"
    rows = _sample_rows()
    write_trace_jsonl_file(path, rows)
    assert is_compressed_trace_path(path)
    raw = path.read_bytes()
    assert raw[:4] != b'{"re'
    with zstandard.ZstdDecompressor().stream_reader(raw) as reader:
        decompressed = reader.read().decode("utf-8")
    assert json.loads(decompressed.splitlines()[0])["record"] == "metadata"
    assert load_trace_jsonl(path) == rows
    assert list(iter_trace_jsonl(path)) == rows


def test_resolve_trace_jsonl_path_prefers_zst(tmp_path: Path) -> None:
    zst_path = tmp_path / f"p001{TRACE_JSONL_ZST_SUFFIX}"
    jsonl_path = tmp_path / f"p001{TRACE_JSONL_SUFFIX}"
    write_trace_jsonl_file(zst_path, _sample_rows())
    write_trace_jsonl_file(jsonl_path, [{"record": "metadata", "prompt_id": "legacy"}])
    resolved = resolve_trace_jsonl_path(tmp_path / "p001")
    assert resolved == zst_path


def test_nvidia_smi_sidecar_path_for_zst_trace(tmp_path: Path) -> None:
    trace = tmp_path / f"p001__ctx8192__kf16__vf16{TRACE_JSONL_ZST_SUFFIX}"
    assert nvidia_smi_sidecar_path(trace).name == "p001__ctx8192__kf16__vf16.nvidia_smi.csv"
    assert trace_path_stem(trace) == "p001__ctx8192__kf16__vf16"
