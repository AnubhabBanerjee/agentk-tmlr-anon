"""F7 Tier-2 — OAW as percentage of VRAM ceiling."""

from __future__ import annotations

import numpy as np

from src.eval.metrics import oaw_mb, oaw_pct_of_ceiling
from src.eval.paths import VRAM_CEILING_MB


def test_oaw_pct_of_ceiling_formula():
    # Mean slack 8000 MB on an 81920 MB ceiling → 8000/81920 * 100 %.
    y_true = np.array([1000.0, 2000.0])
    y_upper = np.array([9000.0, 10000.0])
    assert oaw_mb(y_true, y_upper) == 8000.0
    expected_pct = 8000.0 / VRAM_CEILING_MB * 100.0
    assert oaw_pct_of_ceiling(y_true, y_upper, m_ceiling_mb=VRAM_CEILING_MB) == expected_pct


def test_oaw_pct_clips_negative_slack():
    # Under-provision (upper < true) contributes zero waste.
    y_true = np.array([5000.0])
    y_upper = np.array([4000.0])
    assert oaw_mb(y_true, y_upper) == 0.0
    assert oaw_pct_of_ceiling(y_true, y_upper, m_ceiling_mb=81920.0) == 0.0


def test_ensure_oaw_pct_ceiling_backfill():
    import pandas as pd
    from src.eval.metrics import ensure_oaw_pct_ceiling
    from src.eval.paths import VRAM_CEILING_MB

    df = pd.DataFrame({"oaw_mb": [819.2, 0.0]})
    out = ensure_oaw_pct_ceiling(df)
    assert "oaw_pct_ceiling" in out.columns
    assert out["oaw_pct_ceiling"].iloc[0] == 819.2 / VRAM_CEILING_MB * 100.0

