"""Tests for F3 tool-head token regression."""

from __future__ import annotations

import torch

from src.proxy.forecast import aggregated_tool_tokens
from src.proxy.loss import tool_mse_loss


def test_aggregated_tool_tokens_sums_nodes() -> None:
    hat = torch.tensor([[10.0, 20.0, 0.0, 5.0, 1.0]])
    assert float(aggregated_tool_tokens(hat).item()) == 36.0


def test_tool_mse_loss_zero_on_match() -> None:
    target = torch.tensor([[1.0, 2.0, 3.0, 4.0, 5.0]])
    loss = tool_mse_loss(target, target)
    assert float(loss.item()) == 0.0
