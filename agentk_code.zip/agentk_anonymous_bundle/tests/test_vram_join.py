"""Unit tests for F1 Tier-1 nvidia-smi VRAM join helpers."""

from __future__ import annotations

import time
from pathlib import Path

import pytest

from src.tracing.nvidia_smi_sampler import NvidiaSmiVramSampler
from src.tracing.vram_join import (
    build_vram_samples_from_nvidia_smi,
    nearest_vram_mb,
    parse_nvidia_smi_csv,
    parse_nvidia_smi_timestamp,
    peak_used_mb_from_samples,
    wall_epoch_to_relative_ms,
)
from src.tracing.vram_sampler import VramSample


def test_parse_nvidia_smi_timestamp() -> None:
    epoch = parse_nvidia_smi_timestamp("2026/07/18 17:19:00.673")
    assert epoch > 1_700_000_000


def test_parse_nvidia_smi_csv_sorts_rows() -> None:
    text = "\n".join(
        [
            "100, 2026/07/18 17:19:01.000",
            "50, 2026/07/18 17:19:00.500",
        ]
    )
    rows = parse_nvidia_smi_csv(text)
    assert len(rows) == 2
    assert rows[0][1] == 50.0
    assert rows[1][1] == 100.0


def test_nearest_vram_mb_picks_closer_neighbor() -> None:
    timeline = [
        (1000.0, 10.0),
        (1001.0, 20.0),
    ]
    assert nearest_vram_mb(1000.1, timeline) == 10.0
    assert nearest_vram_mb(1000.9, timeline) == 20.0


def test_build_vram_samples_joins_boundaries() -> None:
    wall_t0 = parse_nvidia_smi_timestamp("2026/07/18 17:19:00.000")
    csv_text = "\n".join(
        [
            "100, 2026/07/18 17:19:00.100",
            "200, 2026/07/18 17:19:00.300",
            "150, 2026/07/18 17:19:00.500",
        ]
    )
    boundary_epoch = parse_nvidia_smi_timestamp("2026/07/18 17:19:00.300")
    samples = build_vram_samples_from_nvidia_smi(
        csv_text=csv_text,
        wall_t0=wall_t0,
        boundaries=[("planner:start", boundary_epoch)],
    )
    boundary_rows = [s for s in samples if s.boundary == "planner:start"]
    assert len(boundary_rows) == 1
    assert boundary_rows[0].vram_used_mb == 200.0
    assert peak_used_mb_from_samples(samples) == 200.0


def test_wall_epoch_to_relative_ms() -> None:
    assert wall_epoch_to_relative_ms(10.5, 10.0) == pytest.approx(500.0)


@pytest.mark.skipif(
    not Path("/usr/local/bin/nvidia-smi").is_file() and not Path("/usr/bin/nvidia-smi").is_file(),
    reason="nvidia-smi not installed",
)
def test_nvidia_smi_sampler_start_stop_roundtrip() -> None:
    sampler = NvidiaSmiVramSampler(interval_ms=200, device_index=0)
    sampler.start()
    time.sleep(0.5)
    sampler.snapshot_boundary("test:start")
    time.sleep(0.3)
    sampler.stop()
    samples = sampler.samples()
    assert len(samples) >= 2
    assert sampler.peak_used_mb() >= 0.0
    assert any(s.boundary == "test:start" for s in samples)
