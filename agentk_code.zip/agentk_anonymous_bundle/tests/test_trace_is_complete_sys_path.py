"""Regression: resume checks must work after AgentK shadows repo ``src``."""

from __future__ import annotations

import sys
from pathlib import Path

from scripts.trace_batch_common import trace_is_complete


def test_trace_is_complete_with_agentk_on_sys_path() -> None:
    repo = Path(__file__).resolve().parents[1]
    agentk_root = str(repo / "third_party" / "agentk")
    if agentk_root not in sys.path:
        sys.path.insert(0, agentk_root)

    sweep_trace = (
        repo
        / "data"
        / "traces_v2"
        / "mistral-7b-instruct-v0.3"
        / "sweep"
        / "kbench-l1-003__ctx8192__kf16__vf16.jsonl.zst"
    )
    if not sweep_trace.is_file():
        return

    assert trace_is_complete(sweep_trace)
