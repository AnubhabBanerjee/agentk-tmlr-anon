"""
render all required paper figures from paper/results/metrics/.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import torch

from src.baselines.common import AGENT_LLMS
from src.eval.backbone_ablation import build_backbone_ablation_test_table
from src.eval.cross_model import build_cross_model_generalization_table
from src.eval.manifest import write_manifest
from src.eval.metrics import ensure_oaw_pct_ceiling
from src.eval.context import eval_context, proxies_available
from src.eval.paths import MAPE_BAR_METHODS, ResultsLayout
from src.eval.tables import render_backbone_ablation_tex

from src.pipeline.tracing_paths import tracing_paths_from_env

# Map guide complexity labels to index.parquet values.
COMPLEXITY_FOR_FIG1: Dict[str, str] = {
    "beginner": "beginner",
    "intermediate": "intermediate",
    "adversarial": "adversarial-broken-spec",
}

# Short display names for agent LLMs in figure legends.
AGENT_LABELS: Dict[str, str] = {
    "qwen2.5-coder-7b": "Qwen2.5-Coder-7B",
    "phi-4-mini": "Phi-4-mini",
    "mistral-7b-instruct-v0.3": "Mistral-7B-Instruct",
}

# Human-readable backbone names for ablation figure.
BACKBONE_LABELS: Dict[str, str] = {
    "minilm-l12": "MiniLM-L12",
    "deberta-v3-base": "DeBERTa-v3",
    "unixcoder": "UniXCoder",
}

# Pareto figure methods: our method (B4) vs baselines B0–B3 (guide §7.2 fig 2).
PARETO_METHODS: Tuple[str, ...] = ("B0", "B1", "B2", "B3", "B4")

# Output PDF basenames under paper/figures/.
FIGURE_NAMES: Tuple[str, ...] = (
    "fig1_vram_trajectory.pdf",
    "fig2_oom_oaw_pareto.pdf",
    "fig3_mape_bar.pdf",
    "fig4_backbone_ablation.pdf",
    "fig5_subcomponent_scatter.pdf",
    "fig6_cross_model_generalization.pdf",
)


def _apply_style() -> None:
    """Set matplotlib/seaborn defaults for publication-ready PDFs."""
    sns.set_theme(style="whitegrid", context="paper", font_scale=1.05)
    plt.rcParams.update(
        {
            "figure.dpi": 100,
            "savefig.dpi": 300,
            "savefig.bbox": "tight",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )


def select_representative_prompts(repo_root: Path, *, split: str = "test") -> pd.DataFrame:
    """
    Pick one prompt per (agent, complexity) for fig 1.

    Uses the lexicographically first prompt_id in each stratum for reproducibility.
    """
    layout = tracing_paths_from_env(repo_root=repo_root)
    index = pd.read_parquet(layout.index_path)
    rows: List[dict] = []
    for agent_llm in AGENT_LLMS:
        for fig_label, complexity in COMPLEXITY_FOR_FIG1.items():
            sub = index[
                (index["agent_llm"] == agent_llm)
                & (index["split"] == split)
                & (index["prompt_complexity"] == complexity)
            ]
            if sub.empty:
                continue
            prompt_id = str(sorted(sub["prompt_id"].astype(str).tolist())[0])
            rows.append(
                {
                    "agent_llm": agent_llm,
                    "prompt_id": prompt_id,
                    "complexity_label": fig_label,
                    "prompt_complexity": complexity,
                }
            )
    return pd.DataFrame(rows)


def plot_fig1_vram_trajectory(
    trajectory: pd.DataFrame,
    representatives: pd.DataFrame,
    out_path: Path,
) -> None:
    """Fig 1 — empirical vs predicted VRAM along deduped node boundaries."""
    fig, axes = plt.subplots(
        len(AGENT_LLMS),
        len(COMPLEXITY_FOR_FIG1),
        figsize=(12, 9),
        sharex=False,
        sharey=False,
    )
    if len(AGENT_LLMS) == 1:
        axes = np.array([axes])
    for row_idx, agent_llm in enumerate(AGENT_LLMS):
        for col_idx, fig_label in enumerate(COMPLEXITY_FOR_FIG1.keys()):
            ax = axes[row_idx, col_idx]
            rep = representatives[
                (representatives["agent_llm"] == agent_llm)
                & (representatives["complexity_label"] == fig_label)
            ]
            if rep.empty:
                ax.set_visible(False)
                continue
            pid = str(rep.iloc[0]["prompt_id"])
            sub = trajectory[
                (trajectory["agent_llm"] == agent_llm) & (trajectory["prompt_id"] == pid)
            ]
            if sub.empty or "boundary_idx" not in trajectory.columns:
                ax.text(0.5, 0.5, "no trajectory", ha="center", va="center", transform=ax.transAxes)
            else:
                sub = sub.sort_values("boundary_idx")
                x = np.arange(len(sub))
                ax.plot(x, sub["m_emp_mb"], "o-", label="Empirical", color="#1f77b4", markersize=4)
                ax.plot(x, sub["m_pred_mb"], "s--", label="Predicted", color="#ff7f0e", markersize=4)
                ax.set_xticks(x[:: max(1, len(x) // 6)])
                ax.set_xticklabels(
                    [str(b)[:12] for b in sub["boundary"].iloc[:: max(1, len(x) // 6)]],
                    rotation=45,
                    ha="right",
                    fontsize=7,
                )
            if row_idx == 0:
                ax.set_title(fig_label.capitalize())
            if col_idx == 0:
                ax.set_ylabel(f"{AGENT_LABELS.get(agent_llm, agent_llm)}\nVRAM (MiB)")
            if row_idx == len(AGENT_LLMS) - 1:
                ax.set_xlabel("Boundary index")
    handles, labels = axes[0, 0].get_legend_handles_labels()
    if handles:
        fig.legend(handles, labels, loc="upper center", ncol=2, bbox_to_anchor=(0.5, 1.02))
    fig.suptitle("VRAM trajectory: empirical vs proxy closed-form (test prompts)", y=1.05)
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)


def plot_fig2_oom_oaw_pareto(z_sweep: pd.DataFrame, out_path: Path) -> None:
    """Fig 2 — upper-bound undercoverage rate vs OAW across z_alpha for B0–B3 and B4 (per agent).

    NOTE: despite the "oom" in this function's name (kept for filename/manifest
    stability), the plotted quantity is undercoverage_rate = Pr(M_peak_true >
    M_upper_pred), not an observed hardware OOM event or admission-control result.
    """
    fig, axes = plt.subplots(1, len(AGENT_LLMS), figsize=(13, 4.2), sharey=True)
    palette = sns.color_palette("tab10", n_colors=len(PARETO_METHODS))
    method_colors = {m: palette[i] for i, m in enumerate(PARETO_METHODS)}
    for ax, agent_llm in zip(axes, AGENT_LLMS):
        for method in PARETO_METHODS:
            sub = z_sweep[
                (z_sweep["agent_llm"] == agent_llm) & (z_sweep["method"] == method)
            ].sort_values("z_alpha")
            if sub.empty:
                continue
            ax.plot(
                sub["oaw_pct_ceiling"],
                sub["undercoverage_rate"],
                "o-",
                color=method_colors[method],
                label=method,
                markersize=5,
                linewidth=1.5,
            )
            for _, row in sub.iterrows():
                ax.annotate(
                    f"{row['z_alpha']:.2f}",
                    (row["oaw_pct_ceiling"], row["undercoverage_rate"]),
                    fontsize=6,
                    alpha=0.75,
                    xytext=(3, 3),
                    textcoords="offset points",
                )
        ax.set_xlabel("OAW (% of $M_{\\mathrm{ceiling}}$)")
        ax.set_title(AGENT_LABELS.get(agent_llm, agent_llm))
        ax.set_ylim(-0.05, 1.05)
    axes[0].set_ylabel("Upper-bound undercoverage rate")
    fig.suptitle("Undercoverage rate vs over-allocation waste ($z_\\alpha$ sweep)", y=1.02)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=len(PARETO_METHODS), bbox_to_anchor=(0.5, 1.12))
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)


def plot_fig3_mape_bar(primary: pd.DataFrame, out_path: Path) -> None:
    """Fig 3 — MAPE bar chart per agent × selected methods."""
    methods = [m for m in MAPE_BAR_METHODS if m in primary["method"].unique()]
    if "B4" not in primary["method"].unique() and "B3" not in methods:
        methods = [m if m != "B4" else "B3" for m in methods]
        methods = [m for m in methods if m in primary["method"].unique()]
    df = primary[primary["method"].isin(methods)].copy()
    df["agent_label"] = df["agent_llm"].map(AGENT_LABELS)
    fig, ax = plt.subplots(figsize=(9, 4.5))
    sns.barplot(
        data=df,
        x="agent_label",
        y="mape_pct",
        hue="method",
        hue_order=list(methods),
        ax=ax,
        palette="Set2",
    )
    ax.set_xlabel("Agent LLM")
    ax.set_ylabel("MAPE on $M_{\\mathrm{peak}}$ (%)")
    ax.set_title("Peak VRAM forecast MAPE (test, $z_\\alpha=1.96$)")
    ax.legend(title="Method", loc="upper right")
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)


def plot_fig4_backbone_ablation(ablation: pd.DataFrame, out_path: Path) -> None:
    """Fig 4 — grouped bars: test MAPE per backbone × agent (table in paper/results/tables/)."""
    if ablation.empty:
        fig, ax = plt.subplots(figsize=(7, 3))
        ax.text(
            0.5,
            0.5,
            "Backbone ablation skipped (no proxy checkpoints in this run)",
            ha="center",
            va="center",
            transform=ax.transAxes,
        )
        ax.axis("off")
        fig.tight_layout()
        fig.savefig(out_path)
        plt.close(fig)
        return
    df = ablation.copy()
    df["agent_label"] = df["agent_llm"].map(AGENT_LABELS)
    df["backbone_label"] = df["backbone"].map(BACKBONE_LABELS).fillna(df["backbone"])
    fig, axes = plt.subplots(1, 3, figsize=(12, 4))
    metrics = [
        ("mape_pct", "MAPE (%)"),
        ("undercoverage_rate", "Undercov. rate"),
        ("oaw_pct_ceiling", "OAW (% ceiling)"),
    ]
    for ax, (col, ylab) in zip(axes, metrics):
        sns.barplot(
            data=df,
            x="agent_label",
            y=col,
            hue="backbone_label",
            ax=ax,
            palette="muted",
        )
        ax.set_xlabel("Agent LLM")
        ax.set_ylabel(ylab)
        ax.tick_params(axis="x", rotation=15)
    axes[0].set_title("Backbone ablation (test set, $z_\\alpha=1.96$)")
    handles, labels = axes[-1].get_legend_handles_labels()
    fig.legend(handles, labels, title="Backbone", loc="upper center", ncol=3, bbox_to_anchor=(0.5, 1.08))
    for ax in axes:
        ax.get_legend().remove()
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)


def plot_fig5_subcomponent_scatter(subcomponents: pd.DataFrame, out_path: Path) -> None:
    """Fig 5 — scatter: N_true vs N_hat and E_true vs E_hat."""
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))
    pairs = [("y_n", "n_hat", "$N$ true", "$\\hat{N}$"), ("y_e", "e_hat", "$E$ true", "$\\hat{E}$")]
    for ax, (xcol, ycol, xlab, ylab) in zip(axes, pairs):
        valid = subcomponents[[xcol, ycol]].dropna()
        ax.scatter(valid[xcol], valid[ycol], alpha=0.35, s=18, edgecolors="none")
        lo = float(min(valid[xcol].min(), valid[ycol].min()))
        hi = float(max(valid[xcol].max(), valid[ycol].max()))
        ax.plot([lo, hi], [lo, hi], "k--", linewidth=1, label="y = x")
        ax.set_xlabel(xlab)
        ax.set_ylabel(ylab)
        ax.set_title(f"{ylab} vs {xlab}")
        ax.legend(loc="upper left", fontsize=8)
    fig.suptitle("Sub-component regression (test set, all agents)", y=1.02)
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)


def plot_fig6_cross_model(cross: pd.DataFrame, out_path: Path) -> None:
    """Fig 6 — Qwen-trained proxy evaluated on each agent test split."""
    if cross.empty:
        fig, ax = plt.subplots(figsize=(7, 3))
        ax.text(
            0.5,
            0.5,
            "Cross-model generalization skipped (no proxy checkpoints in this run)",
            ha="center",
            va="center",
            transform=ax.transAxes,
        )
        ax.axis("off")
        fig.tight_layout()
        fig.savefig(out_path)
        plt.close(fig)
        return
    df = cross.copy()
    df["eval_label"] = df["eval_agent_llm"].map(AGENT_LABELS)
    df["domain"] = df["in_domain"].map({True: "in-domain", False: "out-of-domain"})
    fig, ax = plt.subplots(figsize=(7, 4.5))
    sns.barplot(
        data=df,
        x="eval_label",
        y="mape_pct",
        hue="domain",
        ax=ax,
        palette={"in-domain": "#2ca02c", "out-of-domain": "#d62728"},
    )
    ax.set_xlabel("Evaluation agent (test split)")
    ax.set_ylabel("MAPE on $M_{\\mathrm{peak}}$ (%)")
    train_agent = str(df["train_agent_llm"].iloc[0]) if not df.empty else "qwen"
    backbone = str(df["proxy_backbone"].iloc[0]) if not df.empty else ""
    ax.set_title(
        f"Cross-model generalization\n"
        f"(proxy trained on {AGENT_LABELS.get(train_agent, train_agent)}, "
        f"backbone={BACKBONE_LABELS.get(backbone, backbone)})"
    )
    ax.legend(title="")
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)


def ensure_derived_metrics(
    layout: ResultsLayout,
    repo_root: Path,
    *,
    device: torch.device,
    recompute: bool = False,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Compute backbone ablation and cross-model tables if missing or recompute=True."""
    has_proxies = proxies_available(repo_root)
    if not has_proxies:
        ablation = pd.DataFrame()
        cross = pd.DataFrame()
        if not layout.backbone_ablation_test.is_file():
            ablation.to_parquet(layout.backbone_ablation_test, index=False)
        if not layout.cross_model_generalization.is_file():
            cross.to_parquet(layout.cross_model_generalization, index=False)
        return ablation, cross
    if recompute or not layout.backbone_ablation_test.is_file():
        ablation = build_backbone_ablation_test_table(repo_root, device=device)
        ablation.to_parquet(layout.backbone_ablation_test, index=False)
    else:
        ablation = ensure_oaw_pct_ceiling(pd.read_parquet(layout.backbone_ablation_test))
    if recompute or not layout.cross_model_generalization.is_file():
        cross = build_cross_model_generalization_table(repo_root, device=device)
        cross.to_parquet(layout.cross_model_generalization, index=False)
    else:
        cross = pd.read_parquet(layout.cross_model_generalization)
    if not ablation.empty:
        layout.table_backbone_ablation.write_text(render_backbone_ablation_tex(ablation), encoding="utf-8")
    return ablation, cross


def generate_all_figures(
    layout: ResultsLayout,
    repo_root: Path,
    *,
    dpi: int = 300,
    device: torch.device | None = None,
    recompute_metrics: bool = False,
) -> List[Path]:
    """
    Render all six §7.2 figures into paper/figures/.

    Reads canonical metrics from paper/results/metrics/; computes fig 4/6 tables if needed.
    """
    _apply_style()
    layout.ensure_dirs()
    if not layout.primary_test.is_file():
        raise FileNotFoundError(f"Missing {layout.primary_test} — run `make evaluate` first.")
    dev = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
    primary = ensure_oaw_pct_ceiling(pd.read_parquet(layout.primary_test))
    z_sweep = ensure_oaw_pct_ceiling(pd.read_parquet(layout.z_alpha_sweep))
    subcomponents = pd.read_parquet(layout.subcomponents_test)
    trajectory = pd.read_parquet(layout.trajectory_test)
    ablation, cross = ensure_derived_metrics(
        layout, repo_root, device=dev, recompute=recompute_metrics
    )
    representatives = select_representative_prompts(repo_root)
    reps_path = layout.metrics_dir / "fig1_representative_prompts.json"
    reps_path.write_text(
        json.dumps(representatives.to_dict(orient="records"), indent=2) + "\n",
        encoding="utf-8",
    )
    plt.rcParams["savefig.dpi"] = dpi
    writers = [
        lambda p: plot_fig1_vram_trajectory(trajectory, representatives, p),
        lambda p: plot_fig2_oom_oaw_pareto(z_sweep, p),
        lambda p: plot_fig3_mape_bar(primary, p),
        lambda p: plot_fig4_backbone_ablation(ablation, p),
        lambda p: plot_fig5_subcomponent_scatter(subcomponents, p),
        lambda p: plot_fig6_cross_model(cross, p),
    ]
    written: List[Path] = []
    for name, writer in zip(FIGURE_NAMES, writers):
        out = layout.figures_dir / name
        writer(out)
        written.append(out)
    write_manifest(layout, repo_root=repo_root, extra={"figures": [str(p) for p in written]})
    return written
