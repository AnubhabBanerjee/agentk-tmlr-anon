"""
optional figures supporting paper/analyses/*.md.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

from src.eval.correctness_joint import load_joint_analysis_frame

AGENT_LABELS = {
    "qwen2.5-coder-7b": "Qwen-7B",
    "qwen2.5-coder-14b": "Qwen-14B",
    "phi-4-mini": "Phi",
    "mistral-7b-instruct-v0.3": "Mistral",
}

METHOD_STYLE = {
    "B4": ("#2ca02c", "o"),
    "B2": ("#2ca02c", "o"),
    "B0": ("#1f77b4", "s"),
}


def _style() -> None:
    sns.set_theme(style="whitegrid", context="paper", font_scale=1.0)


def plot_joint_distribution(repo_root: Path, out_path: Path) -> None:
    """Two-panel strip/scatter: M_peak vs compile_success and numerical_correct."""
    _style()
    frame = load_joint_analysis_frame(repo_root)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    agents = list(frame["agent_llm"].unique())
    palette = sns.color_palette("tab10", n_colors=len(agents))
    for i, agent in enumerate(agents):
        sub = frame[frame["agent_llm"] == agent]
        jitter_y = sub["compile_success"].astype(float) + np.random.default_rng(42).normal(
            0, 0.04, size=len(sub)
        )
        axes[0].scatter(
            sub["M_peak_true"],
            jitter_y,
            alpha=0.35,
            s=12,
            color=palette[i],
            label=AGENT_LABELS.get(agent, agent),
        )
    axes[0].set_xlabel("$M_{peak}$ true (MiB)")
    axes[0].set_ylabel("compile_success (jittered)")
    axes[0].set_yticks([0, 1])
    axes[0].set_title("All prompts")
    kb = frame[frame["prompt_source"] == "kernelbench"].copy()
    kb = kb[kb["numerical_correct_kbench"].notna()]
    if not kb.empty:
        for i, agent in enumerate(agents):
            sub = kb[kb["agent_llm"] == agent]
            if sub.empty:
                continue
            jitter_y = sub["numerical_correct_kbench"].astype(float) + np.random.default_rng(
                43
            ).normal(0, 0.04, size=len(sub))
            axes[1].scatter(
                sub["M_peak_true"],
                jitter_y,
                alpha=0.6,
                s=20,
                color=palette[i],
                label=AGENT_LABELS.get(agent, agent),
            )
    axes[1].set_xlabel("$M_{peak}$ true (MiB)")
    axes[1].set_ylabel("numerical_correct_kbench (jittered)")
    axes[1].set_yticks([0, 1])
    axes[1].set_title("KernelBench (labeled rows)")
    if kb.empty:
        axes[1].text(
            0.5,
            0.5,
            "No KernelBench rows reached numerical comparison\n(compile-success axis used in §7.3.b/c)",
            ha="center",
            va="center",
            transform=axes[1].transAxes,
            fontsize=9,
        )
    handles, labels = axes[0].get_legend_handles_labels()
    legend = fig.legend(
        handles,
        labels,
        loc="upper center",
        ncol=len(handles),
        bbox_to_anchor=(0.5, 1.0),
        frameon=True,
        fontsize=9,
    )
    legend.get_frame().set_edgecolor("black")
    legend.get_frame().set_linewidth(0.8)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)


def plot_cost_quality_pareto(pareto: pd.DataFrame, out_path: Path) -> None:
    """Throughput vs correctness across budgets; empirical vs analytical per agent."""
    _style()
    agents = list(pareto["agent_llm"].unique())
    methods = list(pareto["method"].unique())
    corr_col = str(pareto["correctness_column"].iloc[0]) if "correctness_column" in pareto.columns else "compile_success"
    fig, axes = plt.subplots(1, len(agents), figsize=(3.5 * len(agents), 4), sharey=True)
    if len(agents) == 1:
        axes = [axes]
    for ax, agent in zip(axes, agents):
        sub = pareto[pareto["agent_llm"] == agent]
        for method in methods:
            color, marker = METHOD_STYLE.get(method, ("#555555", "o"))
            m = sub[sub["method"] == method].sort_values("budget_gb")
            if m.empty:
                continue
            ax.plot(
                m["throughput"],
                m["correctness_rate"],
                f"{marker}-",
                color=color,
                label=method,
                markersize=6,
            )
            for _, row in m.iterrows():
                ax.annotate(
                    f"{int(row['budget_gb'])}G",
                    (row["throughput"], row["correctness_rate"]),
                    fontsize=7,
                    alpha=0.8,
                )
        ax.set_xlabel("Throughput (fraction admitted)")
        ax.set_title(AGENT_LABELS.get(str(agent), agent))
        ax.set_xlim(-0.05, 1.05)
        ax.set_ylim(-0.05, 1.05)
    axes[0].set_ylabel(f"Correctness rate ({corr_col})")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=2, bbox_to_anchor=(0.5, 1.08))
    fig.suptitle("§7.3.c — Cost–quality Pareto (test)", y=1.12)
    fig.tight_layout()
    fig.savefig(out_path)
    plt.close(fig)


def write_analyses_figures(
    repo_root: Path,
    pareto: pd.DataFrame,
    figures_dir: Path,
) -> list[Path]:
    """Render optional PDFs referenced from paper/analyses/*.md."""
    figures_dir.mkdir(parents=True, exist_ok=True)
    paths = [
        figures_dir / "fig7a_vram_correctness_joint.pdf",
        figures_dir / "fig7c_cost_quality_pareto.pdf",
    ]
    plot_joint_distribution(repo_root, paths[0])
    plot_cost_quality_pareto(pareto, paths[1])
    return paths


def plot_residual_histograms(frame: pd.DataFrame, out_path: Path) -> Path:
    """
    Per-agent histogram of demeaned M_peak_true_mb (ANOVA residual proxy).

    Used in appendix_variance.tex to visualize unexplained within-agent variance.
    """
    _style()
    agents = sorted(frame["agent_llm"].unique())
    n_agents = len(agents)
    ncols = 2
    nrows = int(np.ceil(n_agents / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(7.0, 3.2 * nrows))
    axes_flat = np.atleast_1d(axes).ravel()
    for ax, agent in zip(axes_flat, agents):
        sub = frame[frame["agent_llm"] == agent]
        y = sub["M_peak_true_mb"].to_numpy(dtype=np.float64)
        resid = y - float(np.mean(y))
        # CV is computed first so it can be folded directly into the
        # per-panel title (in place of the separate top-of-figure suptitle,
        # which PDF viewers were clipping at the page boundary).
        cv_pct = 100.0 * float(np.std(resid, ddof=1)) / float(np.mean(y)) if np.mean(y) else 0.0
        ax.hist(resid, bins=30, color="#4c72b0", alpha=0.85, edgecolor="white")
        ax.set_title(f"{AGENT_LABELS.get(str(agent), agent)} (CV = {cv_pct:.1f}%)", fontsize=10)
        ax.set_xlabel("MiB $-$ agent mean")
        ax.set_ylabel("Count")
    for ax in axes_flat[n_agents:]:
        ax.set_visible(False)
    fig.tight_layout()
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path)
    plt.close(fig)
    return out_path
