"""Shared helpers for baseline predictors."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional

import pandas as pd

from src.forecast.q4_km_accounting import (
    agentic_context_length_tokens,
    load_model_calibration,
    m_vram_mb,
    peak_context_length_tokens,
)
from src.proxy.constants import PROXY_NODE_TYPES
from src.proxy.data import AGENT_LABEL_FILES, load_prompt_text_map, _parse_json_field
from src.pipeline.tracing_paths import TracingPaths, tracing_paths_from_env

AGENT_LLMS: List[str] = list(AGENT_LABEL_FILES.keys())
BASELINE_METHODS: List[str] = ["B0", "B1", "B2", "B3", "B4", "B5"]
DEFAULT_Z_ALPHA: float = 1.96


def load_baseline_frame(
    *,
    repo_root: Path,
    agent_llm: str,
    paths: Optional[TracingPaths] = None,
) -> pd.DataFrame:
    """Join labels, trace index metadata, and prompt text for one agent LLM."""
    if agent_llm not in AGENT_LABEL_FILES:
        raise KeyError(f"Unknown agent_llm={agent_llm!r}")
    layout = paths or tracing_paths_from_env(repo_root=repo_root)
    shard = AGENT_LABEL_FILES[agent_llm]
    labels = pd.read_parquet(layout.labels_dir / f"{shard}.parquet")
    index_cols = [
        "prompt_id",
        "trace_jsonl",
        "closed_form_accounting_json",
        "n_ctx",
        "N_true",
        "N_nodes_true",
        "E_true",
        "L_peak_tokens",
    ]
    for node in PROXY_NODE_TYPES:
        index_cols.append(f"t_{node}_executed")
        index_cols.append(f"t_{node}_avg_tokens_out")
    index = pd.read_parquet(layout.index_path)
    index = index[index["agent_llm"] == agent_llm][index_cols]
    prompts = load_prompt_text_map(repo_root, prompts_path=layout.prompts_jsonl)
    join_cols = (
        ["trace_jsonl"]
        if "trace_jsonl" in labels.columns and "trace_jsonl" in index.columns
        else ["prompt_id"]
    )
    merged = labels.merge(index, on=join_cols, how="left", suffixes=("", "_idx"))
    merged["user_goal"] = merged["prompt_id"].map(prompts)
    if merged["user_goal"].isna().any():
        raise RuntimeError("Some label rows are missing prompt text in all.jsonl")
    return merged


def accounting_dict(
    row: pd.Series,
    *,
    agent_llm: Optional[str] = None,
    calibration_path: Optional[Path] = None,
) -> Dict[str, Any]:
    """Parse closed-form accounting JSON for one merged baseline row.

    Trace rows embed ``closed_form_accounting_json`` written at collection time
  with an empty calibration dict, so stored ``M_weights_reported_mb`` /
  ``M_act_mb`` may reflect on-disk GGUF size and zero activation overhead
  rather than live-GPU measurements. When
    *agent_llm* and *calibration_path* are supplied (and the file exists),
    the authoritative post-hoc measurement overrides those two fields
    (and ``runtime_overhead_mb``) here, at read time, rather than trusting
    the stale embedded JSON. The calibration reference measurements
    themselves come from the *train* split only (verified per model), so
    this correction introduces no test-set leakage.
    """
    acc = _parse_json_field(row.get("closed_form_accounting_json"))
    if not acc:
        raise ValueError(f"Missing accounting for prompt_id={row['prompt_id']}")
    acc = dict(acc)
    if agent_llm is not None and calibration_path is not None and calibration_path.is_file():
        calibration = load_model_calibration(
            calibration_path,
            agent_llm,
            cache_type_k=str(acc.get("cache_type_k", "f16")),
            cache_type_v=str(acc.get("cache_type_v", "f16")),
        )
        for key in ("M_weights_reported_mb", "M_act_mb", "runtime_overhead_mb"):
            if key in calibration:
                acc[key] = calibration[key]
    return acc


def true_expected_tool_tokens(row: pd.Series) -> float:
    """Sum per-node avg completion tokens (F3 oracle tool term for B5)."""
    total = 0.0
    for node in PROXY_NODE_TYPES:
        total += float(row.get(f"y_T_{node}_avg_tokens", 0.0) or 0.0)
    return total


def closed_form_peak_scalar(
    *,
    n_steps: float,
    e_hat: float,
    l_base: float,
    expected_tool_tokens: float,
    accounting: Mapping[str, Any],
    n_is_total_completion_tokens: bool = True,
) -> float:
    """Scalar closed-form peak VRAM for B4/B5-style baselines."""
    if n_is_total_completion_tokens:
        l_peak = peak_context_length_tokens(
            l_base=float(l_base),
            total_completion_tokens=float(n_steps),
            expected_tool_tokens=float(expected_tool_tokens),
        )
    else:
        n_i = max(1.0, float(n_steps))
        l_peak = agentic_context_length_tokens(
            step_index=int(round(n_i)),
            n_steps=int(round(n_i)),
            l_base=float(l_base),
            e_hat=float(e_hat),
            expected_tool_tokens=float(expected_tool_tokens),
        )
    return float(
        m_vram_mb(
            context_length_tokens=l_peak,
            m_weights_mb=float(accounting["M_weights_reported_mb"]),
            m_act_mb=float(accounting["M_act_mb"]),
            n_layers=int(accounting["n_layers"]),
            n_kv_heads=int(accounting["n_kv_heads"]),
            d_head=int(accounting["d_head"]),
            b_precision=float(accounting["b_precision"]),
        )
    )


def max_context_peak_scalar(*, n_ctx: int, accounting: Mapping[str, Any]) -> float:
    """B0 worst-case peak: M_weights + M_KV(L=n_ctx) + M_act."""
    return float(
        m_vram_mb(
            context_length_tokens=float(n_ctx),
            m_weights_mb=float(accounting["M_weights_reported_mb"]),
            m_act_mb=float(accounting["M_act_mb"]),
            n_layers=int(accounting["n_layers"]),
            n_kv_heads=int(accounting["n_kv_heads"]),
            d_head=int(accounting["d_head"]),
            b_precision=float(accounting["b_precision"]),
        )
    )


def write_predictions_parquet(
    *,
    repo_root: Path,
    agent_llm: str,
    method: str,
    rows: List[Dict[str, Any]],
    split: str = "test",
    paths: Optional[TracingPaths] = None,
) -> Path:
    """Write {split}.parquet predictions for one (agent, method)."""
    layout = paths or tracing_paths_from_env(repo_root=repo_root)
    out_dir = layout.predictions_root / agent_llm / method
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{split}.parquet"
    df = pd.DataFrame(rows)
    required = {"prompt_id", "Mpeak_pred", "Mupper_pred"}
    if not required.issubset(df.columns):
        missing = required - set(df.columns)
        raise ValueError(f"Prediction rows missing columns: {missing}")
    df.to_parquet(out_path, index=False)
    return out_path


def split_frame(frame: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Return train, val, test partitions from the split column."""
    train = frame[frame["split"] == "train"].reset_index(drop=True)
    val = frame[frame["split"] == "val"].reset_index(drop=True)
    test = frame[frame["split"] == "test"].reset_index(drop=True)
    return train, val, test
