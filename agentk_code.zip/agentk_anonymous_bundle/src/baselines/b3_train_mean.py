"""
Phase 6 — B3 training-set mean baseline (guide §6).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List

import numpy as np

from src.baselines.common import load_baseline_frame, split_frame, write_predictions_parquet


def predict_b3(
    *,
    repo_root: Path,
    agent_llm: str,
    z_alpha: float = 1.96,
) -> Path:
    """B3: constant train mean; upper = mean + z * train residual std."""
    frame = load_baseline_frame(repo_root=repo_root, agent_llm=agent_llm)
    train, _val, test = split_frame(frame)
    y_train = train["y_Mpeak"].to_numpy(dtype=np.float64)
    mean_y = float(np.mean(y_train))
    sigma = float(np.std(y_train - mean_y))
    rows: List[Dict[str, Any]] = []
    for _, row in test.iterrows():
        rows.append(
            {
                "prompt_id": str(row["prompt_id"]),
                "agent_llm": agent_llm,
                "Mpeak_pred": mean_y,
                "Mupper_pred": mean_y + float(z_alpha) * sigma,
            }
        )
    return write_predictions_parquet(
        repo_root=repo_root,
        agent_llm=agent_llm,
        method="B3",
        rows=rows,
    )
