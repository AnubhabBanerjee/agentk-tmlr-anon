"""
Phase 6 — B4 multi-task proxy + closed-form baseline (guide §6).
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import torch
from safetensors.torch import load_file

from src.baselines.common import (
    accounting_dict,
    load_baseline_frame,
    split_frame,
    write_predictions_parquet,
)
from src.proxy.config import load_proxy_training_config
from src.proxy.data import compute_tool_mu_tokens
from src.proxy.peak_mlp import load_peak_mlp_if_present, peaks_from_proxy_outputs
from src.proxy.metrics import compute_l_base_batch
from src.proxy.model import build_multitask_proxy

PROXY_BACKBONES = ("minilm-l12", "deberta-v3-base", "unixcoder")


def _best_proxy_backbone(repo_root: Path, agent_llm: str) -> str:
  """Pick proxy backbone with lowest val_mape from Phase 5 metrics.json files."""
  best_id = PROXY_BACKBONES[0]
  best_mape = float("inf")
  for backbone_id in PROXY_BACKBONES:
    metrics_path = repo_root / "artifacts" / "proxies" / agent_llm / backbone_id / "metrics.json"
    if not metrics_path.is_file():
      continue
    metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
    val_mape = float(metrics["val_mape"])
    if val_mape < best_mape:
      best_mape = val_mape
      best_id = backbone_id
  return best_id


def predict_b4(
  *,
  repo_root: Path,
  agent_llm: str,
  backbone_id: Optional[str] = None,
  device: Optional[torch.device] = None,
) -> Path:
  """B4: trained proxy → (λ, p, Ê) → learned peak MLP (G3) or closed-form prior."""
  if device is None:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
  cfg = load_proxy_training_config(repo_root=repo_root)
  chosen = backbone_id or _best_proxy_backbone(repo_root, agent_llm)
  weights_path = repo_root / "artifacts" / "proxies" / agent_llm / chosen / "model.safetensors"
  if not weights_path.is_file():
    raise FileNotFoundError(f"Missing Phase 5 proxy weights: {weights_path}")
  frame = load_baseline_frame(repo_root=repo_root, agent_llm=agent_llm)
  train, _val, test = split_frame(frame)
  tool_mu = compute_tool_mu_tokens(train)
  model, tokenizer, spec = build_multitask_proxy(
    repo_root=repo_root,
    backbone_id=chosen,
    enable_variance_head=True,
    enable_stretch_heads=False,
  )
  state = load_file(str(weights_path))
  model.load_state_dict(state, strict=True)
  model = model.to(device)
  model.eval()
  peak_mlp = load_peak_mlp_if_present(
    repo_root, agent_llm, chosen, device=device
  )
  rows: List[Dict[str, Any]] = []
  goals = test["user_goal"].tolist()
  accounting_rows = [accounting_dict(row) for _, row in test.iterrows()]
  batch = model.encode_texts(goals, tokenizer=tokenizer, max_length=spec.max_seq_length, device=device)
  with torch.no_grad():
    outputs = model.forward(**batch)
    l_base = compute_l_base_batch(goals, tokenizer, max_length=spec.max_seq_length, device=device)
    m_peak, m_upper = peaks_from_proxy_outputs(
      outputs,
      l_base=l_base,
      accounting_rows=accounting_rows,
      tool_mu_tokens=tool_mu,
      z_alpha=cfg.z_alpha,
      peak_mlp=peak_mlp,
    )
  for i, (_, row) in enumerate(test.iterrows()):
    rows.append(
      {
        "prompt_id": str(row["prompt_id"]),
        "agent_llm": agent_llm,
        "Mpeak_pred": float(m_peak[i].item()),
        "Mupper_pred": float(m_upper[i].item()),
        "proxy_backbone": chosen,
        "peak_forecaster": "learned_mlp" if peak_mlp is not None else "closed_form",
      }
    )
  return write_predictions_parquet(
    repo_root=repo_root,
    agent_llm=agent_llm,
    method="B4",
    rows=rows,
  )
