"""B5 partially oracle-fed closed-form baseline.

Feeds the step-interpolated closed form the true node count, true non-tool
completion-token rate E, and L_base from the run's runtime tokenizer. The
tool-return term is set to zero because traces do not record external tool
payloads separately from completion tokens.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List

from src.baselines.common import (
  accounting_dict,
  closed_form_peak_scalar,
  load_baseline_frame,
  split_frame,
  write_predictions_parquet,
)
from src.pipeline.tracing_paths import tracing_paths_from_env


def predict_b5(
  *,
  repo_root: Path,
  agent_llm: str,
  z_alpha: float = 1.96,
) -> Path:
  """
  B5: feed true (N_nodes, E) into the step-interpolated closed form, with the
  exact runtime L_base reconstructed from already-logged trace fields.

  ``z_alpha`` is accepted only so this function's call signature matches the
  other baselines dispatched from ``runner.py``; it is NOT used to inflate
  ``Mupper_pred``. Unlike B1/B2/B3, B5 has no fitted residual-std term to
  scale by z_alpha (there is no training step here at all — every input is
  either a measured calibration constant or a ground-truth trace field), so
  ``Mupper_pred`` is set equal to the point prediction ``Mpeak_pred``. Do not
  reinterpret B5's ``undercoverage_rate`` in Table 2 as a 95%-style interval
  statistic: for this baseline it is exactly Pr(M_true > Mpeak_pred), i.e. how
  often the point forecast itself undershoots (see §5.1/Table 2 caption).

  - N (n_steps): true node-execution count, y_N_nodes (ground truth).
  - E (e_hat): true non-tool completion tokens per node, y_E. y_E is exactly
    this quantity already: N_true (=total tokens_completion across node
    events; see src/tracing/n_labels.py) never includes tool-return content
    in the first place, because tool-return text becomes the *next* node's
    prompt tokens, not any node's completion tokens. So y_E needs no
    adjustment to satisfy the "non-tool completion tokens" definition.
  - L_base: reconstructed as L_peak_tokens - N_true. At trace time,
    enrich_labels_with_closed_form() (src/tracing/agentk_trace.py) set
    L_peak_tokens = l_base + n_steps*e_hat with l_base taken directly from
    node_events[0].tokens_in — the real GGUF/llama.cpp runtime tokenizer's
    count for the actual formatted first prompt. Subtracting N_true (which
    equals n_steps*e_hat up to E_true's stored 6-decimal rounding) exactly
    recovers that same runtime-tokenizer l_base, with no separate tokenizer
    call and no "equivalent model family" approximation.
  - Tool term: fed as 0.0, NOT oracle-fed. The dataset's only tool-shaped
    field (T_true / y_T_*_avg_tokens) is documented in the trace schema
    itself as "avg_completion_tokens_per_node" (t_true_semantics in
    agentk_trace.py) — i.e. it is per-node completion-token telemetry, not a
    record of observed external tool-return content (RAG passage size,
    compiler diagnostic size). No ground-truth tool-return token total
    exists anywhere in this dataset, so B5 cannot fully oracle-feed Eq. 1's
    tool term; it is reported as "partially oracle-fed" for this reason
    (see §method-baselines-note, §limitations).
  """
  frame = load_baseline_frame(repo_root=repo_root, agent_llm=agent_llm)
  _train, _val, test = split_frame(frame)
  calibration_path = tracing_paths_from_env(repo_root=repo_root).calibration_path
  rows: List[Dict[str, Any]] = []
  for _, row in test.iterrows():
    acc = accounting_dict(row, agent_llm=agent_llm, calibration_path=calibration_path)
    n_nodes_true = float(row["y_N_nodes"])
    e_true = float(row["y_E"])
    n_true = float(row["N_true"])
    l_peak_tokens = float(row["L_peak_tokens"])
    l_base = max(0.0, l_peak_tokens - n_true)
    peak = closed_form_peak_scalar(
      n_steps=n_nodes_true,
      e_hat=e_true,
      l_base=l_base,
      expected_tool_tokens=0.0,
      accounting=acc,
      n_is_total_completion_tokens=False,
    )
    # No fitted residual std exists for this baseline (see docstring), so the
    # "upper bound" is the point prediction itself, not a z_alpha-scaled interval.
    upper = peak
    rows.append(
      {
        "prompt_id": str(row["prompt_id"]),
        "agent_llm": agent_llm,
        "Mpeak_pred": peak,
        "Mupper_pred": upper,
      }
    )
  return write_predictions_parquet(
    repo_root=repo_root,
    agent_llm=agent_llm,
    method="B5",
    rows=rows,
  )
