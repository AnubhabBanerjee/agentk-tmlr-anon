"""
Phase 6 — B5 oracle closed-form baseline (guide §6).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List

from transformers import PreTrainedTokenizerBase

from src.baselines.common import (
    accounting_dict,
    closed_form_peak_scalar,
    load_baseline_frame,
    split_frame,
    true_expected_tool_tokens,
    write_predictions_parquet,
)
from src.proxy.backbone import load_proxy_backbone_and_tokenizer, load_proxy_backbone_spec
from src.proxy.input_format import format_proxy_input


def _l_base_scalar(text: str, tokenizer: PreTrainedTokenizerBase, *, max_length: int) -> float:
  """Token length of formatted proxy input for one user goal."""
  encoded = tokenizer(
    format_proxy_input(user_goal=text),
    truncation=True,
    max_length=max_length,
    return_tensors=None,
  )
  return float(len(encoded["input_ids"]))


def predict_b5(
  *,
  repo_root: Path,
  agent_llm: str,
  z_alpha: float = 1.96,
) -> Path:
  """B5: feed true (N, T, E) into closed form; upper uses N + z*0 (oracle, no σ)."""
  frame = load_baseline_frame(repo_root=repo_root, agent_llm=agent_llm)
  _train, _val, test = split_frame(frame)
  spec = load_proxy_backbone_spec(repo_root=repo_root, backbone_id="minilm-l12")
  _model, tokenizer = load_proxy_backbone_and_tokenizer(spec=spec)
  rows: List[Dict[str, Any]] = []
  for _, row in test.iterrows():
    acc = accounting_dict(row)
    n_true = float(row["y_N"])
    e_true = float(row["y_E"])
    l_base = _l_base_scalar(str(row["user_goal"]), tokenizer, max_length=spec.max_seq_length)
    tool_tokens = true_expected_tool_tokens(row)
    peak = closed_form_peak_scalar(
      n_steps=n_true,
      e_hat=e_true,
      l_base=l_base,
      expected_tool_tokens=tool_tokens,
      accounting=acc,
    )
    upper = closed_form_peak_scalar(
      n_steps=n_true + float(z_alpha) * 0.0,
      e_hat=e_true,
      l_base=l_base,
      expected_tool_tokens=tool_tokens,
      accounting=acc,
    )
    rows.append(
      {
        "prompt_id": str(row["prompt_id"]),
        "agent_llm": agent_llm,
        "Mpeak_pred": peak,
        "Mupper_pred": upper,
      }
    )
  return write_predictions_parquet(
    repo_root=repo_root,
    agent_llm=agent_llm,
    method="B5",
    rows=rows,
  )
