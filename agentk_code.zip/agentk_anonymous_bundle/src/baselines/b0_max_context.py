"""
Phase 6 — B0 max-context worst-case baseline (guide §6).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List

import pandas as pd

from src.baselines.common import (
    accounting_dict,
    load_baseline_frame,
    max_context_peak_scalar,
    split_frame,
    write_predictions_parquet,
)


def predict_b0(
    *,
    repo_root: Path,
    agent_llm: str,
) -> Path:
    """B0: M_peak_pred = M_weights + M_KV(L=n_ctx) + M_act; upper = pred."""
    frame = load_baseline_frame(repo_root=repo_root, agent_llm=agent_llm)
    _train, _val, test = split_frame(frame)
    rows: List[Dict[str, Any]] = []
    for _, row in test.iterrows():
        acc = accounting_dict(row)
        peak = max_context_peak_scalar(n_ctx=int(row["n_ctx"]), accounting=acc)
        rows.append(
            {
                "prompt_id": str(row["prompt_id"]),
                "agent_llm": agent_llm,
                "Mpeak_pred": peak,
                "Mupper_pred": peak,
            }
        )
    return write_predictions_parquet(
        repo_root=repo_root,
        agent_llm=agent_llm,
        method="B0",
        rows=rows,
    )
