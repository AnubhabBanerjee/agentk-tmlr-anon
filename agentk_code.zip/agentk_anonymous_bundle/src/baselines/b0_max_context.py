"""B0 max-context worst-case baseline."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List

import pandas as pd

from src.baselines.common import (
    accounting_dict,
    load_baseline_frame,
    max_context_peak_scalar,
    split_frame,
    write_predictions_parquet,
)
from src.pipeline.tracing_paths import tracing_paths_from_env


def predict_b0(
    *,
    repo_root: Path,
    agent_llm: str,
) -> Path:
    """B0: M_peak_pred = M_weights + M_KV(L=n_ctx) + M_act; upper = pred.

    B0 has no fitted residual-std term either (worst-case n_ctx point
    estimate, no training step), so ``Mupper_pred`` is the point prediction
    itself, exactly like B5. Table 2's ``undercoverage_rate`` for B0 is
    Pr(M_true > Mpeak_pred), not a z_alpha-scaled interval statistic — see
    §5.1/Table 2 caption in the paper.
    """
    frame = load_baseline_frame(repo_root=repo_root, agent_llm=agent_llm)
    _train, _val, test = split_frame(frame)
    calibration_path = tracing_paths_from_env(repo_root=repo_root).calibration_path
    rows: List[Dict[str, Any]] = []
    for _, row in test.iterrows():
        acc = accounting_dict(row, agent_llm=agent_llm, calibration_path=calibration_path)
        peak = max_context_peak_scalar(n_ctx=int(row["n_ctx"]), accounting=acc)
        rows.append(
            {
                "prompt_id": str(row["prompt_id"]),
                "agent_llm": agent_llm,
                "Mpeak_pred": peak,
                "Mupper_pred": peak,
            }
        )
    return write_predictions_parquet(
        repo_root=repo_root,
        agent_llm=agent_llm,
        method="B0",
        rows=rows,
    )
