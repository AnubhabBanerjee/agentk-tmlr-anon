"""
Phase 6 — orchestrate baseline prediction runs (guide §6).
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional

import torch

from src.baselines.b0_max_context import predict_b0
from src.baselines.b1_prompt_lr import predict_b1
from src.baselines.b2_direct_regression import predict_b2
from src.baselines.b3_train_mean import predict_b3
from src.baselines.b4_proxy import predict_b4
from src.baselines.b5_oracle import predict_b5
from src.baselines.common import AGENT_LLMS, BASELINE_METHODS, DEFAULT_Z_ALPHA
from src.pipeline.tracing_paths import TracingPaths, tracing_paths_from_env
from src.proxy.config import load_proxy_training_config

_DISPATCH = {
  "B0": predict_b0,
  "B1": predict_b1,
  "B2": predict_b2,
  "B3": predict_b3,
  "B4": predict_b4,
  "B5": predict_b5,
}


def run_baseline(
  *,
  repo_root: Path,
  agent_llm: str,
  method: str,
  device: Optional[torch.device] = None,
  paths: Optional[TracingPaths] = None,
) -> Path:
  """Run one baseline method for one agent LLM and return test.parquet path."""
  if method not in _DISPATCH:
    raise KeyError(f"Unknown baseline method={method!r}")
  layout = paths or tracing_paths_from_env(repo_root=repo_root)
  cfg = load_proxy_training_config(repo_root=repo_root)
  z_alpha = cfg.z_alpha
  if method == "B0":
    return predict_b0(repo_root=repo_root, agent_llm=agent_llm)
  if method == "B1":
    return predict_b1(repo_root=repo_root, agent_llm=agent_llm, z_alpha=z_alpha)
  if method == "B2":
    return predict_b2(repo_root=repo_root, agent_llm=agent_llm, z_alpha=z_alpha, device=device, paths=layout)
  if method == "B3":
    return predict_b3(repo_root=repo_root, agent_llm=agent_llm, z_alpha=z_alpha)
  if method == "B4":
    return predict_b4(repo_root=repo_root, agent_llm=agent_llm, device=device)
  if method == "B5":
    return predict_b5(repo_root=repo_root, agent_llm=agent_llm, z_alpha=z_alpha)
  raise AssertionError("unreachable")


def run_all_baselines(
  *,
  repo_root: Path,
  agents: Optional[List[str]] = None,
  methods: Optional[List[str]] = None,
  skip_methods: Optional[List[str]] = None,
  device: Optional[torch.device] = None,
  paths: Optional[TracingPaths] = None,
) -> Dict[str, Dict[str, str]]:
  """Run all requested (agent, method) pairs; return map of output paths."""
  layout = paths or tracing_paths_from_env(repo_root=repo_root)
  agent_list = agents or list(AGENT_LLMS)
  skip = set(skip_methods or [])
  method_list = methods or [m for m in BASELINE_METHODS if m not in skip]
  if device is None:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
  outputs: Dict[str, Dict[str, str]] = {}
  for agent_llm in agent_list:
    outputs[agent_llm] = {}
    for method in method_list:
      out_path = run_baseline(
        repo_root=repo_root,
        agent_llm=agent_llm,
        method=method,
        device=device,
        paths=layout,
      )
      outputs[agent_llm][method] = str(out_path)
  return outputs
