"""
Phase 6 — B2 frozen-encoder direct VRAM regression (guide §6).
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
from safetensors.torch import save_file
from torch.utils.data import DataLoader, Dataset
from transformers import PreTrainedModel, PreTrainedTokenizerBase

from src.baselines.common import (
    load_baseline_frame,
    split_frame,
    tracing_paths_from_env,
    write_predictions_parquet,
)
from src.pipeline.tracing_paths import TracingPaths
from src.proxy.backbone import ProxyBackboneSpec, load_proxy_backbone_and_tokenizer, load_proxy_backbone_spec
from src.proxy.config import ProxyTrainingConfig, load_proxy_training_config
from src.proxy.model import mean_pool_hidden

BACKBONE_IDS: Tuple[str, ...] = ("minilm-l12", "deberta-v3-base", "unixcoder")
# Linear head needs a higher LR than the frozen transformer fine-tuning default (2e-5).
B2_HEAD_LEARNING_RATE: float = 1e-3


class _DirectPeakDataset(Dataset):
    def __init__(self, goals: List[str], targets: List[float]) -> None:
        self.goals = goals
        self.targets = targets

    def __len__(self) -> int:
        return len(self.goals)

    def __getitem__(self, idx: int) -> Tuple[str, float]:
        return self.goals[idx], self.targets[idx]


class DirectPeakRegressor(nn.Module):
    """Frozen encoder + linear head predicting standardised M_peak."""

    def __init__(self, *, backbone: PreTrainedModel, hidden_size: int) -> None:
        super().__init__()
        self.backbone = backbone
        self.head = nn.Linear(hidden_size, 1)
        for param in self.backbone.parameters():
            param.requires_grad = False

    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        hidden = self.backbone(input_ids=input_ids, attention_mask=attention_mask).last_hidden_state
        pooled = mean_pool_hidden(hidden, attention_mask)
        return self.head(pooled).squeeze(-1)


def _encode_batch(
    model: DirectPeakRegressor,
    tokenizer: PreTrainedTokenizerBase,
    texts: List[str],
    *,
    max_length: int,
    device: torch.device,
) -> torch.Tensor:
    encoded = tokenizer(
        texts,
        padding=True,
        truncation=True,
        max_length=max_length,
        return_tensors="pt",
    )
    model.backbone.eval()
    return model(
        encoded["input_ids"].to(device),
        encoded["attention_mask"].to(device),
    )


def _mape(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    denom = np.clip(np.abs(y_true), 1e-6, None)
    return float(np.mean(np.abs(y_true - y_pred) / denom) * 100.0)


def _ape_pct(y_true: float, y_pred: float) -> float:
    denom = max(abs(y_true), 1e-6)
    return float(abs(y_true - y_pred) / denom * 100.0)


def _assert_train_sanity(*, y_true: np.ndarray, y_pred: np.ndarray, agent_llm: str) -> None:
    """Guide §A3: median prediction must be within 10% of median target on train."""
    med_true = float(np.median(y_true))
    med_pred = float(np.median(y_pred))
    rel_err = abs(med_pred - med_true) / max(med_true, 1e-6)
    if rel_err >= 0.10:
        raise AssertionError(
            f"B2 train-set sanity failed for {agent_llm}: "
            f"median(Mpeak_pred)={med_pred:.1f} vs median(Mpeak_true)={med_true:.1f} "
            f"(relative error {100 * rel_err:.1f}% >= 10%)"
        )


@dataclass
class _B2FitResult:
    backbone_id: str
    model: DirectPeakRegressor
    tokenizer: PreTrainedTokenizerBase
    spec: ProxyBackboneSpec
    val_mape: float
    residual_std: float
    y_mean: float
    y_std: float


def _denormalize(pred_norm: np.ndarray, *, y_mean: float, y_std: float) -> np.ndarray:
    return pred_norm * y_std + y_mean


def _train_b2_backbone(
    *,
    repo_root: Path,
    agent_llm: str,
    backbone_id: str,
    train_goals: List[str],
    train_y: List[float],
    val_goals: List[str],
    val_y: List[float],
    cfg: ProxyTrainingConfig,
    device: torch.device,
) -> _B2FitResult:
    y_mean = float(np.mean(train_y))
    y_std = float(np.std(train_y))
    if y_std < 1e-6:
        y_std = 1.0
    train_y_norm = [(y - y_mean) / y_std for y in train_y]
    val_y_norm = [(y - y_mean) / y_std for y in val_y]

    spec = load_proxy_backbone_spec(repo_root=repo_root, backbone_id=backbone_id)
    backbone, tokenizer = load_proxy_backbone_and_tokenizer(spec=spec)
    model = DirectPeakRegressor(backbone=backbone, hidden_size=spec.hidden_size).to(device)
    optimizer = torch.optim.AdamW(
        model.head.parameters(),
        lr=B2_HEAD_LEARNING_RATE,
        weight_decay=cfg.weight_decay,
    )
    train_loader = DataLoader(
        _DirectPeakDataset(train_goals, train_y_norm),
        batch_size=cfg.batch_size,
        shuffle=True,
    )
    best_val = float("inf")
    best_state: Optional[Dict[str, torch.Tensor]] = None
    patience = 0
    for _epoch in range(cfg.max_epochs):
        model.head.train()
        for texts, targets in train_loader:
            preds = _encode_batch(model, tokenizer, list(texts), max_length=spec.max_seq_length, device=device)
            target_t = torch.tensor(targets, dtype=preds.dtype, device=device)
            loss = torch.mean((preds - target_t) ** 2)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
        model.head.eval()
        with torch.no_grad():
            val_pred_norm = _encode_batch(
                model, tokenizer, val_goals, max_length=spec.max_seq_length, device=device
            )
        val_pred = _denormalize(val_pred_norm.detach().cpu().numpy(), y_mean=y_mean, y_std=y_std)
        val_mape = _mape(np.array(val_y), val_pred)
        if val_mape < best_val:
            best_val = val_mape
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            patience = 0
        else:
            patience += 1
            if patience >= cfg.early_stopping_patience:
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    model.head.eval()
    with torch.no_grad():
        val_pred_norm = _encode_batch(model, tokenizer, val_goals, max_length=spec.max_seq_length, device=device)
    val_pred = _denormalize(val_pred_norm.detach().cpu().numpy(), y_mean=y_mean, y_std=y_std)
    train_pred_norm = _encode_batch(model, tokenizer, train_goals, max_length=spec.max_seq_length, device=device)
    train_pred = _denormalize(train_pred_norm.detach().cpu().numpy(), y_mean=y_mean, y_std=y_std)
    _assert_train_sanity(y_true=np.array(train_y), y_pred=train_pred, agent_llm=agent_llm)
    resid = np.array(val_y) - val_pred
    return _B2FitResult(
        backbone_id=backbone_id,
        model=model,
        tokenizer=tokenizer,
        spec=spec,
        val_mape=float(_mape(np.array(val_y), val_pred)),
        residual_std=float(np.std(resid)),
        y_mean=y_mean,
        y_std=y_std,
    )


def _predict_mib(
    fit: _B2FitResult,
    goals: List[str],
    *,
    device: torch.device,
) -> np.ndarray:
    with torch.no_grad():
        pred_norm = _encode_batch(
            fit.model,
            fit.tokenizer,
            goals,
            max_length=fit.spec.max_seq_length,
            device=device,
        )
    return _denormalize(pred_norm.detach().cpu().numpy(), y_mean=fit.y_mean, y_std=fit.y_std)


def predict_b2(
    *,
    repo_root: Path,
    agent_llm: str,
    z_alpha: float = 1.96,
    device: Optional[torch.device] = None,
    paths: Optional[TracingPaths] = None,
) -> Path:
    """B2: train frozen-encoder regressors; pick best backbone on val MAPE."""
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    layout = paths or tracing_paths_from_env(repo_root=repo_root)
    cfg = load_proxy_training_config(repo_root=repo_root)
    frame = load_baseline_frame(repo_root=repo_root, agent_llm=agent_llm, paths=layout)
    train, val, test = split_frame(frame)
    train_goals = train["user_goal"].tolist()
    train_y = train["y_Mpeak"].tolist()
    val_goals = val["user_goal"].tolist()
    val_y = val["y_Mpeak"].tolist()
    fits: List[_B2FitResult] = []
    for backbone_id in BACKBONE_IDS:
        fits.append(
            _train_b2_backbone(
                repo_root=repo_root,
                agent_llm=agent_llm,
                backbone_id=backbone_id,
                train_goals=train_goals,
                train_y=train_y,
                val_goals=val_goals,
                val_y=val_y,
                cfg=cfg,
                device=device,
            )
        )
    best = min(fits, key=lambda item: item.val_mape)
    artifact_dir = layout.baselines_root / agent_llm / "B2"
    artifact_dir.mkdir(parents=True, exist_ok=True)
    save_file(best.model.state_dict(), str(artifact_dir / f"{best.backbone_id}.safetensors"))
    meta = {
        "selected_backbone": best.backbone_id,
        "y_mean": best.y_mean,
        "y_std": best.y_std,
        "val_mape": best.val_mape,
    }
    (artifact_dir / "selected_backbone.txt").write_text(
        f"{best.backbone_id}\ny_mean={best.y_mean}\ny_std={best.y_std}\n",
        encoding="utf-8",
    )
    (artifact_dir / "fit_meta.json").write_text(
        __import__("json").dumps(meta, indent=2) + "\n",
        encoding="utf-8",
    )

    train_preds = _predict_mib(best, train_goals, device=device)
    train_rows: List[Dict[str, Any]] = []
    for i, (_, row) in enumerate(train.iterrows()):
        y_true = float(row["y_Mpeak"])
        pred = float(train_preds[i])
        train_rows.append(
            {
                "prompt_id": str(row["prompt_id"]),
                "agent_llm": agent_llm,
                "Mpeak_true": y_true,
                "Mpeak_pred": pred,
                "Mupper_pred": pred + float(z_alpha) * best.residual_std,
                "ape_pct": _ape_pct(y_true, pred),
                "selected_backbone": best.backbone_id,
            }
        )
    write_predictions_parquet(
        repo_root=repo_root,
        agent_llm=agent_llm,
        method="B2",
        rows=train_rows,
        split="train",
        paths=layout,
    )

    test_preds = _predict_mib(best, test["user_goal"].tolist(), device=device)
    test_rows: List[Dict[str, Any]] = []
    for i, (_, row) in enumerate(test.iterrows()):
        pred = float(test_preds[i])
        test_rows.append(
            {
                "prompt_id": str(row["prompt_id"]),
                "agent_llm": agent_llm,
                "Mpeak_pred": pred,
                "Mupper_pred": pred + float(z_alpha) * best.residual_std,
                "selected_backbone": best.backbone_id,
            }
        )
    return write_predictions_parquet(
        repo_root=repo_root,
        agent_llm=agent_llm,
        method="B2",
        rows=test_rows,
        split="test",
        paths=layout,
    )
