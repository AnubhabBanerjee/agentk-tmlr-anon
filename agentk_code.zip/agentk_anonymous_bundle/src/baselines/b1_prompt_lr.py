"""B1 prompt-length linear regression baseline."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
import pandas as pd
from transformers import PreTrainedTokenizerBase

from src.baselines.common import load_baseline_frame, split_frame, write_predictions_parquet
from src.proxy.backbone import load_proxy_backbone_spec, load_proxy_backbone_and_tokenizer
from src.proxy.input_format import format_proxy_input


def _token_lengths(
    texts: List[str],
    tokenizer: PreTrainedTokenizerBase,
    *,
    max_length: int,
) -> np.ndarray:
    """Tokenized prompt lengths for B1 feature vector."""
    formatted = [format_proxy_input(user_goal=t) for t in texts]
    encoded = tokenizer(
        formatted,
        padding=False,
        truncation=True,
        max_length=max_length,
        return_tensors=None,
    )
    return np.array([len(ids) for ids in encoded["input_ids"]], dtype=np.float64)


def _fit_linear_regression(x: np.ndarray, y: np.ndarray) -> Tuple[float, float, float]:
    """Fit y ~ alpha + beta*x on train; return alpha, beta, residual std."""
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    if x.size < 2:
        mean_y = float(np.mean(y)) if y.size else 0.0
        return mean_y, 0.0, float(np.std(y)) if y.size else 0.0
    beta, alpha = np.polyfit(x, y, deg=1)
    resid = y - (alpha + beta * x)
    sigma = float(np.std(resid))
    return float(alpha), float(beta), sigma


def predict_b1(
    *,
    repo_root: Path,
    agent_llm: str,
    z_alpha: float = 1.96,
) -> Path:
    """B1: Mpeak ~ alpha + beta * len(tokenized_prompt); upper = pred + z*sigma."""
    frame = load_baseline_frame(repo_root=repo_root, agent_llm=agent_llm)
    train, _val, test = split_frame(frame)
    spec = load_proxy_backbone_spec(repo_root=repo_root, backbone_id="minilm-l12")
    _model, tokenizer = load_proxy_backbone_and_tokenizer(spec=spec)
    x_train = _token_lengths(train["user_goal"].tolist(), tokenizer, max_length=spec.max_seq_length)
    y_train = train["y_Mpeak"].to_numpy(dtype=np.float64)
    alpha, beta, sigma = _fit_linear_regression(x_train, y_train)
    x_test = _token_lengths(test["user_goal"].tolist(), tokenizer, max_length=spec.max_seq_length)
    rows: List[Dict[str, Any]] = []
    for i, (_, row) in enumerate(test.iterrows()):
        pred = alpha + beta * float(x_test[i])
        upper = pred + float(z_alpha) * sigma
        rows.append(
            {
                "prompt_id": str(row["prompt_id"]),
                "agent_llm": agent_llm,
                "Mpeak_pred": pred,
                "Mupper_pred": upper,
            }
        )
    return write_predictions_parquet(
        repo_root=repo_root,
        agent_llm=agent_llm,
        method="B1",
        rows=rows,
    )
