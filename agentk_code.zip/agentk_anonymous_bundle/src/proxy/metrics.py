"""
validation metrics for proxy training deliverables.
"""

from __future__ import annotations

from typing import Any, Dict, Mapping, Sequence

import torch
from transformers import PreTrainedTokenizerBase

from src.proxy.forecast import closed_form_peaks_from_outputs
from src.proxy.input_format import format_proxy_input
from src.proxy.model import MultiTaskProxyModel, ProxyForwardOutput


def mape_percent(y_true: torch.Tensor, y_pred: torch.Tensor) -> float:
    """Mean absolute percentage error in percent ."""
    denom = torch.clamp(y_true.abs(), min=1e-6)
    return float((torch.abs(y_true - y_pred) / denom).mean().item() * 100.0)


def oom_rate(y_true: torch.Tensor, y_upper: torch.Tensor) -> float:
    """Fraction of rows where true peak exceeds predicted upper bound."""
    if y_true.numel() == 0:
        return float("nan")
    return float((y_true > y_upper).float().mean().item())


def measure_inference_vram_mb(
    model: MultiTaskProxyModel,
    tokenizer: PreTrainedTokenizerBase,
    *,
    max_length: int,
    device: torch.device,
) -> float:
    """Peak CUDA memory for one proxy forward pass (guide §5.3 lightweight claim)."""
    if device.type != "cuda":
        return 0.0
    model.eval()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats(device)
    text = format_proxy_input(user_goal="VRAM inference footprint probe prompt.")
    batch = model.encode_texts([text], tokenizer=tokenizer, max_length=max_length, device=device)
    with torch.no_grad():
        model.forward(**batch)
    return float(torch.cuda.max_memory_allocated(device) / (1024.0 * 1024.0))


def compute_l_base_batch(
    texts: Sequence[str],
    tokenizer: PreTrainedTokenizerBase,
    *,
    max_length: int,
    device: torch.device,
) -> torch.Tensor:
    """Token length of concat(system_prompt, user_goal) per row."""
    formatted = [format_proxy_input(user_goal=t) for t in texts]
    encoded = tokenizer(
        formatted,
        padding=True,
        truncation=True,
        max_length=max_length,
        return_tensors="pt",
    )
    lengths = encoded["attention_mask"].sum(dim=1).to(device=device, dtype=torch.float32)
    return lengths


@torch.no_grad()
def evaluate_vram_metrics(
    model: MultiTaskProxyModel,
    tokenizer: PreTrainedTokenizerBase,
    *,
    texts: Sequence[str],
    accounting_rows: Sequence[Dict[str, Any]],
    y_mpeak: torch.Tensor,
    tool_mu_tokens: Mapping[str, float],
    max_length: int,
    device: torch.device,
    z_alpha: float,
) -> Dict[str, float]:
    """Compute val MAPE and val OOM rate from closed-form peaks."""
    model.eval()
    batch = model.encode_texts(list(texts), tokenizer=tokenizer, max_length=max_length, device=device)
    outputs = model.forward(**batch)
    l_base = compute_l_base_batch(list(texts), tokenizer, max_length=max_length, device=device)
    m_peak, m_upper = closed_form_peaks_from_outputs(
        outputs,
        l_base=l_base,
        accounting_rows=accounting_rows,
        tool_mu_tokens=tool_mu_tokens,
        z_alpha=z_alpha,
    )
    y_true = y_mpeak.to(device=device)
    return {
        "val_mape": mape_percent(y_true, m_peak),
        "val_oom_rate": oom_rate(y_true, m_upper),
    }
