"""
Phase 5.3 — closed-form peak VRAM from proxy head outputs (guide §5.2 / §6 B4).
"""

from __future__ import annotations

from typing import Any, Dict, Mapping, Sequence

import torch

from src.forecast.q4_km_accounting import (
    agentic_context_length_tokens,
    m_vram_mb,
    peak_context_length_tokens,
)
from src.proxy.constants import PROXY_NODE_TYPES
from src.proxy.model import ProxyForwardOutput


def aggregated_tool_tokens(tool_tokens_hat: torch.Tensor) -> torch.Tensor:
    """F3: Σ_i T̂[i] — sum predicted per-node completion tokens (batch,)."""
    return torch.sum(tool_tokens_hat, dim=-1)


def expected_tool_tokens_from_probs(
    tool_tokens_hat: torch.Tensor,
    tool_mu_tokens: Mapping[str, float] | None = None,
) -> torch.Tensor:
    """Sum per-node token predictions (F3). ``tool_mu_tokens`` ignored (compat)."""
    _ = tool_mu_tokens
    return aggregated_tool_tokens(tool_tokens_hat)


def closed_form_peak_mb(
    *,
    n_steps: torch.Tensor,
    e_hat: torch.Tensor,
    l_base: torch.Tensor,
    expected_tool_tokens: torch.Tensor,
    accounting: Dict[str, Any],
    n_is_total_completion_tokens: bool = True,
) -> torch.Tensor:
    """Evaluate M_weights + M_KV(L) + M_act for each batch row."""
    peaks: list[torch.Tensor] = []
    m_weights = float(accounting["M_weights_reported_mb"])
    m_act = float(accounting["M_act_mb"])
    n_layers = int(accounting["n_layers"])
    n_kv_heads = int(accounting["n_kv_heads"])
    d_head = int(accounting["d_head"])
    b_precision = float(accounting["b_precision"])
    for i in range(n_steps.shape[0]):
        if n_is_total_completion_tokens:
            l_peak = peak_context_length_tokens(
                l_base=float(l_base[i].item()),
                total_completion_tokens=float(n_steps[i].item()),
                expected_tool_tokens=float(expected_tool_tokens[i].item()),
            )
        else:
            n_i = max(1.0, float(n_steps[i].item()))
            l_peak = agentic_context_length_tokens(
                step_index=int(round(n_i)),
                n_steps=int(round(n_i)),
                l_base=float(l_base[i].item()),
                e_hat=float(e_hat[i].item()),
                expected_tool_tokens=float(expected_tool_tokens[i].item()),
            )
        peak = m_vram_mb(
            context_length_tokens=l_peak,
            m_weights_mb=m_weights,
            m_act_mb=m_act,
            n_layers=n_layers,
            n_kv_heads=n_kv_heads,
            d_head=d_head,
            b_precision=b_precision,
        )
        peaks.append(torch.tensor(peak, device=n_steps.device, dtype=n_steps.dtype))
    return torch.stack(peaks, dim=0)


def closed_form_peaks_from_outputs(
    outputs: ProxyForwardOutput,
    *,
    l_base: torch.Tensor,
    accounting_rows: Sequence[Dict[str, Any]],
    tool_mu_tokens: Mapping[str, float],
    z_alpha: float,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Return (M_peak_pred, M_upper_pred) using λ, σ_N, Ê, and tool probabilities.

    Upper bound evaluates the closed form at N̂ + z_α σ_N (guide §6 B4).
    """
    n_hat = outputs.lambda_rate.squeeze(-1)
    e_hat = outputs.e_hat.squeeze(-1)
    if outputs.sigma_n is None:
        sigma = torch.zeros_like(n_hat)
    else:
        sigma = outputs.sigma_n.squeeze(-1)
    n_upper = n_hat + float(z_alpha) * sigma
    tool_term = aggregated_tool_tokens(outputs.tool_tokens_hat)

    m_peak_rows: list[torch.Tensor] = []
    m_upper_rows: list[torch.Tensor] = []
    for i, acc in enumerate(accounting_rows):
        m_peak_rows.append(
            closed_form_peak_mb(
                n_steps=n_hat[i : i + 1],
                e_hat=e_hat[i : i + 1],
                l_base=l_base[i : i + 1],
                expected_tool_tokens=tool_term[i : i + 1],
                accounting=acc,
            )
        )
        m_upper_rows.append(
            closed_form_peak_mb(
                n_steps=n_upper[i : i + 1],
                e_hat=e_hat[i : i + 1],
                l_base=l_base[i : i + 1],
                expected_tool_tokens=tool_term[i : i + 1],
                accounting=acc,
            )
        )
    return torch.cat(m_peak_rows, dim=0), torch.cat(m_upper_rows, dim=0)
