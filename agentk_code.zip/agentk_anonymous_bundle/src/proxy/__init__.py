"""Multi-task surrogate model for goal-complexity extraction (Phase 5.1)."""

# Python line: from src.proxy.constants import (
# Phase 5.1 proxy package (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
from src.proxy.constants import (
    # Python line: DEFAULT_SYSTEM_PROMPT,
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    DEFAULT_SYSTEM_PROMPT,
    # Python line: NUM_TOOL_HEAD_OUTPUTS,
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    NUM_TOOL_HEAD_OUTPUTS,
    # Python line: PROXY_NODE_TYPES,
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    PROXY_NODE_TYPES,
# Python line: )
# Phase 5.1 proxy package (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
)
# Python line: from src.proxy.input_format import format_proxy_input
# Phase 5.1 proxy package (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
from src.proxy.input_format import format_proxy_input
# Python line: from src.proxy.backbone import (
# Phase 5.1 proxy package (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
from src.proxy.backbone import (
    # Python line: ProxyBackboneSpec,
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    ProxyBackboneSpec,
    # Python line: load_proxy_backbone_and_tokenizer,
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    load_proxy_backbone_and_tokenizer,
    # Python line: load_proxy_backbone_spec,
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    load_proxy_backbone_spec,
# Python line: )
# Phase 5.1 proxy package (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
)
# Python line: from src.proxy.loss import (
# Phase 5.1 proxy package (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
from src.proxy.loss import (
    # Python line: ProxyLossBreakdown,
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    ProxyLossBreakdown,
    # Python line: ProxyLossWeights,
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    ProxyLossWeights,
    # Python line: ProxyTargets,
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    ProxyTargets,
    # Python line: compute_proxy_loss,
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    compute_proxy_loss,
    # Python line: stack_tool_executed_targets,
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    stack_tool_token_targets,
    stack_tool_executed_targets,
# Python line: )
# Phase 5.1 proxy package (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
)
# Python line: from src.proxy.model import (
# Phase 5.1 proxy package (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
from src.proxy.model import (
    # Python line: MultiTaskProxyModel,
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    MultiTaskProxyModel,
    # Python line: ProxyForwardOutput,
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    ProxyForwardOutput,
    # Python line: build_multitask_proxy,
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    build_multitask_proxy,
    # Python line: mean_pool_hidden,
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    mean_pool_hidden,
# Python line: )
# Phase 5.1 proxy package (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
)

# Python line: __all__ = [
# Phase 5.1 proxy package (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
__all__ = [
    # Python line: "DEFAULT_SYSTEM_PROMPT",
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    "DEFAULT_SYSTEM_PROMPT",
    # Python line: "NUM_TOOL_HEAD_OUTPUTS",
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    "NUM_TOOL_HEAD_OUTPUTS",
    # Python line: "PROXY_NODE_TYPES",
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    "PROXY_NODE_TYPES",
    # Python line: "ProxyBackboneSpec",
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    "ProxyBackboneSpec",
    # Python line: "ProxyLossBreakdown",
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    "ProxyLossBreakdown",
    # Python line: "ProxyLossWeights",
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    "ProxyLossWeights",
    # Python line: "ProxyTargets",
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    "ProxyTargets",
    # Python line: "ProxyForwardOutput",
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    "ProxyForwardOutput",
    # Python line: "MultiTaskProxyModel",
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    "MultiTaskProxyModel",
    # Python line: "build_multitask_proxy",
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    "build_multitask_proxy",
    # Python line: "compute_proxy_loss",
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    "compute_proxy_loss",
    # Python line: "format_proxy_input",
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    "format_proxy_input",
    # Python line: "load_proxy_backbone_and_tokenizer",
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    "load_proxy_backbone_and_tokenizer",
    # Python line: "load_proxy_backbone_spec",
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    "load_proxy_backbone_spec",
    # Python line: "mean_pool_hidden",
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    "mean_pool_hidden",
    # Python line: "stack_tool_executed_targets",
    # Phase 5.1 proxy package (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    "stack_tool_executed_targets",
# Python line: ]
# Phase 5.1 proxy package (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
]
