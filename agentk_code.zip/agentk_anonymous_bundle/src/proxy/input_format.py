"""
proxy input formatting: concat(system_prompt, user_goal) before tokenization.
"""

# Python line: from __future__ import annotations
# proxy input formatting.
# Implements .cursorrules dense-comment policy for src/ code.
from __future__ import annotations

# DEFAULT_SYSTEM_PROMPT supplies the guide's system_prompt when caller omits it.
# Python line: from src.proxy.constants import DEFAULT_SYSTEM_PROMPT
# proxy input formatting.
# Implements .cursorrules dense-comment policy for src/ code.
from src.proxy.constants import DEFAULT_SYSTEM_PROMPT


# Python line: def format_proxy_input(
# proxy input formatting.
# Implements .cursorrules dense-comment policy for src/ code.
def format_proxy_input(
    *,
    user_goal: str,
    system_prompt: str | None = None,
) -> str:
    """
    Build the proxy encoder string: concat(system_prompt, user_goal) .

    Uses a blank line between system and user sections for readability.
    """
    # Python line: system = system_prompt if system_prompt is not None else DEFAULT_SYSTEM_PROMPT
    # proxy input formatting.
    # Implements .cursorrules dense-comment policy for src/ code.
    system = system_prompt if system_prompt is not None else DEFAULT_SYSTEM_PROMPT
    # Python line: goal = user_goal.strip()
    # proxy input formatting.
    # Implements .cursorrules dense-comment policy for src/ code.
    goal = user_goal.strip()
    # Python line: return f"{system.strip()}\n\n{goal}"
    # proxy input formatting.
    # Implements .cursorrules dense-comment policy for src/ code.
    return f"{system.strip()}\n\n{goal}"
