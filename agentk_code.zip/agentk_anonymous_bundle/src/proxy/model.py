"""
multi-task VRAM proxy architecture .

concat(system_prompt, user_goal) → tokenizer → backbone → pooled h ∈ R^d
  → step_head / tool_head / expand_head / [variance_head] / [stretch heads]
"""

# Python line: from __future__ import annotations
# multi-task proxy model.
# Implements .cursorrules dense-comment policy for src/ code.
from __future__ import annotations

# dataclass bundles forward outputs for training and inference callers.
# Python line: from dataclasses import dataclass
# multi-task proxy model.
# Implements .cursorrules dense-comment policy for src/ code.
from dataclasses import dataclass
# Path locates configs when building from backbone id.
# Python line: from pathlib import Path
# multi-task proxy model.
# Implements .cursorrules dense-comment policy for src/ code.
from pathlib import Path
# typing annotates optional stretch-head outputs and batch tensors.
# Python line: from typing import Any, Dict, List, Optional
# multi-task proxy model.
# Implements .cursorrules dense-comment policy for src/ code.
from typing import Any, Dict, List, Optional

# nn defines Linear heads and activation wrappers on pooled embeddings.
# Python line: import torch
# multi-task proxy model.
# Implements .cursorrules dense-comment policy for src/ code.
import torch
# nn.Module is the base class for MultiTaskProxyModel.
# Python line: import torch.nn as nn
# multi-task proxy model.
# Implements .cursorrules dense-comment policy for src/ code.
import torch.nn as nn
# F provides softplus/sigmoid activations specified in guide §5.1.
# Python line: import torch.nn.functional as F
# multi-task proxy model.
# Implements .cursorrules dense-comment policy for src/ code.
import torch.nn.functional as F
# PreTrainedModel type for the HF encoder backbone reference.
# Python line: from transformers import PreTrainedModel, PreTrainedTokenizerBase
# multi-task proxy model.
# Implements .cursorrules dense-comment policy for src/ code.
from transformers import PreTrainedModel, PreTrainedTokenizerBase

# load_proxy_backbone_and_tokenizer wires HF weights from proxy_backbones.yaml.
# Python line: from src.proxy.backbone import (
# multi-task proxy model.
# Implements .cursorrules dense-comment policy for src/ code.
from src.proxy.backbone import (
    # Python line: ProxyBackboneSpec,
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    ProxyBackboneSpec,
    # Python line: load_proxy_backbone_and_tokenizer,
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    load_proxy_backbone_and_tokenizer,
    # Python line: load_proxy_backbone_spec,
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    load_proxy_backbone_spec,
# Python line: )
# multi-task proxy model.
# Implements .cursorrules dense-comment policy for src/ code.
)
# NUM_TOOL_HEAD_OUTPUTS fixes tool_head width at five node types.
# Python line: from src.proxy.constants import NUM_TOOL_HEAD_OUTPUTS
# multi-task proxy model.
# Implements .cursorrules dense-comment policy for src/ code.
from src.proxy.constants import NUM_TOOL_HEAD_OUTPUTS
# format_proxy_input implements concat(system_prompt, user_goal) before tokenize.
# Python line: from src.proxy.input_format import format_proxy_input
# multi-task proxy model.
# Implements .cursorrules dense-comment policy for src/ code.
from src.proxy.input_format import format_proxy_input


# Python line: @dataclass
# multi-task proxy model.
# Implements .cursorrules dense-comment policy for src/ code.
@dataclass
# Python line: class ProxyForwardOutput:
# multi-task proxy model.
# Implements .cursorrules dense-comment policy for src/ code.
class ProxyForwardOutput:
    """Tensor outputs from one MultiTaskProxyModel forward pass."""

    # Python line: pooled: torch.Tensor
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    pooled: torch.Tensor
    # Python line: lambda_rate: torch.Tensor
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    lambda_rate: torch.Tensor
    # Python line: tool_probs: torch.Tensor
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    tool_tokens_hat: torch.Tensor
    # Python line: e_hat: torch.Tensor
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    e_hat: torch.Tensor
    # Python line: sigma_n: Optional[torch.Tensor]
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    sigma_n: Optional[torch.Tensor]
    # Python line: p_compile: Optional[torch.Tensor]
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    p_compile: Optional[torch.Tensor]
    # Python line: p_numcorrect: Optional[torch.Tensor]
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    p_numcorrect: Optional[torch.Tensor]

    @property
    def tool_probs(self) -> torch.Tensor:
        """Backward-compatible alias for pre-F3 ``tool_probs`` field name."""
        return self.tool_tokens_hat


# Python line: def mean_pool_hidden(
# multi-task proxy model.
# Implements .cursorrules dense-comment policy for src/ code.
def mean_pool_hidden(
    hidden: torch.Tensor,
    attention_mask: torch.Tensor,
) -> torch.Tensor:
    """Mean-pool token hidden states → pooled h ∈ R^d ."""
    # Python line: mask = attention_mask.unsqueeze(-1).type_as(hidden)
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    mask = attention_mask.unsqueeze(-1).type_as(hidden)
    # Python line: summed = torch.sum(hidden * mask, dim=1)
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    summed = torch.sum(hidden * mask, dim=1)
    # Python line: counts = torch.clamp(mask.sum(dim=1), min=1e-9)
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    counts = torch.clamp(mask.sum(dim=1), min=1e-9)
    # Python line: return summed / counts
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    return summed / counts


# Python line: class MultiTaskProxyModel(nn.Module):
# multi-task proxy model.
# Implements .cursorrules dense-comment policy for src/ code.
class MultiTaskProxyModel(nn.Module):
    """
    Multi-task proxy: encoder backbone + task heads .

    Heads:
      step_head:     Linear(d → 1) → Softplus → λ
      tool_head:     Linear(d → 5) → sigmoid → p_i
      expand_head:   Linear(d → 1) → identity → Ê
      variance_head: Linear(d → 1) → Softplus → σ_N  (optional)
    Stretch (optional):
      compile_head / numcorrect_head: Linear(d → 1) → sigmoid
    """

    # Python line: def __init__(
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    def __init__(
        self,
        *,
        backbone: PreTrainedModel,
        hidden_size: int,
        enable_variance_head: bool = True,
        enable_stretch_heads: bool = False,
    ) -> None:
        # Python line: super().__init__()
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        super().__init__()
        # Python line: self.backbone = backbone
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        self.backbone = backbone
        # Python line: self.hidden_size = int(hidden_size)
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        self.hidden_size = int(hidden_size)
        # Python line: self.enable_variance_head = bool(enable_variance_head)
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        self.enable_variance_head = bool(enable_variance_head)
        # Python line: self.enable_stretch_heads = bool(enable_stretch_heads)
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        self.enable_stretch_heads = bool(enable_stretch_heads)

        # Python line: self.step_head = nn.Linear(self.hidden_size, 1)
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        self.step_head = nn.Linear(self.hidden_size, 1)
        # Python line: self.tool_head = nn.Linear(self.hidden_size, NUM_TOOL_HEAD_OUTPUTS)
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        self.tool_head = nn.Linear(self.hidden_size, NUM_TOOL_HEAD_OUTPUTS)
        # Python line: self.expand_head = nn.Linear(self.hidden_size, 1)
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        self.expand_head = nn.Linear(self.hidden_size, 1)

        # Python line: if self.enable_variance_head:
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        if self.enable_variance_head:
            # Python line: self.variance_head = nn.Linear(self.hidden_size, 1)
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            self.variance_head = nn.Linear(self.hidden_size, 1)
        # Python line: else:
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        else:
            # Python line: self.variance_head = None
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            self.variance_head = None

        # Python line: if self.enable_stretch_heads:
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        if self.enable_stretch_heads:
            # Python line: self.compile_head = nn.Linear(self.hidden_size, 1)
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            self.compile_head = nn.Linear(self.hidden_size, 1)
            # Python line: self.numcorrect_head = nn.Linear(self.hidden_size, 1)
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            self.numcorrect_head = nn.Linear(self.hidden_size, 1)
        # Python line: else:
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        else:
            # Python line: self.compile_head = None
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            self.compile_head = None
            # Python line: self.numcorrect_head = None
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            self.numcorrect_head = None

    # Python line: def forward(
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    def forward(
        self,
        *,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> ProxyForwardOutput:
        """Run backbone + heads on tokenized proxy inputs."""
        # Python line: outputs = self.backbone(input_ids=input_ids, attention_mask=attention_mask)
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        outputs = self.backbone(input_ids=input_ids, attention_mask=attention_mask)
        # Python line: hidden = outputs.last_hidden_state
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        hidden = outputs.last_hidden_state
        # Python line: pooled = mean_pool_hidden(hidden, attention_mask)
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        pooled = mean_pool_hidden(hidden, attention_mask)

        # Python line: lambda_rate = F.softplus(self.step_head(pooled))
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        lambda_rate = F.softplus(self.step_head(pooled))
        # Python line: tool_probs = torch.sigmoid(self.tool_head(pooled))
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        tool_tokens_hat = F.softplus(self.tool_head(pooled))
        # Python line: e_hat = self.expand_head(pooled)
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        e_hat = self.expand_head(pooled)

        # Python line: sigma_n: Optional[torch.Tensor] = None
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        sigma_n: Optional[torch.Tensor] = None
        # Python line: if self.variance_head is not None:
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        if self.variance_head is not None:
            # Python line: sigma_n = F.softplus(self.variance_head(pooled))
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            sigma_n = F.softplus(self.variance_head(pooled))

        # Python line: p_compile: Optional[torch.Tensor] = None
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        p_compile: Optional[torch.Tensor] = None
        # Python line: p_numcorrect: Optional[torch.Tensor] = None
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        p_numcorrect: Optional[torch.Tensor] = None
        # Python line: if self.compile_head is not None:
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        if self.compile_head is not None:
            # Python line: p_compile = torch.sigmoid(self.compile_head(pooled))
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            p_compile = torch.sigmoid(self.compile_head(pooled))
        # Python line: if self.numcorrect_head is not None:
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        if self.numcorrect_head is not None:
            # Python line: p_numcorrect = torch.sigmoid(self.numcorrect_head(pooled))
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            p_numcorrect = torch.sigmoid(self.numcorrect_head(pooled))

        # Python line: return ProxyForwardOutput(
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        return ProxyForwardOutput(
            # Python line: pooled=pooled,
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            pooled=pooled,
            # Python line: lambda_rate=lambda_rate,
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            lambda_rate=lambda_rate,
            # Python line: tool_probs=tool_probs,
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            tool_tokens_hat=tool_tokens_hat,
            # Python line: e_hat=e_hat,
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            e_hat=e_hat,
            # Python line: sigma_n=sigma_n,
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            sigma_n=sigma_n,
            # Python line: p_compile=p_compile,
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            p_compile=p_compile,
            # Python line: p_numcorrect=p_numcorrect,
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            p_numcorrect=p_numcorrect,
        # Python line: )
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        )

    # Python line: def encode_texts(
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    def encode_texts(
        self,
        texts: List[str],
        *,
        tokenizer: PreTrainedTokenizerBase,
        max_length: int,
        device: torch.device,
    ) -> Dict[str, torch.Tensor]:
        """Tokenize formatted proxy strings for forward()."""
        # Python line: encoded = tokenizer(
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        encoded = tokenizer(
            # Python line: texts,
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            texts,
            # Python line: padding=True,
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            padding=True,
            # Python line: truncation=True,
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            truncation=True,
            # Python line: max_length=max_length,
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            max_length=max_length,
            # Python line: return_tensors="pt",
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            return_tensors="pt",
        # Python line: )
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        )
        # Python line: return {
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        return {
            # Python line: "input_ids": encoded["input_ids"].to(device),
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            "input_ids": encoded["input_ids"].to(device),
            # Python line: "attention_mask": encoded["attention_mask"].to(device),
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            "attention_mask": encoded["attention_mask"].to(device),
        # Python line: }
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        }

    # Python line: def predict_from_goals(
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    def predict_from_goals(
        self,
        user_goals: List[str],
        *,
        tokenizer: PreTrainedTokenizerBase,
        max_length: int,
        device: torch.device,
        system_prompt: str | None = None,
    ) -> ProxyForwardOutput:
        """End-to-end: user goals → concat → tokenize → forward."""
        # Python line: texts = [
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        texts = [
            # Python line: format_proxy_input(user_goal=goal, system_prompt=system_prompt)
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            format_proxy_input(user_goal=goal, system_prompt=system_prompt)
            # Python line: for goal in user_goals
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            for goal in user_goals
        # Python line: ]
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        ]
        # Python line: batch = self.encode_texts(
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        batch = self.encode_texts(
            # Python line: texts,
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            texts,
            # Python line: tokenizer=tokenizer,
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            tokenizer=tokenizer,
            # Python line: max_length=max_length,
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            max_length=max_length,
            # Python line: device=device,
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            device=device,
        # Python line: )
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        )
        # Python line: return self.forward(**batch)
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        return self.forward(**batch)

    # Python line: def set_backbone_trainable(self, trainable: bool) -> None:
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    def set_backbone_trainable(self, trainable: bool) -> None:
        """Freeze or unfreeze encoder weights (guide §5.2: freeze first 2 epochs)."""
        # Python line: for param in self.backbone.parameters():
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        for param in self.backbone.parameters():
            # Python line: param.requires_grad = bool(trainable)
            # multi-task proxy model.
            # Implements .cursorrules dense-comment policy for src/ code.
            param.requires_grad = bool(trainable)


# Python line: def build_multitask_proxy(
# multi-task proxy model.
# Implements .cursorrules dense-comment policy for src/ code.
def build_multitask_proxy(
    *,
    repo_root: Path,
    backbone_id: str,
    enable_variance_head: bool = True,
    enable_stretch_heads: bool = False,
) -> tuple[MultiTaskProxyModel, PreTrainedTokenizerBase, ProxyBackboneSpec]:
    """Factory: load backbone from config and attach multi-task heads."""
    # Python line: spec = load_proxy_backbone_spec(repo_root=repo_root, backbone_id=backbone_id)
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    spec = load_proxy_backbone_spec(repo_root=repo_root, backbone_id=backbone_id)
    # Python line: backbone, tokenizer = load_proxy_backbone_and_tokenizer(spec=spec)
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    backbone, tokenizer = load_proxy_backbone_and_tokenizer(spec=spec)
    # Python line: model = MultiTaskProxyModel(
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    model = MultiTaskProxyModel(
        # Python line: backbone=backbone,
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        backbone=backbone,
        # Python line: hidden_size=spec.hidden_size,
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        hidden_size=spec.hidden_size,
        # Python line: enable_variance_head=enable_variance_head,
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        enable_variance_head=enable_variance_head,
        # Python line: enable_stretch_heads=enable_stretch_heads,
        # multi-task proxy model.
        # Implements .cursorrules dense-comment policy for src/ code.
        enable_stretch_heads=enable_stretch_heads,
    # Python line: )
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: return model, tokenizer, spec
    # multi-task proxy model.
    # Implements .cursorrules dense-comment policy for src/ code.
    return model, tokenizer, spec
