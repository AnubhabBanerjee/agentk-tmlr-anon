"""
Phase 5.1 — multi-task VRAM proxy architecture (guide §5.1).

concat(system_prompt, user_goal) → tokenizer → backbone → pooled h ∈ R^d
  → step_head / tool_head / expand_head / [variance_head] / [stretch heads]
"""

# Python line: from __future__ import annotations
# Phase 5.1 multi-task proxy model (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
from __future__ import annotations

# dataclass bundles forward outputs for training and inference callers.
# Python line: from dataclasses import dataclass
# Phase 5.1 multi-task proxy model (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
from dataclasses import dataclass
# Path locates configs when building from backbone id.
# Python line: from pathlib import Path
# Phase 5.1 multi-task proxy model (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
from pathlib import Path
# typing annotates optional stretch-head outputs and batch tensors.
# Python line: from typing import Any, Dict, List, Optional
# Phase 5.1 multi-task proxy model (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
from typing import Any, Dict, List, Optional

# nn defines Linear heads and activation wrappers on pooled embeddings.
# Python line: import torch
# Phase 5.1 multi-task proxy model (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
import torch
# nn.Module is the base class for MultiTaskProxyModel.
# Python line: import torch.nn as nn
# Phase 5.1 multi-task proxy model (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
import torch.nn as nn
# F provides softplus/sigmoid activations specified in guide §5.1.
# Python line: import torch.nn.functional as F
# Phase 5.1 multi-task proxy model (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
import torch.nn.functional as F
# PreTrainedModel type for the HF encoder backbone reference.
# Python line: from transformers import PreTrainedModel, PreTrainedTokenizerBase
# Phase 5.1 multi-task proxy model (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
from transformers import PreTrainedModel, PreTrainedTokenizerBase

# load_proxy_backbone_and_tokenizer wires HF weights from proxy_backbones.yaml.
# Python line: from src.proxy.backbone import (
# Phase 5.1 multi-task proxy model (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
from src.proxy.backbone import (
    # Python line: ProxyBackboneSpec,
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    ProxyBackboneSpec,
    # Python line: load_proxy_backbone_and_tokenizer,
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    load_proxy_backbone_and_tokenizer,
    # Python line: load_proxy_backbone_spec,
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    load_proxy_backbone_spec,
# Python line: )
# Phase 5.1 multi-task proxy model (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
)
# NUM_TOOL_HEAD_OUTPUTS fixes tool_head width at five node types.
# Python line: from src.proxy.constants import NUM_TOOL_HEAD_OUTPUTS
# Phase 5.1 multi-task proxy model (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
from src.proxy.constants import NUM_TOOL_HEAD_OUTPUTS
# format_proxy_input implements concat(system_prompt, user_goal) before tokenize.
# Python line: from src.proxy.input_format import format_proxy_input
# Phase 5.1 multi-task proxy model (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
from src.proxy.input_format import format_proxy_input


# Python line: @dataclass
# Phase 5.1 multi-task proxy model (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
@dataclass
# Python line: class ProxyForwardOutput:
# Phase 5.1 multi-task proxy model (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
class ProxyForwardOutput:
    """Tensor outputs from one MultiTaskProxyModel forward pass."""

    # Python line: pooled: torch.Tensor
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    pooled: torch.Tensor
    # Python line: lambda_rate: torch.Tensor
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    lambda_rate: torch.Tensor
    # Python line: tool_probs: torch.Tensor
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    tool_tokens_hat: torch.Tensor
    # Python line: e_hat: torch.Tensor
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    e_hat: torch.Tensor
    # Python line: sigma_n: Optional[torch.Tensor]
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    sigma_n: Optional[torch.Tensor]
    # Python line: p_compile: Optional[torch.Tensor]
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    p_compile: Optional[torch.Tensor]
    # Python line: p_numcorrect: Optional[torch.Tensor]
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    p_numcorrect: Optional[torch.Tensor]

    @property
    def tool_probs(self) -> torch.Tensor:
        """Backward-compatible alias for pre-F3 ``tool_probs`` field name."""
        return self.tool_tokens_hat


# Python line: def mean_pool_hidden(
# Phase 5.1 multi-task proxy model (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
def mean_pool_hidden(
    hidden: torch.Tensor,
    attention_mask: torch.Tensor,
) -> torch.Tensor:
    """Mean-pool token hidden states → pooled h ∈ R^d (guide §5.1)."""
    # Python line: mask = attention_mask.unsqueeze(-1).type_as(hidden)
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    mask = attention_mask.unsqueeze(-1).type_as(hidden)
    # Python line: summed = torch.sum(hidden * mask, dim=1)
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    summed = torch.sum(hidden * mask, dim=1)
    # Python line: counts = torch.clamp(mask.sum(dim=1), min=1e-9)
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    counts = torch.clamp(mask.sum(dim=1), min=1e-9)
    # Python line: return summed / counts
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    return summed / counts


# Python line: class MultiTaskProxyModel(nn.Module):
# Phase 5.1 multi-task proxy model (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
class MultiTaskProxyModel(nn.Module):
    """
    Multi-task proxy: encoder backbone + task heads (guide §5.1).

    Heads:
      step_head:     Linear(d → 1) → Softplus → λ
      tool_head:     Linear(d → 5) → sigmoid → p_i
      expand_head:   Linear(d → 1) → identity → Ê
      variance_head: Linear(d → 1) → Softplus → σ_N  (optional)
    Stretch (optional):
      compile_head / numcorrect_head: Linear(d → 1) → sigmoid
    """

    # Python line: def __init__(
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    def __init__(
        self,
        *,
        backbone: PreTrainedModel,
        hidden_size: int,
        enable_variance_head: bool = True,
        enable_stretch_heads: bool = False,
    ) -> None:
        # Python line: super().__init__()
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        super().__init__()
        # Python line: self.backbone = backbone
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        self.backbone = backbone
        # Python line: self.hidden_size = int(hidden_size)
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        self.hidden_size = int(hidden_size)
        # Python line: self.enable_variance_head = bool(enable_variance_head)
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        self.enable_variance_head = bool(enable_variance_head)
        # Python line: self.enable_stretch_heads = bool(enable_stretch_heads)
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        self.enable_stretch_heads = bool(enable_stretch_heads)

        # Python line: self.step_head = nn.Linear(self.hidden_size, 1)
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        self.step_head = nn.Linear(self.hidden_size, 1)
        # Python line: self.tool_head = nn.Linear(self.hidden_size, NUM_TOOL_HEAD_OUTPUTS)
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        self.tool_head = nn.Linear(self.hidden_size, NUM_TOOL_HEAD_OUTPUTS)
        # Python line: self.expand_head = nn.Linear(self.hidden_size, 1)
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        self.expand_head = nn.Linear(self.hidden_size, 1)

        # Python line: if self.enable_variance_head:
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        if self.enable_variance_head:
            # Python line: self.variance_head = nn.Linear(self.hidden_size, 1)
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            self.variance_head = nn.Linear(self.hidden_size, 1)
        # Python line: else:
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        else:
            # Python line: self.variance_head = None
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            self.variance_head = None

        # Python line: if self.enable_stretch_heads:
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        if self.enable_stretch_heads:
            # Python line: self.compile_head = nn.Linear(self.hidden_size, 1)
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            self.compile_head = nn.Linear(self.hidden_size, 1)
            # Python line: self.numcorrect_head = nn.Linear(self.hidden_size, 1)
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            self.numcorrect_head = nn.Linear(self.hidden_size, 1)
        # Python line: else:
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        else:
            # Python line: self.compile_head = None
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            self.compile_head = None
            # Python line: self.numcorrect_head = None
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            self.numcorrect_head = None

    # Python line: def forward(
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    def forward(
        self,
        *,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> ProxyForwardOutput:
        """Run backbone + heads on tokenized proxy inputs."""
        # Python line: outputs = self.backbone(input_ids=input_ids, attention_mask=attention_mask)
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        outputs = self.backbone(input_ids=input_ids, attention_mask=attention_mask)
        # Python line: hidden = outputs.last_hidden_state
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        hidden = outputs.last_hidden_state
        # Python line: pooled = mean_pool_hidden(hidden, attention_mask)
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        pooled = mean_pool_hidden(hidden, attention_mask)

        # Python line: lambda_rate = F.softplus(self.step_head(pooled))
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        lambda_rate = F.softplus(self.step_head(pooled))
        # Python line: tool_probs = torch.sigmoid(self.tool_head(pooled))
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        tool_tokens_hat = F.softplus(self.tool_head(pooled))
        # Python line: e_hat = self.expand_head(pooled)
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        e_hat = self.expand_head(pooled)

        # Python line: sigma_n: Optional[torch.Tensor] = None
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        sigma_n: Optional[torch.Tensor] = None
        # Python line: if self.variance_head is not None:
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        if self.variance_head is not None:
            # Python line: sigma_n = F.softplus(self.variance_head(pooled))
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            sigma_n = F.softplus(self.variance_head(pooled))

        # Python line: p_compile: Optional[torch.Tensor] = None
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        p_compile: Optional[torch.Tensor] = None
        # Python line: p_numcorrect: Optional[torch.Tensor] = None
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        p_numcorrect: Optional[torch.Tensor] = None
        # Python line: if self.compile_head is not None:
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        if self.compile_head is not None:
            # Python line: p_compile = torch.sigmoid(self.compile_head(pooled))
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            p_compile = torch.sigmoid(self.compile_head(pooled))
        # Python line: if self.numcorrect_head is not None:
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        if self.numcorrect_head is not None:
            # Python line: p_numcorrect = torch.sigmoid(self.numcorrect_head(pooled))
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            p_numcorrect = torch.sigmoid(self.numcorrect_head(pooled))

        # Python line: return ProxyForwardOutput(
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        return ProxyForwardOutput(
            # Python line: pooled=pooled,
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            pooled=pooled,
            # Python line: lambda_rate=lambda_rate,
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            lambda_rate=lambda_rate,
            # Python line: tool_probs=tool_probs,
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            tool_tokens_hat=tool_tokens_hat,
            # Python line: e_hat=e_hat,
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            e_hat=e_hat,
            # Python line: sigma_n=sigma_n,
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            sigma_n=sigma_n,
            # Python line: p_compile=p_compile,
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            p_compile=p_compile,
            # Python line: p_numcorrect=p_numcorrect,
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            p_numcorrect=p_numcorrect,
        # Python line: )
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        )

    # Python line: def encode_texts(
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    def encode_texts(
        self,
        texts: List[str],
        *,
        tokenizer: PreTrainedTokenizerBase,
        max_length: int,
        device: torch.device,
    ) -> Dict[str, torch.Tensor]:
        """Tokenize formatted proxy strings for forward()."""
        # Python line: encoded = tokenizer(
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        encoded = tokenizer(
            # Python line: texts,
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            texts,
            # Python line: padding=True,
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            padding=True,
            # Python line: truncation=True,
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            truncation=True,
            # Python line: max_length=max_length,
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            max_length=max_length,
            # Python line: return_tensors="pt",
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            return_tensors="pt",
        # Python line: )
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        )
        # Python line: return {
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        return {
            # Python line: "input_ids": encoded["input_ids"].to(device),
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            "input_ids": encoded["input_ids"].to(device),
            # Python line: "attention_mask": encoded["attention_mask"].to(device),
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            "attention_mask": encoded["attention_mask"].to(device),
        # Python line: }
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        }

    # Python line: def predict_from_goals(
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    def predict_from_goals(
        self,
        user_goals: List[str],
        *,
        tokenizer: PreTrainedTokenizerBase,
        max_length: int,
        device: torch.device,
        system_prompt: str | None = None,
    ) -> ProxyForwardOutput:
        """End-to-end: user goals → concat → tokenize → forward."""
        # Python line: texts = [
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        texts = [
            # Python line: format_proxy_input(user_goal=goal, system_prompt=system_prompt)
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            format_proxy_input(user_goal=goal, system_prompt=system_prompt)
            # Python line: for goal in user_goals
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            for goal in user_goals
        # Python line: ]
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        ]
        # Python line: batch = self.encode_texts(
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        batch = self.encode_texts(
            # Python line: texts,
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            texts,
            # Python line: tokenizer=tokenizer,
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            tokenizer=tokenizer,
            # Python line: max_length=max_length,
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            max_length=max_length,
            # Python line: device=device,
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            device=device,
        # Python line: )
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        )
        # Python line: return self.forward(**batch)
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        return self.forward(**batch)

    # Python line: def set_backbone_trainable(self, trainable: bool) -> None:
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    def set_backbone_trainable(self, trainable: bool) -> None:
        """Freeze or unfreeze encoder weights (guide §5.2: freeze first 2 epochs)."""
        # Python line: for param in self.backbone.parameters():
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        for param in self.backbone.parameters():
            # Python line: param.requires_grad = bool(trainable)
            # Phase 5.1 multi-task proxy model (src/proxy).
            # Implements .cursorrules dense-comment policy for src/ code.
            param.requires_grad = bool(trainable)


# Python line: def build_multitask_proxy(
# Phase 5.1 multi-task proxy model (src/proxy).
# Implements .cursorrules dense-comment policy for src/ code.
def build_multitask_proxy(
    *,
    repo_root: Path,
    backbone_id: str,
    enable_variance_head: bool = True,
    enable_stretch_heads: bool = False,
) -> tuple[MultiTaskProxyModel, PreTrainedTokenizerBase, ProxyBackboneSpec]:
    """Factory: load backbone from config and attach multi-task heads."""
    # Python line: spec = load_proxy_backbone_spec(repo_root=repo_root, backbone_id=backbone_id)
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    spec = load_proxy_backbone_spec(repo_root=repo_root, backbone_id=backbone_id)
    # Python line: backbone, tokenizer = load_proxy_backbone_and_tokenizer(spec=spec)
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    backbone, tokenizer = load_proxy_backbone_and_tokenizer(spec=spec)
    # Python line: model = MultiTaskProxyModel(
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    model = MultiTaskProxyModel(
        # Python line: backbone=backbone,
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        backbone=backbone,
        # Python line: hidden_size=spec.hidden_size,
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        hidden_size=spec.hidden_size,
        # Python line: enable_variance_head=enable_variance_head,
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        enable_variance_head=enable_variance_head,
        # Python line: enable_stretch_heads=enable_stretch_heads,
        # Phase 5.1 multi-task proxy model (src/proxy).
        # Implements .cursorrules dense-comment policy for src/ code.
        enable_stretch_heads=enable_stretch_heads,
    # Python line: )
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: return model, tokenizer, spec
    # Phase 5.1 multi-task proxy model (src/proxy).
    # Implements .cursorrules dense-comment policy for src/ code.
    return model, tokenizer, spec
