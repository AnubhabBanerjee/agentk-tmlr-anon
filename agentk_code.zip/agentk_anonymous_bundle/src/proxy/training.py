"""
Phase 5.3 — proxy training loop (freeze → unfreeze, Adam, cosine, early stopping).
"""

from __future__ import annotations

import json
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import torch
from safetensors.torch import save_file
from torch.utils.data import DataLoader
from transformers import PreTrainedTokenizerBase

from src.proxy.config import ProxyTrainingConfig, load_proxy_training_config
from src.proxy.data import (
    ProxyDataset,
    collate_proxy_batch,
    compute_tool_mu_tokens,
    load_proxy_training_frame,
)
from src.proxy.loss import ProxyLossWeights, compute_proxy_loss
from src.proxy.metrics import evaluate_vram_metrics, measure_inference_vram_mb
from src.proxy.model import MultiTaskProxyModel, build_multitask_proxy


def _run_epoch(
    model: MultiTaskProxyModel,
    loader: DataLoader,
    *,
    tokenizer: PreTrainedTokenizerBase,
    max_length: int,
    device: torch.device,
    optimizer: Optional[torch.optim.Optimizer],
    loss_weights: ProxyLossWeights,
    enable_variance_loss: bool,
    enable_stretch_losses: bool,
    train: bool,
) -> Tuple[float, Dict[str, float]]:
    """One pass over a dataloader; returns mean loss and mean component losses."""
    if train:
        model.train()
    else:
        model.eval()
    total_loss = 0.0
    component_sums: Dict[str, float] = {}
    n_batches = 0
    for texts, targets, _accounting, _mpeak, _yn in loader:
        batch = model.encode_texts(texts, tokenizer=tokenizer, max_length=max_length, device=device)
        if train:
            optimizer = optimizer
            assert optimizer is not None
            optimizer.zero_grad(set_to_none=True)
            outputs = model.forward(**batch)
            breakdown = compute_proxy_loss(
                outputs,
                targets,
                weights=loss_weights,
                enable_variance_loss=enable_variance_loss,
                enable_stretch_losses=enable_stretch_losses,
            )
            breakdown.total.backward()
            optimizer.step()
        else:
            with torch.no_grad():
                outputs = model.forward(**batch)
                breakdown = compute_proxy_loss(
                    outputs,
                    targets,
                    weights=loss_weights,
                    enable_variance_loss=enable_variance_loss,
                    enable_stretch_losses=enable_stretch_losses,
                )
        total_loss += float(breakdown.total.item())
        for key, value in breakdown.components.items():
            component_sums[key] = component_sums.get(key, 0.0) + float(value.item())
        n_batches += 1
    if n_batches == 0:
        return float("nan"), {}
    mean_components = {k: v / n_batches for k, v in component_sums.items()}
    return total_loss / n_batches, mean_components


def _collect_split_batches(
    loader: DataLoader,
) -> Tuple[List[str], List[Dict[str, Any]], torch.Tensor]:
    """Flatten a dataloader into texts, accounting rows, and y_mpeak tensors."""
    texts: List[str] = []
    accounting: List[Dict[str, Any]] = []
    mpeaks: List[float] = []
    for batch_texts, _targets, batch_acc, batch_mpeak, _yn in loader:
        texts.extend(batch_texts)
        accounting.extend(batch_acc)
        mpeaks.extend(batch_mpeak.tolist())
    return texts, accounting, torch.tensor(mpeaks, dtype=torch.float32)


def train_proxy_model(
    *,
    repo_root: Path,
    agent_llm: str,
    backbone_id: str,
    output_dir: Path,
    enable_stretch_heads: bool = False,
    device: Optional[torch.device] = None,
    training_cfg: Optional[ProxyTrainingConfig] = None,
) -> Dict[str, Any]:
    """
    Train one proxy for (agent_llm, backbone) and write Phase 5.4 deliverables.

    Writes:
      output_dir/model.safetensors
      output_dir/metrics.json
    """
    cfg = training_cfg or load_proxy_training_config(repo_root=repo_root)
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    frame = load_proxy_training_frame(repo_root=repo_root, agent_llm=agent_llm)
    train_df = frame[frame["split"] == "train"]
    val_df = frame[frame["split"] == "val"]
    tool_mu = compute_tool_mu_tokens(train_df)

    train_ds = ProxyDataset(train_df)
    val_ds = ProxyDataset(val_df)
    train_loader = DataLoader(
        train_ds,
        batch_size=cfg.batch_size,
        shuffle=True,
        collate_fn=collate_proxy_batch,
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=cfg.batch_size,
        shuffle=False,
        collate_fn=collate_proxy_batch,
    )

    model, tokenizer, spec = build_multitask_proxy(
        repo_root=repo_root,
        backbone_id=backbone_id,
        enable_variance_head=True,
        enable_stretch_heads=enable_stretch_heads,
    )
    model = model.to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=cfg.learning_rate,
        weight_decay=cfg.weight_decay,
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer,
        T_max=cfg.max_epochs,
    )

    best_val_loss = float("inf")
    best_state: Optional[Dict[str, torch.Tensor]] = None
    best_epoch = 0
    epochs_without_improve = 0
    history: List[Dict[str, Any]] = []

    for epoch in range(1, cfg.max_epochs + 1):
        model.set_backbone_trainable(epoch > cfg.freeze_backbone_epochs)

        train_loss, train_components = _run_epoch(
            model,
            train_loader,
            tokenizer=tokenizer,
            max_length=spec.max_seq_length,
            device=device,
            optimizer=optimizer,
            loss_weights=cfg.loss_weights,
            enable_variance_loss=True,
            enable_stretch_losses=enable_stretch_heads,
            train=True,
        )
        val_loss, val_components = _run_epoch(
            model,
            val_loader,
            tokenizer=tokenizer,
            max_length=spec.max_seq_length,
            device=device,
            optimizer=None,
            loss_weights=cfg.loss_weights,
            enable_variance_loss=True,
            enable_stretch_losses=enable_stretch_heads,
            train=False,
        )
        history.append(
            {
                "epoch": epoch,
                "train_loss": train_loss,
                "val_loss": val_loss,
                "backbone_trainable": epoch > cfg.freeze_backbone_epochs,
            }
        )
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_epoch = epoch
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            epochs_without_improve = 0
        else:
            epochs_without_improve += 1
        scheduler.step()
        if epochs_without_improve >= cfg.early_stopping_patience:
            break

    if best_state is None:
        best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    model.load_state_dict(best_state)
    model = model.to(device)

    val_texts, val_accounting, val_mpeak = _collect_split_batches(val_loader)
    vram_metrics = evaluate_vram_metrics(
        model,
        tokenizer,
        texts=val_texts,
        accounting_rows=val_accounting,
        y_mpeak=val_mpeak,
        tool_mu_tokens=tool_mu,
        max_length=spec.max_seq_length,
        device=device,
        z_alpha=cfg.z_alpha,
    )
    inference_vram_mb = measure_inference_vram_mb(
        model,
        tokenizer,
        max_length=spec.max_seq_length,
        device=device,
    )
    agent_peak_median = float(frame["y_Mpeak"].median())
    proxy_pct_of_agent_peak = (
        (inference_vram_mb / agent_peak_median) * 100.0 if agent_peak_median > 0 else float("nan")
    )

    output_dir.mkdir(parents=True, exist_ok=True)
    save_file(best_state, str(output_dir / "model.safetensors"))

    metrics: Dict[str, Any] = {
        "agent_llm": agent_llm,
        "backbone": backbone_id,
        "hf_model_id": spec.hf_model_id,
        "best_epoch": best_epoch,
        "best_val_loss": best_val_loss,
        "val_mape": vram_metrics["val_mape"],
        "val_oom_rate": vram_metrics["val_oom_rate"],
        "z_alpha": cfg.z_alpha,
        "inference_vram_mb": inference_vram_mb,
        "agent_median_peak_vram_mb": agent_peak_median,
        "proxy_pct_of_agent_peak_vram": proxy_pct_of_agent_peak,
        "train_rows": len(train_ds),
        "val_rows": len(val_ds),
        "tool_mu_tokens": tool_mu,
        "training_config": {
            "batch_size": cfg.batch_size,
            "learning_rate": cfg.learning_rate,
            "weight_decay": cfg.weight_decay,
            "max_epochs": cfg.max_epochs,
            "early_stopping_patience": cfg.early_stopping_patience,
            "freeze_backbone_epochs": cfg.freeze_backbone_epochs,
            "loss_weights": asdict(cfg.loss_weights),
        },
        "history": history,
        "generated_at_utc": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
    }
    (output_dir / "metrics.json").write_text(
        json.dumps(metrics, indent=2, sort_keys=False) + "\n",
        encoding="utf-8",
    )
    return metrics
