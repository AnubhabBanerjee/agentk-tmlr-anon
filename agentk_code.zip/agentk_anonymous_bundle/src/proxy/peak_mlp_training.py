"""
Train StructuralPeakMLP on frozen Phase-5 proxy outputs ( G3).
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import torch
from safetensors.torch import load_file, save_file
from torch.utils.data import DataLoader, TensorDataset
from transformers import PreTrainedTokenizerBase

from src.proxy.config import ProxyTrainingConfig, load_proxy_training_config
from src.proxy.data import ProxyDataset, compute_tool_mu_tokens, load_proxy_training_frame
from src.proxy.metrics import compute_l_base_batch, mape_percent, oom_rate
from src.proxy.model import MultiTaskProxyModel, build_multitask_proxy
from src.proxy.peak_mlp import (
    PeakMLPConfig,
    StructuralPeakMLP,
    build_structural_feature_matrix,
    closed_form_prior_peaks,
    learned_peaks_from_outputs,
)


def _cache_features(
    model: MultiTaskProxyModel,
    tokenizer: PreTrainedTokenizerBase,
    dataset: ProxyDataset,
    *,
    tool_mu: Dict[str, float],
    max_length: int,
    device: torch.device,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Run frozen proxy forward; return (features, y_mpeak, m_prior)."""
    texts = [dataset[i].user_goal for i in range(len(dataset))]
    accounting = [dataset[i].accounting for i in range(len(dataset))]
    y_mpeak = torch.tensor([dataset[i].y_mpeak for i in range(len(dataset))], dtype=torch.float32)
    model.eval()
    with torch.no_grad():
        batch = model.encode_texts(texts, tokenizer=tokenizer, max_length=max_length, device=device)
        outputs = model.forward(**batch)
        l_base = compute_l_base_batch(texts, tokenizer, max_length=max_length, device=device)
        m_prior = closed_form_prior_peaks(
            outputs, l_base=l_base, accounting_rows=accounting, tool_mu_tokens=tool_mu
        )
        features = build_structural_feature_matrix(
            outputs,
            l_base=l_base,
            accounting_rows=accounting,
            tool_mu_tokens=tool_mu,
            m_prior=m_prior,
        )
    return features.cpu(), y_mpeak, m_prior.cpu()


def train_peak_mlp(
    *,
    repo_root: Path,
    agent_llm: str,
    backbone_id: str,
    output_dir: Optional[Path] = None,
    device: Optional[torch.device] = None,
    proxy_cfg: Optional[ProxyTrainingConfig] = None,
    peak_cfg: Optional[PeakMLPConfig] = None,
) -> Dict[str, Any]:
    """
  Train peak MLP for one (agent, backbone) using frozen proxy weights.

  Writes peak_mlp.safetensors and metrics.json under artifacts/peak_mlp/.
    """
    proxy_cfg = proxy_cfg or load_proxy_training_config(repo_root=repo_root)
    peak_cfg = peak_cfg or PeakMLPConfig()
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    out = output_dir or (repo_root / "artifacts" / "peak_mlp" / agent_llm / backbone_id)
    proxy_weights = repo_root / "artifacts" / "proxies" / agent_llm / backbone_id / "model.safetensors"
    if not proxy_weights.is_file():
        raise FileNotFoundError(f"Train Phase-5 proxy first: {proxy_weights}")

    frame = load_proxy_training_frame(repo_root=repo_root, agent_llm=agent_llm)
    train_df = frame[frame["split"] == "train"]
    val_df = frame[frame["split"] == "val"]
    tool_mu = compute_tool_mu_tokens(train_df)
    train_ds = ProxyDataset(train_df)
    val_ds = ProxyDataset(val_df)

    model, tokenizer, spec = build_multitask_proxy(
        repo_root=repo_root,
        backbone_id=backbone_id,
        enable_variance_head=True,
        enable_stretch_heads=False,
    )
    state = load_file(str(proxy_weights))
    model.load_state_dict(state, strict=True)
    model = model.to(device)
    model.eval()
    for param in model.parameters():
        param.requires_grad = False

    train_x, train_y, train_prior = _cache_features(
        model, tokenizer, train_ds, tool_mu=tool_mu, max_length=spec.max_seq_length, device=device
    )
    val_x, val_y, val_prior = _cache_features(
        model, tokenizer, val_ds, tool_mu=tool_mu, max_length=spec.max_seq_length, device=device
    )

    peak_mlp = StructuralPeakMLP(cfg=peak_cfg).to(device)
    optimizer = torch.optim.AdamW(
        peak_mlp.parameters(), lr=peak_cfg.learning_rate, weight_decay=peak_cfg.weight_decay
    )
    train_loader = DataLoader(
        TensorDataset(train_x, train_y, train_prior),
        batch_size=peak_cfg.batch_size,
        shuffle=True,
    )
    val_loader = DataLoader(
        TensorDataset(val_x, val_y, val_prior), batch_size=peak_cfg.batch_size, shuffle=False
    )

    best_val_mape = float("inf")
    best_state: Optional[Dict[str, torch.Tensor]] = None
    best_epoch = 0
    stale = 0
    history: List[Dict[str, float]] = []

    for epoch in range(1, peak_cfg.max_epochs + 1):
        peak_mlp.train()
        train_loss_sum = 0.0
        n_batches = 0
        for xb, yb, prior_b in train_loader:
            xb = xb.to(device)
            yb = yb.to(device)
            prior_b = prior_b.to(device)
            delta, log_sigma = peak_mlp(xb)
            pred = torch.nn.functional.softplus(prior_b + delta)
            loss = torch.nn.functional.mse_loss(pred, yb)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
            train_loss_sum += float(loss.item())
            n_batches += 1
        train_loss = train_loss_sum / max(n_batches, 1)

        peak_mlp.eval()
        val_preds: List[torch.Tensor] = []
        val_uppers: List[torch.Tensor] = []
        val_trues: List[torch.Tensor] = []
        with torch.no_grad():
            for xb, yb, prior_b in val_loader:
                xb = xb.to(device)
                yb = yb.to(device)
                prior_b = prior_b.to(device)
                delta, log_sigma = peak_mlp(xb)
                pred = torch.nn.functional.softplus(prior_b + delta)
                upper = pred + proxy_cfg.z_alpha * torch.nn.functional.softplus(log_sigma)
                val_preds.append(pred)
                val_uppers.append(upper)
                val_trues.append(yb)
        val_pred = torch.cat(val_preds)
        val_upper = torch.cat(val_uppers)
        val_true = torch.cat(val_trues)
        val_mape = mape_percent(val_true, val_pred)
        val_oom = oom_rate(val_true, val_upper)
        prior_mape = mape_percent(val_true, val_prior.to(device) if val_prior.device != device else val_prior)
        history.append(
            {
                "epoch": float(epoch),
                "train_mse": train_loss,
                "val_mape": val_mape,
                "val_oom_rate": val_oom,
                "prior_only_val_mape": prior_mape,
            }
        )
        if val_mape < best_val_mape:
            best_val_mape = val_mape
            best_epoch = epoch
            best_state = {k: v.detach().cpu().clone() for k, v in peak_mlp.state_dict().items()}
            stale = 0
        else:
            stale += 1
        if stale >= peak_cfg.early_stopping_patience:
            break

    if best_state is None:
        best_state = {k: v.detach().cpu().clone() for k, v in peak_mlp.state_dict().items()}
    peak_mlp.load_state_dict(best_state)
    peak_mlp = peak_mlp.to(device)

    # Full-val metrics with learned_peaks_from_outputs for consistency with inference.
    val_texts = [val_ds[i].user_goal for i in range(len(val_ds))]
    val_acc = [val_ds[i].accounting for i in range(len(val_ds))]
    with torch.no_grad():
        batch = model.encode_texts(
            val_texts, tokenizer=tokenizer, max_length=spec.max_seq_length, device=device
        )
        outputs = model.forward(**batch)
        l_base = compute_l_base_batch(
            val_texts, tokenizer, max_length=spec.max_seq_length, device=device
        )
        m_peak, m_upper = learned_peaks_from_outputs(
            outputs,
            peak_mlp,
            l_base=l_base,
            accounting_rows=val_acc,
            tool_mu_tokens=tool_mu,
            z_alpha=proxy_cfg.z_alpha,
        )
    final_mape = mape_percent(val_y.to(device), m_peak)
    final_oom = oom_rate(val_y.to(device), m_upper)

    out.mkdir(parents=True, exist_ok=True)
    save_file(best_state, str(out / "peak_mlp.safetensors"))
    metrics: Dict[str, Any] = {
        "agent_llm": agent_llm,
        "backbone": backbone_id,
        "forecaster": "structural_peak_mlp_g3",
        "best_epoch": best_epoch,
        "val_mape_learned": final_mape,
        "val_oom_rate_learned": final_oom,
        "val_mape_prior_only": float(history[-1]["prior_only_val_mape"]) if history else float("nan"),
        "z_alpha": proxy_cfg.z_alpha,
        "train_rows": len(train_ds),
        "val_rows": len(val_ds),
        "peak_mlp_config": {
            "hidden_dim": peak_cfg.hidden_dim,
            "num_layers": peak_cfg.num_layers,
            "learning_rate": peak_cfg.learning_rate,
            "max_epochs": peak_cfg.max_epochs,
        },
        "history": history,
        "generated_at_utc": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
    }
    (out / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n", encoding="utf-8")
    return metrics
