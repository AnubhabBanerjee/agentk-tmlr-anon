"""
multi-task proxy loss .

L_total = w_N * NLL_Poisson(λ, y_N)
        + w_T * BCE(p, y_T)
        + w_E * MSE(Ê, y_E)
        + w_var * NLL_Gauss(y_N | μ=λ, σ=σ_N)

Optional stretch:
        + w_c * BCE(p_compile, y_compile)
        + w_nc * masked_BCE(p_correct, y_numcorrect_kbench)
"""

# Python line: from __future__ import annotations
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
from __future__ import annotations

# dataclass stores per-term loss weights and breakdown outputs.
# Python line: from dataclasses import dataclass, field
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
from dataclasses import dataclass, field
# typing annotates optional stretch targets and loss component dicts.
# Python line: from typing import Dict, Optional
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
from typing import Dict, Optional

# torch tensors carry model predictions and supervised targets.
# Python line: import torch
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
import torch
# F implements Poisson / BCE / MSE / Gaussian NLL primitives.
# Python line: import torch.nn.functional as F
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
import torch.nn.functional as F

# PROXY_NODE_TYPES fixes column order when stacking y_T executed flags.
# Python line: from src.proxy.constants import PROXY_NODE_TYPES
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
from src.proxy.constants import PROXY_NODE_TYPES
# ProxyForwardOutput is the prediction bundle from MultiTaskProxyModel.
# Python line: from src.proxy.model import ProxyForwardOutput
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
from src.proxy.model import ProxyForwardOutput


# Python line: @dataclass(frozen=True)
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
@dataclass(frozen=True)
# Python line: class ProxyLossWeights:
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
class ProxyLossWeights:
    """Scalar weights for each supervised head ."""

    # Python line: w_n: float = 1.0
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    w_n: float = 1.0
    # Python line: w_t: float = 1.0
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    w_t: float = 1.0
    # Python line: w_e: float = 1.0
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    w_e: float = 1.0
    # Python line: w_var: float = 1.0
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    w_var: float = 1.0
    # Python line: w_c: float = 0.5
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    w_c: float = 0.5
    # Python line: w_nc: float = 0.5
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    w_nc: float = 0.5


# Python line: @dataclass
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
@dataclass
# Python line: class ProxyTargets:
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
class ProxyTargets:
    """Supervised targets for one proxy minibatch."""

    # Python line: y_n: torch.Tensor
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    y_n: torch.Tensor
    # Python line: y_t_executed: torch.Tensor
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    y_t_tokens: torch.Tensor
    # Python line: y_e: torch.Tensor
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    y_e: torch.Tensor
    # Python line: y_compile: Optional[torch.Tensor] = None
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    y_compile: Optional[torch.Tensor] = None
    # Python line: y_numcorrect_kbench: Optional[torch.Tensor] = None
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    y_numcorrect_kbench: Optional[torch.Tensor] = None
    # Python line: numcorrect_mask: Optional[torch.Tensor] = None
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    numcorrect_mask: Optional[torch.Tensor] = None


# Python line: @dataclass
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
@dataclass
# Python line: class ProxyLossBreakdown:
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
class ProxyLossBreakdown:
    """Weighted and unweighted per-head losses plus L_total."""

    # Python line: total: torch.Tensor
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    total: torch.Tensor
    # Python line: components: Dict[str, torch.Tensor] = field(default_factory=dict)
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    components: Dict[str, torch.Tensor] = field(default_factory=dict)
    # Python line: weighted_components: Dict[str, torch.Tensor] = field(default_factory=dict)
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    weighted_components: Dict[str, torch.Tensor] = field(default_factory=dict)


# Python line: def stack_tool_executed_targets(columns: Dict[str, torch.Tensor]) -> torch.Tensor:
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
def stack_tool_token_targets(columns: Dict[str, torch.Tensor]) -> torch.Tensor:
    """Stack ``y_T_{node}_avg_tokens`` columns in PROXY_NODE_TYPES order → (B, 5)."""
    stacked: list[torch.Tensor] = []
    for node in PROXY_NODE_TYPES:
        key = f"y_T_{node}_avg_tokens"
        if key not in columns:
            raise KeyError(f"Missing tool target column: {key}")
        stacked.append(columns[key].to(dtype=torch.float32))
    return torch.stack(stacked, dim=1)


def stack_tool_executed_targets(columns: Dict[str, torch.Tensor]) -> torch.Tensor:
    """Deprecated pre-F3 helper; kept for imports."""
    stacked: list[torch.Tensor] = []
    for node in PROXY_NODE_TYPES:
        key = f"y_T_{node}_executed"
        if key not in columns:
            raise KeyError(f"Missing tool target column: {key}")
        stacked.append(columns[key].to(dtype=torch.float32))
    return torch.stack(stacked, dim=1)


def tool_mse_loss(tool_tokens_hat: torch.Tensor, y_t_tokens: torch.Tensor) -> torch.Tensor:
    """MSE(T̂, y_T) over five per-node avg completion token targets (F3)."""
    pred = tool_tokens_hat.to(dtype=torch.float32)
    target = y_t_tokens.to(device=pred.device, dtype=pred.dtype)
    return F.mse_loss(pred, target, reduction="mean")


def poisson_nll_loss(lambda_rate: torch.Tensor, y_n: torch.Tensor) -> torch.Tensor:
    """NLL_Poisson(λ, y_N) for step_head ."""
    # Python line: rate = lambda_rate.squeeze(-1)
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    rate = lambda_rate.squeeze(-1)
    # Python line: target = y_n.to(device=rate.device, dtype=rate.dtype)
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    target = y_n.to(device=rate.device, dtype=rate.dtype)
    # Python line: return F.poisson_nll_loss(
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    return F.poisson_nll_loss(
        # Python line: rate,
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        rate,
        # Python line: target,
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        target,
        # Python line: log_input=False,
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        log_input=False,
        # Python line: full=False,
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        full=False,
        # Python line: reduction="mean",
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        reduction="mean",
    # Python line: )
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    )


# Python line: def tool_bce_loss(tool_probs: torch.Tensor, y_t_executed: torch.Tensor) -> torch.Tensor:
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
def tool_bce_loss(tool_probs: torch.Tensor, y_t_executed: torch.Tensor) -> torch.Tensor:
    """BCE(p, y_T) over five node execution indicators ."""
    # Python line: probs = tool_probs.to(dtype=torch.float32)
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    probs = tool_probs.to(dtype=torch.float32)
    # Python line: target = y_t_executed.to(device=probs.device, dtype=probs.dtype)
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    target = y_t_executed.to(device=probs.device, dtype=probs.dtype)
    # Python line: return F.binary_cross_entropy(probs, target, reduction="mean")
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    return F.binary_cross_entropy(probs, target, reduction="mean")


# Python line: def expand_mse_loss(e_hat: torch.Tensor, y_e: torch.Tensor) -> torch.Tensor:
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
def expand_mse_loss(e_hat: torch.Tensor, y_e: torch.Tensor) -> torch.Tensor:
    """MSE(Ê, y_E) for expand_head ."""
    # Python line: pred = e_hat.squeeze(-1)
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    pred = e_hat.squeeze(-1)
    # Python line: target = y_e.to(device=pred.device, dtype=pred.dtype)
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    target = y_e.to(device=pred.device, dtype=pred.dtype)
    # Python line: return F.mse_loss(pred, target, reduction="mean")
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    return F.mse_loss(pred, target, reduction="mean")


# Python line: def gaussian_nll_on_steps(
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
def gaussian_nll_on_steps(
    lambda_rate: torch.Tensor,
    sigma_n: torch.Tensor,
    y_n: torch.Tensor,
) -> torch.Tensor:
    """
    NLL_Gauss(y_N | μ=λ, σ=σ_N) for variance_head .

    Trains σ_N for the upper-bound funnel (eval at N̂ + z_α σ_N).
    """
    # Python line: mean = lambda_rate.squeeze(-1)
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    mean = lambda_rate.squeeze(-1)
    # Python line: std = sigma_n.squeeze(-1)
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    std = sigma_n.squeeze(-1)
    # Python line: target = y_n.to(device=mean.device, dtype=mean.dtype)
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    target = y_n.to(device=mean.device, dtype=mean.dtype)
    # Python line: var = std.pow(2)
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    var = std.pow(2)
    # Python line: return F.gaussian_nll_loss(
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    return F.gaussian_nll_loss(
        # Python line: mean,
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        mean,
        # Python line: target,
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        target,
        # Python line: var,
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        var,
        # Python line: full=False,
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        full=False,
        # Python line: reduction="mean",
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        reduction="mean",
    # Python line: )
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    )


# Python line: def compile_bce_loss(p_compile: torch.Tensor, y_compile: torch.Tensor) -> torch.Tensor:
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
def compile_bce_loss(p_compile: torch.Tensor, y_compile: torch.Tensor) -> torch.Tensor:
    """BCE(p_compile, y_compile) stretch-goal head ."""
    # Python line: probs = p_compile.squeeze(-1).to(dtype=torch.float32)
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    probs = p_compile.squeeze(-1).to(dtype=torch.float32)
    # Python line: target = y_compile.to(device=probs.device, dtype=probs.dtype)
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    target = y_compile.to(device=probs.device, dtype=probs.dtype)
    # Python line: return F.binary_cross_entropy(probs, target, reduction="mean")
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    return F.binary_cross_entropy(probs, target, reduction="mean")


# Python line: def masked_binary_cross_entropy(
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
def masked_binary_cross_entropy(
    probs: torch.Tensor,
    target: torch.Tensor,
    mask: torch.Tensor,
) -> torch.Tensor:
    """
    BCE averaged only over rows where ``mask`` is True.

    Used for y_numcorrect_kbench on KernelBench-slice rows only .
    """
    # Python line: flat_probs = probs.squeeze(-1).to(dtype=torch.float32)
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    flat_probs = probs.squeeze(-1).to(dtype=torch.float32)
    # Python line: flat_target = target.to(device=flat_probs.device, dtype=flat_probs.dtype)
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    flat_target = target.to(device=flat_probs.device, dtype=flat_probs.dtype)
    # Python line: flat_mask = mask.to(device=flat_probs.device).bool()
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    flat_mask = mask.to(device=flat_probs.device).bool()
    # Python line: if flat_mask.sum().item() == 0:
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    if flat_mask.sum().item() == 0:
        # Python line: return flat_probs.new_zeros(())
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
        return flat_probs.new_zeros(())
    # Python line: selected_probs = flat_probs[flat_mask]
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    selected_probs = flat_probs[flat_mask]
    # Python line: selected_target = flat_target[flat_mask]
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    selected_target = flat_target[flat_mask]
    # Python line: return F.binary_cross_entropy(selected_probs, selected_target, reduction="mean")
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    return F.binary_cross_entropy(selected_probs, selected_target, reduction="mean")


# Python line: def compute_proxy_loss(
# proxy loss.
# Implements .cursorrules dense-comment policy for src/ code.
def compute_proxy_loss(
    outputs: ProxyForwardOutput,
    targets: ProxyTargets,
    *,
    weights: ProxyLossWeights | None = None,
    enable_variance_loss: bool = True,
    enable_stretch_losses: bool = False,
) -> ProxyLossBreakdown:
    """
    Combine all loss terms into L_total.

    Primary heads are always active. Variance and stretch terms are gated
    by ``enable_variance_loss`` / ``enable_stretch_losses`` and model outputs.
    """
    # Python line: w = weights if weights is not None else ProxyLossWeights()
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    w = weights if weights is not None else ProxyLossWeights()
    # Python line: components: Dict[str, torch.Tensor] = {}
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    components: Dict[str, torch.Tensor] = {}
    # Python line: weighted_components: Dict[str, torch.Tensor] = {}
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    weighted_components: Dict[str, torch.Tensor] = {}

    # Python line: loss_n = poisson_nll_loss(outputs.lambda_rate, targets.y_n)
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    loss_n = poisson_nll_loss(outputs.lambda_rate, targets.y_n)
    # Python line: components["nll_poisson"] = loss_n
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    components["nll_poisson"] = loss_n
    # Python line: weighted_components["nll_poisson"] = w.w_n * loss_n
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    weighted_components["nll_poisson"] = w.w_n * loss_n

    # Python line: loss_t = tool_bce_loss(outputs.tool_probs, targets.y_t_executed)
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    loss_t = tool_mse_loss(outputs.tool_tokens_hat, targets.y_t_tokens)
    components["mse_tool"] = loss_t
    weighted_components["mse_tool"] = w.w_t * loss_t

    # Python line: loss_e = expand_mse_loss(outputs.e_hat, targets.y_e)
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    loss_e = expand_mse_loss(outputs.e_hat, targets.y_e)
    # Python line: components["mse_expand"] = loss_e
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    components["mse_expand"] = loss_e
    # Python line: weighted_components["mse_expand"] = w.w_e * loss_e
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    weighted_components["mse_expand"] = w.w_e * loss_e

    # Python line: total = weighted_components["nll_poisson"] + weighted_components["bce_tool"] + weighted_components["mse_expand"]
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    total = (
        weighted_components["nll_poisson"]
        + weighted_components["mse_tool"]
        + weighted_components["mse_expand"]
    )

    # Python line: if enable_variance_loss and outputs.sigma_n is not None:
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    if enable_variance_loss and outputs.sigma_n is not None:
        # Python line: loss_var = gaussian_nll_on_steps(outputs.lambda_rate, outputs.sigma_n, targets.y_n)
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        loss_var = gaussian_nll_on_steps(outputs.lambda_rate, outputs.sigma_n, targets.y_n)
        # Python line: components["nll_gauss_n"] = loss_var
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        components["nll_gauss_n"] = loss_var
        # Python line: weighted_components["nll_gauss_n"] = w.w_var * loss_var
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        weighted_components["nll_gauss_n"] = w.w_var * loss_var
        # Python line: total = total + weighted_components["nll_gauss_n"]
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        total = total + weighted_components["nll_gauss_n"]

    # Python line: if enable_stretch_losses and outputs.p_compile is not None and targets.y_compile is not None:
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    if (
        enable_stretch_losses
        and outputs.p_compile is not None
        and targets.y_compile is not None
    ):
        # Python line: loss_c = compile_bce_loss(outputs.p_compile, targets.y_compile)
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        loss_c = compile_bce_loss(outputs.p_compile, targets.y_compile)
        # Python line: components["bce_compile"] = loss_c
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        components["bce_compile"] = loss_c
        # Python line: weighted_components["bce_compile"] = w.w_c * loss_c
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        weighted_components["bce_compile"] = w.w_c * loss_c
        # Python line: total = total + weighted_components["bce_compile"]
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        total = total + weighted_components["bce_compile"]

    # Python line: if (
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    if (
        # Python line: enable_stretch_losses
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        enable_stretch_losses
        # Python line: and outputs.p_numcorrect is not None
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        and outputs.p_numcorrect is not None
        # Python line: and targets.y_numcorrect_kbench is not None
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        and targets.y_numcorrect_kbench is not None
        # Python line: and targets.numcorrect_mask is not None
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        and targets.numcorrect_mask is not None
    # Python line: ):
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    ):
        # Python line: loss_nc = masked_binary_cross_entropy(
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        loss_nc = masked_binary_cross_entropy(
            # Python line: outputs.p_numcorrect,
            # proxy loss.
            # Implements .cursorrules dense-comment policy for src/ code.
            outputs.p_numcorrect,
            # Python line: targets.y_numcorrect_kbench,
            # proxy loss.
            # Implements .cursorrules dense-comment policy for src/ code.
            targets.y_numcorrect_kbench,
            # Python line: targets.numcorrect_mask,
            # proxy loss.
            # Implements .cursorrules dense-comment policy for src/ code.
            targets.numcorrect_mask,
        # Python line: )
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        )
        # Python line: components["bce_numcorrect_masked"] = loss_nc
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        components["bce_numcorrect_masked"] = loss_nc
        # Python line: weighted_components["bce_numcorrect_masked"] = w.w_nc * loss_nc
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        weighted_components["bce_numcorrect_masked"] = w.w_nc * loss_nc
        # Python line: total = total + weighted_components["bce_numcorrect_masked"]
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        total = total + weighted_components["bce_numcorrect_masked"]

    # Python line: return ProxyLossBreakdown(
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    return ProxyLossBreakdown(
        # Python line: total=total,
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        total=total,
        # Python line: components=components,
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        components=components,
        # Python line: weighted_components=weighted_components,
        # proxy loss.
        # Implements .cursorrules dense-comment policy for src/ code.
        weighted_components=weighted_components,
    # Python line: )
    # proxy loss.
    # Implements .cursorrules dense-comment policy for src/ code.
    )
