"""
Plan B G3 — learned peak VRAM forecaster over structural proxy outputs (N, T, E).

The closed-form Q4_K_M peak is fed as an interpretable analytical prior; a small MLP
predicts a residual correction and upper-bound scale.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence

import torch
import torch.nn as nn
from safetensors.torch import load_file

from src.proxy.constants import PROXY_NODE_TYPES
from src.proxy.forecast import aggregated_tool_tokens, closed_form_peak_mb
from src.proxy.model import ProxyForwardOutput

# Input feature layout (fixed order for checkpoint compatibility).
FEATURE_NAMES: tuple[str, ...] = (
    "n_hat",
    "sigma_n",
    "e_hat",
    "expected_tool_tokens",
    "l_base",
    "m_prior_mb",
    "m_weights_mb",
    "m_act_mb",
    "n_layers",
    "n_kv_heads",
    "d_head",
    "b_precision",
    *tuple(f"tool_tokens_{node}" for node in PROXY_NODE_TYPES),
)

INPUT_DIM: int = len(FEATURE_NAMES)


@dataclass
class PeakMLPConfig:
    """Hyperparameters for the structural peak MLP."""

    hidden_dim: int = 64
    num_layers: int = 2
    dropout: float = 0.1
    learning_rate: float = 1e-3
    weight_decay: float = 1e-4
    batch_size: int = 64
    max_epochs: int = 200
    early_stopping_patience: int = 15


class StructuralPeakMLP(nn.Module):
    """
    MLP: structural features (N̂, T̂, Ê, prior) → (Δ_peak, log σ_upper).

    m_peak = softplus(m_prior + Δ_peak) keeps peaks positive while anchoring to prior.
    """

    def __init__(self, *, input_dim: int = INPUT_DIM, cfg: Optional[PeakMLPConfig] = None) -> None:
        super().__init__()
        self.cfg = cfg or PeakMLPConfig()
        layers: List[nn.Module] = []
        in_dim = input_dim
        for _ in range(self.cfg.num_layers):
            layers.append(nn.Linear(in_dim, self.cfg.hidden_dim))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(self.cfg.dropout))
            in_dim = self.cfg.hidden_dim
        self.trunk = nn.Sequential(*layers)
        self.head = nn.Linear(in_dim, 2)

    def forward(self, features: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Return (delta_peak_mb, log_sigma_upper_mb) per row."""
        out = self.head(self.trunk(features))
        return out[:, 0], out[:, 1]


def build_structural_feature_matrix(
    outputs: ProxyForwardOutput,
    *,
    l_base: torch.Tensor,
    accounting_rows: Sequence[Dict[str, Any]],
    tool_mu_tokens: Mapping[str, float],
    m_prior: torch.Tensor,
) -> torch.Tensor:
    """Stack per-row features for the peak MLP (batch × INPUT_DIM)."""
    n_hat = outputs.lambda_rate.squeeze(-1)
    e_hat = outputs.e_hat.squeeze(-1)
    if outputs.sigma_n is None:
        sigma_n = torch.zeros_like(n_hat)
    else:
        sigma_n = outputs.sigma_n.squeeze(-1)
    tool_term = aggregated_tool_tokens(outputs.tool_tokens_hat)
    rows: List[List[float]] = []
    for i, acc in enumerate(accounting_rows):
        row = [
            float(n_hat[i].item()),
            float(sigma_n[i].item()),
            float(e_hat[i].item()),
            float(tool_term[i].item()),
            float(l_base[i].item()),
            float(m_prior[i].item()),
            float(acc["M_weights_reported_mb"]),
            float(acc["M_act_mb"]),
            float(acc["n_layers"]),
            float(acc["n_kv_heads"]),
            float(acc["d_head"]),
            float(acc["b_precision"]),
        ]
        for j in range(len(PROXY_NODE_TYPES)):
            row.append(float(outputs.tool_tokens_hat[i, j].item()))
        rows.append(row)
    return torch.tensor(rows, dtype=torch.float32, device=n_hat.device)


def closed_form_prior_peaks(
    outputs: ProxyForwardOutput,
    *,
    l_base: torch.Tensor,
    accounting_rows: Sequence[Dict[str, Any]],
    tool_mu_tokens: Mapping[str, float],
) -> torch.Tensor:
    """Analytical prior M_peak (one value per row) from proxy structure."""
    n_hat = outputs.lambda_rate.squeeze(-1)
    e_hat = outputs.e_hat.squeeze(-1)
    tool_term = aggregated_tool_tokens(outputs.tool_tokens_hat)
    priors: List[torch.Tensor] = []
    for i, acc in enumerate(accounting_rows):
        priors.append(
            closed_form_peak_mb(
                n_steps=n_hat[i : i + 1],
                e_hat=e_hat[i : i + 1],
                l_base=l_base[i : i + 1],
                expected_tool_tokens=tool_term[i : i + 1],
                accounting=acc,
            )
        )
    return torch.cat(priors, dim=0)


def learned_peaks_from_outputs(
    outputs: ProxyForwardOutput,
    peak_mlp: StructuralPeakMLP,
    *,
    l_base: torch.Tensor,
    accounting_rows: Sequence[Dict[str, Any]],
    tool_mu_tokens: Mapping[str, float],
    z_alpha: float,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Learned peak forecaster: prior + MLP residual; upper = peak + z·σ.
    """
    m_prior = closed_form_prior_peaks(
        outputs,
        l_base=l_base,
        accounting_rows=accounting_rows,
        tool_mu_tokens=tool_mu_tokens,
    )
    features = build_structural_feature_matrix(
        outputs,
        l_base=l_base,
        accounting_rows=accounting_rows,
        tool_mu_tokens=tool_mu_tokens,
        m_prior=m_prior,
    )
    delta, log_sigma = peak_mlp(features)
    m_peak = torch.nn.functional.softplus(m_prior + delta)
    m_upper = m_peak + float(z_alpha) * torch.nn.functional.softplus(log_sigma)
    return m_peak, m_upper


def peak_mlp_artifact_dir(repo_root: Path, agent_llm: str, backbone_id: str) -> Path:
    """artifacts/peak_mlp/{agent}/{backbone}/"""
    return repo_root / "artifacts" / "peak_mlp" / agent_llm / backbone_id


def peak_mlp_weights_path(repo_root: Path, agent_llm: str, backbone_id: str) -> Path:
    return peak_mlp_artifact_dir(repo_root, agent_llm, backbone_id) / "peak_mlp.safetensors"


def peak_mlp_metrics_path(repo_root: Path, agent_llm: str, backbone_id: str) -> Path:
    return peak_mlp_artifact_dir(repo_root, agent_llm, backbone_id) / "metrics.json"


def load_peak_mlp_if_present(
    repo_root: Path,
    agent_llm: str,
    backbone_id: str,
    *,
    device: torch.device,
    cfg: Optional[PeakMLPConfig] = None,
) -> Optional[StructuralPeakMLP]:
    """Load trained peak MLP weights when artifacts/peak_mlp/... exists."""
    path = peak_mlp_weights_path(repo_root, agent_llm, backbone_id)
    if not path.is_file():
        return None
    model = StructuralPeakMLP(cfg=cfg or PeakMLPConfig())
    state = load_file(str(path))
    model.load_state_dict(state, strict=True)
    model = model.to(device)
    model.eval()
    return model


def peaks_from_proxy_outputs(
    outputs: ProxyForwardOutput,
    *,
    l_base: torch.Tensor,
    accounting_rows: Sequence[Dict[str, Any]],
    tool_mu_tokens: Mapping[str, float],
    z_alpha: float,
    peak_mlp: Optional[StructuralPeakMLP] = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    B4 peak path: learned MLP when ``peak_mlp`` is provided, else closed-form only.
    """
    if peak_mlp is not None:
        return learned_peaks_from_outputs(
            outputs,
            peak_mlp,
            l_base=l_base,
            accounting_rows=accounting_rows,
            tool_mu_tokens=tool_mu_tokens,
            z_alpha=z_alpha,
        )
    from src.proxy.forecast import closed_form_peaks_from_outputs

    return closed_form_peaks_from_outputs(
        outputs,
        l_base=l_base,
        accounting_rows=accounting_rows,
        tool_mu_tokens=tool_mu_tokens,
        z_alpha=z_alpha,
    )
