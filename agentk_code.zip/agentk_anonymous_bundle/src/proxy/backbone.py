"""
load Hugging Face encoder backbones from configs/proxy_backbones.yaml.
"""

# Python line: from __future__ import annotations
# proxy backbone loader.
# Implements .cursorrules dense-comment policy for src/ code.
from __future__ import annotations

# dataclass holds resolved backbone metadata for model construction.
# Python line: from dataclasses import dataclass
# proxy backbone loader.
# Implements .cursorrules dense-comment policy for src/ code.
from dataclasses import dataclass
# Path resolves repo configs and optional local checkpoint paths.
# Python line: from pathlib import Path
# proxy backbone loader.
# Implements .cursorrules dense-comment policy for src/ code.
from pathlib import Path
# typing annotates YAML-derived backbone configuration dicts.
# Python line: from typing import Any, Dict, Tuple
# proxy backbone loader.
# Implements .cursorrules dense-comment policy for src/ code.
from typing import Any, Dict, Tuple

# yaml loads configs/proxy_backbones.yaml backbone entries.
# Python line: import yaml
# proxy backbone loader.
# Implements .cursorrules dense-comment policy for src/ code.
import yaml
# AutoModel and AutoTokenizer instantiate HF encoders per backbone id.
# Python line: from transformers import AutoModel, AutoTokenizer, PreTrainedModel, PreTrainedTokenizerBase
# proxy backbone loader.
# Implements .cursorrules dense-comment policy for src/ code.
from transformers import AutoModel, AutoTokenizer, PreTrainedModel, PreTrainedTokenizerBase


# Python line: @dataclass(frozen=True)
# proxy backbone loader.
# Implements .cursorrules dense-comment policy for src/ code.
@dataclass(frozen=True)
# Python line: class ProxyBackboneSpec:
# proxy backbone loader.
# Implements .cursorrules dense-comment policy for src/ code.
class ProxyBackboneSpec:
    """Resolved backbone metadata from proxy_backbones.yaml."""

    # Python line: backbone_id: str
    # proxy backbone loader.
    # Implements .cursorrules dense-comment policy for src/ code.
    backbone_id: str
    # Python line: hf_model_id: str
    # proxy backbone loader.
    # Implements .cursorrules dense-comment policy for src/ code.
    hf_model_id: str
    # Python line: hidden_size: int
    # proxy backbone loader.
    # Implements .cursorrules dense-comment policy for src/ code.
    hidden_size: int
    # Python line: max_seq_length: int
    # proxy backbone loader.
    # Implements .cursorrules dense-comment policy for src/ code.
    max_seq_length: int


# Python line: def load_proxy_backbone_spec(
# proxy backbone loader.
# Implements .cursorrules dense-comment policy for src/ code.
def load_proxy_backbone_spec(
    *,
    repo_root: Path,
    backbone_id: str,
) -> ProxyBackboneSpec:
    """Read one backbone entry from configs/proxy_backbones.yaml."""
    # Python line: cfg_path = repo_root / "configs" / "proxy_backbones.yaml"
    # proxy backbone loader.
    # Implements .cursorrules dense-comment policy for src/ code.
    cfg_path = repo_root / "configs" / "proxy_backbones.yaml"
    # Python line: data = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    # proxy backbone loader.
    # Implements .cursorrules dense-comment policy for src/ code.
    data = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    # Python line: backbones: Dict[str, Any] = data.get("backbones", {})
    # proxy backbone loader.
    # Implements .cursorrules dense-comment policy for src/ code.
    backbones: Dict[str, Any] = data.get("backbones", {})
    # Python line: if backbone_id not in backbones:
    # proxy backbone loader.
    # Implements .cursorrules dense-comment policy for src/ code.
    if backbone_id not in backbones:
        # Python line: raise KeyError(f"unknown backbone_id={backbone_id!r} in {cfg_path}")
        # proxy backbone loader.
        # Implements .cursorrules dense-comment policy for src/ code.
        raise KeyError(f"unknown backbone_id={backbone_id!r} in {cfg_path}")
    # Python line: row = backbones[backbone_id]
    # proxy backbone loader.
    # Implements .cursorrules dense-comment policy for src/ code.
    row = backbones[backbone_id]
    # Python line: return ProxyBackboneSpec(
    # proxy backbone loader.
    # Implements .cursorrules dense-comment policy for src/ code.
    return ProxyBackboneSpec(
        # Python line: backbone_id=backbone_id,
        # proxy backbone loader.
        # Implements .cursorrules dense-comment policy for src/ code.
        backbone_id=backbone_id,
        # Python line: hf_model_id=str(row["hf_model_id"]),
        # proxy backbone loader.
        # Implements .cursorrules dense-comment policy for src/ code.
        hf_model_id=str(row["hf_model_id"]),
        # Python line: hidden_size=int(row["hidden_size"]),
        # proxy backbone loader.
        # Implements .cursorrules dense-comment policy for src/ code.
        hidden_size=int(row["hidden_size"]),
        # Python line: max_seq_length=int(row["max_seq_length"]),
        # proxy backbone loader.
        # Implements .cursorrules dense-comment policy for src/ code.
        max_seq_length=int(row["max_seq_length"]),
    # Python line: )
    # proxy backbone loader.
    # Implements .cursorrules dense-comment policy for src/ code.
    )


# Python line: def load_proxy_backbone_and_tokenizer(
# proxy backbone loader.
# Implements .cursorrules dense-comment policy for src/ code.
def load_proxy_backbone_and_tokenizer(
    *,
    spec: ProxyBackboneSpec,
) -> Tuple[PreTrainedModel, PreTrainedTokenizerBase]:
    """Download/load HF encoder + tokenizer for a proxy backbone spec."""
    # Python line: tokenizer = AutoTokenizer.from_pretrained(spec.hf_model_id)
    # proxy backbone loader.
    # Implements .cursorrules dense-comment policy for src/ code.
    tokenizer = AutoTokenizer.from_pretrained(spec.hf_model_id)
    model = AutoModel.from_pretrained(spec.hf_model_id, use_safetensors=True)
    # Python line: return model, tokenizer
    # proxy backbone loader.
    # Implements .cursorrules dense-comment policy for src/ code.
    return model, tokenizer
