"""
shared constants for the multi-task VRAM proxy architecture.

Five AgentK node types align with ``y_T_*`` label columns and ``tool_head`` outputs.
"""

# Python line: from __future__ import annotations
# proxy constants.
# Implements .cursorrules dense-comment policy for src/ code.
from __future__ import annotations

# typing provides immutable tuple typing for node-name lists.
# Python line: from typing import Tuple
# proxy constants.
# Implements .cursorrules dense-comment policy for src/ code.
from typing import Tuple

# Canonical node order for tool_head outputs (guide §5.1: Linear(d → 5)).
# Python line: PROXY_NODE_TYPES: Tuple[str, ...] = (
# proxy constants.
# Implements .cursorrules dense-comment policy for src/ code.
PROXY_NODE_TYPES: Tuple[str, ...] = (
    # Python line: "planner",
    # proxy constants.
    # Implements .cursorrules dense-comment policy for src/ code.
    "planner",
    # Python line: "analyzer",
    # proxy constants.
    # Implements .cursorrules dense-comment policy for src/ code.
    "analyzer",
    # Python line: "optimizer",
    # proxy constants.
    # Implements .cursorrules dense-comment policy for src/ code.
    "optimizer",
    # Python line: "generator",
    # proxy constants.
    # Implements .cursorrules dense-comment policy for src/ code.
    "generator",
    # Python line: "critic",
    # proxy constants.
    # Implements .cursorrules dense-comment policy for src/ code.
    "critic",
# Python line: )
# proxy constants.
# Implements .cursorrules dense-comment policy for src/ code.
)

# Number of tool_head outputs; must match len(PROXY_NODE_TYPES).
# Python line: NUM_TOOL_HEAD_OUTPUTS: int = len(PROXY_NODE_TYPES)
# proxy constants.
# Implements .cursorrules dense-comment policy for src/ code.
NUM_TOOL_HEAD_OUTPUTS: int = len(PROXY_NODE_TYPES)

# Default system prompt when none is supplied at inference (CUDA agent framing).
# Python line: DEFAULT_SYSTEM_PROMPT: str = (
# proxy constants.
# Implements .cursorrules dense-comment policy for src/ code.
DEFAULT_SYSTEM_PROMPT: str = (
    # Python line: "You are a CUDA kernel optimization agent. "
    # proxy constants.
    # Implements .cursorrules dense-comment policy for src/ code.
    "You are a CUDA kernel optimization agent. "
    # Python line: "Plan, analyze, optimize, generate, and critique GPU kernels."
    # proxy constants.
    # Implements .cursorrules dense-comment policy for src/ code.
    "Plan, analyze, optimize, generate, and critique GPU kernels."
# Python line: )
# proxy constants.
# Implements .cursorrules dense-comment policy for src/ code.
)
