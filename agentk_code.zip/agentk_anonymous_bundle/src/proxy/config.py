"""
Phase 5.3 — load proxy training hyperparameters from configs/proxy_backbones.yaml.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict

import yaml

from src.proxy.loss import ProxyLossWeights


@dataclass(frozen=True)
class ProxyTrainingConfig:
    """Resolved training block from proxy_backbones.yaml."""

    batch_size: int
    learning_rate: float
    weight_decay: float
    max_epochs: int
    early_stopping_patience: int
    freeze_backbone_epochs: int
    loss_weights: ProxyLossWeights
    z_alpha: float = 1.96


def load_proxy_training_config(*, repo_root: Path) -> ProxyTrainingConfig:
    """Read the ``training`` section from configs/proxy_backbones.yaml."""
    cfg_path = repo_root / "configs" / "proxy_backbones.yaml"
    data: Dict[str, Any] = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    block = data.get("training", {})
    lw = block.get("loss_weights", {})
    return ProxyTrainingConfig(
        batch_size=int(block.get("batch_size", 32)),
        learning_rate=float(block.get("learning_rate", 2.0e-5)),
        weight_decay=float(block.get("weight_decay", 0.01)),
        max_epochs=int(block.get("max_epochs", 20)),
        early_stopping_patience=int(block.get("early_stopping_patience", 3)),
        freeze_backbone_epochs=int(block.get("freeze_backbone_epochs", 2)),
        loss_weights=ProxyLossWeights(
            w_n=float(lw.get("steps", 1.0)),
            w_t=float(lw.get("tools", 1.0)),
            w_e=float(lw.get("expansion", 1.0)),
            w_var=float(lw.get("variance", 1.0)),
            w_c=float(lw.get("compile", 0.5)),
            w_nc=float(lw.get("numcorrect", 0.5)),
        ),
        z_alpha=float(block.get("z_alpha", 1.96)),
    )
