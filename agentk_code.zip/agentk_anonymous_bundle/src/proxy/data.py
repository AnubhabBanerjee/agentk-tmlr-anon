"""
proxy training dataset: labels + prompts + trace accounting metadata.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import pandas as pd
import torch
from torch.utils.data import Dataset

from src.proxy.constants import PROXY_NODE_TYPES
from src.proxy.loss import ProxyTargets, stack_tool_token_targets

AGENT_LABEL_FILES: Dict[str, str] = {
    "qwen2.5-coder-7b": "qwen",
    "phi-4-mini": "phi",
    "mistral-7b-instruct-v0.3": "mistral",
    "qwen2.5-coder-14b": "qwen14b",
}


def _parse_json_field(raw: Any) -> Any:
    """Parse JSON string columns from parquet; pass through dict/list."""
    if raw is None or (isinstance(raw, float) and pd.isna(raw)):
        return None
    if isinstance(raw, (dict, list)):
        return raw
    if isinstance(raw, str) and raw.strip():
        return json.loads(raw)
    return None


def load_prompt_text_map(repo_root: Path, *, prompts_path: Optional[Path] = None) -> Dict[str, str]:
    """Map prompt_id → user goal text from the merged prompts JSONL."""
    path = prompts_path or (repo_root / "data" / "prompts" / "all.jsonl")
    out: Dict[str, str] = {}
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            row = json.loads(line)
            out[str(row["id"])] = str(row["prompt"])
    return out


def load_proxy_training_frame(
    *,
    repo_root: Path,
    agent_llm: str,
) -> pd.DataFrame:
    """
    Join labels shard, trace index accounting, and prompt text for one agent LLM.
    """
    if agent_llm not in AGENT_LABEL_FILES:
        raise KeyError(f"Unknown agent_llm={agent_llm!r}")
    shard = AGENT_LABEL_FILES[agent_llm]
    labels = pd.read_parquet(repo_root / "data" / "labels" / f"{shard}.parquet")
    index = pd.read_parquet(repo_root / "data" / "traces" / "index.parquet")
    index = index[index["agent_llm"] == agent_llm][
        [
            "prompt_id",
            "closed_form_accounting_json",
            "L_peak_tokens",
            "M_peak_true",
            "N_nodes_true",
        ]
    ]
    prompts = load_prompt_text_map(repo_root)
    merged = labels.merge(index, on="prompt_id", how="left", suffixes=("", "_idx"))
    merged["user_goal"] = merged["prompt_id"].map(prompts)
    missing = merged["user_goal"].isna().sum()
    if missing:
        raise RuntimeError(f"{missing} label rows missing prompt text in all.jsonl")
    return merged


def compute_tool_mu_tokens(train_df: pd.DataFrame) -> Dict[str, float]:
    """
    Historical mean per-node completion tokens (train split).

    Retained for logging/metadata; F3 closed-form uses direct ``tool_tokens_hat``.
    """
    mu: Dict[str, float] = {}
    for node in PROXY_NODE_TYPES:
        tok_col = f"y_T_{node}_avg_tokens"
        mu[node] = float(train_df[tok_col].mean()) if tok_col in train_df.columns else 0.0
    return mu


@dataclass(frozen=True)
class ProxySample:
    """One training/eval row after joins."""

    user_goal: str
    split: str
    prompt_id: str
    y_n: float
    y_e: float
    y_mpeak: float
    y_t_tokens: Tuple[float, ...]
    accounting: Dict[str, Any]
    y_compile: Optional[float] = None
    y_numcorrect_kbench: Optional[float] = None
    numcorrect_mask: bool = False


class ProxyDataset(Dataset):
    """PyTorch dataset over joined proxy training rows."""

    def __init__(self, frame: pd.DataFrame) -> None:
        self._rows: List[ProxySample] = []
        for _, row in frame.iterrows():
            tokens = tuple(float(row[f"y_T_{node}_avg_tokens"]) for node in PROXY_NODE_TYPES)
            acc = _parse_json_field(row.get("closed_form_accounting_json"))
            if not acc:
                continue
            num = row.get("y_numcorrect_kbench")
            has_num = pd.notna(num)
            self._rows.append(
                ProxySample(
                    user_goal=str(row["user_goal"]),
                    split=str(row["split"]),
                    prompt_id=str(row["prompt_id"]),
                    y_n=float(row["y_N"]),
                    y_e=float(row["y_E"]),
                    y_mpeak=float(row["y_Mpeak"]),
                    y_t_tokens=tokens,
                    accounting=dict(acc),
                    y_compile=float(bool(row["y_compile"])),
                    y_numcorrect_kbench=float(bool(num)) if has_num else None,
                    numcorrect_mask=bool(has_num),
                )
            )

    def __len__(self) -> int:
        return len(self._rows)

    def __getitem__(self, index: int) -> ProxySample:
        return self._rows[index]


def collate_proxy_batch(samples: Sequence[ProxySample]) -> Tuple[List[str], ProxyTargets, List[Dict[str, Any]], torch.Tensor, torch.Tensor]:
    """Collate ProxySample list into texts, targets, accounting list, mpeak, l_base placeholder."""
    texts = [s.user_goal for s in samples]
    tool_cols = {
        f"y_T_{node}_avg_tokens": torch.tensor(
            [s.y_t_tokens[i] for s in samples], dtype=torch.float32
        )
        for i, node in enumerate(PROXY_NODE_TYPES)
    }
    y_num = [s.y_numcorrect_kbench for s in samples]
    has_num = [s.numcorrect_mask for s in samples]
    targets = ProxyTargets(
        y_n=torch.tensor([s.y_n for s in samples], dtype=torch.float32),
        y_t_tokens=stack_tool_token_targets(tool_cols),
        y_e=torch.tensor([s.y_e for s in samples], dtype=torch.float32),
        y_compile=torch.tensor([s.y_compile or 0.0 for s in samples], dtype=torch.float32),
        y_numcorrect_kbench=torch.tensor(
            [v if v is not None else 0.0 for v in y_num], dtype=torch.float32
        ),
        numcorrect_mask=torch.tensor(has_num, dtype=torch.bool),
    )
    accounting = [s.accounting for s in samples]
    y_mpeak = torch.tensor([s.y_mpeak for s in samples], dtype=torch.float32)
    return texts, targets, accounting, y_mpeak, targets.y_n
