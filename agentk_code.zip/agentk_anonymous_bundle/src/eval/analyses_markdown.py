"""
Phase 7 §7.3 — render three self-contained markdown analyses to paper/analyses/.
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List

import pandas as pd

from src.eval.cost_quality_pareto import BUDGET_GB

AGENT_LABELS: Dict[str, str] = {
    "qwen2.5-coder-7b": "Qwen2.5-Coder-7B",
    "qwen2.5-coder-14b": "Qwen2.5-Coder-14B",
    "phi-4-mini": "Phi-4-mini",
    "mistral-7b-instruct-v0.3": "Mistral-7B-Instruct",
}


def _ts() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


def _fmt(x: float, digits: int = 3) -> str:
    if x is None or (isinstance(x, float) and pd.isna(x)):
        return "—"
    return f"{float(x):.{digits}f}"


def render_7_3a_markdown(joint: pd.DataFrame, repo_root: Path) -> str:
    """§7.3.a empirical joint distribution analysis."""
    lines: List[str] = [
        "# §7.3.a — Empirical joint distribution: peak VRAM vs correctness",
        "",
        f"- **Generated:** {_ts()}",
        "- **Data:** `data/traces/index.parquet` + `data/correctness/kernelbench.parquet`",
        "- **Scope:** Phase 3 trace outputs (no additional tracing).",
        "",
        "## Question",
        "",
        "Does observed peak VRAM correlate with task correctness, and is that relationship",
        "mediated by compile retry count?",
        "",
        "## Methods",
        "",
        "- **Left axis (all prompts):** `M_peak_true` vs `compile_success` (binary).",
        "- **Right axis (KernelBench):** `M_peak_true` vs `numerical_correct_kbench` where the",
        "  KernelBench harness produced a label (compile-successful runs only).",
        "- **Point-biserial correlation** $r_{pb}$ per agent LLM.",
        "- **Partial correlation** $r(M_{peak}, \\mathrm{correct} \\mid n_{\\mathrm{compile\\_attempts}})$",
        "  via residualization on retry count.",
        "",
        "## Point-biserial correlation ($r_{pb}$)",
        "",
        "### compile_success (all prompt slices)",
        "",
        "| Agent | n | $r_{pb}$ | p-value | partial $r$ given attempts |",
        "|-------|--:|--------:|--------:|---------------------------:|",
    ]
    compile_pb = joint[
        (joint["label"] == "compile_success")
        & (joint["metric"] == "point_biserial_r")
        & (joint["subset"] == "all_prompts")
    ]
    for _, row in compile_pb.iterrows():
        agent = AGENT_LABELS.get(str(row["agent_llm"]), row["agent_llm"])
        lines.append(
            f"| {agent} | {int(row['n'])} | {_fmt(row['value'])} | {_fmt(row['extra'], 4)} "
            f"| {_fmt(row['partial_r_given_attempts'])} |"
        )
    lines.extend(
        [
            "",
            "### numerical_correct_kbench (KernelBench, labeled rows only)",
            "",
            "| Agent | n labeled | $r_{pb}$ | p-value | partial $r$ given attempts |",
            "|-------|----------:|--------:|--------:|---------------------------:|",
        ]
    )
    num_pb = joint[
        (joint["label"] == "numerical_correct_kbench")
        & (joint["metric"] == "point_biserial_r")
        & (joint["subset"] == "kernelbench_labeled")
    ]
    for _, row in num_pb.iterrows():
        agent = AGENT_LABELS.get(str(row["agent_llm"]), row["agent_llm"])
        lines.append(
            f"| {agent} | {int(row['n'])} | {_fmt(row['value'])} | {_fmt(row['extra'], 4)} "
            f"| {_fmt(row['partial_r_given_attempts'])} |"
        )
    if num_pb.empty or (num_pb["n"] == 0).all():
        lines.extend(
            [
                "",
                "> **Plan C note:** No KernelBench rows reached numerical comparison in v2; "
                "the compile-success axis (left panel / §7.3.b) is the operative correctness proxy.",
            ]
        )
    lines.extend(
        [
            "",
            "## Conditional $M_{peak}$ (MB)",
            "",
            "### Given compile_success",
            "",
            "| Agent | stratum | n | mean | std |",
            "|-------|---------|--:|-----:|----:|",
        ]
    )
    cond_compile = joint[
        (joint["label"] == "compile_success")
        & joint["metric"].str.startswith("conditional_")
    ]
    for _, row in cond_compile.iterrows():
        agent = AGENT_LABELS.get(str(row["agent_llm"]), row["agent_llm"])
        stratum = str(row["metric"]).replace("conditional_", "")
        lines.append(
            f"| {agent} | {stratum} | {int(row['n'])} | {_fmt(row['value'], 1)} | {_fmt(row['extra'], 1)} |"
        )
    lines.extend(
        [
            "",
            "### Given numerical_correct_kbench (labeled KernelBench rows)",
            "",
            "| Agent | stratum | n | mean | std |",
            "|-------|---------|--:|-----:|----:|",
        ]
    )
    cond_num = joint[
        (joint["label"] == "numerical_correct_kbench")
        & joint["metric"].str.startswith("conditional_")
    ]
    for _, row in cond_num.iterrows():
        agent = AGENT_LABELS.get(str(row["agent_llm"]), row["agent_llm"])
        stratum = str(row["metric"]).replace("conditional_", "")
        lines.append(
            f"| {agent} | {stratum} | {int(row['n'])} | {_fmt(row['value'], 1)} | {_fmt(row['extra'], 1)} |"
        )
    lines.extend(
        [
            "",
            "## Interpretation",
            "",
        ]
    )
    low_compile = compile_pb[compile_pb["n"] > 0]
    if not low_compile.empty and (low_compile["value"].abs() < 0.05).all():
        lines.append(
            "- Point-biserial correlations are near zero across agents on this trace batch. "
            "Peak VRAM does **not** linearly separate compile-successful from failing runs."
        )
    lines.append(
        "- Compile-success base rates are very low on this batch (especially Qwen), so "
        "$r_{pb}$ is often undefined or unstable; treat numerical KernelBench correlations "
        "with extreme caution (few labeled rows)."
    )
    lines.append(
        "- Compare raw $r_{pb}$ with partial $r$ given `n_compile_attempts`: a collapse "
        "would indicate retries mediate any VRAM–correctness association."
    )
    lines.extend(
        [
            "",
            "## Figures",
            "",
            "Scatter / density panels: `paper/figures/fig7a_vram_correctness_joint.pdf` (if generated).",
            "",
            "## Reproduce",
            "",
            "```bash",
            "make analyses",
            "```",
            "",
        ]
    )
    return "\n".join(lines)


def render_7_3b_markdown(strata: pd.DataFrame) -> str:
    """§7.3.b proxy calibration by correctness stratum."""
    methods = sorted(strata["method"].unique().tolist()) if not strata.empty else ["B2", "B5"]
    method_list = ", ".join(methods)
    lines: List[str] = [
        "# §7.3.b — Proxy calibration by correctness stratum",
        "",
        f"- **Generated:** {_ts()}",
        "- **Split:** test ($z_\\alpha = 1.96$)",
        f"- **Methods:** {method_list}",
        "",
        "## Question",
        "",
        "Does our proxy forecast peak VRAM equally well on correct vs incorrect runs?",
        "",
        "## Per-stratum metrics",
        "",
    ]
    detail = strata[strata["stratum"].isin(["correct", "incorrect"])].copy()
    for label in ["compile_success", "numerical_correct_kbench"]:
        sub_label = detail[detail["correctness_label"] == label]
        if sub_label.empty:
            continue
        lines.append(f"### Label: `{label}`")
        lines.append("")
        lines.append(
            "| Agent | Method | Stratum | n | MAPE (%) | MAE (MB) | OOM rate | OAW (% ceil.) |"
        )
        lines.append("|-------|--------|---------|--:|---------:|---------:|---------:|---------:|")
        sub = detail[detail["correctness_label"] == label].sort_values(
            ["agent_llm", "method", "stratum"]
        )
        for _, row in sub.iterrows():
            agent = AGENT_LABELS.get(str(row["agent_llm"]), row["agent_llm"])
            lines.append(
                f"| {agent} | {row['method']} | {row['stratum']} | {int(row['n_rows'])} "
                f"| {_fmt(row['mape_pct'], 2)} | {_fmt(row['mae_peak_mb'], 1)} "
                f"| {_fmt(row['oom_rate'], 3)} | {_fmt(row['oaw_pct_ceiling'], 2)} |"
            )
        lines.append("")
    lines.extend(
        [
            "## MAPE gap (incorrect − correct) and significance",
            "",
            "Strata are **disjoint** prompt sets; we test |APE| differences with a two-sided",
            "Mann–Whitney U test (not a paired sign test).",
            "",
            "| Agent | Method | Label | gap (pp) | p-value | disclosure (>5 pp)? |",
            "|-------|--------|-------|---------:|--------:|:-------------------:|",
        ]
    )
    gaps = strata[strata["stratum"] == "gap_summary"].copy()
    for _, row in gaps.iterrows():
        agent = AGENT_LABELS.get(str(row["agent_llm"]), row["agent_llm"])
        gap = float(row.get("mape_gap_pp", row["mape_pct"]))
        p = row.get("stratum_test_p_value", float("nan"))
        disclose = "yes" if pd.notna(gap) and abs(gap) > 5.0 else "no"
        lines.append(
            f"| {agent} | {row['method']} | {row['correctness_label']} "
            f"| {_fmt(gap, 2)} | {_fmt(p, 4)} | {disclose} |"
        )
    lines.extend(
        [
            "",
            "## Reviewer-facing template (B2, compile_success)",
            "",
        ]
    )
    headline_method = "B4" if "B4" in methods else "B2"
    b_compile = gaps[
        (gaps["method"] == headline_method) & (gaps["correctness_label"] == "compile_success")
    ]
    for _, row in b_compile.iterrows():
        agent = AGENT_LABELS.get(str(row["agent_llm"]), row["agent_llm"])
        correct_row = detail[
            (detail["agent_llm"] == row["agent_llm"])
            & (detail["method"] == headline_method)
            & (detail["correctness_label"] == "compile_success")
            & (detail["stratum"] == "correct")
        ]
        incorrect_row = detail[
            (detail["agent_llm"] == row["agent_llm"])
            & (detail["method"] == headline_method)
            & (detail["correctness_label"] == "compile_success")
            & (detail["stratum"] == "incorrect")
        ]
        x = _fmt(correct_row.iloc[0]["mape_pct"], 2) if not correct_row.empty else "—"
        y = _fmt(incorrect_row.iloc[0]["mape_pct"], 2) if not incorrect_row.empty else "—"
        z = _fmt(row.get("mape_gap_pp", row["mape_pct"]), 2)
        p_raw = row.get("stratum_test_p_value", float("nan"))
        p = _fmt(p_raw, 4)
        sig = (
            "not statistically significant"
            if pd.isna(p_raw) or float(p_raw) > 0.05
            else "statistically significant"
        )
        lines.append(
            f"- **{agent}:** {headline_method} predicts VRAM with **{x}%** MAPE on compile-correct "
            f"runs and **{y}%** MAPE on failing runs. The gap is **{z} pp**, which is "
            f"**{sig}** (Mann–Whitney U, p = {p})."
        )
    lines.extend(["", "## Reproduce", "", "```bash", "make analyses", "```", ""])
    return "\n".join(lines)


def render_7_3c_markdown(pareto: pd.DataFrame) -> str:
    """§7.3.c cost–quality Pareto under F5 Tier-2 counterfactual VRAM budgets."""
    budget_list = ", ".join(str(gb) for gb in BUDGET_GB)
    methods = sorted(pareto["method"].unique().tolist()) if not pareto.empty else ["B2", "B0"]
    corr_col = (
        str(pareto["correctness_column"].iloc[0])
        if "correctness_column" in pareto.columns and not pareto.empty
        else "compile_success"
    )
    method_desc = " vs ".join(methods)
    lines: List[str] = [
        "# §7.3.c — Cost–quality Pareto (VRAM admission control)",
        "",
        f"- **Generated:** {_ts()}",
        "- **Split:** test",
        f"- **Counterfactual budgets (GB, F5 Tier-2):** {budget_list}",
        f"- **Methods:** {method_desc}",
        f"- **Correctness axis:** `{corr_col}`",
        "",
        "## Definitions",
        "",
        "- **Counterfactual OOM rate** = fraction of test prompts with "
        "$M_{peak,true} > B$ (F5 Tier-2; method-independent).",
        "- **Counterfactual OAW (% ceiling)** = mean $\\max(0, B - M_{peak,true}) / M_{ceiling}$.",
        "- **Throughput** = fraction of test prompts admitted ($M_{upper} \\leq B$).",
        f"- **Correctness rate** = mean `{corr_col}` among admitted prompts.",
        "- **Admission OOM rate** = fraction admitted but with $M_{peak,true} > B$.",
        "- **OAW (% ceiling)** = F7 slack among admitted prompts only.",
        "",
        "## Curves (per agent)",
        "",
    ]
    m_primary = methods[0] if methods else "B2"
    m_baseline = methods[1] if len(methods) > 1 else "B0"
    for agent in pareto["agent_llm"].unique():
        agent_label = AGENT_LABELS.get(str(agent), agent)
        lines.append(f"### {agent_label}")
        lines.append("")
        lines.append(
            f"| Budget (GB) | CF OOM | CF OAW (% ceil.) | {m_primary} thr. | {m_primary} corr. "
            f"| {m_primary} adm. OOM | {m_baseline} thr. | {m_baseline} corr. | {m_baseline} adm. OOM |"
        )
        lines.append(
            "|------------:|-------:|-----------------:|--------:|---------:|------------:|"
            "--------:|---------:|------------:|"
        )
        sub = pareto[pareto["agent_llm"] == agent]
        for gb in sorted(sub["budget_gb"].unique()):
            r_primary = sub[(sub["budget_gb"] == gb) & (sub["method"] == m_primary)]
            r_baseline = sub[(sub["budget_gb"] == gb) & (sub["method"] == m_baseline)]
            if r_primary.empty or r_baseline.empty:
                continue
            rp = r_primary.iloc[0]
            rb = r_baseline.iloc[0]
            lines.append(
                f"| {int(gb)} | {_fmt(rp['counterfactual_oom_rate']*100, 1)}% "
                f"| {_fmt(rp['counterfactual_oaw_pct_ceiling'], 2)} "
                f"| {_fmt(rp['throughput']*100, 1)}% | {_fmt(rp['correctness_rate']*100, 1)}% "
                f"| {_fmt(rp['admission_oom_rate']*100, 1)}% "
                f"| {_fmt(rb['throughput']*100, 1)}% | {_fmt(rb['correctness_rate']*100, 1)}% "
                f"| {_fmt(rb['admission_oom_rate']*100, 1)}% |"
            )
        lines.append("")
    lines.extend(["## Headline @ 6 GB and 8 GB (pooled counterfactual OOM)", ""])
    for headline_gb in (6, 8):
        slice_df = pareto[pareto["budget_gb"] == headline_gb]
        if slice_df.empty:
            continue
        cf_oom = float(slice_df["counterfactual_oom_rate"].mean())
        lines.append(
            f"- **B = {headline_gb} GB:** counterfactual OOM "
            f"**{_fmt(cf_oom * 100, 1)}%** (mean over agents × methods)."
        )
    lines.extend(["", "## Headline @ 8 GB (admission throughput)", ""])
    eight = pareto[pareto["budget_gb"] == 8]
    primary_pool = eight[eight["method"] == m_primary]
    baseline_pool = eight[eight["method"] == m_baseline]
    t_primary = float(primary_pool["throughput"].mean())
    t_baseline = float(baseline_pool["throughput"].mean())
    c_primary = float(primary_pool["correctness_rate"].mean())
    c_baseline = float(baseline_pool["correctness_rate"].mean())
    if t_baseline > 0:
        f_pct = (t_primary - t_baseline) / t_baseline * 100.0
    else:
        f_pct = float("nan")
    lines.append(
        f"> At an **8 GB** VRAM budget on 1× A100, **{m_primary}** admits "
        f"**{f_pct:.1f}%** more agentic tasks than **{m_baseline}** "
        f"(throughput {_fmt(t_primary*100,1)}% vs {_fmt(t_baseline*100,1)}%; "
        f"correctness among admitted {_fmt(c_primary*100,1)}% vs {_fmt(c_baseline*100,1)}%)."
    )
    lines.extend(
        [
            "",
            "Equal-correctness comparison: if correctness rates differ materially at 8 GB,",
            "interpret throughput gains jointly with the correctness column above.",
            "",
            "## Figure",
            "",
            "`paper/figures/fig7c_cost_quality_pareto.pdf` (if generated).",
            "",
            "## Reproduce",
            "",
            "```bash",
            "make analyses",
            "```",
            "",
        ]
    )
    return "\n".join(lines)


def write_analyses_markdown(
    analyses_dir: Path,
    *,
    joint: pd.DataFrame,
    strata: pd.DataFrame,
    pareto: pd.DataFrame,
    repo_root: Path,
) -> List[Path]:
    """Write three §7.3 markdown files."""
    analyses_dir.mkdir(parents=True, exist_ok=True)
    files = {
        "7.3a_joint_distribution_vram_correctness.md": render_7_3a_markdown(joint, repo_root),
        "7.3b_proxy_calibration_by_correctness_stratum.md": render_7_3b_markdown(strata),
        "7.3c_cost_quality_pareto.md": render_7_3c_markdown(pareto),
    }
    written: List[Path] = []
    for name, body in files.items():
        path = analyses_dir / name
        path.write_text(body, encoding="utf-8")
        written.append(path)
    return written
