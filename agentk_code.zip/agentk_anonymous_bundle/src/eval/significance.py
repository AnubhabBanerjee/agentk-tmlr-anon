"""
paired sign tests on per-prompt |APE| .

Supports Plan-C v2 comparisons (B5/B0 vs B3, B2 vs B3/B0/B5) and optional B4 vs B2
when proxy predictions exist.
"""

from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import torch
from scipy import stats

from src.baselines.common import AGENT_LLMS, DEFAULT_Z_ALPHA
from src.eval.bootstrap import build_per_prompt_test_frames

# Priority order for Plan-C abstract claims (F1 / F2).
PAIRED_SIGN_TEST_SPECS: Tuple[Tuple[str, str, str], ...] = (
    ("B5", "B3", "Oracle-fed closed form vs constant mean (F1 headline)"),
    ("B0", "B3", "Closed-form max-context vs constant mean (F1 corroboration)"),
    ("B2", "B3", "Learned regression vs constant mean (F2)"),
    ("B2", "B0", "Empirical vs analytical closed form (F1 corroboration)"),
    ("B2", "B5", "Empirical vs oracle-fed closed form (F1 corroboration)"),
)


def _absolute_pct_error(y_true: np.ndarray, y_pred: np.ndarray) -> np.ndarray:
    """Per-row absolute percentage error."""
    denom = np.clip(np.abs(y_true), 1e-6, None)
    return np.abs(y_true - y_pred) / denom * 100.0


def _row_key_column(frame: pd.DataFrame) -> str:
    """Prefer trace_jsonl for hardware sweep rows; fall back to prompt_id."""
    if "trace_jsonl" in frame.columns and frame["trace_jsonl"].notna().any():
        return "trace_jsonl"
    return "prompt_id"


def _paired_sign_test(ape_a: np.ndarray, ape_b: np.ndarray) -> Dict[str, Any]:
    """
    Two-sided paired sign test on |APE| differences (a − b).

    Negative diff ⇒ method A has lower |APE| on that prompt.
    Ties (diff == 0) are excluded per standard sign-test practice.
    """
    diff = np.asarray(ape_a, dtype=np.float64) - np.asarray(ape_b, dtype=np.float64)
    nontied = diff[diff != 0.0]
    n = int(nontied.size)
    if n == 0:
        return {
            "n_pairs": int(len(diff)),
            "n_nonzero": 0,
            "n_a_better": 0,
            "n_b_better": 0,
            "n_ties": int(np.sum(diff == 0.0)),
            "p_value": float("nan"),
            "statistic": float("nan"),
            "effect_direction": "undefined",
        }
    n_a_better = int(np.sum(nontied < 0.0))
    n_b_better = int(np.sum(nontied > 0.0))
    k = min(n_a_better, n_b_better)
    result = stats.binomtest(k, n, 0.5, alternative="two-sided")
    if n_a_better > n_b_better:
        direction = "A_lower_error"
    elif n_b_better > n_a_better:
        direction = "B_lower_error"
    else:
        direction = "tie"
    return {
        "n_pairs": int(len(diff)),
        "n_nonzero": n,
        "n_a_better": n_a_better,
        "n_b_better": n_b_better,
        "n_ties": int(np.sum(diff == 0.0)),
        "p_value": float(result.pvalue),
        "statistic": float(k),
        "effect_direction": direction,
    }


def _interpretation(method_a: str, method_b: str, test: Dict[str, Any]) -> str:
    """Human-readable winner line for one paired comparison."""
    direction = test.get("effect_direction")
    if direction == "A_lower_error":
        return f"{method_a} lower |APE| on more prompts than {method_b}"
    if direction == "B_lower_error":
        return f"{method_b} lower |APE| on more prompts than {method_a}"
    return "no clear winner"


def _compare_methods_on_frames(
    frames_a: pd.DataFrame,
    frames_b: pd.DataFrame,
    *,
    method_a: str,
    method_b: str,
) -> Tuple[np.ndarray, np.ndarray]:
    """Align two per-prompt frames and return |APE| vectors."""
    key_col = _row_key_column(frames_a)
    if key_col not in frames_b.columns:
        key_col = "prompt_id"
    a = frames_a.set_index(key_col).sort_index()
    b = frames_b.set_index(key_col).sort_index()
    common = a.index.intersection(b.index)
    ape_a = _absolute_pct_error(
        a.loc[common, "M_peak_true"].to_numpy(),
        a.loc[common, "Mpeak_pred"].to_numpy(),
    )
    ape_b = _absolute_pct_error(
        b.loc[common, "M_peak_true"].to_numpy(),
        b.loc[common, "Mpeak_pred"].to_numpy(),
    )
    return ape_a, ape_b


def build_paired_sign_test_block(
    per_agent_frames: Dict[str, Dict[str, pd.DataFrame]],
    *,
    method_a: str,
    method_b: str,
    split: str = "test",
    claim: str = "",
) -> Dict[str, Any]:
    """One paired-sign-test block (per agent + pooled) for significance_tests.json."""
    comparison = f"{method_a}_vs_{method_b}"
    per_agent: List[dict] = []
    pooled_a: List[float] = []
    pooled_b: List[float] = []

    for agent_llm in AGENT_LLMS:
        frames = per_agent_frames.get(agent_llm, {})
        if method_a not in frames or method_b not in frames:
            per_agent.append(
                {
                    "agent_llm": agent_llm,
                    "comparison": comparison,
                    "split": split,
                    "z_alpha": DEFAULT_Z_ALPHA,
                    "status": "missing_predictions",
                }
            )
            continue
        ape_a, ape_b = _compare_methods_on_frames(
            frames[method_a], frames[method_b], method_a=method_a, method_b=method_b
        )
        test = _paired_sign_test(ape_a, ape_b)
        per_agent.append(
            {
                "agent_llm": agent_llm,
                "comparison": comparison,
                "split": split,
                "z_alpha": DEFAULT_Z_ALPHA,
                "status": "ok",
                "method_a": method_a,
                "method_b": method_b,
                "test": "paired_sign_test",
                "metric": "absolute_pct_error",
                f"mean_ape_{method_a.lower()}_pct": float(np.mean(ape_a)),
                f"mean_ape_{method_b.lower()}_pct": float(np.mean(ape_b)),
                "mean_diff_a_minus_b_pp": float(np.mean(ape_a - ape_b)),
                **test,
                "interpretation": _interpretation(method_a, method_b, test),
            }
        )
        pooled_a.extend(ape_a.tolist())
        pooled_b.extend(ape_b.tolist())

    pooled_test = _paired_sign_test(np.asarray(pooled_a), np.asarray(pooled_b))
    return {
        "test_name": f"paired_sign_test_{comparison}",
        "claim": claim,
        "split": split,
        "z_alpha": DEFAULT_Z_ALPHA,
        "method_a": method_a,
        "method_b": method_b,
        "per_agent": per_agent,
        "pooled_all_agents": {
            "n_prompts": len(pooled_a),
            f"mean_ape_{method_a.lower()}_pct": float(np.mean(pooled_a)) if pooled_a else float("nan"),
            f"mean_ape_{method_b.lower()}_pct": float(np.mean(pooled_b)) if pooled_b else float("nan"),
            **pooled_test,
            "interpretation": _interpretation(method_a, method_b, pooled_test),
        },
    }


def build_significance_tests(
    repo_root: Path,
    *,
    device: torch.device,
    split: str = "test",
    include_b4_vs_b2: bool = True,
) -> Dict[str, Any]:
    """
    Build all paired sign-test blocks for significance_tests.json.

    Returns a dict keyed by ``paired_sign_test_{A}_vs_{B}`` plus metadata.
    """
    per_agent = build_per_prompt_test_frames(repo_root, device=device, split=split)
    out: Dict[str, Any] = {
        "split": split,
        "z_alpha": DEFAULT_Z_ALPHA,
        "test_family": "paired_sign_test_absolute_pct_error",
    }

    for method_a, method_b, claim in PAIRED_SIGN_TEST_SPECS:
        key = f"paired_sign_test_{method_a}_vs_{method_b}"
        out[key] = build_paired_sign_test_block(
            per_agent,
            method_a=method_a,
            method_b=method_b,
            split=split,
            claim=claim,
        )

    if include_b4_vs_b2:
        key = "paired_sign_test_B4_vs_B2"
        out[key] = build_paired_sign_test_block(
            per_agent,
            method_a="B4",
            method_b="B2",
            split=split,
            claim="Proxy upper bound vs direct regression (legacy Part-1 gate)",
        )

    return out


def build_b4_vs_b2_significance(
    repo_root: Path,
    *,
    device: torch.device,
    split: str = "test",
) -> Dict[str, Any]:
    """Backward-compatible wrapper returning only the B4 vs B2 block."""
    full = build_significance_tests(
        repo_root, device=device, split=split, include_b4_vs_b2=True
    )
    return full["paired_sign_test_B4_vs_B2"]


def _json_default(obj: Any) -> Any:
    """Serialize NaN/Inf as JSON null."""
    if isinstance(obj, float) and (math.isnan(obj) or math.isinf(obj)):
        return None
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def write_significance_tests_json(
    path: Path,
    payload: Dict[str, Any],
) -> Path:
    """Write significance_tests.json (NaN-safe)."""
    path.write_text(
        json.dumps(payload, indent=2, default=_json_default) + "\n",
        encoding="utf-8",
    )
    return path
