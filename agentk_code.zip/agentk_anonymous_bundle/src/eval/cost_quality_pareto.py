"""
Phase 7 §7.3.c — cost–quality Pareto under counterfactual VRAM budgets (F5 Tier-2).

OOM/OAW are evaluated on the primary budget grid
``B ∈ {2, 4, 6, 8, 10, 12, 16, 24, 40}`` GB rather than measured hardware OOM
events (Part-1 F5 Tier-2; Part-2 A1 step 10).
"""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import torch

from src.baselines.common import AGENT_LLMS, DEFAULT_Z_ALPHA
from src.eval.context import EvalContext, eval_context
from src.eval.loaders import load_ground_truth_test, load_merged_predictions
from src.eval.metrics import oaw_pct_of_ceiling
from src.eval.paths import VRAM_CEILING_MB
from src.eval.proxy_bundle import load_agent_proxy_bundle, peaks_from_bundle, run_proxy_forward_on_frame

# F5 Tier-2 counterfactual VRAM budget grid in GB (Part-2 A1 step 10).
COUNTERFACTUAL_BUDGET_GB: tuple[int, ...] = (2, 4, 6, 8, 10, 12, 16, 24, 40)

# Primary §7.3.c axis — same grid as ``COUNTERFACTUAL_BUDGET_GB``.
BUDGET_GB: tuple[int, ...] = COUNTERFACTUAL_BUDGET_GB


def _budget_mb(gb: int) -> float:
    """Convert a counterfactual budget from gigabytes to megabytes."""
    return float(gb) * 1024.0


def counterfactual_metrics_at_budget(
    m_peak_true: np.ndarray,
    budget_mb: float,
    *,
    m_ceiling_mb: float = VRAM_CEILING_MB,
) -> dict[str, float | int]:
    """
    F5 Tier-2 OOM/OAW when each prompt is evaluated against budget ``B``.

    - ``counterfactual_oom_rate`` = fraction with ``M_peak_true > B``
    - ``counterfactual_oaw_pct_ceiling`` = mean slack ``max(0, B - M_peak) / M_ceiling``
    """
    y_true = np.asarray(m_peak_true, dtype=np.float64)
    n = int(y_true.size)
    if n == 0:
        return {
            "counterfactual_oom_rate": float("nan"),
            "counterfactual_oaw_pct_ceiling": float("nan"),
            "n_over_budget": 0,
        }
    over = y_true > float(budget_mb)
    slack_mb = np.maximum(0.0, float(budget_mb) - y_true)
    ceiling = max(float(m_ceiling_mb), 1e-6)
    return {
        "counterfactual_oom_rate": float(np.mean(over)),
        "counterfactual_oaw_pct_ceiling": float(np.mean(slack_mb / ceiling * 100.0)),
        "n_over_budget": int(np.sum(over)),
    }


def admission_metrics_at_budget(
    merged: pd.DataFrame,
    budget_mb: float,
    *,
    correctness_column: str = "compile_success",
    m_ceiling_mb: float = VRAM_CEILING_MB,
) -> dict[str, float | int]:
    """
    Admission-control metrics at counterfactual budget ``B``.

    - ``throughput`` = fraction admitted (``M_upper ≤ B``)
    - ``correctness_rate`` = mean ``correctness_column`` among admitted rows
    - ``admission_oom_rate`` = fraction admitted but with ``M_peak_true > B``
    - ``oaw_pct_ceiling`` = F7 slack among admitted rows only
    """
    if correctness_column not in merged.columns:
        raise KeyError(
            f"correctness_column={correctness_column!r} missing from merged frame; "
            f"available={list(merged.columns)}"
        )
    y_true = merged["M_peak_true"].to_numpy(dtype=np.float64)
    y_upper = merged["Mupper_pred"].to_numpy(dtype=np.float64)
    n_total = int(len(merged))
    if n_total == 0:
        return {
            "n_total": 0,
            "n_admitted": 0,
            "throughput": float("nan"),
            "correctness_rate": float("nan"),
            "admission_oom_rate": float("nan"),
            "oaw_pct_ceiling": float("nan"),
        }

    cap = float(budget_mb)
    admitted_mask = y_upper <= cap
    n_admit = int(np.sum(admitted_mask))
    throughput = float(n_admit / n_total)

    if n_admit > 0:
        admitted = merged.loc[admitted_mask]
        correctness = float(admitted[correctness_column].astype(float).mean())
        admission_oom_rate = float(np.mean(y_true[admitted_mask] > cap))
        oaw_pct = oaw_pct_of_ceiling(
            y_true[admitted_mask],
            y_upper[admitted_mask],
            m_ceiling_mb=m_ceiling_mb,
        )
    else:
        correctness = float("nan")
        admission_oom_rate = float("nan")
        oaw_pct = float("nan")

    return {
        "n_total": n_total,
        "n_admitted": n_admit,
        "throughput": throughput,
        "correctness_rate": correctness,
        "admission_oom_rate": admission_oom_rate,
        "oaw_pct_ceiling": oaw_pct,
    }


def _load_b4_test_predictions(
    repo_root: Path,
    agent_llm: str,
    *,
    device: torch.device,
) -> pd.DataFrame:
    """Fresh B4 peak/upper on test via best proxy backbone."""
    bundle = load_agent_proxy_bundle(repo_root, agent_llm, device=device)
    outputs, l_base, accounting_rows = run_proxy_forward_on_frame(bundle)
    m_peak, m_upper = peaks_from_bundle(bundle, outputs, l_base, accounting_rows)
    return pd.DataFrame(
        {
            "prompt_id": bundle.test_frame["prompt_id"].tolist(),
            "agent_llm": agent_llm,
            "Mpeak_pred": m_peak.detach().cpu().numpy(),
            "Mupper_pred": m_upper.detach().cpu().numpy(),
            "proxy_backbone": bundle.backbone_id,
        }
    )


def pareto_methods_for_context(ctx: EvalContext) -> Tuple[str, ...]:
    """Empirical best (B2) vs analytical worst-case (B0) when B4 is skipped."""
    if ctx.skip_b4 or not ctx.has_proxies:
        return ("B2", "B0")
    return ("B4", "B0")


def build_cost_quality_pareto_table(
    repo_root: Path,
    *,
    device: torch.device,
    split: str = "test",
    budget_gb: tuple[int, ...] = BUDGET_GB,
    correctness_column: str = "compile_success",
    methods: Optional[Sequence[str]] = None,
    ctx: Optional[EvalContext] = None,
) -> pd.DataFrame:
    """
    For each agent × method × counterfactual budget ``B`` (GB):

    F5 Tier-2 (primary axis):
    - ``counterfactual_oom_rate`` — fraction with ``M_peak_true > B``
    - ``counterfactual_oaw_pct_ceiling`` — oracle slack if cap is exactly ``B``

    Admission control (§7.3.c):
    - ``throughput`` — fraction with ``M_upper_pred ≤ B``
    - ``correctness_rate`` — mean ``correctness_column`` among admitted prompts
    - ``admission_oom_rate`` — admitted but ``M_peak_true > B``
    - ``oaw_pct_ceiling`` — F7 slack among admitted prompts
    """
    eval_ctx = ctx or eval_context(repo_root)
    method_list = tuple(methods) if methods is not None else pareto_methods_for_context(eval_ctx)
    rows: List[dict] = []
    for agent_llm in AGENT_LLMS:
        truth = load_ground_truth_test(repo_root, agent_llm, paths=eval_ctx.tracing)
        y_true_all = truth["M_peak_true"].to_numpy(dtype=np.float64)
        cf_by_budget = {
            int(gb): counterfactual_metrics_at_budget(y_true_all, _budget_mb(gb))
            for gb in budget_gb
        }

        for method in method_list:
            if method == "B4":
                pred = _load_b4_test_predictions(repo_root, agent_llm, device=device)
                backbone = str(pred["proxy_backbone"].iloc[0])
                merged = load_merged_predictions(repo_root, agent_llm, method, paths=eval_ctx.tracing)
                merged = merged.drop(columns=[c for c in ("Mpeak_pred", "Mupper_pred") if c in merged.columns])
                merged = merged.merge(
                    pred[["prompt_id", "Mpeak_pred", "Mupper_pred"]],
                    on="prompt_id",
                    how="left",
                )
            else:
                merged = load_merged_predictions(repo_root, agent_llm, method, paths=eval_ctx.tracing)
                backbone = ""
            for gb in budget_gb:
                cap = _budget_mb(gb)
                cf = cf_by_budget[int(gb)]
                admit = admission_metrics_at_budget(
                    merged,
                    cap,
                    correctness_column=correctness_column,
                )
                rows.append(
                    {
                        "agent_llm": agent_llm,
                        "method": method,
                        "split": split,
                        "budget_gb": int(gb),
                        "budget_mb": cap,
                        "z_alpha": float(DEFAULT_Z_ALPHA),
                        "correctness_column": correctness_column,
                        "n_total": int(admit["n_total"]),
                        "n_admitted": int(admit["n_admitted"]),
                        "n_over_budget": int(cf["n_over_budget"]),
                        "throughput": float(admit["throughput"]),
                        "correctness_rate": float(admit["correctness_rate"]),
                        "counterfactual_oom_rate": float(cf["counterfactual_oom_rate"]),
                        "counterfactual_oaw_pct_ceiling": float(
                            cf["counterfactual_oaw_pct_ceiling"]
                        ),
                        "admission_oom_rate": float(admit["admission_oom_rate"]),
                        "oaw_pct_ceiling": float(admit["oaw_pct_ceiling"]),
                        "proxy_backbone": backbone,
                    }
                )
    return pd.DataFrame(rows)
