"""
Phase 7 — generate LaTeX tables from paper/results/metrics/ parquets.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from src.eval.paths import MAPE_BAR_METHODS, ResultsLayout
from src.eval.metrics import ensure_oaw_pct_ceiling


def render_primary_results_tex(primary: pd.DataFrame) -> str:
    """LaTeX table: test MAPE / OOM / OAW per agent × method (z=1.96)."""
    df = ensure_oaw_pct_ceiling(primary.copy())
    df = df[df["method"].isin(MAPE_BAR_METHODS + ("B0", "B3"))].sort_values(
        ["agent_llm", "method"]
    )
    lines = [
        "% Auto-generated from paper/results/metrics/primary_test.parquet — do not edit by hand.",
        "\\begin{table}[t]",
        "\\centering",
        "\\caption{Test-set peak VRAM forecast metrics ($z_\\alpha=1.96$).}",
        "\\label{tab:primary-results}",
        "\\begin{tabular}{llrrrr}",
        "\\toprule",
        "Agent LLM & Method & MAPE (\\%) & MAE (MB) & OOM rate & OAW (\\% ceil.) \\\\",
        "\\midrule",
    ]
    for _, row in df.iterrows():
        agent = str(row["agent_llm"]).replace("_", "\\_")
        method = str(row["method"])
        lines.append(
            f"{agent} & {method} & {row['mape_pct']:.2f} & {row['mae_peak_mb']:.1f} "
            f"& {row['oom_rate']:.3f} & {row['oaw_pct_ceiling']:.2f} \\\\"
        )
    lines.extend(["\\bottomrule", "\\end{tabular}", "\\end{table}", ""])
    return "\n".join(lines)


def write_primary_results_table(layout: ResultsLayout, primary: pd.DataFrame) -> Path:
    layout.ensure_dirs()
    tex = render_primary_results_tex(primary)
    layout.table_primary_results.write_text(tex, encoding="utf-8")
    return layout.table_primary_results


def render_primary_results_ci_tex(
    primary: pd.DataFrame,
    bootstrap_ci: pd.DataFrame,
) -> str:
    """LaTeX table: primary metrics with bootstrap 95% CIs on MAPE."""
    df = primary.copy()
    df = df[df["method"].isin(MAPE_BAR_METHODS + ("B0", "B3"))].sort_values(
        ["agent_llm", "method"]
    )
    mape_ci = bootstrap_ci[bootstrap_ci["metric"] == "mape_pct"].set_index(
        ["agent_llm", "method"]
    )
    lines = [
        "% Auto-generated from primary_test.parquet + bootstrap_ci.parquet (§7.4).",
        "\\begin{table}[t]",
        "\\centering",
        "\\caption{Test MAPE with bootstrap 95\\% CIs ($n=600$ resamples, 90 prompts).}",
        "\\label{tab:primary-results-ci}",
        "\\begin{tabular}{llr}",
        "\\toprule",
        "Agent LLM & Method & MAPE (\\%) [95\\% CI] \\\\",
        "\\midrule",
    ]
    for _, row in df.iterrows():
        agent = str(row["agent_llm"]).replace("_", "\\_")
        method = str(row["method"])
        key = (row["agent_llm"], row["method"])
        if key in mape_ci.index:
            ci = mape_ci.loc[key]
            cell = (
                f"{ci['point_estimate']:.2f} "
                f"[{ci['ci_lo']:.2f}, {ci['ci_hi']:.2f}]"
            )
        else:
            cell = f"{row['mape_pct']:.2f}"
        lines.append(f"{agent} & {method} & {cell} \\\\")
    lines.extend(["\\bottomrule", "\\end{tabular}", "\\end{table}", ""])
    return "\n".join(lines)


def write_primary_results_ci_table(
    layout: ResultsLayout,
    primary: pd.DataFrame,
    bootstrap_ci: pd.DataFrame,
) -> Path:
    layout.ensure_dirs()
    tex = render_primary_results_ci_tex(primary, bootstrap_ci)
    layout.table_primary_results_ci.write_text(tex, encoding="utf-8")
    return layout.table_primary_results_ci


def render_backbone_ablation_tex(ablation: pd.DataFrame) -> str:
    """LaTeX table: test metrics per agent × proxy backbone (§7.2 fig 4)."""
    df = ensure_oaw_pct_ceiling(ablation).sort_values(["agent_llm", "backbone"])
    lines = [
        "% Auto-generated from paper/results/metrics/backbone_ablation_test.parquet.",
        "\\begin{table}[t]",
        "\\centering",
        "\\caption{Proxy backbone ablation on the test set ($z_\\alpha=1.96$).}",
        "\\label{tab:backbone-ablation}",
        "\\begin{tabular}{llrrrr}",
        "\\toprule",
        "Agent LLM & Backbone & MAPE (\\%) & MAE (MB) & OOM rate & OAW (\\% ceil.) \\\\",
        "\\midrule",
    ]
    for _, row in df.iterrows():
        agent = str(row["agent_llm"]).replace("_", "\\_")
        backbone = str(row.get("backbone", row.get("proxy_backbone", ""))).replace("_", "\\_")
        lines.append(
            f"{agent} & {backbone} & {row['mape_pct']:.2f} & {row['mae_peak_mb']:.1f} "
            f"& {row['oom_rate']:.3f} & {row['oaw_pct_ceiling']:.2f} \\\\"
        )
    lines.extend(["\\bottomrule", "\\end{tabular}", "\\end{table}", ""])
    return "\n".join(lines)
