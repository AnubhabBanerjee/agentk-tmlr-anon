"""
Phase 7 — write manifest.json tracking all paper metric artifacts.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from src.eval.paths import ResultsLayout


def _file_status(path: Path) -> Dict[str, Any]:
    if not path.is_file():
        return {"status": "pending", "path": str(path)}
    st = path.stat()
    return {
        "status": "ready",
        "path": str(path),
        "bytes": st.st_size,
        "mtime_utc": datetime.fromtimestamp(st.st_mtime, tz=timezone.utc).strftime(
            "%Y-%m-%d %H:%M:%S UTC"
        ),
    }


def build_manifest(
    layout: ResultsLayout,
    *,
    repo_root: Path,
    extra: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    """Describe every canonical paper/results/ artifact and whether it exists."""
    metrics_files = {
        "primary_test": layout.primary_test,
        "z_alpha_sweep": layout.z_alpha_sweep,
        "subcomponents_test": layout.subcomponents_test,
        "subcomponents_mae": layout.subcomponents_mae,
        "trajectory_test": layout.trajectory_test,
        "trajectory_mape": layout.trajectory_mape,
        "vram_strata_mape": layout.vram_strata_mape,
        "backbone_ablation_test": layout.backbone_ablation_test,
        "cross_model_generalization": layout.cross_model_generalization,
        "correctness_joint": layout.correctness_joint,
        "correctness_strata": layout.correctness_strata,
        "cost_quality_pareto": layout.cost_quality_pareto,
        "bootstrap_ci": layout.bootstrap_ci,
        "significance_tests": layout.significance_tests,
    }
    table_files = {
        "primary_results": layout.table_primary_results,
        "primary_results_ci": layout.table_primary_results_ci,
        "backbone_ablation": layout.table_backbone_ablation,
    }
    payload: Dict[str, Any] = {
        "generated_at_utc": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
        "repo_root": str(repo_root.resolve()),
        "paper_inputs": {
            "narrative": str(layout.summary_md),
            "figures_dir": str(layout.figures_dir),
            "metrics_dir": str(layout.metrics_dir),
            "tables_dir": str(layout.tables_dir),
        },
        "pipeline_inputs": {
            "predictions": str(repo_root / "artifacts" / "predictions"),
            "proxies": str(repo_root / "artifacts" / "proxies"),
            "traces_index": str(repo_root / "data" / "traces" / "index.parquet"),
            "labels": str(repo_root / "data" / "labels"),
            "correctness": str(repo_root / "data" / "correctness" / "kernelbench.parquet"),
        },
        "metrics": {name: _file_status(path) for name, path in metrics_files.items()},
        "tables": {name: _file_status(path) for name, path in table_files.items()},
        "notes": {
            "single_source_of_truth": "All paper numbers must come from paper/results/metrics/ and paper/results/tables/.",
            "do_not_cite": [
                "artifacts/proxies/*/metrics.json (validation-only training logs)",
                "data/*_report.md (Phase 3/4 sanity reports)",
            ],
            "z_alpha_sweep_b4": "B4 rows computed via proxy σ_N resweep (best backbone per agent).",
        },
    }
    if extra:
        payload["run"] = extra
    return payload


def write_manifest(layout: ResultsLayout, *, repo_root: Path, extra: Dict[str, Any] | None = None) -> Path:
    layout.ensure_dirs()
    payload = build_manifest(layout, repo_root=repo_root, extra=extra)
    layout.manifest_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return layout.manifest_json
