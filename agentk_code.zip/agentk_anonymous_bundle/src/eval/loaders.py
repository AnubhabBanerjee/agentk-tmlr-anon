"""
Phase 7 — load Phase 6 predictions and join ground-truth peaks.
"""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional

import pandas as pd

from src.baselines.common import AGENT_LLMS, load_baseline_frame, split_frame
from src.eval.context import active_baseline_methods, eval_context
from src.pipeline.tracing_paths import TracingPaths, tracing_paths_from_env


def _tracing(repo_root: Path, paths: Optional[TracingPaths] = None) -> TracingPaths:
    return paths or tracing_paths_from_env(repo_root=repo_root)


def load_ground_truth_test(
    repo_root: Path,
    agent_llm: str,
    *,
    paths: Optional[TracingPaths] = None,
) -> pd.DataFrame:
    """Test-split ground truth keyed by prompt_id (and trace_jsonl when present)."""
    layout = _tracing(repo_root, paths)
    index = pd.read_parquet(layout.index_path)
    cols = ["prompt_id", "agent_llm", "M_peak_true", "compile_success", "prompt_source"]
    if "trace_jsonl" in index.columns:
        cols.insert(1, "trace_jsonl")
    test = index[(index["agent_llm"] == agent_llm) & (index["split"] == "test")][cols].copy()
    return test


def align_predictions_to_test_split(
    repo_root: Path,
    agent_llm: str,
    pred: pd.DataFrame,
    *,
    paths: Optional[TracingPaths] = None,
) -> pd.DataFrame:
    """
    Attach ``trace_jsonl`` to Phase-6 parquets that only store ``prompt_id``.

    Predictions are emitted in ``split_frame`` test order (one row per trace).
    """
    layout = _tracing(repo_root, paths)
    frame = load_baseline_frame(repo_root=repo_root, agent_llm=agent_llm, paths=layout)
    _train, _val, test = split_frame(frame)
    if len(pred) != len(test):
        raise RuntimeError(
            f"Prediction/test row count mismatch for {agent_llm}: "
            f"pred={len(pred)} baseline_test={len(test)}"
        )
    aligned = pred.copy()
    if "trace_jsonl" in test.columns:
        aligned["trace_jsonl"] = test["trace_jsonl"].to_numpy()
    return aligned


def load_merged_predictions(
    repo_root: Path,
    agent_llm: str,
    method: str,
    *,
    paths: Optional[TracingPaths] = None,
) -> pd.DataFrame:
    """Load predictions and inner-join to test-split ground truth."""
    layout = _tracing(repo_root, paths)
    pred = load_predictions(repo_root, agent_llm, method, paths=layout)
    pred = align_predictions_to_test_split(repo_root, agent_llm, pred, paths=layout)
    truth = load_ground_truth_test(repo_root, agent_llm, paths=layout)
    return join_predictions_to_truth(pred, truth)


def load_predictions(
    repo_root: Path,
    agent_llm: str,
    method: str,
    *,
    paths: Optional[TracingPaths] = None,
) -> pd.DataFrame:
    """Load one Phase 6 test.parquet."""
    layout = _tracing(repo_root, paths)
    path = layout.predictions_root / agent_llm / method / "test.parquet"
    if not path.is_file():
        raise FileNotFoundError(f"Missing prediction file: {path}")
    return pd.read_parquet(path)


def join_predictions_to_truth(
    pred: pd.DataFrame,
    truth: pd.DataFrame,
) -> pd.DataFrame:
    """Inner-join predictions with M_peak_true on trace_jsonl or prompt_id."""
    join_cols = (
        ["trace_jsonl", "agent_llm"]
        if "trace_jsonl" in pred.columns and "trace_jsonl" in truth.columns
        else ["prompt_id", "agent_llm"]
    )
    merged = pred.merge(truth, on=join_cols, how="inner")
    if "prompt_id_x" in merged.columns:
        merged["prompt_id"] = merged["prompt_id_x"]
        drop_cols = [c for c in ("prompt_id_x", "prompt_id_y") if c in merged.columns]
        merged = merged.drop(columns=drop_cols)
    if len(merged) != len(pred):
        raise RuntimeError(
            f"Prediction/truth row mismatch on {join_cols}: "
            f"pred={len(pred)} merged={len(merged)}"
        )
    return merged


def list_available_predictions(repo_root: Path) -> List[tuple[str, str]]:
    """Return (agent_llm, method) pairs with existing test.parquet files."""
    ctx = eval_context(repo_root)
    out: List[tuple[str, str]] = []
    for agent in AGENT_LLMS:
        for method in active_baseline_methods(skip_b4=ctx.skip_b4):
            path = ctx.tracing.predictions_root / agent / method / "test.parquet"
            if path.is_file():
                out.append((agent, method))
    return out


def predictions_root(repo_root: Path) -> Path:
    """Location of Phase 6 raw prediction parquets (read-only for eval)."""
    return tracing_paths_from_env(repo_root=repo_root).predictions_root
