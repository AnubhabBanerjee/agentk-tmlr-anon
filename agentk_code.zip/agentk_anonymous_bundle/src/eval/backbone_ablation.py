"""
Phase 7 §7.2 fig 4 — test-set metrics for all proxy backbones per agent.
"""

from __future__ import annotations

from pathlib import Path
from typing import List

import pandas as pd
import torch

from src.baselines.b4_proxy import PROXY_BACKBONES
from src.baselines.common import AGENT_LLMS, DEFAULT_Z_ALPHA
from src.eval.loaders import load_ground_truth_test
from src.eval.metrics import summarize_predictions
from src.eval.proxy_bundle import load_agent_proxy_bundle, peaks_from_bundle, run_proxy_forward_on_frame


def _b4_metrics_one_backbone(
    repo_root: Path,
    agent_llm: str,
    backbone_id: str,
    *,
    device: torch.device,
    split: str = "test",
) -> dict:
    truth = load_ground_truth_test(repo_root, agent_llm)
    bundle = load_agent_proxy_bundle(
        repo_root, agent_llm, device=device, backbone_id=backbone_id
    )
    outputs, l_base, accounting_rows = run_proxy_forward_on_frame(bundle)
    m_peak, m_upper = peaks_from_bundle(bundle, outputs, l_base, accounting_rows)
    frame = pd.DataFrame(
        {
            "prompt_id": bundle.test_frame["prompt_id"].tolist(),
            "agent_llm": agent_llm,
            "M_peak_true": truth.set_index("prompt_id")
            .loc[bundle.test_frame["prompt_id"], "M_peak_true"]
            .to_numpy(),
            "Mpeak_pred": m_peak.detach().cpu().numpy(),
            "Mupper_pred": m_upper.detach().cpu().numpy(),
        }
    )
    row = summarize_predictions(
        frame,
        agent_llm=agent_llm,
        method="B4",
        split=split,
        z_alpha=DEFAULT_Z_ALPHA,
    )
    row["backbone"] = backbone_id
    row["proxy_backbone"] = backbone_id
    return row


def build_backbone_ablation_test_table(
    repo_root: Path,
    *,
    device: torch.device,
    split: str = "test",
) -> pd.DataFrame:
    """Test MAPE / OOM / OAW for MiniLM, DeBERTa-v3, UniXCoder per agent."""
    rows: List[dict] = []
    for agent_llm in AGENT_LLMS:
        for backbone_id in PROXY_BACKBONES:
            rows.append(
                _b4_metrics_one_backbone(
                    repo_root,
                    agent_llm,
                    backbone_id,
                    device=device,
                    split=split,
                )
            )
    return pd.DataFrame(rows)
