"""
Step 2 — sub-component MAE (N̂, Ê, aggregated T̂).
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd
import torch

from src.baselines.common import AGENT_LLMS, PROXY_NODE_TYPES
from src.eval.proxy_bundle import load_agent_proxy_bundle, predicted_aggregated_tool_tokens, run_proxy_forward_on_frame


def true_aggregated_tool_tokens(row: pd.Series) -> float:
    """Σ_i t_{i,avg_tokens} from label columns (0 when node did not run)."""
    total = 0.0
    for node in PROXY_NODE_TYPES:
        total += float(row.get(f"y_T_{node}_avg_tokens", 0.0) or 0.0)
    return total


def build_subcomponents_test_table(
    repo_root: Path,
    *,
    device: torch.device,
    split: str = "test",
) -> pd.DataFrame:
    """Per test prompt: N̂, Ê, Σ p_i μ_i vs ground truth + absolute errors."""
    rows: List[dict] = []
    for agent_llm in AGENT_LLMS:
        bundle = load_agent_proxy_bundle(repo_root, agent_llm, device=device)
        outputs, _l_base, _acc = run_proxy_forward_on_frame(bundle)
        n_hat = outputs.lambda_rate.squeeze(-1).detach().cpu().numpy()
        e_hat = outputs.e_hat.squeeze(-1).detach().cpu().numpy()
        t_hat = predicted_aggregated_tool_tokens(outputs, bundle.tool_mu).detach().cpu().numpy()
        for i, (_, row) in enumerate(bundle.test_frame.iterrows()):
            y_n = float(row["y_N"])
            y_e = float(row["y_E"])
            y_t = true_aggregated_tool_tokens(row)
            rows.append(
                {
                    "agent_llm": agent_llm,
                    "prompt_id": str(row["prompt_id"]),
                    "split": split,
                    "proxy_backbone": bundle.backbone_id,
                    "n_hat": float(n_hat[i]),
                    "y_n": y_n,
                    "abs_err_n": abs(float(n_hat[i]) - y_n),
                    "e_hat": float(e_hat[i]),
                    "y_e": y_e,
                    "abs_err_e": abs(float(e_hat[i]) - y_e),
                    "t_hat_agg": float(t_hat[i]),
                    "y_t_agg": y_t,
                    "abs_err_t_agg": abs(float(t_hat[i]) - y_t),
                }
            )
    return pd.DataFrame(rows)


def aggregate_subcomponent_mae(sub: pd.DataFrame) -> pd.DataFrame:
    """One row per agent_llm with MAE for N, E, aggregated T."""
    if sub.empty:
        return pd.DataFrame(
            columns=["agent_llm", "proxy_backbone", "n_rows", "mae_n", "mae_e", "mae_t_agg"]
        )
    rows: List[dict] = []
    for agent_llm, grp in sub.groupby("agent_llm", sort=False):
        rows.append(
            {
                "agent_llm": agent_llm,
                "proxy_backbone": str(grp["proxy_backbone"].iloc[0]),
                "n_rows": int(len(grp)),
                "mae_n": float(grp["abs_err_n"].mean()),
                "mae_e": float(grp["abs_err_e"].mean()),
                "mae_t_agg": float(grp["abs_err_t_agg"].mean()),
            }
        )
    return pd.DataFrame(rows)
