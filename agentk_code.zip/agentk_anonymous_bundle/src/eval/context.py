"""
Phase 7 — resolve evaluation layout from TRACING_CONFIG / SKIP env vars.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from src.baselines.common import BASELINE_METHODS
from src.eval.paths import ResultsLayout
from src.pipeline.tracing_paths import TracingPaths, tracing_paths_from_env


def skip_b4_from_env() -> bool:
    """True when Makefile ``SKIP=B4`` or ``SKIP`` list contains B4."""
    raw = os.environ.get("SKIP", "").strip()
    if not raw:
        return False
    tokens = {part.strip().upper() for part in raw.replace(",", " ").split()}
    return "B4" in tokens


def active_baseline_methods(*, skip_b4: bool | None = None) -> tuple[str, ...]:
    """Baseline methods included in this evaluation run."""
    skip = skip_b4 if skip_b4 is not None else skip_b4_from_env()
    if skip:
        return tuple(m for m in BASELINE_METHODS if m != "B4")
    return tuple(BASELINE_METHODS)


def proxies_root(repo_root: Path, tracing: TracingPaths | None = None) -> Path:
    """Directory holding Phase-5 proxy checkpoints (v1 or v2)."""
    layout = tracing or tracing_paths_from_env(repo_root=repo_root)
    return layout.repo_root / ("artifacts_v2/proxies" if layout.is_v2 else "artifacts/proxies")


def proxies_available(repo_root: Path, tracing: TracingPaths | None = None) -> bool:
    """True when at least one agent/backbone has proxy metrics.json."""
    root = proxies_root(repo_root, tracing)
    if not root.is_dir():
        return False
    return any(root.glob("*/*/metrics.json"))


@dataclass(frozen=True)
class EvalContext:
    """Canonical paths and flags for one evaluate/figures/analyses invocation."""

    repo_root: Path
    tracing: TracingPaths
    results: ResultsLayout
    skip_b4: bool

    @property
    def is_v2(self) -> bool:
        return self.tracing.is_v2

    @property
    def has_proxies(self) -> bool:
        return proxies_available(self.repo_root, self.tracing)

    @property
    def analyses_dir(self) -> Path:
        suffix = "_v2" if self.is_v2 else ""
        return self.repo_root / f"paper/analyses{suffix}"

    @property
    def methods(self) -> tuple[str, ...]:
        return active_baseline_methods(skip_b4=self.skip_b4)


def eval_context(repo_root: Path) -> EvalContext:
    """Build evaluation context from environment (TRACING_CONFIG, SKIP)."""
    tracing = tracing_paths_from_env(repo_root=repo_root)
    suffix = "_v2" if tracing.is_v2 else ""
    results = ResultsLayout(root=repo_root / f"paper/results{suffix}")
    return EvalContext(
        repo_root=repo_root,
        tracing=tracing,
        results=results,
        skip_b4=skip_b4_from_env(),
    )
