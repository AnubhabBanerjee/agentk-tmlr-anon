"""
Step 3 — trajectory MAPE (proxy closed-form vs empirical VRAM).
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
import torch

from src.baselines.common import AGENT_LLMS, accounting_dict
from src.eval.proxy_bundle import load_agent_proxy_bundle, predicted_aggregated_tool_tokens, run_proxy_forward_on_frame
from src.forecast.q4_km_accounting import agentic_context_length_tokens, m_vram_mb


def _parse_trajectory(raw: Any) -> Optional[List[Dict[str, Any]]]:
    if raw is None or (isinstance(raw, float) and np.isnan(raw)):
        return None
    if isinstance(raw, list):
        return raw
    if isinstance(raw, str) and raw.strip():
        return json.loads(raw)
    return None


def _predicted_vram_at_step(
    *,
    step_index: int,
    n_steps: float,
    l_base: float,
    e_hat: float,
    expected_tool_tokens: float,
    accounting: Dict[str, Any],
) -> float:
    n_i = max(1.0, float(n_steps))
    step = max(0, min(int(step_index), int(round(n_i))))
    l_t = agentic_context_length_tokens(
        step_index=step,
        n_steps=int(round(n_i)),
        l_base=l_base,
        e_hat=e_hat,
        expected_tool_tokens=expected_tool_tokens,
    )
    return float(
        m_vram_mb(
            context_length_tokens=l_t,
            m_weights_mb=float(accounting["M_weights_reported_mb"]),
            m_act_mb=float(accounting["M_act_mb"]),
            n_layers=int(accounting["n_layers"]),
            n_kv_heads=int(accounting["n_kv_heads"]),
            d_head=int(accounting["d_head"]),
            b_precision=float(accounting["b_precision"]),
        )
    )


def _dedupe_trajectory_by_boundary(traj: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Keep one point per logical boundary (last sample by t_ms).

    Trace JSON repeats the same boundary label at every VRAM poll; §7.1 targets
    node-boundary accuracy, not per-poll samples.
    """
    by_name: Dict[str, Dict[str, Any]] = {}
    for point in traj:
        name = str(point.get("boundary", ""))
        if not name:
            continue
        prev = by_name.get(name)
        if prev is None or float(point.get("t_ms", 0)) >= float(prev.get("t_ms", 0)):
            by_name[name] = point
    ordered = sorted(by_name.values(), key=lambda p: float(p.get("t_ms", 0)))
    return ordered


def build_trajectory_boundary_table(
    repo_root: Path,
    *,
    device: torch.device,
    split: str = "test",
) -> pd.DataFrame:
    """Per boundary: empirical vs predicted VRAM and absolute percentage error."""
    index = pd.read_parquet(repo_root / "data" / "traces" / "index.parquet")
    rows: List[dict] = []
    for agent_llm in AGENT_LLMS:
        bundle = load_agent_proxy_bundle(repo_root, agent_llm, device=device)
        outputs, l_base_t, _acc = run_proxy_forward_on_frame(bundle)
        n_hat = outputs.lambda_rate.squeeze(-1).detach().cpu().numpy()
        e_hat = outputs.e_hat.squeeze(-1).detach().cpu().numpy()
        t_hat = predicted_aggregated_tool_tokens(outputs, bundle.tool_mu).detach().cpu().numpy()
        l_base = l_base_t.detach().cpu().numpy()
        idx_agent = index[(index["agent_llm"] == agent_llm) & (index["split"] == split)].set_index(
            "prompt_id"
        )
        for i, (_, row) in enumerate(bundle.test_frame.iterrows()):
            pid = str(row["prompt_id"])
            traj = _parse_trajectory(row.get("y_trajectory_json"))
            if traj is None and pid in idx_agent.index:
                traj = _parse_trajectory(idx_agent.loc[pid].get("M_trajectory_true_json"))
            try:
                acc = accounting_dict(row)
            except ValueError:
                continue
            if not traj:
                continue
            traj = _dedupe_trajectory_by_boundary(traj)
            n_nodes = float(row.get("N_nodes_true", row.get("y_N_nodes", len(traj))))
            n_steps = max(1.0, n_nodes)
            for b_idx, point in enumerate(traj):
                m_emp = float(point["vram_used_mb"])
                m_pred = _predicted_vram_at_step(
                    step_index=b_idx,
                    n_steps=n_steps,
                    l_base=float(l_base[i]),
                    e_hat=float(e_hat[i]),
                    expected_tool_tokens=float(t_hat[i]),
                    accounting=acc,
                )
                denom = max(abs(m_emp), 1e-6)
                pct_err = abs(m_emp - m_pred) / denom * 100.0
                rows.append(
                    {
                        "agent_llm": agent_llm,
                        "prompt_id": pid,
                        "split": split,
                        "proxy_backbone": bundle.backbone_id,
                        "boundary_idx": int(b_idx),
                        "boundary": str(point.get("boundary", "")),
                        "m_emp_mb": m_emp,
                        "m_pred_mb": m_pred,
                        "abs_pct_err": float(pct_err),
                    }
                )
    return pd.DataFrame(rows)


def aggregate_trajectory_mape(boundaries: pd.DataFrame) -> pd.DataFrame:
    """Mean abs_pct_err per agent (guide §7.1 trajectory MAPE)."""
    if boundaries.empty:
        return pd.DataFrame(
            columns=["agent_llm", "proxy_backbone", "n_boundaries", "trajectory_mape_pct"]
        )
    rows: List[dict] = []
    for agent_llm, grp in boundaries.groupby("agent_llm", sort=False):
        rows.append(
            {
                "agent_llm": agent_llm,
                "proxy_backbone": str(grp["proxy_backbone"].iloc[0]),
                "n_boundaries": int(len(grp)),
                "trajectory_mape_pct": float(grp["abs_pct_err"].mean()),
            }
        )
    overall = float(boundaries["abs_pct_err"].mean())
    rows.append(
        {
            "agent_llm": "__all__",
            "proxy_backbone": "",
            "n_boundaries": int(len(boundaries)),
            "trajectory_mape_pct": overall,
        }
    )
    return pd.DataFrame(rows)
