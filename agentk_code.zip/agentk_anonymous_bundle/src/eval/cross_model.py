"""
fig 6 — cross-model proxy generalization (Qwen train → Phi/Mistral eval).
"""

from __future__ import annotations

from pathlib import Path
from typing import List

import pandas as pd
import torch

from src.baselines.common import DEFAULT_Z_ALPHA, load_baseline_frame, split_frame
from src.eval.loaders import load_ground_truth_test
from src.eval.metrics import summarize_predictions
from src.eval.proxy_bundle import best_proxy_backbone
from src.proxy.data import compute_tool_mu_tokens
from src.eval.proxy_bundle import peaks_from_bundle
from src.proxy.peak_mlp import load_peak_mlp_if_present, peaks_from_proxy_outputs
from src.proxy.model import build_multitask_proxy
from safetensors.torch import load_file

TRAIN_AGENT = "qwen2.5-coder-7b"
EVAL_AGENTS = ("qwen2.5-coder-7b", "phi-4-mini", "mistral-7b-instruct-v0.3")


def build_cross_model_generalization_table(
    repo_root: Path,
    *,
    device: torch.device,
    split: str = "test",
) -> pd.DataFrame:
    """
    Evaluate Qwen-trained proxy (best backbone) on each agent's test split.

    Rows include in-domain (qwen→qwen) and out-of-domain (qwen→phi/mistral).
    """
    backbone_id = best_proxy_backbone(repo_root, TRAIN_AGENT)
    weights_path = (
        repo_root / "artifacts" / "proxies" / TRAIN_AGENT / backbone_id / "model.safetensors"
    )
    qwen_frame = load_baseline_frame(repo_root=repo_root, agent_llm=TRAIN_AGENT)
    train_df, _val, _test = split_frame(qwen_frame)
    tool_mu = compute_tool_mu_tokens(train_df)

    model, tokenizer, spec = build_multitask_proxy(
        repo_root=repo_root,
        backbone_id=backbone_id,
        enable_variance_head=True,
        enable_stretch_heads=False,
    )
    state = load_file(str(weights_path))
    model.load_state_dict(state, strict=True)
    model = model.to(device)
    model.eval()
    peak_mlp = load_peak_mlp_if_present(repo_root, TRAIN_AGENT, backbone_id, device=device)

    rows: List[dict] = []
    for eval_agent in EVAL_AGENTS:
        truth = load_ground_truth_test(repo_root, eval_agent)
        eval_frame = load_baseline_frame(repo_root=repo_root, agent_llm=eval_agent)
        test = eval_frame[eval_frame["split"] == split].reset_index(drop=True)
        from src.baselines.common import accounting_dict
        from src.proxy.metrics import compute_l_base_batch

        goals = test["user_goal"].tolist()
        accounting_rows = [accounting_dict(row) for _, row in test.iterrows()]
        batch = model.encode_texts(
            goals, tokenizer=tokenizer, max_length=spec.max_seq_length, device=device
        )
        with torch.no_grad():
            outputs = model.forward(**batch)
            l_base = compute_l_base_batch(
                goals, tokenizer, max_length=spec.max_seq_length, device=device
            )
            m_peak, m_upper = peaks_from_proxy_outputs(
                outputs,
                l_base=l_base,
                accounting_rows=accounting_rows,
                tool_mu_tokens=tool_mu,
                z_alpha=DEFAULT_Z_ALPHA,
                peak_mlp=peak_mlp,
            )
        frame = pd.DataFrame(
            {
                "prompt_id": test["prompt_id"].tolist(),
                "agent_llm": eval_agent,
                "M_peak_true": truth.set_index("prompt_id")
                .loc[test["prompt_id"], "M_peak_true"]
                .to_numpy(),
                "Mpeak_pred": m_peak.detach().cpu().numpy(),
                "Mupper_pred": m_upper.detach().cpu().numpy(),
            }
        )
        row = summarize_predictions(
            frame,
            agent_llm=eval_agent,
            method="B4_cross",
            split=split,
            z_alpha=DEFAULT_Z_ALPHA,
        )
        row["train_agent_llm"] = TRAIN_AGENT
        row["eval_agent_llm"] = eval_agent
        row["proxy_backbone"] = backbone_id
        row["in_domain"] = eval_agent == TRAIN_AGENT
        rows.append(row)
    return pd.DataFrame(rows)
