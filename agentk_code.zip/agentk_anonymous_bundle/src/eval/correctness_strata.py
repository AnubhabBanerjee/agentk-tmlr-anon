"""
Phase 7 §7.3.b — proxy forecast metrics stratified by correctness.
"""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional

import numpy as np
import pandas as pd
import torch
from scipy import stats

from src.baselines.common import AGENT_LLMS, DEFAULT_Z_ALPHA
from src.eval.b4_sweep import build_b4_z_alpha_rows
from src.eval.context import EvalContext, eval_context
from src.eval.loaders import load_merged_predictions
from src.eval.metrics import mape_percent, mae_mb, oaw_mb, oaw_pct_of_ceiling, oom_rate
from src.eval.paths import CORRECTNESS_STRATA_METHODS, VRAM_CEILING_MB
from src.pipeline.tracing_paths import TracingPaths


def _load_test_labels(repo_root: Path, agent_llm: str, *, paths: TracingPaths) -> pd.DataFrame:
    """Test-split rows with compile and KernelBench numerical labels."""
    index = pd.read_parquet(paths.index_path)
    kb = pd.read_parquet(paths.correctness_parquet)
    test = index[(index["agent_llm"] == agent_llm) & (index["split"] == "test")].copy()
    kb_cols = (
        kb[["trace_jsonl", "agent_llm", "prompt_id", "numerical_correct_kbench"]].copy()
        if "trace_jsonl" in kb.columns
        else kb[["agent_llm", "prompt_id", "numerical_correct_kbench"]].copy()
    )
    if "trace_jsonl" in test.columns and "trace_jsonl" in kb_cols.columns:
        kb_merge = kb_cols.drop(columns=["agent_llm", "prompt_id"], errors="ignore")
        test = test.merge(kb_merge, on=["trace_jsonl"], how="left")
    else:
        test = test.merge(kb_cols, on=["agent_llm", "prompt_id"], how="left")
    if "prompt_id_x" in test.columns:
        test["prompt_id"] = test["prompt_id_x"]
        test = test.drop(columns=[c for c in ("prompt_id_x", "prompt_id_y", "agent_llm_x", "agent_llm_y") if c in test.columns])
    return test


def _label_has_variance(series: pd.Series) -> bool:
    """True when a binary correctness column has both True and False."""
    observed = series.dropna()
    if observed.empty:
        return False
    if observed.dtype == bool or set(observed.unique()).issubset({True, False, 0, 1}):
        return observed.astype(bool).nunique() >= 2
    return observed.nunique() >= 2


def _stratum_metrics(frame: pd.DataFrame) -> dict:
    """MAPE / OOM / OAW / MAE for one stratum slice."""
    if frame.empty:
        return {
            "n_rows": 0,
            "mape_pct": float("nan"),
            "mae_peak_mb": float("nan"),
            "oom_rate": float("nan"),
            "oaw_mb": float("nan"),
            "oaw_pct_ceiling": float("nan"),
        }
    y_true = frame["M_peak_true"].to_numpy(dtype=np.float64)
    y_pred = frame["Mpeak_pred"].to_numpy(dtype=np.float64)
    y_upper = frame["Mupper_pred"].to_numpy(dtype=np.float64)
    return {
        "n_rows": int(len(frame)),
        "mape_pct": mape_percent(y_true, y_pred),
        "mae_peak_mb": mae_mb(y_true, y_pred),
        "oom_rate": oom_rate(y_true, y_upper),
        "oaw_mb": oaw_mb(y_true, y_upper),
        "oaw_pct_ceiling": oaw_pct_of_ceiling(
            y_true, y_upper, m_ceiling_mb=VRAM_CEILING_MB
        ),
    }


def _mann_whitney_p(ape_correct: np.ndarray, ape_incorrect: np.ndarray) -> float:
    """Two-sided Mann–Whitney U on absolute pct errors (disjoint strata)."""
    if ape_correct.size < 2 or ape_incorrect.size < 2:
        return float("nan")
    _, p = stats.mannwhitneyu(ape_correct, ape_incorrect, alternative="two-sided")
    return float(p)


def _per_prompt_ape(frame: pd.DataFrame) -> np.ndarray:
    y_true = frame["M_peak_true"].to_numpy(dtype=np.float64)
    y_pred = frame["Mpeak_pred"].to_numpy(dtype=np.float64)
    denom = np.clip(np.abs(y_true), 1e-6, None)
    return np.abs(y_true - y_pred) / denom * 100.0


def _active_strata_methods(ctx: EvalContext) -> tuple[str, ...]:
    """Methods for §7.3.b; omit B4 when proxies are skipped."""
    allowed = set(ctx.methods)
    return tuple(m for m in CORRECTNESS_STRATA_METHODS if m in allowed)


def build_correctness_strata_table(
    repo_root: Path,
    *,
    device: torch.device,
    split: str = "test",
    ctx: Optional[EvalContext] = None,
) -> pd.DataFrame:
    """
    Per (agent, method, correctness label, stratum) forecast metrics on test.

    Strata are disjoint prompt sets; significance uses Mann–Whitney U on |APE|.
    Falls back to compile_success only when numerical_correct_kbench has no variance.
    """
    eval_ctx = ctx or eval_context(repo_root)
    paths = eval_ctx.tracing
    b4_by_agent: dict[str, str] = {}
    if not eval_ctx.skip_b4 and eval_ctx.has_proxies:
        b4_rows = build_b4_z_alpha_rows(repo_root, device=device, split=split)
        b4_by_agent = {
            row["agent_llm"]: row["proxy_backbone"]
            for _, row in b4_rows[b4_rows["z_alpha"] == DEFAULT_Z_ALPHA].iterrows()
        }
    methods = _active_strata_methods(eval_ctx)
    rows: List[dict] = []
    for agent_llm in AGENT_LLMS:
        labels = _load_test_labels(repo_root, agent_llm, paths=paths)
        for method in methods:
            if method == "B4":
                from src.eval.proxy_bundle import load_agent_proxy_bundle, peaks_from_bundle, run_proxy_forward_on_frame

                bundle = load_agent_proxy_bundle(
                    repo_root,
                    agent_llm,
                    device=device,
                    backbone_id=b4_by_agent.get(agent_llm),
                )
                outputs, l_base, accounting_rows = run_proxy_forward_on_frame(bundle)
                m_peak, m_upper = peaks_from_bundle(bundle, outputs, l_base, accounting_rows)
                pred = pd.DataFrame(
                    {
                        "prompt_id": bundle.test_frame["prompt_id"].tolist(),
                        "agent_llm": agent_llm,
                        "Mpeak_pred": m_peak.detach().cpu().numpy(),
                        "Mupper_pred": m_upper.detach().cpu().numpy(),
                    }
                )
                merged = load_merged_predictions(repo_root, agent_llm, "B2", paths=paths)
                merged = merged.drop(columns=[c for c in ("Mpeak_pred", "Mupper_pred") if c in merged.columns])
                merged = merged.merge(pred, on="prompt_id", how="left")
            else:
                merged = load_merged_predictions(repo_root, agent_llm, method, paths=paths)
            label_cols = [("compile_success", "compile_success")]
            if _label_has_variance(labels["numerical_correct_kbench"]):
                label_cols.append(("numerical_correct_kbench", "numerical_correct_kbench"))
            kb_cols = [
                c for c, _ in label_cols if c == "numerical_correct_kbench" and c not in merged.columns
            ]
            if kb_cols:
                merged = merged.merge(labels[["prompt_id"] + kb_cols], on="prompt_id", how="left")
            for label_col, label_name in label_cols:
                if label_col == "numerical_correct_kbench":
                    labeled = merged[merged["numerical_correct_kbench"].notna()].copy()
                    labeled[label_col] = labeled[label_col].astype(bool)
                else:
                    labeled = merged.copy()
                for stratum_val, stratum_name in [(True, "correct"), (False, "incorrect")]:
                    sub = labeled[labeled[label_col] == stratum_val]
                    met = _stratum_metrics(sub)
                    rows.append(
                        {
                            "agent_llm": agent_llm,
                            "method": method,
                            "split": split,
                            "z_alpha": DEFAULT_Z_ALPHA,
                            "correctness_label": label_name,
                            "stratum": stratum_name,
                            "proxy_backbone": b4_by_agent.get(agent_llm, ""),
                            **met,
                        }
                    )
                correct = labeled[labeled[label_col] == True]
                incorrect = labeled[labeled[label_col] == False]
                m_c = _stratum_metrics(correct)
                m_i = _stratum_metrics(incorrect)
                gap_pp = (
                    float(m_i["mape_pct"] - m_c["mape_pct"])
                    if np.isfinite(m_c["mape_pct"]) and np.isfinite(m_i["mape_pct"])
                    else float("nan")
                )
                p_val = _mann_whitney_p(_per_prompt_ape(correct), _per_prompt_ape(incorrect))
                rows.append(
                    {
                        "agent_llm": agent_llm,
                        "method": method,
                        "split": split,
                        "z_alpha": DEFAULT_Z_ALPHA,
                        "correctness_label": label_name,
                        "stratum": "gap_summary",
                        "proxy_backbone": b4_by_agent.get(agent_llm, ""),
                        "n_rows": int(m_c["n_rows"] + m_i["n_rows"]),
                        "mape_pct": gap_pp,
                        "mae_peak_mb": float("nan"),
                        "oom_rate": float("nan"),
                        "oaw_mb": float("nan"),
                        "mape_gap_pp": gap_pp,
                        "stratum_test_p_value": p_val,
                    }
                )
    return pd.DataFrame(rows)
