"""
Phase 7 / F6 Tier-2 — stratified peak-VRAM MAPE by ``M_peak_true`` bucket.

Reports per-bucket MAPE plus a macro-averaged headline (equal weight per
non-empty bucket) so percentages stay legible when global denominators vary.
"""

from __future__ import annotations

from pathlib import Path
from typing import List

import pandas as pd
import torch

from src.baselines.common import AGENT_LLMS, DEFAULT_Z_ALPHA
from src.eval.b4_sweep import build_b4_merged_predictions
from src.eval.context import active_baseline_methods, skip_b4_from_env
from src.eval.loaders import join_predictions_to_truth, load_ground_truth_test, load_merged_predictions, load_predictions
from src.eval.metrics import (
    PEAK_VRAM_BUCKET_LABELS,
    assign_peak_vram_buckets,
    macro_averaged_mape,
    mape_percent,
)


def _per_bucket_mape(frame: pd.DataFrame) -> dict[str, float]:
    """MAPE per F6 bucket label for one (agent, method) prediction frame."""
    # Copy avoids mutating the caller's merged prediction/truth frame.
    work = frame.copy()
    # Bucket column drives per-stratum MAPE aggregation below.
    work["peak_vram_bucket"] = assign_peak_vram_buckets(work["M_peak_true"])
    # Initialise every canonical bucket to NaN (empty strata stay missing).
    out: dict[str, float] = {label: float("nan") for label in PEAK_VRAM_BUCKET_LABELS}
    # Compute MAPE only on rows that landed in each bucket.
    for label in PEAK_VRAM_BUCKET_LABELS:
        # Slice rows whose true peak VRAM falls in this stratum.
        sub = work[work["peak_vram_bucket"] == label]
        # Skip empty buckets — macro average ignores them later.
        if sub.empty:
            continue
        # Standard MAPE on in-bucket prompts only.
        out[label] = mape_percent(
            sub["M_peak_true"].to_numpy(dtype=float),
            sub["Mpeak_pred"].to_numpy(dtype=float),
        )
    return out


def build_vram_strata_mape_table(
    repo_root: Path,
    *,
    device: torch.device,
    split: str = "test",
    z_alpha: float = DEFAULT_Z_ALPHA,
) -> pd.DataFrame:
    """
    Per (agent, method, peak_vram_bucket) MAPE on the test split.

    Includes one ``__macro_avg__`` row per (agent, method) with the equal-weight
    mean of non-empty bucket MAPEs (F6 Tier-2 headline).
    """
    # Accumulate long-form rows for parquet export and summary tables.
    rows: List[dict] = []
    # Same agent × method loop as ``build_primary_test_table``.
    for agent_llm in AGENT_LLMS:
        for method in active_baseline_methods():
            if method == "B4":
                if skip_b4_from_env():
                    continue
                try:
                    # Match primary_test B4 refresh (proxy re-inference, not Phase-6 parquet).
                    merged = build_b4_merged_predictions(
                        repo_root, agent_llm, device=device, z_alpha=z_alpha
                    )
                except (FileNotFoundError, OSError):
                    continue
            else:
                try:
                    merged = load_merged_predictions(repo_root, agent_llm, method)
                except FileNotFoundError:
                    continue
            # Per-bucket MAPE dict (NaN for empty buckets).
            bucket_map = _per_bucket_mape(merged)
            # Tag merged rows once for per-bucket row counts.
            merged = merged.copy()
            merged["peak_vram_bucket"] = assign_peak_vram_buckets(merged["M_peak_true"])
            # Emit one row per canonical bucket label (even if ``n_rows=0``).
            for label in PEAK_VRAM_BUCKET_LABELS:
                sub = merged[merged["peak_vram_bucket"] == label]
                rows.append(
                    {
                        "agent_llm": agent_llm,
                        "method": method,
                        "split": split,
                        "z_alpha": float(z_alpha),
                        "peak_vram_bucket": label,
                        "n_rows": int(len(sub)),
                        "mape_pct": bucket_map[label],
                    }
                )
            # Macro-averaged MAPE across populated buckets only.
            rows.append(
                {
                    "agent_llm": agent_llm,
                    "method": method,
                    "split": split,
                    "z_alpha": float(z_alpha),
                    "peak_vram_bucket": "__macro_avg__",
                    "n_rows": int(len(merged)),
                    "mape_pct": macro_averaged_mape(bucket_map),
                }
            )
    return pd.DataFrame(rows)


def augment_primary_with_stratified_mape(
    primary: pd.DataFrame,
    strata: pd.DataFrame,
) -> pd.DataFrame:
    """
    Add ``mape_strat_macro_pct`` to the primary table from ``__macro_avg__`` rows.
    """
    # Nothing to merge if stratified table was not built.
    if strata.empty or primary.empty:
        return primary.copy()
    # Pull macro-average rows only (one per agent × method).
    macro = strata[strata["peak_vram_bucket"] == "__macro_avg__"][
        ["agent_llm", "method", "mape_pct"]
    ].rename(columns={"mape_pct": "mape_strat_macro_pct"})
    # Left join preserves primary row order and methods without strata.
    out = primary.merge(macro, on=["agent_llm", "method"], how="left")
    return out
