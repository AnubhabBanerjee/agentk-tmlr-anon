"""
One-way ANOVA variance decomposition of per-agent M_peak_true_mb (guide C5 / step 33).

Reads trace index + optional label shards; emits parquet metrics and a LaTeX summary table.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from scipy import stats

# Human-readable grouping keys stored in ``grouping`` column of output parquet.
GROUPING_PROMPT_FAMILY: str = "prompt_family"
GROUPING_RETRY_COUNT: str = "retry_count"
GROUPING_CONFIG_SWEEP: str = "config_sweep"

# Ordered list drives row order in generated LaTeX tables.
GROUPING_ORDER: Tuple[str, ...] = (
    GROUPING_PROMPT_FAMILY,
    GROUPING_RETRY_COUNT,
    GROUPING_CONFIG_SWEEP,
)

# Short agent labels for figure titles / compact tables.
AGENT_LABELS: Dict[str, str] = {
    "qwen2.5-coder-7b": "Qwen-7B",
    "qwen2.5-coder-14b": "Qwen-14B",
    "phi-4-mini": "Phi",
    "mistral-7b-instruct-v0.3": "Mistral",
}


def _nan_result(agent_llm: str, grouping: str, n: int = 0) -> Dict[str, Any]:
    """Return a schema-complete row filled with NaN for degenerate one-way ANOVA cells."""
  # Degenerate cells still carry agent/grouping identity so downstream tables keep fixed shape.
    return {
        "agent_llm": agent_llm,
        "grouping": grouping,
        "total_var_mb2": np.nan,
        "between_var_mb2": np.nan,
        "eta_sq": np.nan,
        "F": np.nan,
        "df_num": np.nan,
        "df_den": np.nan,
        "p_value": np.nan,
        "n": n,
        "residual_frac": np.nan,
    }


def _one_way_anova_row(
    agent_llm: str,
    grouping: str,
    y: np.ndarray,
    group_labels: np.ndarray,
) -> Dict[str, Any]:
    """
    Compute one-way ANOVA variance partition for a single (agent, grouping) pair.

    ``eta_sq`` = SS_between / SS_total; ``residual_frac`` = 1 - ``eta_sq``.
  # ``between_var_mb2`` is scaled so ``eta_sq = between_var / total_var`` with sample variance.
    """
    # Coerce to float arrays and drop rows with missing outcome or group label.
    y = np.asarray(y, dtype=np.float64)
    group_labels = np.asarray(group_labels)
    valid = np.isfinite(y) & pd.notna(group_labels)
    y = y[valid]
    group_labels = group_labels[valid]
    n = int(y.size)
    # Fewer than two observations cannot define a variance or ANOVA.
    if n < 2:
        return _nan_result(agent_llm, grouping, n=n)
    # Unique non-null group levels; fewer than two levels → skip with NaN per spec.
    levels = pd.unique(group_labels)
    levels = levels[pd.notna(levels)]
    if len(levels) < 2:
        return _nan_result(agent_llm, grouping, n=n)
    # Build per-level sample arrays for scipy.stats.f_oneway.
    group_arrays: List[np.ndarray] = []
    for level in levels:
        mask = group_labels == level
        if mask.sum() == 0:
            continue
        group_arrays.append(y[mask])
    if len(group_arrays) < 2:
        return _nan_result(agent_llm, grouping, n=n)
    # Classic one-way F-test (two-sided p-value from F distribution).
    f_stat, p_value = stats.f_oneway(*group_arrays)
    grand_mean = float(y.mean())
    ss_total = float(((y - grand_mean) ** 2).sum())
    if ss_total <= 0.0:
        return _nan_result(agent_llm, grouping, n=n)
    ss_between = 0.0
    for arr in group_arrays:
        ss_between += float(arr.size) * (float(arr.mean()) - grand_mean) ** 2
    eta_sq = ss_between / ss_total
    total_var_mb2 = ss_total / (n - 1)
    between_var_mb2 = eta_sq * total_var_mb2
    residual_frac = 1.0 - eta_sq
    df_num = len(group_arrays) - 1
    df_den = n - len(group_arrays)
    return {
        "agent_llm": agent_llm,
        "grouping": grouping,
        "total_var_mb2": total_var_mb2,
        "between_var_mb2": between_var_mb2,
        "eta_sq": eta_sq,
        "F": float(f_stat),
        "df_num": float(df_num),
        "df_den": float(df_den),
        "p_value": float(p_value),
        "n": n,
        "residual_frac": residual_frac,
    }


def load_variance_frame(
    repo_root: Path,
    *,
    index_path: Optional[Path] = None,
    correctness_path: Optional[Path] = None,
    labels_glob: Optional[str] = None,
) -> pd.DataFrame:
    """
    Load and join trace index, correctness parquet, and label shards.

    Grouping columns are taken from the index; labels are merged for schema validation.
    """
    repo_root = Path(repo_root)
    if index_path is None:
        index_path = repo_root / "data/traces_v2/index.parquet"
    if correctness_path is None:
        correctness_path = repo_root / "data/correctness_v2/kernelbench.parquet"
    if labels_glob is None:
        label_paths = sorted((repo_root / "data/labels_v2").glob("*.parquet"))
    else:
        label_paths = sorted(Path(repo_root).glob(labels_glob))
    # Primary measurement frame: one row per traced run.
    index = pd.read_parquet(index_path)
    correctness = pd.read_parquet(correctness_path)
    label_frames = [pd.read_parquet(p) for p in label_paths]
    labels = pd.concat(label_frames, ignore_index=True) if label_frames else pd.DataFrame()
    # Join correctness on trace_jsonl (unique per run; prompt_id alone duplicates sweeps).
    merge_key = "trace_jsonl"
    if merge_key in index.columns and merge_key in correctness.columns:
        corr_cols = [c for c in correctness.columns if c not in index.columns or c == merge_key]
        merged = index.merge(
            correctness[corr_cols],
            on=merge_key,
            how="left",
        )
    else:
        corr_dedup = correctness.drop_duplicates(subset=["agent_llm", "prompt_id"], keep="first")
        merged = index.merge(
            corr_dedup,
            on=["agent_llm", "prompt_id"],
            how="left",
            suffixes=("", "_corr"),
        )
    if not labels.empty and "trace_jsonl" in labels.columns:
        label_cols = [c for c in ["trace_jsonl", "prompt_id", "agent_llm"] if c in labels.columns]
        merged = merged.merge(
            labels[label_cols].drop_duplicates(subset=["trace_jsonl"]),
            on="trace_jsonl",
            how="left",
            suffixes=("", "_lbl"),
        )
    if "M_peak_true_mb" not in merged.columns:
        if "M_peak_true" in merged.columns:
            merged["M_peak_true_mb"] = merged["M_peak_true"]
        else:
            raise KeyError("index must contain M_peak_true_mb or M_peak_true")
    return merged


def _config_sweep_label(row: pd.Series) -> str:
    """Tuple key string for (n_ctx, cache_type_k, cache_type_v) sweep cells."""
    return (
        f"n_ctx={int(row['n_ctx'])};"
        f"k={row['cache_type_k']};"
        f"v={row['cache_type_v']}"
    )


def build_variance_decomposition_table(frame: pd.DataFrame) -> pd.DataFrame:
    """Run one-way ANOVA per (agent_llm × grouping) on ``M_peak_true_mb``."""
    rows: List[Dict[str, Any]] = []
    agents = sorted(frame["agent_llm"].unique())
    for agent in agents:
        sub = frame[frame["agent_llm"] == agent].copy()
        y_all = sub["M_peak_true_mb"].to_numpy(dtype=np.float64)
        # --- Prompt family: prompt_source has three canonical levels in released.
        prompt_groups = sub["prompt_source"].astype(str).to_numpy()
        rows.append(
            _one_way_anova_row(agent, GROUPING_PROMPT_FAMILY, y_all, prompt_groups)
        )
        # --- Retry count: discrete retry_count field (matches Table 3's global
        # retry-count histogram; NOT the same column as n_compile_attempts,
        # which differs on a minority of rows -- keep this grouping and Table 3
        # speaking the same vocabulary).
        retry_groups = sub["retry_count"].to_numpy()
        rows.append(
            _one_way_anova_row(agent, GROUPING_RETRY_COUNT, y_all, retry_groups)
        )
        # --- Config sweep: only is_sweep=True rows; skip if no sweep rows for agent.
        sweep = sub[sub["is_sweep"].astype(bool)]
        if sweep.empty:
            rows.append(_nan_result(agent, GROUPING_CONFIG_SWEEP, n=0))
        else:
            sweep = sweep.copy()
            sweep["_config_key"] = sweep.apply(_config_sweep_label, axis=1)
            rows.append(
                _one_way_anova_row(
                    agent,
                    GROUPING_CONFIG_SWEEP,
                    sweep["M_peak_true_mb"].to_numpy(dtype=np.float64),
                    sweep["_config_key"].to_numpy(),
                )
            )
    out = pd.DataFrame(rows)
    col_order = [
        "agent_llm",
        "grouping",
        "total_var_mb2",
        "between_var_mb2",
        "eta_sq",
        "F",
        "df_num",
        "df_den",
        "p_value",
        "n",
        "residual_frac",
    ]
    return out[col_order]


def _grouping_display_name(grouping: str) -> str:
    """Map internal grouping key to paper-facing label."""
    return {
        GROUPING_PROMPT_FAMILY: "Prompt family",
        GROUPING_RETRY_COUNT: "Retry count",
        GROUPING_CONFIG_SWEEP: "Config sweep",
    }.get(grouping, grouping)


def _agent_display(agent: str) -> str:
    """Short agent name for LaTeX tables."""
    return AGENT_LABELS.get(agent, agent.replace("_", "\\_"))


def render_variance_decomposition_tex(df: pd.DataFrame) -> str:
    """Booktabs LaTeX table: one row per (agent × grouping)."""
    lines = [
        "% Auto-generated from paper/results_v2/metrics/variance_decomposition.parquet",
        "\\begin{table}[t]",
        "\\centering",
        "\\caption{One-way ANOVA of $M_{\\mathrm{peak,true}}$ (MiB) by grouping factor. "
        "Config sweep rows use \\texttt{is\\_sweep=True} subsets only; "
        "$\\mathrm{NaN}$ indicates a degenerate single-level factor.}",
        "\\label{tab:variance-decomposition}",
        "\\begin{tabular}{llrrrrr}",
        "\\toprule",
        "Agent & Grouping & $\\eta^2$ & $F$ & $p$ & $n$ & Residual frac. \\\\",
        "\\midrule",
    ]
    for agent in sorted(df["agent_llm"].unique()):
        sub = df[df["agent_llm"] == agent]
        for grouping in GROUPING_ORDER:
            row = sub[sub["grouping"] == grouping]
            if row.empty:
                continue
            r = row.iloc[0]
            eta = r["eta_sq"]
            f_val = r["F"]
            p_val = r["p_value"]
            resid = r["residual_frac"]
            eta_s = "---" if pd.isna(eta) else f"{eta:.3f}"
            f_s = "---" if pd.isna(f_val) else f"{f_val:.2f}"
            p_s = "---" if pd.isna(p_val) else f"{p_val:.2e}"
            resid_s = "---" if pd.isna(resid) else f"{resid:.3f}"
            lines.append(
                f"{_agent_display(str(agent))} & {_grouping_display_name(str(grouping))} "
                f"& {eta_s} & {f_s} & {p_s} & {int(r['n'])} & {resid_s} \\\\"
            )
    lines.extend(["\\bottomrule", "\\end{tabular}", "\\end{table}", ""])
    return "\n".join(lines)


def write_variance_decomposition_outputs(
    df: pd.DataFrame,
    *,
    out_parquet: Path,
    out_tex: Path,
) -> Tuple[Path, Path]:
    """Persist parquet metrics and LaTeX table."""
    out_parquet = Path(out_parquet)
    out_tex = Path(out_tex)
    out_parquet.parent.mkdir(parents=True, exist_ok=True)
    out_tex.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(out_parquet, index=False)
    out_tex.write_text(render_variance_decomposition_tex(df), encoding="utf-8")
    return out_parquet, out_tex


def summarize_residual_range(
    df: pd.DataFrame,
    *,
    exclude_config_sweep: bool = True,
) -> Tuple[float, float, float]:
    """
    Return (min_residual_pct, max_residual_pct, max_eta_sq_pct) over valid ANOVA rows.

    By default excludes ``config_sweep`` rows (sweep-subset-only; dominates by design).
    """
    valid = df.dropna(subset=["residual_frac"])
    if exclude_config_sweep:
        valid = valid[valid["grouping"] != GROUPING_CONFIG_SWEEP]
    if valid.empty:
        return float("nan"), float("nan"), float("nan")
    min_res = float(valid["residual_frac"].min() * 100.0)
    max_res = float(valid["residual_frac"].max() * 100.0)
    max_eta = float(valid["eta_sq"].max() * 100.0)
    return min_res, max_res, max_eta
