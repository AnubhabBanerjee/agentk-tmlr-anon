"""
Phase 7 §7.3.a — empirical joint distribution of peak VRAM vs correctness.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
from scipy import stats


def _partial_correlation(x: np.ndarray, y: np.ndarray, z: np.ndarray) -> float:
    """Pearson partial correlation r(x, y | z) via residualization."""
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    z = np.asarray(z, dtype=np.float64)
    if x.size < 3 or np.std(z) < 1e-12:
        return float("nan")
    rz_x = stats.linregress(z, x)
    rz_y = stats.linregress(z, y)
    res_x = x - (rz_x.intercept + rz_x.slope * z)
    res_y = y - (rz_y.intercept + rz_y.slope * z)
    if np.std(res_x) < 1e-12 or np.std(res_y) < 1e-12:
        return float("nan")
    return float(stats.pearsonr(res_x, res_y)[0])


def _point_biserial_safe(x: np.ndarray, y_binary: np.ndarray) -> Dict[str, float]:
    """Point-biserial r and two-sided p-value; NaN if y has no variance."""
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y_binary, dtype=np.float64)
    if y.size == 0 or np.unique(y[~np.isnan(y)]).size < 2:
        return {"r_pb": float("nan"), "p_value": float("nan"), "n": int(y.size)}
    r, p = stats.pointbiserialr(y, x)
    return {"r_pb": float(r), "p_value": float(p), "n": int(y.size)}


def _conditional_peak_stats(frame: pd.DataFrame, label_col: str) -> List[dict]:
    """Mean/std/count of M_peak_true conditional on binary label."""
    rows: List[dict] = []
    for val, name in [(True, "correct"), (False, "incorrect")]:
        sub = frame[frame[label_col] == val]
        if sub.empty:
            rows.append(
                {
                    "stratum": name,
                    "n": 0,
                    "m_peak_mean_mb": float("nan"),
                    "m_peak_std_mb": float("nan"),
                    "m_peak_median_mb": float("nan"),
                }
            )
            continue
        peaks = sub["M_peak_true"].to_numpy(dtype=np.float64)
        rows.append(
            {
                "stratum": name,
                "n": int(len(sub)),
                "m_peak_mean_mb": float(np.mean(peaks)),
                "m_peak_std_mb": float(np.std(peaks)),
                "m_peak_median_mb": float(np.median(peaks)),
            }
        )
    return rows


from src.pipeline.tracing_paths import tracing_paths_from_env


def load_joint_analysis_frame(repo_root: Path) -> pd.DataFrame:
    """Join trace index with KernelBench numerical correctness labels."""
    layout = tracing_paths_from_env(repo_root=repo_root)
    index = pd.read_parquet(layout.index_path)
    kb = pd.read_parquet(layout.correctness_parquet)
    kb_cols = kb[
        ["trace_jsonl", "agent_llm", "prompt_id", "numerical_correct_kbench", "harness_status"]
    ].copy() if "trace_jsonl" in kb.columns else kb[
        ["agent_llm", "prompt_id", "numerical_correct_kbench", "harness_status"]
    ].copy()
    if "trace_jsonl" in index.columns and "trace_jsonl" in kb_cols.columns:
        kb_merge = kb_cols.drop(columns=["agent_llm", "prompt_id"], errors="ignore")
        merged = index.merge(kb_merge, on=["trace_jsonl"], how="left")
    else:
        merged = index.merge(kb_cols, on=["agent_llm", "prompt_id"], how="left")
    merged["is_kernelbench"] = merged["prompt_source"] == "kernelbench"
    return merged


def build_correctness_joint_table(repo_root: Path) -> pd.DataFrame:
    """
    Per-agent correlations and conditional VRAM stats (§7.3.a).

    Rows tagged by analysis axis: compile_success (all prompts) or
    numerical_correct_kbench (KernelBench subset with observed label).
    """
    frame = load_joint_analysis_frame(repo_root)
    rows: List[dict] = []
    for agent_llm, grp in frame.groupby("agent_llm", sort=False):
        peaks = grp["M_peak_true"].to_numpy(dtype=np.float64)
        compile_y = grp["compile_success"].astype(float).to_numpy()
        pb_compile = _point_biserial_safe(peaks, compile_y)
        attempts = grp["n_compile_attempts"].to_numpy(dtype=np.float64)
        partial_compile = _partial_correlation(peaks, compile_y, attempts)
        for cond in _conditional_peak_stats(grp, "compile_success"):
            rows.append(
                {
                    "agent_llm": agent_llm,
                    "label": "compile_success",
                    "subset": "all_prompts",
                    "metric": f"conditional_{cond['stratum']}",
                    "n": cond["n"],
                    "value": cond["m_peak_mean_mb"],
                    "extra": cond["m_peak_std_mb"],
                    "r_pb": pb_compile["r_pb"],
                    "p_value": pb_compile["p_value"],
                    "partial_r_given_attempts": partial_compile,
                }
            )
        rows.append(
            {
                "agent_llm": agent_llm,
                "label": "compile_success",
                "subset": "all_prompts",
                "metric": "point_biserial_r",
                "n": pb_compile["n"],
                "value": pb_compile["r_pb"],
                "extra": pb_compile["p_value"],
                "r_pb": pb_compile["r_pb"],
                "p_value": pb_compile["p_value"],
                "partial_r_given_attempts": partial_compile,
            }
        )
        kb = grp[grp["is_kernelbench"]].copy()
        kb_obs = kb[kb["numerical_correct_kbench"].notna()].copy()
        if kb_obs.empty:
            rows.append(
                {
                    "agent_llm": agent_llm,
                    "label": "numerical_correct_kbench",
                    "subset": "kernelbench_labeled",
                    "metric": "point_biserial_r",
                    "n": 0,
                    "value": float("nan"),
                    "extra": float("nan"),
                    "r_pb": float("nan"),
                    "p_value": float("nan"),
                    "partial_r_given_attempts": float("nan"),
                }
            )
            continue
        kb_obs["numerical_correct_kbench"] = kb_obs["numerical_correct_kbench"].astype(bool)
        peaks_kb = kb_obs["M_peak_true"].to_numpy(dtype=np.float64)
        num_y = kb_obs["numerical_correct_kbench"].astype(float).to_numpy()
        pb_num = _point_biserial_safe(peaks_kb, num_y)
        partial_num = _partial_correlation(
            peaks_kb, num_y, kb_obs["n_compile_attempts"].to_numpy(dtype=np.float64)
        )
        for cond in _conditional_peak_stats(kb_obs, "numerical_correct_kbench"):
            rows.append(
                {
                    "agent_llm": agent_llm,
                    "label": "numerical_correct_kbench",
                    "subset": "kernelbench_labeled",
                    "metric": f"conditional_{cond['stratum']}",
                    "n": cond["n"],
                    "value": cond["m_peak_mean_mb"],
                    "extra": cond["m_peak_std_mb"],
                    "r_pb": pb_num["r_pb"],
                    "p_value": pb_num["p_value"],
                    "partial_r_given_attempts": partial_num,
                }
            )
        rows.append(
            {
                "agent_llm": agent_llm,
                "label": "numerical_correct_kbench",
                "subset": "kernelbench_labeled",
                "metric": "point_biserial_r",
                "n": pb_num["n"],
                "value": pb_num["r_pb"],
                "extra": pb_num["p_value"],
                "r_pb": pb_num["r_pb"],
                "p_value": pb_num["p_value"],
                "partial_r_given_attempts": partial_num,
            }
        )
    return pd.DataFrame(rows)
