"""
Phase 7 §7.4 — bootstrap 95% CIs over the test split (guide: 600 resamples).
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd
import torch

from src.baselines.common import AGENT_LLMS, DEFAULT_Z_ALPHA
from src.eval.context import active_baseline_methods, skip_b4_from_env
from src.eval.loaders import join_predictions_to_truth, load_ground_truth_test, load_merged_predictions, load_predictions
from src.eval.metrics import mae_mb, mape_percent, oaw_mb, oaw_pct_of_ceiling, oom_rate, summarize_predictions
from src.eval.proxy_bundle import load_agent_proxy_bundle, peaks_from_bundle, run_proxy_forward_on_frame

# Guide §7.4: 600 bootstrap draws over the 90-prompt test set per agent.
BOOTSTRAP_RESAMPLES: int = 600
BOOTSTRAP_CI_ALPHA: float = 0.05
BOOTSTRAP_SEED: int = 20260718

# Primary metrics that receive bootstrap intervals.
BOOTSTRAP_METRICS: tuple[str, ...] = (
    "mape_pct",
    "mae_peak_mb",
    "oom_rate",
    "oaw_pct_ceiling",
)


def _load_b4_test_frame(
    repo_root: Path,
    agent_llm: str,
    *,
    device: torch.device,
) -> pd.DataFrame:
    """Per-prompt B4 predictions at z_alpha=1.96 from best proxy backbone."""
    truth = load_ground_truth_test(repo_root, agent_llm)
    bundle = load_agent_proxy_bundle(repo_root, agent_llm, device=device)
    outputs, l_base, accounting_rows = run_proxy_forward_on_frame(bundle)
    m_peak, m_upper = peaks_from_bundle(bundle, outputs, l_base, accounting_rows)
    prompt_ids = bundle.test_frame["prompt_id"].tolist()
    return pd.DataFrame(
        {
            "prompt_id": prompt_ids,
            "agent_llm": agent_llm,
            "M_peak_true": truth.set_index("prompt_id")
            .loc[prompt_ids, "M_peak_true"]
            .to_numpy(),
            "Mpeak_pred": m_peak.detach().cpu().numpy(),
            "Mupper_pred": m_upper.detach().cpu().numpy(),
            "proxy_backbone": bundle.backbone_id,
        }
    )


def build_per_prompt_test_frames(
    repo_root: Path,
    *,
    device: torch.device,
    split: str = "test",
) -> Dict[str, Dict[str, pd.DataFrame]]:
    """
    Nested map agent_llm → method → joined prediction frame (one row per test prompt).

    B4 is recomputed from the best Phase-5 proxy; other methods load Phase 6 parquets.
    """
    frames: Dict[str, Dict[str, pd.DataFrame]] = {}
    for agent_llm in AGENT_LLMS:
        agent_frames: Dict[str, pd.DataFrame] = {}
        for method in active_baseline_methods():
            if method == "B4":
                if skip_b4_from_env():
                    continue
                agent_frames[method] = _load_b4_test_frame(
                    repo_root, agent_llm, device=device
                )
                continue
            try:
                agent_frames[method] = load_merged_predictions(repo_root, agent_llm, method)
            except FileNotFoundError:
                continue
        frames[agent_llm] = agent_frames
    return frames


def _bootstrap_metric_values(
    frame: pd.DataFrame,
    *,
    metric: str,
    n_resamples: int,
    rng: np.random.Generator,
) -> np.ndarray:
    """Vector of one scalar metric per bootstrap resample."""
    y_true = frame["M_peak_true"].to_numpy(dtype=np.float64)
    y_pred = frame["Mpeak_pred"].to_numpy(dtype=np.float64)
    y_upper = frame["Mupper_pred"].to_numpy(dtype=np.float64)
    n = len(frame)
    out = np.empty(n_resamples, dtype=np.float64)
    for b in range(n_resamples):
        idx = rng.integers(0, n, size=n)
        yt = y_true[idx]
        yp = y_pred[idx]
        yu = y_upper[idx]
        if metric == "mape_pct":
            out[b] = mape_percent(yt, yp)
        elif metric == "mae_peak_mb":
            out[b] = mae_mb(yt, yp)
        elif metric == "oom_rate":
            out[b] = oom_rate(yt, yu)
        elif metric == "oaw_mb":
            out[b] = oaw_mb(yt, yu)
        elif metric == "oaw_pct_ceiling":
            out[b] = oaw_pct_of_ceiling(yt, yu)
        else:
            raise KeyError(f"Unknown bootstrap metric: {metric}")
    return out


def build_bootstrap_ci_table(
    repo_root: Path,
    *,
    device: torch.device,
    split: str = "test",
    n_resamples: int = BOOTSTRAP_RESAMPLES,
) -> pd.DataFrame:
    """
    Bootstrap 95% CIs for primary metrics (MAPE, MAE, OOM, OAW).

    Each row: (agent_llm, method, metric) with point estimate and [lo, hi] CI.
    """
    per_agent = build_per_prompt_test_frames(repo_root, device=device, split=split)
    rows: List[dict] = []
    lo_q = 100.0 * (BOOTSTRAP_CI_ALPHA / 2.0)
    hi_q = 100.0 * (1.0 - BOOTSTRAP_CI_ALPHA / 2.0)
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    for agent_llm, method_frames in per_agent.items():
        for method, frame in method_frames.items():
            point = summarize_predictions(
                frame,
                agent_llm=agent_llm,
                method=method,
                split=split,
                z_alpha=DEFAULT_Z_ALPHA,
            )
            backbone = ""
            if method == "B4" and "proxy_backbone" in frame.columns:
                backbone = str(frame["proxy_backbone"].iloc[0])
            for metric in BOOTSTRAP_METRICS:
                samples = _bootstrap_metric_values(
                    frame, metric=metric, n_resamples=n_resamples, rng=rng
                )
                ci_lo = float(np.percentile(samples, lo_q))
                ci_hi = float(np.percentile(samples, hi_q))
                rows.append(
                    {
                        "agent_llm": agent_llm,
                        "method": method,
                        "split": split,
                        "z_alpha": DEFAULT_Z_ALPHA,
                        "metric": metric,
                        "point_estimate": float(point[metric]),
                        "ci_lo": ci_lo,
                        "ci_hi": ci_hi,
                        "ci_level": 1.0 - BOOTSTRAP_CI_ALPHA,
                        "n_resamples": int(n_resamples),
                        "n_prompts": int(len(frame)),
                        "proxy_backbone": backbone,
                    }
                )
    return pd.DataFrame(rows)
