"""
Phase 7 — core forecast evaluation metrics (project_plan.md §4.3).

F6 Tier-2: stratified MAPE by peak-VRAM bucket avoids tiny-denominator blow-ups
when ``M_peak`` spans orders of magnitude (guide §F6).

F7 Tier-2: OAW reported as ``max(0, M_upper - M_peak) / M_ceiling`` (percent of
hardware ceiling) instead of absolute megabytes (guide §F7).
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from src.eval.paths import VRAM_CEILING_MB

# F6 Tier-2 bucket edges in megabytes (``M_peak_true`` is stored in MB).
# Buckets: ``<1 GB``, ``1–5 GB``, ``5–20 GB``, ``>20 GB`` (guide §F6).
_PEAK_VRAM_BUCKET_EDGES_MB: tuple[float, ...] = (1024.0, 5120.0, 20480.0)
PEAK_VRAM_BUCKET_LABELS: tuple[str, ...] = (
    "<1 GB",
    "1–5 GB",
    "5–20 GB",
    ">20 GB",
)


def peak_vram_bucket_mb(m_peak_mb: float) -> str:
    """
    Assign one ``M_peak_true`` value (megabytes) to an F6 VRAM stratum label.

    Left-closed intervals on the upper edges: 1 GB → ``1–5 GB``, 5 GB → ``5–20 GB``.
    """
    # Coerce to float so pandas/numpy scalars and None-ish inputs behave predictably.
    m = float(m_peak_mb)
    # First bucket: strictly below 1 GiB (1024 MiB).
    if m < _PEAK_VRAM_BUCKET_EDGES_MB[0]:
        return PEAK_VRAM_BUCKET_LABELS[0]
    # Second bucket: [1 GiB, 5 GiB).
    if m < _PEAK_VRAM_BUCKET_EDGES_MB[1]:
        return PEAK_VRAM_BUCKET_LABELS[1]
    # Third bucket: [5 GiB, 20 GiB).
    if m < _PEAK_VRAM_BUCKET_EDGES_MB[2]:
        return PEAK_VRAM_BUCKET_LABELS[2]
    # Fourth bucket: 20 GiB and above.
    return PEAK_VRAM_BUCKET_LABELS[3]


def assign_peak_vram_buckets(m_peak_series: pd.Series) -> pd.Series:
    """Vectorised F6 bucket labels for a column of ``M_peak_true`` (MB)."""
    # ``map`` keeps index alignment with the input frame for groupby joins.
    return m_peak_series.map(peak_vram_bucket_mb)


def macro_averaged_mape(bucket_mape: dict[str, float]) -> float:
    """
    Equal-weight mean of per-bucket MAPE values (F6 “bucket-averaged” headline).

    Empty buckets are skipped; returns NaN if no finite bucket MAPE exists.
    """
    # Collect only finite bucket-level MAPE values (non-empty strata).
    finite = [v for v in bucket_mape.values() if np.isfinite(v)]
    # No populated buckets → undefined macro average.
    if not finite:
        return float("nan")
    # Macro mean: each non-empty bucket counts equally regardless of ``n``.
    return float(np.mean(finite))


def mape_percent(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Mean absolute percentage error in percent."""
    y_true = np.asarray(y_true, dtype=np.float64)
    y_pred = np.asarray(y_pred, dtype=np.float64)
    denom = np.clip(np.abs(y_true), 1e-6, None)
    return float(np.mean(np.abs(y_true - y_pred) / denom) * 100.0)


def mae_mb(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Mean absolute error in megabytes."""
    return float(np.mean(np.abs(np.asarray(y_true) - np.asarray(y_pred))))


def oom_rate(y_true: np.ndarray, y_upper: np.ndarray) -> float:
    """Fraction of rows where true peak exceeds predicted upper bound."""
    y_true = np.asarray(y_true, dtype=np.float64)
    y_upper = np.asarray(y_upper, dtype=np.float64)
    if y_true.size == 0:
        return float("nan")
    return float(np.mean(y_true > y_upper))


def oaw_mb(y_true: np.ndarray, y_upper: np.ndarray) -> float:
    """Mean over-allocation waste: max(0, upper - true) in MB."""
    y_true = np.asarray(y_true, dtype=np.float64)
    y_upper = np.asarray(y_upper, dtype=np.float64)
    if y_true.size == 0:
        return float("nan")
    return float(np.mean(np.maximum(0.0, y_upper - y_true)))


def oaw_pct_of_ceiling(
    y_true: np.ndarray,
    y_upper: np.ndarray,
    *,
    m_ceiling_mb: float = VRAM_CEILING_MB,
) -> float:
    """
    F7 Tier-2 mean slack as a percentage of the hardware VRAM ceiling.

    Per prompt: ``100 * max(0, M_upper - M_peak_true) / M_ceiling``.
    """
    # Coerce inputs to float64 arrays for stable slack arithmetic.
    y_true = np.asarray(y_true, dtype=np.float64)
    y_upper = np.asarray(y_upper, dtype=np.float64)
    # Empty slice → undefined aggregate (matches ``oaw_mb`` / ``oom_rate``).
    if y_true.size == 0:
        return float("nan")
    # Guard against zero/negative ceiling misconfiguration in configs.
    ceiling = max(float(m_ceiling_mb), 1e-6)
    # Slack in MB, clipped at zero (under-provision is not negative waste).
    slack_mb = np.maximum(0.0, y_upper - y_true)
    # Normalise each prompt's slack by the shared hardware ceiling.
    return float(np.mean(slack_mb / ceiling) * 100.0)


def summarize_predictions(
    df: pd.DataFrame,
    *,
    agent_llm: str,
    method: str,
    split: str,
    z_alpha: float,
    m_ceiling_mb: float = VRAM_CEILING_MB,
) -> dict:
    """Aggregate MAPE / OOM / OAW / MAE for one prediction frame."""
    y_true = df["M_peak_true"].to_numpy(dtype=np.float64)
    y_pred = df["Mpeak_pred"].to_numpy(dtype=np.float64)
    y_upper = df["Mupper_pred"].to_numpy(dtype=np.float64)
    return {
        "agent_llm": agent_llm,
        "method": method,
        "split": split,
        "z_alpha": float(z_alpha),
        "n_rows": int(len(df)),
        "mape_pct": mape_percent(y_true, y_pred),
        "mae_peak_mb": mae_mb(y_true, y_pred),
        "oom_rate": oom_rate(y_true, y_upper),
        "oaw_mb": oaw_mb(y_true, y_upper),
        "oaw_pct_ceiling": oaw_pct_of_ceiling(
            y_true, y_upper, m_ceiling_mb=m_ceiling_mb
        ),
        "m_ceiling_mb": float(m_ceiling_mb),
    }


def ensure_oaw_pct_ceiling(df: pd.DataFrame) -> pd.DataFrame:
    """
    Backfill F7 ``oaw_pct_ceiling`` on legacy metric frames that only have ``oaw_mb``.

    Used when reading cached parquets written before the F7 Tier-2 column existed.
    """
    # Work on a copy so callers' frames are never mutated in place.
    out = df.copy()
    # Already up to date — nothing to do.
    if "oaw_pct_ceiling" in out.columns:
        return out
    # Legacy frames stored absolute MB slack only; convert with constant ceiling.
    if "oaw_mb" in out.columns:
        out["oaw_pct_ceiling"] = out["oaw_mb"] / VRAM_CEILING_MB * 100.0
    return out
