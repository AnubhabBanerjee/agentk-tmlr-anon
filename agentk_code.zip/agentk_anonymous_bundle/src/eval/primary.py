"""
Phase 7 — primary test metrics and z_alpha sweep from Phase 6 predictions.
"""

from __future__ import annotations

from pathlib import Path
from typing import List

import pandas as pd

from src.baselines.common import AGENT_LLMS, DEFAULT_Z_ALPHA
from src.eval.context import active_baseline_methods, skip_b4_from_env
from src.eval.loaders import load_merged_predictions, load_predictions
from src.eval.metrics import summarize_predictions
from src.eval.paths import Z_ALPHA_GRID


def _residual_sigma_at_z(pred: pd.DataFrame, z_alpha: float = DEFAULT_Z_ALPHA) -> float:
    """Back out residual sigma from stored pred/upper at reference z_alpha."""
    delta = pred["Mupper_pred"] - pred["Mpeak_pred"]
    if z_alpha <= 0:
        return 0.0
    return float(delta.mean() / z_alpha)


def recompute_upper_at_z(pred: pd.DataFrame, z_alpha: float, method: str) -> pd.Series:
    """
    Recompute Mupper_pred at a new z_alpha where the funnel is affine in z.

    B0/B5: upper = pred (deterministic / oracle).
    B1/B2/B3: upper = pred + z * sigma (sigma from reference z=1.96 parquets).
  B4: cannot affine-extrapolate; caller must supply proxy-based uppers.
    """
    if method in ("B0", "B5"):
        return pred["Mpeak_pred"].copy()
    if method == "B4":
        raise ValueError("B4 upper bounds require proxy re-inference; use recompute_b4_z_sweep")
    sigma = _residual_sigma_at_z(pred, z_alpha=DEFAULT_Z_ALPHA)
    return pred["Mpeak_pred"] + float(z_alpha) * sigma


def build_primary_test_table(repo_root: Path, *, split: str = "test") -> pd.DataFrame:
    """One row per (agent_llm, method) with MAPE/OOM/OAW at z_alpha=1.96."""
    rows: List[dict] = []
    methods = active_baseline_methods()
    for agent_llm in AGENT_LLMS:
        for method in methods:
            try:
                merged = load_merged_predictions(repo_root, agent_llm, method)
            except FileNotFoundError:
                continue
            rows.append(
                summarize_predictions(
                    merged,
                    agent_llm=agent_llm,
                    method=method,
                    split=split,
                    z_alpha=DEFAULT_Z_ALPHA,
                )
            )
    return pd.DataFrame(rows)


def build_z_alpha_sweep_table(repo_root: Path, *, split: str = "test") -> pd.DataFrame:
    """
    OOM/OAW across z_alpha grid (guide §7.1).

    B0/B1/B2/B3/B5 use affine or fixed uppers from stored parquets.
    B4 rows are omitted here until proxy re-inference is wired (see manifest status).
    """
    rows: List[dict] = []
    methods = active_baseline_methods()
    for agent_llm in AGENT_LLMS:
        for method in methods:
            if method == "B4":
                continue
            try:
                merged = load_merged_predictions(repo_root, agent_llm, method)
            except FileNotFoundError:
                continue
            for z in Z_ALPHA_GRID:
                frame = merged.copy()
                frame["Mupper_pred"] = recompute_upper_at_z(merged, z, method)
                rows.append(
                    summarize_predictions(
                        frame,
                        agent_llm=agent_llm,
                        method=method,
                        split=split,
                        z_alpha=z,
                    )
                )
    return pd.DataFrame(rows)
