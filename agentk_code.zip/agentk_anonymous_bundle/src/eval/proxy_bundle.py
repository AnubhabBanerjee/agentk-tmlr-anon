"""
load best Phase-5 proxy per agent for B4-aligned evaluation.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import pandas as pd
import torch
from safetensors.torch import load_file
from transformers import PreTrainedTokenizerBase

from src.baselines.common import load_baseline_frame, split_frame
from src.eval.context import proxies_root
from src.pipeline.tracing_paths import tracing_paths_from_env
from src.baselines.b4_proxy import PROXY_BACKBONES
from src.proxy.config import ProxyTrainingConfig, load_proxy_training_config
from src.proxy.data import compute_tool_mu_tokens
from src.proxy.forecast import aggregated_tool_tokens
from src.proxy.metrics import compute_l_base_batch
from src.proxy.model import MultiTaskProxyModel, ProxyForwardOutput, build_multitask_proxy
from src.proxy.peak_mlp import StructuralPeakMLP, load_peak_mlp_if_present, peaks_from_proxy_outputs


def best_proxy_backbone(repo_root: Path, agent_llm: str) -> str:
    """Lowest val_mape backbone from artifacts/proxies/{agent}/{backbone}/metrics.json."""
    best_id = PROXY_BACKBONES[0]
    best_mape = float("inf")
    root = proxies_root(repo_root)
    for backbone_id in PROXY_BACKBONES:
        metrics_path = root / agent_llm / backbone_id / "metrics.json"
        if not metrics_path.is_file():
            continue
        metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
        val_mape = float(metrics["val_mape"])
        if val_mape < best_mape:
            best_mape = val_mape
            best_id = backbone_id
    return best_id


@dataclass
class AgentProxyBundle:
    """Loaded proxy + test rows for one agent LLM (B4 backbone)."""

    agent_llm: str
    backbone_id: str
    model: MultiTaskProxyModel
    tokenizer: PreTrainedTokenizerBase
    max_seq_length: int
    tool_mu: Dict[str, float]
    cfg: ProxyTrainingConfig
    test_frame: pd.DataFrame
    device: torch.device
    peak_mlp: Optional[StructuralPeakMLP] = None


def load_agent_proxy_bundle(
    repo_root: Path,
    agent_llm: str,
    *,
    device: torch.device,
    backbone_id: str | None = None,
) -> AgentProxyBundle:
    """Load best (or specified) proxy weights and test-split frame."""
    chosen = backbone_id or best_proxy_backbone(repo_root, agent_llm)
    weights_path = proxies_root(repo_root) / agent_llm / chosen / "model.safetensors"
    if not weights_path.is_file():
        raise FileNotFoundError(f"Missing proxy weights: {weights_path}")
    cfg = load_proxy_training_config(repo_root=repo_root)
    frame = load_baseline_frame(
        repo_root=repo_root,
        agent_llm=agent_llm,
        paths=tracing_paths_from_env(repo_root=repo_root),
    )
    train, _val, test = split_frame(frame)
    tool_mu = compute_tool_mu_tokens(train)
    model, tokenizer, spec = build_multitask_proxy(
        repo_root=repo_root,
        backbone_id=chosen,
        enable_variance_head=True,
        enable_stretch_heads=False,
    )
    state = load_file(str(weights_path))
    model.load_state_dict(state, strict=True)
    model = model.to(device)
    model.eval()
    peak_mlp = load_peak_mlp_if_present(repo_root, agent_llm, chosen, device=device)
    return AgentProxyBundle(
        agent_llm=agent_llm,
        backbone_id=chosen,
        model=model,
        tokenizer=tokenizer,
        max_seq_length=spec.max_seq_length,
        tool_mu=tool_mu,
        cfg=cfg,
        test_frame=test,
        device=device,
        peak_mlp=peak_mlp,
    )


def run_proxy_forward_on_frame(bundle: AgentProxyBundle) -> Tuple[ProxyForwardOutput, torch.Tensor, List[Dict]]:
    """Forward pass on all test user goals; returns outputs, l_base, accounting rows."""
    goals = bundle.test_frame["user_goal"].tolist()
    accounting_rows = [accounting_dict(row) for _, row in bundle.test_frame.iterrows()]
    batch = bundle.model.encode_texts(
        goals,
        tokenizer=bundle.tokenizer,
        max_length=bundle.max_seq_length,
        device=bundle.device,
    )
    with torch.no_grad():
        outputs = bundle.model.forward(**batch)
        l_base = compute_l_base_batch(
            goals,
            bundle.tokenizer,
            max_length=bundle.max_seq_length,
            device=bundle.device,
        )
    return outputs, l_base, accounting_rows


def predicted_aggregated_tool_tokens(outputs: ProxyForwardOutput, tool_mu: Dict[str, float] | None = None) -> torch.Tensor:
    """F3: Σ_i T̂[i] predicted per-node completion tokens."""
    _ = tool_mu
    return aggregated_tool_tokens(outputs.tool_tokens_hat)


def peaks_from_bundle(
    bundle: AgentProxyBundle,
    outputs: ProxyForwardOutput,
    l_base: torch.Tensor,
    accounting_rows: List[Dict],
    *,
    z_alpha: float | None = None,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """B4 peaks: learned MLP when trained, else closed-form prior."""
    z = float(z_alpha if z_alpha is not None else bundle.cfg.z_alpha)
    return peaks_from_proxy_outputs(
        outputs,
        l_base=l_base,
        accounting_rows=accounting_rows,
        tool_mu_tokens=bundle.tool_mu,
        z_alpha=z,
        peak_mlp=bundle.peak_mlp,
    )
