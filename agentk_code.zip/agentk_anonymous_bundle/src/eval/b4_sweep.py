"""
Step 1 — B4 z_alpha sweep and refreshed peak metrics from best proxy.
"""

from __future__ import annotations

from pathlib import Path
from typing import List

import pandas as pd
import torch

from src.baselines.common import AGENT_LLMS, DEFAULT_Z_ALPHA
from src.eval.context import active_baseline_methods, skip_b4_from_env
from src.eval.loaders import load_ground_truth_test, load_merged_predictions
from src.eval.metrics import summarize_predictions
from src.eval.paths import Z_ALPHA_GRID
from src.eval.primary import build_primary_test_table, recompute_upper_at_z
from src.eval.proxy_bundle import load_agent_proxy_bundle, peaks_from_bundle, run_proxy_forward_on_frame


def build_b4_merged_predictions(
    repo_root: Path,
    agent_llm: str,
    *,
    device: torch.device,
    z_alpha: float = DEFAULT_Z_ALPHA,
) -> pd.DataFrame:
    """
    Per-prompt B4 peaks joined to test ``M_peak_true`` (best proxy backbone).

    Same source as ``build_primary_test_with_b4_refresh`` / z_alpha sweep B4 rows.
    """
    # Test-split ground truth for inner join on ``prompt_id``.
    truth = load_ground_truth_test(repo_root, agent_llm)
    # Best Phase-5 proxy bundle for this agent LLM.
    bundle = load_agent_proxy_bundle(repo_root, agent_llm, device=device)
    # Forward pass yields heads used by closed-form + learned peak MLP.
    outputs, l_base, accounting_rows = run_proxy_forward_on_frame(bundle)
    # Align prompt order with proxy test frame rows.
    prompt_ids = bundle.test_frame["prompt_id"].tolist()
    # True peaks in the same row order as proxy inference.
    y_true = truth.set_index("prompt_id").loc[prompt_ids, "M_peak_true"].to_numpy()
    # Closed-form / learned peak and upper bound at ``z_alpha``.
    m_peak, m_upper = peaks_from_bundle(
        bundle, outputs, l_base, accounting_rows, z_alpha=float(z_alpha)
    )
    # Merged frame matches ``join_predictions_to_truth`` column names.
    return pd.DataFrame(
        {
            "prompt_id": prompt_ids,
            "agent_llm": agent_llm,
            "M_peak_true": y_true,
            "Mpeak_pred": m_peak.detach().cpu().numpy(),
            "Mupper_pred": m_upper.detach().cpu().numpy(),
            "proxy_backbone": bundle.backbone_id,
        }
    )


def build_b4_z_alpha_rows(
    repo_root: Path,
    *,
    device: torch.device,
    split: str = "test",
) -> pd.DataFrame:
    """B4 OOM/OAW/MAPE at each z_alpha using σ_N funnel (best backbone per agent)."""
    rows: List[dict] = []
    for agent_llm in AGENT_LLMS:
        truth = load_ground_truth_test(repo_root, agent_llm)
        bundle = load_agent_proxy_bundle(repo_root, agent_llm, device=device)
        outputs, l_base, accounting_rows = run_proxy_forward_on_frame(bundle)
        prompt_ids = bundle.test_frame["prompt_id"].tolist()
        y_true = truth.set_index("prompt_id").loc[prompt_ids, "M_peak_true"].to_numpy()
        for z in Z_ALPHA_GRID:
            m_peak, m_upper = peaks_from_bundle(
                bundle, outputs, l_base, accounting_rows, z_alpha=float(z)
            )
            frame = pd.DataFrame(
                {
                    "prompt_id": prompt_ids,
                    "agent_llm": agent_llm,
                    "M_peak_true": y_true,
                    "Mpeak_pred": m_peak.detach().cpu().numpy(),
                    "Mupper_pred": m_upper.detach().cpu().numpy(),
                    "proxy_backbone": bundle.backbone_id,
                }
            )
            rows.append(
                summarize_predictions(
                    frame,
                    agent_llm=agent_llm,
                    method="B4",
                    split=split,
                    z_alpha=float(z),
                )
            )
            rows[-1]["proxy_backbone"] = bundle.backbone_id
    return pd.DataFrame(rows)


def build_full_z_alpha_sweep_table(
    repo_root: Path,
    *,
    device: torch.device,
    split: str = "test",
) -> pd.DataFrame:
    """All methods × z_alpha; B4 from proxy, others from parquets."""
    base = []
    methods = active_baseline_methods()
    for agent_llm in AGENT_LLMS:
        for method in methods:
            if method == "B4":
                continue
            try:
                merged = load_merged_predictions(repo_root, agent_llm, method)
            except FileNotFoundError:
                continue
            for z in Z_ALPHA_GRID:
                frame = merged.copy()
                frame["Mupper_pred"] = recompute_upper_at_z(merged, z, method)
                base.append(
                    summarize_predictions(
                        frame,
                        agent_llm=agent_llm,
                        method=method,
                        split=split,
                        z_alpha=z,
                    )
                )
    if skip_b4_from_env():
        return pd.DataFrame(base)
    b4 = build_b4_z_alpha_rows(repo_root, device=device, split=split)
    return pd.concat([pd.DataFrame(base), b4], ignore_index=True)


def build_primary_test_with_b4_refresh(
    repo_root: Path,
    *,
    device: torch.device,
    split: str = "test",
) -> pd.DataFrame:
    """primary_test.parquet with B4 row recomputed from best proxy @ z=1.96."""
    primary = build_primary_test_table(repo_root, split=split)
    if skip_b4_from_env():
        return primary.sort_values(["agent_llm", "method"])
    primary = primary[primary["method"] != "B4"].copy()
    b4_rows = build_b4_z_alpha_rows(repo_root, device=device, split=split)
    b4_primary = b4_rows[b4_rows["z_alpha"] == DEFAULT_Z_ALPHA].copy()
    return pd.concat([primary, b4_primary], ignore_index=True).sort_values(
        ["agent_llm", "method"]
    )
