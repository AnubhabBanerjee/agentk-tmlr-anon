"""Evaluation metrics: MAPE, MAE, OOM rate, OAW, trajectory MAPE."""

from src.eval.manifest import build_manifest, write_manifest
from src.eval.metrics import mae_mb, mape_percent, oaw_mb, oaw_pct_of_ceiling, oom_rate, summarize_predictions
from src.eval.paths import (
    CORRECTNESS_STRATA_METHODS,
    MAPE_BAR_METHODS,
    ResultsLayout,
    Z_ALPHA_GRID,
    results_layout,
)
from src.eval.primary import build_primary_test_table, build_z_alpha_sweep_table

__all__ = [
    "CORRECTNESS_STRATA_METHODS",
    "MAPE_BAR_METHODS",
    "ResultsLayout",
    "Z_ALPHA_GRID",
    "build_manifest",
    "build_primary_test_table",
    "build_z_alpha_sweep_table",
    "mae_mb",
    "mape_percent",
    "oaw_mb",
    "oaw_pct_of_ceiling",
    "oom_rate",
    "results_layout",
    "summarize_predictions",
    "write_manifest",
]
