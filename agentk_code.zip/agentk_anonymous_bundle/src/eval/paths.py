"""
canonical paths for all paper-facing evaluation outputs.

All metrics, tables, and the narrative summary live under ``paper/results/``.
Pipeline artifacts (models, raw predictions) stay in ``artifacts/``.
Figures are written to ``paper/figures/``.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ResultsLayout:
    """Single source of truth for paper outputs."""

    root: Path

    @property
    def metrics_dir(self) -> Path:
        return self.root / "metrics"

    @property
    def tables_dir(self) -> Path:
        return self.root / "tables"

    @property
    def figures_dir(self) -> Path:
        suffix = "_v2" if self.root.name.endswith("_v2") else ""
        return self.root.parent / f"figures{suffix}"

    @property
    def summary_md(self) -> Path:
        return self.root / "summary.md"

    @property
    def manifest_json(self) -> Path:
        return self.root / "manifest.json"

    @property
    def readme_md(self) -> Path:
        return self.root / "README.md"

    # --- metrics parquet / json  ---
    @property
    def primary_test(self) -> Path:
        return self.metrics_dir / "primary_test.parquet"

    @property
    def z_alpha_sweep(self) -> Path:
        return self.metrics_dir / "z_alpha_sweep.parquet"

    @property
    def subcomponents_test(self) -> Path:
        return self.metrics_dir / "subcomponents_test.parquet"

    @property
    def subcomponents_mae(self) -> Path:
        return self.metrics_dir / "subcomponents_mae.parquet"

    @property
    def trajectory_test(self) -> Path:
        return self.metrics_dir / "trajectory_test.parquet"

    @property
    def trajectory_mape(self) -> Path:
        return self.metrics_dir / "trajectory_mape.parquet"

    @property
    def vram_strata_mape(self) -> Path:
        return self.metrics_dir / "vram_strata_mape.parquet"

    @property
    def backbone_ablation_test(self) -> Path:
        return self.metrics_dir / "backbone_ablation_test.parquet"

    @property
    def cross_model_generalization(self) -> Path:
        return self.metrics_dir / "cross_model_generalization.parquet"

    @property
    def correctness_joint(self) -> Path:
        return self.metrics_dir / "correctness_joint.parquet"

    @property
    def correctness_strata(self) -> Path:
        return self.metrics_dir / "correctness_strata.parquet"

    @property
    def cost_quality_pareto(self) -> Path:
        return self.metrics_dir / "cost_quality_pareto.parquet"

    @property
    def bootstrap_ci(self) -> Path:
        return self.metrics_dir / "bootstrap_ci.parquet"

    @property
    def significance_tests(self) -> Path:
        return self.metrics_dir / "significance_tests.json"

    # --- LaTeX tables (generated from metrics/) ---
    @property
    def table_primary_results(self) -> Path:
        return self.tables_dir / "primary_results.tex"

    @property
    def table_backbone_ablation(self) -> Path:
        return self.tables_dir / "backbone_ablation.tex"

    @property
    def table_primary_results_ci(self) -> Path:
        return self.tables_dir / "primary_results_ci.tex"

    def ensure_dirs(self) -> None:
        """Create paper/results/metrics and paper/results/tables."""
        self.metrics_dir.mkdir(parents=True, exist_ok=True)
        self.tables_dir.mkdir(parents=True, exist_ok=True)
        self.figures_dir.mkdir(parents=True, exist_ok=True)


def results_layout(repo_root: Path) -> ResultsLayout:
    """Return ``paper/results/`` or ``paper/results_v2/`` from ``TRACING_CONFIG``."""
    from src.eval.context import eval_context

    return eval_context(repo_root).results


# z_alpha grid for OOM/OAW Pareto curves .
Z_ALPHA_GRID: tuple[float, ...] = (1.0, 1.28, 1.64, 1.96, 2.33, 2.58)

# Primary comparison methods for MAPE bar chart (guide §7.2 fig 3).
MAPE_BAR_METHODS: tuple[str, ...] = ("B1", "B2", "B4", "B5")

# Methods included in correctness-strata analysis (guide §7.3.b).
CORRECTNESS_STRATA_METHODS: tuple[str, ...] = ("B2", "B4", "B5")

# Bootstrap settings .
BOOTSTRAP_RESAMPLES: int = 600

# F7 Tier-2: OAW as % of hardware VRAM ceiling (guide §F7; tracing on 80 GB A100/H100).
VRAM_CEILING_GB: float = 80.0
VRAM_CEILING_MB: float = VRAM_CEILING_GB * 1024.0
