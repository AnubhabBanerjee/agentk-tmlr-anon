"""
Self-contained KernelBench numerical correctness harness.

Reimplements upstream ``kernelbench.eval`` core paths without third-party
KernelBench imports. Compares reference ``Model`` vs custom ``ModelNew``.
"""

# Python line: from __future__ import annotations
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
from __future__ import annotations

# dataclass holds parquet-bound scalar labels from one harness invocation.
# Python line: from dataclasses import dataclass
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
from dataclasses import dataclass
# os pins TORCH_EXTENSIONS_DIR before exec of load_inline custom kernels.
# Python line: import os
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
import os
# pathlib types optional per-eval ninja build directories for extensions.
# Python line: from pathlib import Path
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
from pathlib import Path
# traceback records kernel launch failures during correctness validation.
# Python line: import traceback
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
import traceback
# typing annotates exec-loaded factories and optional GPU metric fields.
# Python line: from typing import Any, Callable, List, Optional, Tuple, Union
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
from typing import Any, Callable, List, Optional, Tuple, Union

# numpy median reduces CUDA-event trial times to runtime_ms_kbench.
# Python line: import numpy as np
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
import numpy as np
# torch runs reference/custom modules, allclose checks, and CUDA events.
# Python line: import torch
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
import torch
# nn.Module is the exec-loaded KernelBench problem class base type.
# Python line: import torch.nn as nn
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
import torch.nn as nn

# Python line: @dataclass
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
@dataclass
# Python line: class KbenchEvalOutcome:
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
class KbenchEvalOutcome:
    """Outcome of one KernelBench numerical correctness evaluation."""

    # Python line: numerical_correct_kbench: bool
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    numerical_correct_kbench: bool
    # Python line: max_abs_err_kbench: Optional[float]
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    max_abs_err_kbench: Optional[float]
    # Python line: runtime_ms_kbench: Optional[float]
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    runtime_ms_kbench: Optional[float]
    # Python line: compiled: bool
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    compiled: bool
    # Python line: metadata: dict
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    metadata: dict


# Python line: def _set_seed(seed: int) -> None:
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
def _set_seed(seed: int) -> None:
    """Set CPU and current CUDA RNG seeds (KernelBench ``set_seed``)."""
    # Python line: torch.manual_seed(seed)
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    torch.manual_seed(seed)
    # Python line: if torch.cuda.is_available(): torch.cuda.manual_seed(seed)
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)


# Python line: def _get_tolerance_for_precision(precision: Union[str, torch.dtype]) -> float:
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
def _get_tolerance_for_precision(precision: Union[str, torch.dtype]) -> float:
    """Return atol/rtol for ``torch.allclose`` (fp32 default 1e-4 per torchbench)."""
    # Python line: mapping = {torch.float32: 1e-4, torch.float16: 1e-2, torch.bfloat16: 1e-2}
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    mapping = {torch.float32: 1e-4, torch.float16: 1e-2, torch.bfloat16: 1e-2}
    # Python line: if isinstance(precision, str):
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    if isinstance(precision, str):
        precision = {"fp32": torch.float32, "fp16": torch.float16, "bf16": torch.bfloat16}[precision]
    # Python line: return mapping[precision]
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    return mapping[precision]


# Python line: def _process_input_tensor(value: Any, device: torch.device, precision: torch.dtype) -> Any:
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
def _process_input_tensor(value: Any, device: torch.device, precision: torch.dtype) -> Any:
    """Cast/move tensor inputs; leave non-tensor init values unchanged."""
    # Python line: if not isinstance(value, torch.Tensor): return value
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    if not isinstance(value, torch.Tensor):
        return value
    # Python line: return value.to(dtype=precision, device=device)
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    return value.to(dtype=precision, device=device)


# Python line: def load_original_model_and_inputs(model_original_src: str, context: dict):
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
def load_original_model_and_inputs(
    model_original_src: str, context: dict
) -> Optional[Tuple[type, Callable[[], list], Callable[[], list]]]:
    """Exec reference KernelBench source; return Model and input factories."""
    # Python line: try:
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    try:
        compile(model_original_src, "<ref>", "exec")
        exec(model_original_src, context)
    except Exception as exc:
        context["reference_exec_error"] = str(exc)
        return None
    model_cls, get_init, get_inp = context.get("Model"), context.get("get_init_inputs"), context.get("get_inputs")
    # Python line: if not all((model_cls, get_init, get_inp)): return None
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    if not all((model_cls, get_init, get_inp)):
        return None
    # Python line: return model_cls, get_init, get_inp
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    return model_cls, get_init, get_inp


# Python line: def load_custom_model(model_custom_src: str, context: dict, build_directory=None):
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
def load_custom_model(
    model_custom_src: str, context: dict, build_directory: Optional[Union[str, Path]] = None
) -> Optional[type]:
    """Exec custom ModelNew; optionally redirect torch extension build cache."""
    # Python line: src = model_custom_src
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    src = model_custom_src
    # Python line: if build_directory is not None:
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    if build_directory is not None:
        build_path = str(Path(build_directory))
        context["BUILD_DIRECTORY"] = build_path
        src = f"import os\nos.environ['TORCH_EXTENSIONS_DIR'] = '{build_path}'\n" + src
    # Python line: try:
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    try:
        compile(src, "<custom>", "exec")
        exec(src, context)
    except Exception as exc:
        context["custom_exec_error"] = str(exc)
        return None
    # Python line: return context.get("ModelNew")
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    return context.get("ModelNew")


# Python line: def _graceful_eval_cleanup(device: torch.device) -> None:
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
def _graceful_eval_cleanup(device: torch.device) -> None:
    """Empty CUDA cache and synchronize between back-to-back harness runs."""
    # Python line: if not torch.cuda.is_available(): return
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    if not torch.cuda.is_available():
        return
    # Python line: with torch.cuda.device(device):
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    with torch.cuda.device(device):
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats(device=device)
        torch.cuda.synchronize(device=device)


# Python line: def _clear_l2_cache(device: torch.device) -> None:
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
def _clear_l2_cache(device: torch.device) -> None:
    """Thrash device memory so perf trials approximate cold-cache launches."""
    # Python line: dummy = torch.empty((32, 1024, 1024), dtype=torch.int64, device=device)
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    dummy = torch.empty((32, 1024, 1024), dtype=torch.int64, device=device)
    dummy.fill_(42)
    del dummy


# Python line: def time_execution_with_cuda_event(kernel_fn, args, *, num_warmup=3, num_trials=100, discard_first=1, verbose=False, device):
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
def time_execution_with_cuda_event(
    kernel_fn: Callable[..., Any],
    args: list,
    *,
    num_warmup: int = 3,
    num_trials: int = 100,
    discard_first: int = 1,
    verbose: bool = False,
    device: torch.device,
) -> List[float]:
    """CUDA-event timing of ``kernel_fn(*args)``; returns elapsed ms per trial."""
    # Python line: elapsed: List[float] = []
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    elapsed: List[float] = []
    # Python line: with torch.cuda.device(device):
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    with torch.cuda.device(device):
        for _ in range(num_warmup):
            kernel_fn(*args)
            torch.cuda.synchronize(device=device)
        torch.cuda.empty_cache()
        for trial in range(num_trials + discard_first):
            torch.cuda.synchronize(device=device)
            start_ev, end_ev = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
            _clear_l2_cache(device)
            start_ev.record()
            kernel_fn(*args)
            end_ev.record()
            torch.cuda.synchronize(device=device)
            ms = float(start_ev.elapsed_time(end_ev))
            if trial >= discard_first:
                elapsed.append(ms)
                if verbose:
                    print(f"[perf] trial {trial - discard_first + 1}: {ms:.4f} ms")
    # Python line: return elapsed
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    return elapsed


# Python line: def run_and_check_correctness(original_model, custom_model, get_inputs_fn, *, metadata, num_correct_trials, seed, device, precision, verbose=False):
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
def run_and_check_correctness(
    original_model: nn.Module,
    custom_model: nn.Module,
    get_inputs_fn: Callable[[], list],
    *,
    metadata: dict,
    num_correct_trials: int,
    seed: int,
    device: torch.device,
    precision: torch.dtype,
    verbose: bool = False,
) -> bool:
    """Multi-trial ``torch.allclose`` check; append per-trial max abs diff to metadata."""
    # Python line: tol = _get_tolerance_for_precision(precision)
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    tol = _get_tolerance_for_precision(precision)
    pass_count = 0
    torch.manual_seed(seed)
    trial_seeds = [torch.randint(0, 2**32 - 1, (1,)).item() for _ in range(num_correct_trials)]
    # Python line: with torch.no_grad():
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    with torch.no_grad():
        for idx, trial_seed in enumerate(trial_seeds):
            if verbose:
                print(f"[correctness] trial {idx} seed={trial_seed}")
            _set_seed(trial_seed)
            inputs = [_process_input_tensor(x, device, precision) for x in get_inputs_fn()]
            try:
                ref_out = original_model(*inputs)
                torch.cuda.synchronize(device=device)
                custom_out = custom_model(*inputs)
                torch.cuda.synchronize(device=device)
            except Exception as exc:
                metadata.update(runtime_error=str(exc), runtime_error_traceback=traceback.format_exc())
                metadata["correctness_trials"] = f"({pass_count} / {num_correct_trials})"
                return False
            if ref_out.shape != custom_out.shape:
                metadata["correctness_issue"] = f"shape mismatch: {tuple(ref_out.shape)} vs {tuple(custom_out.shape)}"
                metadata["correctness_trials"] = f"({pass_count} / {num_correct_trials})"
                return False
            max_diff = float(torch.max(torch.abs(ref_out - custom_out)).item())
            metadata.setdefault("max_difference", []).append(max_diff)
            if not torch.allclose(ref_out, custom_out, atol=tol, rtol=tol):
                metadata["correctness_issue"] = "output mismatch"
                metadata["correctness_trials"] = f"({pass_count} / {num_correct_trials})"
                return False
            pass_count += 1
    metadata["correctness_trials"] = f"({pass_count} / {num_correct_trials})"
    # Python line: return pass_count == num_correct_trials
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    return pass_count == num_correct_trials


# Python line: def _max_abs_err_from_metadata(metadata: dict) -> Optional[float]:
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
def _max_abs_err_from_metadata(metadata: dict) -> Optional[float]:
    """Max over metadata ``max_difference`` list (floats or legacy strings)."""
    # Python line: vals = metadata.get("max_difference") or []
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    vals = metadata.get("max_difference") or []
    # Python line: return float(max(float(v) for v in vals)) if vals else None
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    return float(max(float(v) for v in vals)) if vals else None


# Python line: def _make_outcome(*, correct: bool, compiled: bool, metadata: dict, runtime_ms=None) -> KbenchEvalOutcome:
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
def _make_outcome(
    *, correct: bool, compiled: bool, metadata: dict, runtime_ms: Optional[float] = None
) -> KbenchEvalOutcome:
    """Assemble ``KbenchEvalOutcome`` from intermediate harness state."""
    # Python line: return KbenchEvalOutcome(correct, _max_abs_err_from_metadata(metadata), runtime_ms, compiled, metadata)
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    return KbenchEvalOutcome(correct, _max_abs_err_from_metadata(metadata), runtime_ms, compiled, metadata)


# Python line: def run_kernelbench_eval(*, ref_src, custom_model_src, seed=20260716, num_correct_trials=5, num_perf_trials=100, build_dir=None, device=None, verbose=False):
# KernelBench eval harness.
# Implements .cursorrules dense-comment policy for src/ code.
def run_kernelbench_eval(
    *,
    ref_src: str,
    custom_model_src: str,
    seed: int = 20260716,
    num_correct_trials: int = 5,
    num_perf_trials: int = 100,
    build_dir: Optional[Path] = None,
    device: Optional[torch.device] = None,
    verbose: bool = False,
) -> KbenchEvalOutcome:
    """
    Evaluate custom ``ModelNew`` against reference ``Model`` (§3.5).

    Compile/link failures set ``numerical_correct_kbench=False`` and log errors
    in ``metadata``. Validation uses fixed ``seed`` (default 20260716).
    """
    # Python line: if not torch.cuda.is_available(): raise RuntimeError("CUDA is required for KernelBench eval")
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for KernelBench eval")
    # Python line: device = device or torch.device("cuda", torch.cuda.current_device())
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    device = device or torch.device("cuda", torch.cuda.current_device())
    torch.cuda.set_device(device)
    precision = torch.float32
    metadata: dict = {"seed": seed, "device": str(device), "hardware": torch.cuda.get_device_name(device)}
    context: dict = {}
    if verbose:
        print(f"[kbench_eval] device={device}")

    loaded = load_original_model_and_inputs(ref_src, context)
    if loaded is None:
        metadata["reference_load_error"] = context.get("reference_exec_error", "missing symbols")
        if verbose:
            print(f"[kbench_eval] reference load failed: {metadata['reference_load_error']}")
        _graceful_eval_cleanup(device)
        return _make_outcome(correct=False, compiled=False, metadata=metadata)

    model_cls, get_init_inputs, get_inputs = loaded
    _set_seed(seed)
    init_inputs = [_process_input_tensor(x, device, precision) for x in get_init_inputs()]
    with torch.no_grad():
        _set_seed(seed)
        original_model = model_cls(*init_inputs).to(device=device, dtype=precision)

    try:
        os.environ["TORCH_USE_CUDA_DSA"] = "1"
        model_new_cls = load_custom_model(custom_model_src, context, build_dir)
        torch.cuda.synchronize(device=device)
    except Exception as exc:
        metadata["compilation_error"] = str(exc)
        if verbose:
            print(f"[kbench_eval] compile/link failed: {exc}")
        _graceful_eval_cleanup(device)
        return _make_outcome(correct=False, compiled=False, metadata=metadata)

    if model_new_cls is None:
        metadata["compilation_error"] = context.get("custom_exec_error", "ModelNew missing after exec")
        if verbose:
            print(f"[kbench_eval] compile/link failed: {metadata['compilation_error']}")
        _graceful_eval_cleanup(device)
        return _make_outcome(correct=False, compiled=False, metadata=metadata)

    try:
        with torch.no_grad():
            _set_seed(seed)
            custom_model = model_new_cls(*init_inputs).to(device=device, dtype=precision)
            torch.cuda.synchronize(device=device)
    except Exception as exc:
        metadata["runtime_error"] = str(exc)
        if verbose:
            print(f"[kbench_eval] runtime init failed: {exc}")
        _graceful_eval_cleanup(device)
        return _make_outcome(correct=False, compiled=True, metadata=metadata)

    correct = run_and_check_correctness(
        original_model, custom_model, get_inputs,
        metadata=metadata, num_correct_trials=num_correct_trials, seed=seed,
        device=device, precision=precision, verbose=verbose,
    )
    runtime_ms: Optional[float] = None
    if correct:
        try:
            _set_seed(seed)
            perf_inputs = [_process_input_tensor(x, device, precision) for x in get_inputs()]
            elapsed = time_execution_with_cuda_event(
                custom_model, perf_inputs, num_trials=num_perf_trials, verbose=verbose, device=device,
            )
            runtime_ms = float(np.median(elapsed))
            metadata["perf_elapsed_ms"] = elapsed
        except Exception as exc:
            metadata["error_during_performance"] = str(exc)
            if verbose:
                print(f"[kbench_eval] perf failed: {exc}")

    outcome = _make_outcome(correct=correct, compiled=True, metadata=metadata, runtime_ms=runtime_ms)
    _graceful_eval_cleanup(device)
    # Python line: return outcome
    # KernelBench eval harness.
    # Implements .cursorrules dense-comment policy for src/ code.
    return outcome
