"""
Persist and load emitted CUDA sidecars for Phase 3.5 KernelBench harness.

Traces store metrics in JSONL; the final ``source_code`` from AgentK is
written beside traces under ``data/traces/cuda/{agent_llm}/{prompt_id}.cu``.
"""

# Python line: from __future__ import annotations
# CUDA sidecar IO (src/correctness/cuda_sidecar.py).
# Implements .cursorrules dense-comment policy for src/ code.
from __future__ import annotations

# Path resolves repo-relative cuda sidecar locations under data/traces/cuda/.
# Python line: from pathlib import Path
# CUDA sidecar IO (src/correctness/cuda_sidecar.py).
# Implements .cursorrules dense-comment policy for src/ code.
from pathlib import Path
# typing annotates optional sidecar text returned when a file is missing.
# Python line: from typing import Optional
# CUDA sidecar IO (src/correctness/cuda_sidecar.py).
# Implements .cursorrules dense-comment policy for src/ code.
from typing import Optional


# Python line: def cuda_sidecar_root(repo_root: Path) -> Path:
# CUDA sidecar IO (src/correctness/cuda_sidecar.py).
# Implements .cursorrules dense-comment policy for src/ code.
def cuda_sidecar_root(repo_root: Path) -> Path:
    """Return ``data/traces/cuda`` directory for emitted CUDA sidecars."""
    # Python line: return repo_root / "data" / "traces" / "cuda"
    # CUDA sidecar IO (src/correctness/cuda_sidecar.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return repo_root / "data" / "traces" / "cuda"


# Python line: def cuda_sidecar_path(*, repo_root: Path, agent_llm: str, prompt_id: str) -> Path:
# CUDA sidecar IO (src/correctness/cuda_sidecar.py).
# Implements .cursorrules dense-comment policy for src/ code.
def cuda_sidecar_path(*, repo_root: Path, agent_llm: str, prompt_id: str) -> Path:
    """Build the absolute path for one (agent_llm, prompt_id) CUDA sidecar file."""
    # Python line: return cuda_sidecar_root(repo_root) / agent_llm / f"{prompt_id}.cu"
    # CUDA sidecar IO (src/correctness/cuda_sidecar.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return cuda_sidecar_root(repo_root) / agent_llm / f"{prompt_id}.cu"


# Python line: def write_cuda_sidecar(
# CUDA sidecar IO (src/correctness/cuda_sidecar.py).
# Implements .cursorrules dense-comment policy for src/ code.
def write_cuda_sidecar(
    *,
    repo_root: Path,
    agent_llm: str,
    prompt_id: str,
    source_code: str,
) -> Path:
    """Write emitted CUDA source to the sidecar path; return the path written."""
    # Python line: path = cuda_sidecar_path(repo_root=repo_root, agent_llm=agent_llm, prompt_id=prompt_id)
    # CUDA sidecar IO (src/correctness/cuda_sidecar.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    path = cuda_sidecar_path(repo_root=repo_root, agent_llm=agent_llm, prompt_id=prompt_id)
    # Python line: path.parent.mkdir(parents=True, exist_ok=True)
    # CUDA sidecar IO (src/correctness/cuda_sidecar.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    path.parent.mkdir(parents=True, exist_ok=True)
    # Python line: path.write_text(source_code, encoding="utf-8")
    # CUDA sidecar IO (src/correctness/cuda_sidecar.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    path.write_text(source_code, encoding="utf-8")
    # Python line: return path
    # CUDA sidecar IO (src/correctness/cuda_sidecar.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return path


# Python line: def load_cuda_sidecar(*, repo_root: Path, agent_llm: str, prompt_id: str) -> Optional[str]:
# CUDA sidecar IO (src/correctness/cuda_sidecar.py).
# Implements .cursorrules dense-comment policy for src/ code.
def load_cuda_sidecar(*, repo_root: Path, agent_llm: str, prompt_id: str) -> Optional[str]:
    """Load CUDA sidecar text when present; return None if the file is absent."""
    # Python line: path = cuda_sidecar_path(repo_root=repo_root, agent_llm=agent_llm, prompt_id=prompt_id)
    # CUDA sidecar IO (src/correctness/cuda_sidecar.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    path = cuda_sidecar_path(repo_root=repo_root, agent_llm=agent_llm, prompt_id=prompt_id)
    # Python line: if not path.is_file():
    # CUDA sidecar IO (src/correctness/cuda_sidecar.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if not path.is_file():
        # Python line: return None
        # CUDA sidecar IO (src/correctness/cuda_sidecar.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        return None
    # Python line: text = path.read_text(encoding="utf-8").strip()
    # CUDA sidecar IO (src/correctness/cuda_sidecar.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    text = path.read_text(encoding="utf-8").strip()
    # Python line: return text if text else None
    # CUDA sidecar IO (src/correctness/cuda_sidecar.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return text if text else None


# Python line: def delete_cuda_sidecar(*, repo_root: Path, agent_llm: str, prompt_id: str) -> bool:
# CUDA sidecar IO (src/correctness/cuda_sidecar.py).
# Implements .cursorrules dense-comment policy for src/ code.
def delete_cuda_sidecar(*, repo_root: Path, agent_llm: str, prompt_id: str) -> bool:
    """Remove CUDA sidecar file if present; return True when a file was deleted."""
    # Python line: path = cuda_sidecar_path(repo_root=repo_root, agent_llm=agent_llm, prompt_id=prompt_id)
    # CUDA sidecar IO (src/correctness/cuda_sidecar.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    path = cuda_sidecar_path(repo_root=repo_root, agent_llm=agent_llm, prompt_id=prompt_id)
    # Python line: if path.is_file():
    # CUDA sidecar IO (src/correctness/cuda_sidecar.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if path.is_file():
        # Python line: path.unlink()
        # CUDA sidecar IO (src/correctness/cuda_sidecar.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        path.unlink()
        # Python line: return True
        # CUDA sidecar IO (src/correctness/cuda_sidecar.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        return True
    # Python line: return False
    # CUDA sidecar IO (src/correctness/cuda_sidecar.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return False
