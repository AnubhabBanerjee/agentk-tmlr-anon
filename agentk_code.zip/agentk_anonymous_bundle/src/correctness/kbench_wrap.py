"""
Wrap AgentK-emitted CUDA into KernelBench ``ModelNew`` Python (§3.5).

KernelBench's driver expects a full PyTorch module source with ``ModelNew``.
AgentK emits raw ``.cu`` text; this module stitches reference tails and
optional ``load_inline`` bindings before calling ``kernelbench.eval``.
"""

# Python line: from __future__ import annotations
# KC CUDA → KernelBench ModelNew wrapper.
# Implements .cursorrules dense-comment policy for src/ code.
from __future__ import annotations

# ast parses reference ``Model.forward`` parameter names for binding codegen.
# Python line: import ast
# KC CUDA → KernelBench ModelNew wrapper.
# Implements .cursorrules dense-comment policy for src/ code.
import ast
# re extracts ``__global__`` kernel names and detects embedded Python solutions.
# Python line: import re
# KC CUDA → KernelBench ModelNew wrapper.
# Implements .cursorrules dense-comment policy for src/ code.
import re
# textwrap dedents generated host-binding C++ snippets embedded in Python strings.
# Python line: import textwrap
# KC CUDA → KernelBench ModelNew wrapper.
# Implements .cursorrules dense-comment policy for src/ code.
import textwrap
# typing carries wrap failures as explicit exception messages for the harness.
# Python line: from typing import List, Tuple
# KC CUDA → KernelBench ModelNew wrapper.
# Implements .cursorrules dense-comment policy for src/ code.
from typing import List, Tuple


# Python line: class KbenchWrapError(Exception):
# KC CUDA → KernelBench ModelNew wrapper.
# Implements .cursorrules dense-comment policy for src/ code.
class KbenchWrapError(Exception):
    """Raised when KC CUDA cannot be converted into KernelBench ModelNew source."""


# Python line: def rename_model_to_modelnew(src: str) -> str:
# KC CUDA → KernelBench ModelNew wrapper.
# Implements .cursorrules dense-comment policy for src/ code.
def rename_model_to_modelnew(src: str) -> str:
    """Rename ``class Model`` to ``class ModelNew`` (KernelBench convention)."""
    # Python line: if re.search(r"\\bclass\\s+ModelNew\\b", src):
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    if re.search(r"\bclass\s+ModelNew\b", src):
        # Python line: return src
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        return src
    # Python line: src = re.sub(r"\\bclass\\s+Model\\s*\\(", "class ModelNew(", src)
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    src = re.sub(r"\bclass\s+Model\s*\(", "class ModelNew(", src)
    # Python line: src = re.sub(r"\\bsuper\\s*\\(\\s*Model\\s*,", "super(ModelNew,", src)
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    src = re.sub(r"\bsuper\s*\(\s*Model\s*,", "super(ModelNew,", src)
    # Python line: return src
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    return src


# Python line: def _find_tail_section(src: str) -> int:
# KC CUDA → KernelBench ModelNew wrapper.
# Implements .cursorrules dense-comment policy for src/ code.
def _find_tail_section(src: str) -> int:
    """Return char offset where module-level tail (get_inputs, N=...) begins."""
    # Python line: lines = src.split("\\n")
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    lines = src.split("\n")
    # Python line: last_class_idx = -1
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    last_class_idx = -1
    # Python line: for i, line in enumerate(lines):
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    for i, line in enumerate(lines):
        # Python line: if re.match(r"^class\\s+", line):
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        if re.match(r"^class\s+", line):
            # Python line: last_class_idx = i
            # KC CUDA → KernelBench ModelNew wrapper.
            # Implements .cursorrules dense-comment policy for src/ code.
            last_class_idx = i
    # Python line: if last_class_idx == -1:
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    if last_class_idx == -1:
        # Python line: return len(src)
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        return len(src)
    # Python line: for i in range(last_class_idx + 1, len(lines)):
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    for i in range(last_class_idx + 1, len(lines)):
        # Python line: line = lines[i]
        # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
        line = lines[i]
        # Python line: if line.strip() == "" or (line and line[0] in (" ", "\\t")):
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        if line.strip() == "" or (line and line[0] in (" ", "\t")):
            # Python line: continue
            # KC CUDA → KernelBench ModelNew wrapper.
            # Implements .cursorrules dense-comment policy for src/ code.
            continue
        # Python line: return sum(len(l) + 1 for l in lines[:i])
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        return sum(len(l) + 1 for l in lines[:i])
    # Python line: return len(src)
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    return len(src)


# Python line: def prepare_solution_source(ref_src: str, sol_src: str) -> str:
# KC CUDA → KernelBench ModelNew wrapper.
# Implements .cursorrules dense-comment policy for src/ code.
def prepare_solution_source(ref_src: str, sol_src: str) -> str:
    """
    Merge a Python solution with the reference tail section (KernelBench helper).

    Keeps reference ``get_inputs`` / ``get_init_inputs`` / shape constants.
    """
    # Python line: modified = rename_model_to_modelnew(sol_src)
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    modified = rename_model_to_modelnew(sol_src)
    # Python line: sol_tail_start = _find_tail_section(modified)
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    sol_tail_start = _find_tail_section(modified)
    # Python line: modified = modified[:sol_tail_start].rstrip()
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    modified = modified[:sol_tail_start].rstrip()
    # Python line: ref_tail_start = _find_tail_section(ref_src)
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    ref_tail_start = _find_tail_section(ref_src)
    # Python line: ref_tail = ref_src[ref_tail_start:]
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    ref_tail = ref_src[ref_tail_start:]
    # Python line: if ref_tail.strip():
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    if ref_tail.strip():
        # Python line: modified = modified + "\\n\\n" + ref_tail
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        modified = modified + "\n\n" + ref_tail
    # Python line: else:
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    else:
        # Python line: modified = modified + "\\n"
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        modified = modified + "\n"
    # Python line: return modified
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    return modified


# Python line: def _forward_arg_names(ref_src: str) -> List[str]:
# KC CUDA → KernelBench ModelNew wrapper.
# Implements .cursorrules dense-comment policy for src/ code.
def _forward_arg_names(ref_src: str) -> List[str]:
    """Parse ``Model.forward`` tensor argument names from reference source."""
    # Python line: tree = ast.parse(ref_src)
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    tree = ast.parse(ref_src)
    # Python line: for node in tree.body:
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    for node in tree.body:
        # Python line: if not isinstance(node, ast.ClassDef) or node.name != "Model":
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        if not isinstance(node, ast.ClassDef) or node.name != "Model":
            # Python line: continue
            # KC CUDA → KernelBench ModelNew wrapper.
            # Implements .cursorrules dense-comment policy for src/ code.
            continue
        # Python line: for item in node.body:
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        for item in node.body:
            # Python line: if isinstance(item, ast.FunctionDef) and item.name == "forward":
            # KC CUDA → KernelBench ModelNew wrapper.
            # Implements .cursorrules dense-comment policy for src/ code.
            if isinstance(item, ast.FunctionDef) and item.name == "forward":
                # Python line: names: List[str] = []
                # KC CUDA → KernelBench ModelNew wrapper.
                # Implements .cursorrules dense-comment policy for src/ code.
                names: List[str] = []
                # Python line: for arg in item.args.args[1:]:
                # KC CUDA → KernelBench ModelNew wrapper.
                # Implements .cursorrules dense-comment policy for src/ code.
                for arg in item.args.args[1:]:
                    # Python line: names.append(arg.arg)
                    # KC CUDA → KernelBench ModelNew wrapper.
                    # Implements .cursorrules dense-comment policy for src/ code.
                    names.append(arg.arg)
                # Python line: return names
                # KC CUDA → KernelBench ModelNew wrapper.
                # Implements .cursorrules dense-comment policy for src/ code.
                return names
    # Python line: raise KbenchWrapError("reference source has no Model.forward()")
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    raise KbenchWrapError("reference source has no Model.forward()")


# Python line: def _first_global_kernel(cuda_src: str) -> Tuple[str, str]:
# KC CUDA → KernelBench ModelNew wrapper.
# Implements .cursorrules dense-comment policy for src/ code.
def _first_global_kernel(cuda_src: str) -> Tuple[str, str]:
    """Return (kernel_name, full signature inside parentheses) for first __global__ kernel."""
    # Python line: match = re.search(
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    match = re.search(
        # Python line: r"__global__\\s+(?:void|int|float|double)\\s+(\\w+)\\s*\\(([^)]*)\\)",
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        r"__global__\s+(?:void|int|float|double)\s+(\w+)\s*\(([^)]*)\)",
        # Python line: cuda_src,
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        cuda_src,
    )
    # Python line: if not match:
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    if not match:
        # Python line: raise KbenchWrapError("no __global__ kernel found in CUDA sidecar")
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        raise KbenchWrapError("no __global__ kernel found in CUDA sidecar")
    # Python line: return match.group(1), match.group(2)
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    return match.group(1), match.group(2)


# Python line: def _wrap_raw_cuda_with_load_inline(ref_src: str, cuda_src: str) -> str:
# KC CUDA → KernelBench ModelNew wrapper.
# Implements .cursorrules dense-comment policy for src/ code.
def _wrap_raw_cuda_with_load_inline(ref_src: str, cuda_src: str) -> str:
    """
    Best-effort ``load_inline`` wrapper for raw KC ``.cu`` (device-only) sources.

  Falls back to a single-input or two-input binding based on ``Model.forward``.
    """
    # Python line: arg_names = _forward_arg_names(ref_src)
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    arg_names = _forward_arg_names(ref_src)
    # Python line: kernel_name, _sig = _first_global_kernel(cuda_src)
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    kernel_name, _sig = _first_global_kernel(cuda_src)
    # Python line: module_name = "agentk_kernel_mod"
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    module_name = "agentk_kernel_mod"
    # Python line: launch_fn = "agentk_launch_cuda"
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    launch_fn = "agentk_launch_cuda"

    # Python line: if len(arg_names) == 1:
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    if len(arg_names) == 1:
        # Python line: a0 = arg_names[0]
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        a0 = arg_names[0]
        # Python line: host_cpp = textwrap.dedent(
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        host_cpp = textwrap.dedent(
            f"""
            #include <torch/extension.h>
            torch::Tensor {launch_fn}(torch::Tensor {a0}) {{
                auto out = torch::empty_like({a0});
                int n = static_cast<int>({a0}.numel());
                const int block = 256;
                const int grid = (n + block - 1) / block;
                {kernel_name}<<<grid, block>>>(
                    {a0}.data_ptr<float>(),
                    out.data_ptr<float>(),
                    n
                );
                return out;
            }}
            """
        ).strip()
        # Python line: forward_call = f"return self.{module_name}.{launch_fn}({a0})"
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        forward_call = f"return self.{module_name}.{launch_fn}({a0})"
        # Python line: forward_args = a0
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        forward_args = a0
        # Python line: cpp_decl = f"torch::Tensor {launch_fn}(torch::Tensor {a0});"
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        cpp_decl = f"torch::Tensor {launch_fn}(torch::Tensor {a0});"
    # Python line: elif len(arg_names) == 2:
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    elif len(arg_names) == 2:
        # Python line: a0, a1 = arg_names
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        a0, a1 = arg_names
        # Python line: host_cpp = textwrap.dedent(
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        host_cpp = textwrap.dedent(
            f"""
            #include <torch/extension.h>
            torch::Tensor {launch_fn}(torch::Tensor {a0}, torch::Tensor {a1}) {{
                auto out = torch::empty_like({a0});
                int n = static_cast<int>({a0}.numel());
                const int block = 256;
                const int grid = (n + block - 1) / block;
                {kernel_name}<<<grid, block>>>(
                    {a0}.data_ptr<float>(),
                    {a1}.data_ptr<float>(),
                    out.data_ptr<float>(),
                    n
                );
                return out;
            }}
            """
        ).strip()
        # Python line: forward_call = f"return self.{module_name}.{launch_fn}({a0}, {a1})"
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        forward_call = f"return self.{module_name}.{launch_fn}({a0}, {a1})"
        # Python line: forward_args = f"{a0}, {a1}"
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        forward_args = f"{a0}, {a1}"
        # Python line: cpp_decl = f"torch::Tensor {launch_fn}(torch::Tensor {a0}, torch::Tensor {a1});"
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        cpp_decl = f"torch::Tensor {launch_fn}(torch::Tensor {a0}, torch::Tensor {a1});"
    # Python line: else:
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    else:
        # Python line: raise KbenchWrapError(
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        raise KbenchWrapError(
            f"automatic load_inline wrapper supports 1-2 forward args, got {len(arg_names)}"
        )

    # Python line: cuda_bundle = cuda_src.rstrip() + "\\n\\n" + host_cpp
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    cuda_bundle = cuda_src.rstrip() + "\n\n" + host_cpp
    # Python line: cuda_literal = repr(cuda_bundle)
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    cuda_literal = repr(cuda_bundle)
    # Python line: cpp_literal = repr(cpp_decl)
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    cpp_literal = repr(cpp_decl)
    # Python line: sol = f'''import torch
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    sol = f'''import torch
import torch.nn as nn
from torch.utils.cpp_extension import load_inline

_cuda_src = {cuda_literal}

_cpp_src = {cpp_literal}

{module_name} = load_inline(
    name="{module_name}",
    cpp_sources=_cpp_src,
    cuda_sources=_cuda_src,
    functions=["{launch_fn}"],
    verbose=False,
)

class Model(nn.Module):
    def __init__(self):
        super().__init__()
        self.{module_name} = {module_name}

    def forward(self, {forward_args}):
        {forward_call}
'''
    # Python line: return prepare_solution_source(ref_src, sol)
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    return prepare_solution_source(ref_src, sol)


# Python line: def wrap_agentk_cuda_for_kernelbench(*, ref_src: str, cuda_src: str) -> str:
# KC CUDA → KernelBench ModelNew wrapper.
# Implements .cursorrules dense-comment policy for src/ code.
def wrap_agentk_cuda_for_kernelbench(*, ref_src: str, cuda_src: str) -> str:
    """
    Convert KC-emitted CUDA into KernelBench-evaluable ``ModelNew`` Python source.

    If ``cuda_src`` is already Python (contains ``class Model`` / ``ModelNew`` or
    ``load_inline``), apply ``prepare_solution_source`` only. Otherwise build a
    best-effort ``load_inline`` wrapper around raw ``__global__`` kernels.
    """
    # Python line: text = cuda_src.strip()
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    text = cuda_src.strip()
    # Python line: if not text:
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    if not text:
        # Python line: raise KbenchWrapError("empty CUDA sidecar")
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        raise KbenchWrapError("empty CUDA sidecar")
    # Python line: if "class ModelNew" in text or re.search(r"\\bclass\\s+Model\\s*\\(", text):
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    if "class ModelNew" in text or re.search(r"\bclass\s+Model\s*\(", text):
        # Python line: return prepare_solution_source(ref_src, text)
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        return prepare_solution_source(ref_src, text)
    # Python line: if "load_inline" in text and "Model" in text:
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    if "load_inline" in text and "Model" in text:
        # Python line: return prepare_solution_source(ref_src, text)
        # KC CUDA → KernelBench ModelNew wrapper.
        # Implements .cursorrules dense-comment policy for src/ code.
        return prepare_solution_source(ref_src, text)
    # Python line: return _wrap_raw_cuda_with_load_inline(ref_src, text)
    # KC CUDA → KernelBench ModelNew wrapper.
    # Implements .cursorrules dense-comment policy for src/ code.
    return _wrap_raw_cuda_with_load_inline(ref_src, text)
