"""Phase 3.5 — KernelBench numerical correctness harness (§3.5)."""

# Python line: from src.correctness.cuda_sidecar import cuda_sidecar_path, load_cuda_sidecar, write_cuda_sidecar
# Phase 3.5 correctness package (src/correctness).
# Implements .cursorrules dense-comment policy for src/ code.
from src.correctness.cuda_sidecar import cuda_sidecar_path, load_cuda_sidecar, write_cuda_sidecar
# Python line: from src.correctness.kbench_wrap import wrap_kc_cuda_for_kernelbench
# Phase 3.5 correctness package (src/correctness).
# Implements .cursorrules dense-comment policy for src/ code.
from src.correctness.kbench_wrap import wrap_kc_cuda_for_kernelbench
# Python line: from src.correctness.kbench_eval import run_kernelbench_eval
# Phase 3.5 correctness package (src/correctness).
# Implements .cursorrules dense-comment policy for src/ code.
from src.correctness.kbench_eval import run_kernelbench_eval

# Python line: __all__ = [
# Phase 3.5 correctness package (src/correctness).
# Implements .cursorrules dense-comment policy for src/ code.
__all__ = [
    # Python line: "cuda_sidecar_path",
    # Phase 3.5 correctness package (src/correctness).
    # Implements .cursorrules dense-comment policy for src/ code.
    "cuda_sidecar_path",
    # Python line: "load_cuda_sidecar",
    # Phase 3.5 correctness package (src/correctness).
    # Implements .cursorrules dense-comment policy for src/ code.
    "load_cuda_sidecar",
    # Python line: "write_cuda_sidecar",
    # Phase 3.5 correctness package (src/correctness).
    # Implements .cursorrules dense-comment policy for src/ code.
    "write_cuda_sidecar",
    # Python line: "wrap_kc_cuda_for_kernelbench",
    # Phase 3.5 correctness package (src/correctness).
    # Implements .cursorrules dense-comment policy for src/ code.
    "wrap_kc_cuda_for_kernelbench",
    # Python line: "run_kernelbench_eval",
    # Phase 3.5 correctness package (src/correctness).
    # Implements .cursorrules dense-comment policy for src/ code.
    "run_kernelbench_eval",
# Python line: ]
# Phase 3.5 correctness package (src/correctness).
# Implements .cursorrules dense-comment policy for src/ code.
]
