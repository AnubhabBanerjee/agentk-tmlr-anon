"""
Resolve trace / label / correctness / artifact paths from tracing YAML configs.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

import yaml

# Default tracing config for the four-backbone evaluated corpus.
DEFAULT_V2_CONFIG = "configs/tracing_v2.yaml"


@dataclass(frozen=True)
class TracingPaths:
    """Filesystem layout for one tracing pipeline variant."""

    repo_root: Path
    config_path: Optional[Path]
    index_path: Path
    labels_dir: Path
    correctness_parquet: Path
    correctness_report: Path
    predictions_root: Path
    baselines_root: Path
    prompts_jsonl: Path

    @property
    def is_v2(self) -> bool:
        """True when this layout uses the released artifact directory names."""
        return "traces_v2" in str(self.index_path) or "labels_v2" in str(self.labels_dir)

    @property
    def kbench_artifacts_dir(self) -> Path:
        """Directory for harness progress, logs, and torch extension build cache."""
        return self.repo_root / ("artifacts_v2" if self.is_v2 else "artifacts")

    @property
    def kbench_progress_json(self) -> Path:
        return self.kbench_artifacts_dir / "kbench_correctness_progress.json"

    @property
    def kbench_build_root(self) -> Path:
        return self.kbench_artifacts_dir / "kbench_build"

    @property
    def calibration_path(self) -> Path:
        """Authoritative post-hoc Q4 VRAM calibration file for this layout.

        Trace rows may embed ``closed_form_accounting_json`` written at
        collection time before calibration constants were available; baseline
        evaluation applies this file post-hoc via
        ``src/baselines/common.accounting_dict``.
        """
        return self.repo_root / "configs" / (
            "q4_vram_calibration_v2.yaml" if self.is_v2 else "q4_vram_calibration.yaml"
        )


def _resolve(repo_root: Path, raw: str) -> Path:
    """Expand a repo-relative path from YAML to an absolute Path."""
    path = Path(raw)
    if path.is_absolute():
        return path
    return repo_root / path


def load_tracing_paths(
    *,
    repo_root: Path,
    config: Optional[Path | str] = None,
) -> TracingPaths:
    """
    Load path layout from ``configs/tracing_v2.yaml`` when *config* is set.

    When *config* is omitted, return the legacy default layout.
    """
    if config is None:
        return TracingPaths(
            repo_root=repo_root,
            config_path=None,
            index_path=repo_root / "data" / "traces" / "index.parquet",
            labels_dir=repo_root / "data" / "labels",
            correctness_parquet=repo_root / "data" / "correctness" / "kernelbench.parquet",
            correctness_report=repo_root / "data" / "correctness_report.md",
            predictions_root=repo_root / "artifacts" / "predictions",
            baselines_root=repo_root / "artifacts" / "baselines",
            prompts_jsonl=repo_root / "data" / "prompts" / "all.jsonl",
        )

    config_path = Path(config)
    if not config_path.is_absolute():
        config_path = repo_root / config_path
    cfg: Dict[str, Any] = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    trace_out = cfg.get("trace_output", {})
    correctness = cfg.get("correctness", {})
    index_raw = trace_out.get("index_file", "data/traces/index.parquet")
    kb_raw = correctness.get("kernelbench_output", "data/correctness/kernelbench.parquet")
    is_v2 = "v2" in str(index_raw) or "v2" in str(kb_raw)
    labels_dir = repo_root / ("data/labels_v2" if is_v2 else "data/labels")
    report_name = "correctness_report_v2.md" if is_v2 else "correctness_report.md"
    predictions_root = repo_root / ("artifacts_v2/predictions" if is_v2 else "artifacts/predictions")
    baselines_root = repo_root / ("artifacts_v2/baselines" if is_v2 else "artifacts/baselines")
    return TracingPaths(
        repo_root=repo_root,
        config_path=config_path,
        index_path=_resolve(repo_root, str(index_raw)),
        labels_dir=labels_dir,
        correctness_parquet=_resolve(repo_root, str(kb_raw)),
        correctness_report=repo_root / "data" / report_name,
        predictions_root=predictions_root,
        baselines_root=baselines_root,
        prompts_jsonl=repo_root / ("data/prompts_v2/all.jsonl" if is_v2 else "data/prompts/all.jsonl"),
    )


def tracing_paths_from_env(*, repo_root: Path) -> TracingPaths:
    """Read optional ``TRACING_CONFIG`` env var (set by Makefile ``CONFIG=``)."""
    import os

    raw = os.environ.get("TRACING_CONFIG", "").strip()
    if raw:
        return load_tracing_paths(repo_root=repo_root, config=raw)
    return load_tracing_paths(repo_root=repo_root, config=None)
