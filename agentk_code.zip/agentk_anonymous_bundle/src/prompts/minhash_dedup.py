"""
MinHash utilities for near-duplicate filtering (/ A2).

Used when downsampling KernelBench from 270 → 100 prompts by dropping
lowest-diversity pairs with estimated Jaccard ≥ threshold (default 0.85).
"""

# Enable postponed evaluation of type hints for forward references.
from __future__ import annotations

# hashlib supplies stable 64-bit hashes for MinHash permutations.
import hashlib
# re tokenizes prompt text into word shingles.
import re
# typing annotates generic row containers passed into dedup helpers.
from typing import Any, Callable, Iterable, List, Sequence, TypeVar


# Default Jaccard threshold from step_by_step_execution_guide §2.2 / released A2.
JACCARD_THRESHOLD: float = 0.85
# Number of MinHash permutations (signature length).
NUM_PERM: int = 128
# Word-shingle width for CUDA/NL prompt text.
SHINGLE_K: int = 3

# Generic row type for list-of-dict prompt records.
T = TypeVar("T")


def _word_shingles(text: str, *, k: int = SHINGLE_K) -> set[str]:
    """Return the set of word k-shingles from normalized prompt text."""
    # Lowercase and extract alphanumeric tokens for stable shingling.
    words = re.findall(r"[a-z0-9]+", text.lower())
    # Degenerate short prompts become a single shingle of joined tokens.
    if len(words) < k:
        joined = " ".join(words)
        return {joined} if joined else set()
    # Slide a length-k window across the token list.
    return {" ".join(words[i : i + k]) for i in range(len(words) - k + 1)}


def _hash64(token: str, seed: int) -> int:
    """Hash (token, seed) to a 64-bit unsigned integer."""
    # SHA-256 gives reproducible hashes independent of Python's hash().
    payload = f"{seed}\0{token}".encode("utf-8")
    digest = hashlib.sha256(payload).digest()
    # Take the first eight bytes as an unsigned 64-bit value.
    return int.from_bytes(digest[:8], byteorder="big", signed=False)


def minhash_signature(text: str, *, num_perm: int = NUM_PERM) -> tuple[int, ...]:
    """Compute a MinHash signature for one prompt string."""
    # Build shingles once; empty text yields an all-zero signature.
    shingles = _word_shingles(text)
    if not shingles:
        return tuple(0 for _ in range(num_perm))
    # For each permutation seed, keep the minimum hashed shingle value.
    sig: List[int] = []
    for seed in range(num_perm):
        minimum = min(_hash64(shingle, seed) for shingle in shingles)
        sig.append(minimum)
    # Immutable tuple so signatures are hashable / cache-friendly.
    return tuple(sig)


def estimated_jaccard(sig_a: Sequence[int], sig_b: Sequence[int]) -> float:
    """Estimate Jaccard similarity from two equal-length MinHash signatures."""
    # Guard against mismatched signature lengths (should not happen in-repo).
    if len(sig_a) != len(sig_b) or not sig_a:
        return 0.0
    # Agreement fraction is the standard MinHash Jaccard estimator.
    matches = sum(1 for a, b in zip(sig_a, sig_b) if a == b)
    return matches / len(sig_a)


def _diversity_score(signatures: Sequence[tuple[int, ...]], index: int) -> float:
    """Mean dissimilarity (1 − Ĵ) between signature[index] and all others."""
    # Singleton lists are maximally diverse by convention.
    if len(signatures) <= 1:
        return 1.0
    target = signatures[index]
    total = 0.0
    # Average dissimilarity to every other prompt in the level bucket.
    for j, other in enumerate(signatures):
        if j == index:
            continue
        total += 1.0 - estimated_jaccard(target, other)
    return total / (len(signatures) - 1)


def deduplicate_by_minhash(
    rows: Sequence[T],
    *,
    text_getter: Callable[[T], str],
    threshold: float = JACCARD_THRESHOLD,
) -> List[T]:
    """
    Greedy diversity-preserving dedup: drop near-duplicates (Ĵ ≥ threshold).

    Rows are processed in descending diversity order; a row is kept only if
  it is not a near-duplicate of any row already kept.
    """
    # Empty input is a no-op for callers building per-level buckets.
    if not rows:
        return []
    # Precompute one MinHash signature per row.
    signatures = [minhash_signature(text_getter(row)) for row in rows]
    # Rank row indices by how dissimilar they are to siblings in the bucket.
    order = sorted(
        range(len(rows)),
        key=lambda idx: _diversity_score(signatures, idx),
        reverse=True,
    )
    kept: List[T] = []
    kept_sigs: List[tuple[int, ...]] = []
    # Walk from most diverse to least; skip near-duplicates of kept rows.
    for idx in order:
        sig = signatures[idx]
        if any(estimated_jaccard(sig, kept_sig) >= threshold for kept_sig in kept_sigs):
            continue
        kept.append(rows[idx])
        kept_sigs.append(sig)
    return kept


def signatures_for_rows(
    rows: Iterable[Any],
    *,
    text_getter: Callable[[Any], str],
) -> List[tuple[int, ...]]:
    """Convenience helper: MinHash signatures for an iterable of prompt rows."""
    return [minhash_signature(text_getter(row)) for row in rows]
