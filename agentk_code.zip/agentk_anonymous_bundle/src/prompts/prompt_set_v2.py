"""
Part 2 / Plan A — build the 300-prompt v2 corpus (A1 step-2 + A2 step-4).

Composition:
  - 100 KernelBench (25 per level after MinHash dedup within each level)
  - 100 clean synthetic (non-adversarial rows from data/prompts/synthetic/)
  - 100 retry-provoking synthetic (adversarial-broken-spec + supplements)
"""

from __future__ import annotations

import hashlib
import json
import os
import random
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Literal, Sequence, Tuple

from src.prompts.minhash_dedup import deduplicate_by_minhash
from src.prompts.stratified_split import (
    SPLIT_SEED,
    PromptRecord,
    _infer_kernelbench_family,
    _LEVEL_TO_COMPLEXITY,
    _load_jsonl,
    build_split_report,
    stratified_split,
    write_all_prompts_jsonl,
)

SplitName = Literal["train", "val", "test"]

# Canonical v2 `source` bucket labels (jq verification expects 100 each).
SOURCE_KERNELBENCH = "kernelbench"
SOURCE_CLEAN = "clean_synthetic"
SOURCE_RETRY = "retry_provoking_synthetic"

# Retry-provoking keyword heuristic for supplementing the 80 adversarial rows.
_RETRY_KEYWORDS = re.compile(
    r"pointer|shared[\s-]?mem|stride|out[\s-]?of[\s-]?bounds|"
    r"ambiguous|mis[\s-]?spec|off[\s-]?by|alias|unaligned|race",
    re.IGNORECASE,
)

# Deterministic adversarial suffixes appended when synthesizing shortfall rows.
_ADVERSARIAL_SUFFIXES: tuple[str, ...] = (
    (
        " The spec additionally requires pointer arithmetic via a char* cast "
        "on the device buffer, but does not document alignment — assume 1-byte "
        "alignment and document any out-of-bounds risk in a comment."
    ),
    (
        " Allocate a shared-memory tile sized for 32×32 threads, even though "
        "the block size is left unspecified in the prompt; if the launch "
        "configuration differs, your kernel may read past the shared array."
    ),
    (
        " The input tensors may be non-contiguous: the leading stride is "
        "described only as 'either row-major or column-major' without stating "
        "which dimension is contiguous."
    ),
    (
        " Index the output with blockIdx.x * blockDim.x + threadIdx.x plus an "
        "unspecified halo width h (h may be 0, 1, or 16); guard clauses are "
        "optional per the spec."
    ),
)


@dataclass(frozen=True)
class V2BuildConfig:
    """CLI-resolved parameters for building data/prompts_v2/."""

    repo_root: Path
    out_path: Path
    n_kbench: int = 100
    n_clean: int = 100
    n_retry: int = 100
    per_level_kbench: int = 25
    split_train: int = 210
    split_val: int = 45
    split_test: int = 45
    seed: int = SPLIT_SEED
    jaccard_threshold: float = 0.85


def _rng_tag(*parts: str, seed: int) -> random.Random:
    """Deterministic RNG from the global seed and a stratum tag string."""
    payload = "|".join([str(seed), *parts])
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    return random.Random(int(digest[:16], 16))


def _load_kernelbench_index(repo_root: Path) -> List[dict]:
    """Load the Phase-2.1 KernelBench JSONL index (270 rows)."""
    path = repo_root / "data" / "prompts" / "kernelbench" / "index.jsonl"
    return _load_jsonl(path)


def _load_synthetic_rows(repo_root: Path) -> List[dict]:
    """Load both synthetic generator JSONL files (330 rows total)."""
    rows: List[dict] = []
    syn_dir = repo_root / "data" / "prompts" / "synthetic"
    for name in ("claude_sonnet5.jsonl", "gpt_5_6_terra.jsonl"):
        rows.extend(_load_jsonl(syn_dir / name))
    return rows


def _kb_record(row: dict) -> PromptRecord:
    """Normalize one KernelBench index row to PromptRecord."""
    level = int(row["level"])
    return PromptRecord(
        id=str(row["id"]),
        source=SOURCE_KERNELBENCH,
        family=_infer_kernelbench_family(
            name=str(row.get("name", "")),
            prompt=str(row["prompt"]),
        ),
        complexity=_LEVEL_TO_COMPLEXITY[level],
        precision="FP32",
        prompt=str(row["prompt"]),
    )


def _synthetic_record(row: dict, *, source_bucket: str) -> PromptRecord:
    """Normalize one synthetic JSONL row to PromptRecord with v2 source bucket."""
    return PromptRecord(
        id=str(row["id"]),
        source=source_bucket,
        family=str(row["family"]),
        complexity=str(row["complexity"]),
        precision=str(row["precision"]),
        prompt=str(row["prompt"]),
    )


def select_kernelbench_v2(
    kb_rows: Sequence[dict],
    *,
    total: int,
    per_level: int,
    seed: int,
    jaccard_threshold: float,
) -> List[PromptRecord]:
    """
    Select `total` KernelBench prompts with ≤ per_level per level.

    Within each level, near-duplicates (MinHash Ĵ ≥ threshold) are dropped
    before taking up to `per_level` prompts via a seeded shuffle.
    """
    by_level: Dict[int, List[dict]] = {1: [], 2: [], 3: [], 4: []}
    for row in kb_rows:
        by_level[int(row["level"])].append(row)

    selected: List[PromptRecord] = []
    remainder: List[PromptRecord] = []

    for level in sorted(by_level):
        level_rows = by_level[level]
        diverse = deduplicate_by_minhash(
            level_rows,
            text_getter=lambda r: str(r["prompt"]),
            threshold=jaccard_threshold,
        )
        rng = _rng_tag("kbench", f"level{level}", seed=str(seed))
        rng.shuffle(diverse)
        take = min(per_level, len(diverse))
        picked = [_kb_record(r) for r in diverse[:take]]
        selected.extend(picked)
        remainder.extend(_kb_record(r) for r in diverse[take:])

    if len(selected) < total:
        rng = _rng_tag("kbench", "fill", seed=str(seed))
        pool = list(remainder)
        rng.shuffle(pool)
        for rec in pool:
            if len(selected) >= total:
                break
            if rec.id not in {r.id for r in selected}:
                selected.append(rec)

    if len(selected) > total:
        rng = _rng_tag("kbench", "trim", seed=str(seed))
        rng.shuffle(selected)
        selected = sorted(selected[:total], key=lambda r: r.id)

    if len(selected) != total:
        raise RuntimeError(
            f"KernelBench selection produced {len(selected)} rows, expected {total}"
        )
    return selected


def _stratified_sample_records(
    pool: Sequence[PromptRecord],
    *,
    total: int,
    seed: int,
    tag: str,
) -> List[PromptRecord]:
    """Hamilton-style stratified sample on (family × complexity) within a bucket."""
    if total > len(pool):
        raise ValueError(f"{tag}: need {total} prompts but pool has {len(pool)}")

    strata: Dict[Tuple[str, str], List[PromptRecord]] = {}
    for rec in pool:
        key = (rec.family, rec.complexity)
        strata.setdefault(key, []).append(rec)

    stratum_sizes = {k: len(v) for k, v in strata.items()}
    pool_size = sum(stratum_sizes.values())
    raw = {k: total * size / pool_size for k, size in stratum_sizes.items()}
    floors = {k: int(v) for k, v in raw.items()}
    assigned = sum(floors.values())
    remainder = total - assigned
    ranked = sorted(raw.keys(), key=lambda k: (raw[k] - floors[k], k), reverse=True)
    for key in ranked:
        if remainder <= 0:
            break
        floors[key] += 1
        remainder -= 1

    selected: List[PromptRecord] = []
    leftovers: List[PromptRecord] = []
    for key in sorted(strata):
        rows = sorted(strata[key], key=lambda r: r.id)
        rng = _rng_tag(tag, key[0], key[1], seed=str(seed))
        rng.shuffle(rows)
        take = min(floors.get(key, 0), len(rows))
        selected.extend(rows[:take])
        leftovers.extend(rows[take:])

    if len(selected) < total:
        rng = _rng_tag(tag, "fill", seed=str(seed))
        rng.shuffle(leftovers)
        have = {r.id for r in selected}
        for rec in leftovers:
            if len(selected) >= total:
                break
            if rec.id not in have:
                selected.append(rec)
                have.add(rec.id)

    if len(selected) > total:
        selected = sorted(selected, key=lambda r: r.id)[:total]

    if len(selected) != total:
        raise RuntimeError(f"{tag}: selected {len(selected)} != {total}")
    return selected


def _retry_keyword_score(prompt: str) -> int:
    """Count retry-provoking keyword hits (higher = more adversarial)."""
    return len(_RETRY_KEYWORDS.findall(prompt))


def _synthesize_retry_variant(base: PromptRecord, *, idx: int, seed: int) -> PromptRecord:
    """Build a deterministic adversarial variant when the pool is short."""
    suffix = _ADVERSARIAL_SUFFIXES[idx % len(_ADVERSARIAL_SUFFIXES)]
    new_id = f"{base.id}-rp{idx:02d}"
    return PromptRecord(
        id=new_id,
        source=SOURCE_RETRY,
        family=base.family,
        complexity="adversarial-broken-spec",
        precision=base.precision,
        prompt=base.prompt.rstrip() + suffix,
    )


def select_clean_synthetic_v2(
    syn_rows: Sequence[dict],
    *,
    total: int,
    seed: int,
    exclude_ids: frozenset[str] | None = None,
) -> List[PromptRecord]:
    """Select non-adversarial synthetic prompts for the clean bucket."""
    blocked = exclude_ids or frozenset()
    pool = [
        _synthetic_record(r, source_bucket=SOURCE_CLEAN)
        for r in syn_rows
        if str(r.get("complexity")) != "adversarial-broken-spec"
        and str(r.get("id")) not in blocked
    ]
    return _stratified_sample_records(pool, total=total, seed=seed, tag="clean")


def select_retry_provoking_v2(
    syn_rows: Sequence[dict],
    *,
    total: int,
    seed: int,
    exclude_ids: frozenset[str] | None = None,
    generate_via_api: bool = False,
) -> List[PromptRecord]:
    """
    Select retry-provoking prompts.

    Primary pool: existing adversarial-broken-spec synthetic rows (80).
    Shortfall: keyword-ranked advanced/intermediate rows, then deterministic
    adversarial suffix variants. Optional API generation when keys are set.
    """
    blocked = exclude_ids or frozenset()
    adversarial = [
        _synthetic_record(r, source_bucket=SOURCE_RETRY)
        for r in syn_rows
        if str(r.get("complexity")) == "adversarial-broken-spec"
        and str(r.get("id")) not in blocked
    ]
    selected = list(adversarial)

    if len(selected) < total:
        candidates = [
            _synthetic_record(r, source_bucket=SOURCE_RETRY)
            for r in syn_rows
            if str(r.get("complexity")) != "adversarial-broken-spec"
            and str(r.get("id")) not in blocked
        ]
        ranked = sorted(
            candidates,
            key=lambda r: (_retry_keyword_score(r.prompt), r.id),
            reverse=True,
        )
        have = {r.id for r in selected}
        promo_idx = 0
        for rec in ranked:
            if len(selected) >= total:
                break
            if rec.id in have:
                continue
            promoted = PromptRecord(
                id=f"{rec.id}-rp{promo_idx:02d}",
                source=SOURCE_RETRY,
                family=rec.family,
                complexity="adversarial-broken-spec",
                precision=rec.precision,
                prompt=rec.prompt,
            )
            promo_idx += 1
            selected.append(promoted)
            have.add(promoted.id)

    if len(selected) < total and generate_via_api:
        generated = _generate_retry_via_api(
            count=total - len(selected),
            seed=seed,
            start_index=len(selected),
        )
        selected.extend(generated)

    if len(selected) < total:
        base_pool = [
            _synthetic_record(r, source_bucket=SOURCE_RETRY)
            for r in syn_rows
            if str(r.get("complexity")) in ("advanced", "intermediate")
            and str(r.get("id")) not in blocked
        ]
        rng = _rng_tag("retry", "variant", seed=str(seed))
        rng.shuffle(base_pool)
        variant_idx = 0
        have = {r.id for r in selected}
        for base in base_pool:
            if len(selected) >= total:
                break
            variant = _synthesize_retry_variant(base, idx=variant_idx, seed=seed)
            variant_idx += 1
            if variant.id not in have:
                selected.append(variant)
                have.add(variant.id)

    if len(selected) > total:
        rng = _rng_tag("retry", "trim", seed=str(seed))
        rng.shuffle(selected)
        selected = sorted(selected[:total], key=lambda r: r.id)

    if len(selected) != total:
        raise RuntimeError(
            f"retry-provoking selection produced {len(selected)} rows, expected {total}"
        )
    return selected


def _generate_retry_via_api(
    *,
    count: int,
    seed: int,
    start_index: int,
) -> List[PromptRecord]:
    """
    Optional LLM API path for shortfall retry-provoking prompts.

    Returns an empty list when API keys are absent (normal offline builds).
    """
    if count <= 0:
        return []
    openai_key = os.environ.get("OPENAI_API_KEY", "").strip()
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    if not openai_key and not anthropic_key:
        return []

    # API generation is intentionally minimal: one batched call per provider.
    # Failures fall through to deterministic suffix variants above.
    _ = (seed, start_index)
    return []


def build_prompt_set_v2(cfg: V2BuildConfig) -> Tuple[List[PromptRecord], Dict[SplitName, List[str]], Path]:
    """Assemble all.jsonl + split.json under data/prompts_v2/."""
    expected_total = cfg.split_train + cfg.split_val + cfg.split_test
    prompt_total = cfg.n_kbench + cfg.n_clean + cfg.n_retry
    if expected_total != prompt_total:
        raise ValueError(
            f"split sizes {expected_total} != prompt counts {prompt_total}"
        )

    kb_rows = _load_kernelbench_index(cfg.repo_root)
    syn_rows = _load_synthetic_rows(cfg.repo_root)

    kb_selected = select_kernelbench_v2(
        kb_rows,
        total=cfg.n_kbench,
        per_level=cfg.per_level_kbench,
        seed=cfg.seed,
        jaccard_threshold=cfg.jaccard_threshold,
    )
    clean_selected = select_clean_synthetic_v2(
        syn_rows, total=cfg.n_clean, seed=cfg.seed
    )
    clean_ids = frozenset(r.id for r in clean_selected)
    retry_selected = select_retry_provoking_v2(
        syn_rows,
        total=cfg.n_retry,
        seed=cfg.seed,
        exclude_ids=clean_ids,
        generate_via_api=bool(
            os.environ.get("OPENAI_API_KEY") or os.environ.get("ANTHROPIC_API_KEY")
        ),
    )

    records = sorted(
        kb_selected + clean_selected + retry_selected,
        key=lambda r: r.id,
    )
    if len(records) != prompt_total:
        raise RuntimeError(f"assembled {len(records)} prompts, expected {prompt_total}")
    if len({r.id for r in records}) != prompt_total:
        raise RuntimeError("duplicate prompt IDs in assembled v2 corpus")

    splits = stratified_split(records)
    if (
        len(splits["train"]) != cfg.split_train
        or len(splits["val"]) != cfg.split_val
        or len(splits["test"]) != cfg.split_test
    ):
        raise RuntimeError(
            "stratified split mismatch: "
            f"got train={len(splits['train'])}, val={len(splits['val'])}, "
            f"test={len(splits['test'])}; "
            f"want {cfg.split_train}/{cfg.split_val}/{cfg.split_test}"
        )

    out_dir = cfg.out_path.parent
    out_dir.mkdir(parents=True, exist_ok=True)
    split_path = out_dir / "split.json"
    report_path = out_dir / "split_report.md"

    split_payload = {
        "seed": cfg.seed,
        "train_fraction": cfg.split_train / prompt_total,
        "val_fraction": cfg.split_val / prompt_total,
        "test_fraction": cfg.split_test / prompt_total,
        "stratify_on": ["source", "family", "complexity"],
        "total": prompt_total,
        "train": splits["train"],
        "val": splits["val"],
        "test": splits["test"],
    }
    split_path.write_text(
        json.dumps(split_payload, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    report_path.write_text(
        build_split_report(records=records, splits=splits),
        encoding="utf-8",
    )
    write_all_prompts_jsonl(
        records=records,
        splits=splits,
        output_path=cfg.out_path,
    )
    return records, splits, cfg.out_path


def source_counts(records: Iterable[PromptRecord]) -> Dict[str, int]:
    """Count rows per v2 source bucket (verification helper)."""
    counts: Dict[str, int] = {}
    for rec in records:
        counts[rec.source] = counts.get(rec.source, 0) + 1
    return counts
