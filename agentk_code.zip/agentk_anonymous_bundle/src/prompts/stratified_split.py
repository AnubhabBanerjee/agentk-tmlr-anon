"""
stratified train/val/test split for the assembled prompt corpus.

Stratify on (source × kernel-family × complexity-band), seed = 20260715,
persist ID lists to data/split.json.
"""

# Python line: from __future__ import annotations
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
from __future__ import annotations

# hashlib derives deterministic per-stratum shuffle sub-seeds from the global seed.
# Python line: import hashlib
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
import hashlib
# json reads prompt JSONL inputs and writes data/split.json.
# Python line: import json
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
import json
# random shuffles IDs inside each stratum with reproducible sub-seeds.
# Python line: import random
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
import random
# re matches KernelBench filenames/prompts against kernel-family keyword rules.
# Python line: import re
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
import re
# dataclass holds one normalized prompt row used for stratification.
# Python line: from dataclasses import dataclass
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
from dataclasses import dataclass
# Path locates data/prompts/*.jsonl and data/split.json under the repo root.
# Python line: from pathlib import Path
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
from pathlib import Path
# typing aliases annotate stratum keys and split-name literals.
# Python line: from typing import Dict, Iterable, List, Literal, Tuple
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
from typing import Dict, Iterable, List, Literal, Tuple


# Fixed RNG seed mandated by step_by_step_execution_guide §2.3.
# Python line: SPLIT_SEED: int = 20260715
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
SPLIT_SEED: int = 20260715
# Train fraction for the 70 / 15 / 15 split.
# Python line: TRAIN_FRAC: float = 0.70
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
TRAIN_FRAC: float = 0.70
# Validation fraction for the 70 / 15 / 15 split.
# Python line: VAL_FRAC: float = 0.15
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
VAL_FRAC: float = 0.15
# Test fraction for the 70 / 15 / 15 split (remainder after train + val).
# Python line: TEST_FRAC: float = 0.15
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
TEST_FRAC: float = 0.15
# Allowed split labels written into split.json.
# Python line: SplitName = Literal["train", "val", "test"]
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
SplitName = Literal["train", "val", "test"]


# Map KernelBench integer level to synthetic complexity-band vocabulary (§2.2).
# Python line: _LEVEL_TO_COMPLEXITY: dict[int, str] = {
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
_LEVEL_TO_COMPLEXITY: dict[int, str] = {
    # Python line: 1: "beginner",
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    1: "beginner",
    # Python line: 2: "intermediate",
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    2: "intermediate",
    # Python line: 3: "advanced",
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    3: "advanced",
    # Python line: 4: "adversarial-broken-spec",
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    4: "adversarial-broken-spec",
# Python line: }
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
}


# Ordered (family, compiled-regex) rules for KernelBench family inference.
# Python line: _KB_FAMILY_RULES: tuple[tuple[str, re.Pattern[str]], ...] = (
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
_KB_FAMILY_RULES: tuple[tuple[str, re.Pattern[str]], ...] = (
    # Python line: (
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    (
        # Python line: "transformer-attention",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "transformer-attention",
        # Python line: re.compile(
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        re.compile(
            # Python line: r"attention|softmax|mamba|flash|bert|gpt|transformer|multihead",
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            r"attention|softmax|mamba|flash|bert|gpt|transformer|multihead",
            # Python line: re.IGNORECASE,
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            re.IGNORECASE,
        # Python line: ),
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        ),
    # Python line: ),
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    ),
    # Python line: (
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    (
        # Python line: "convolution",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "convolution",
        # Python line: re.compile(r"conv|convolution|Conv2d|Conv3d", re.IGNORECASE),
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        re.compile(r"conv|convolution|Conv2d|Conv3d", re.IGNORECASE),
    # Python line: ),
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    ),
    # Python line: (
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    (
        # Python line: "GEMM",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "GEMM",
        # Python line: re.compile(
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        re.compile(
            # Python line: r"matmul|matrix multi|gemm|linear|mm\b|bmm|tensor-matrix",
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            r"matmul|matrix multi|gemm|linear|mm\b|bmm|tensor-matrix",
            # Python line: re.IGNORECASE,
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            re.IGNORECASE,
        # Python line: ),
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        ),
    # Python line: ),
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    ),
    # Python line: (
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    (
        # Python line: "reduction",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "reduction",
        # Python line: re.compile(
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        re.compile(
            # Python line: r"reduce|reduction|sum\b|mean\b|max\b|min\b|norm|loss|hinge|entropy",
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            r"reduce|reduction|sum\b|mean\b|max\b|min\b|norm|loss|hinge|entropy",
            # Python line: re.IGNORECASE,
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            re.IGNORECASE,
        # Python line: ),
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        ),
    # Python line: ),
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    ),
    # Python line: (
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    (
        # Python line: "scan",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "scan",
        # Python line: re.compile(r"scan|prefix|cumsum|cumulative", re.IGNORECASE),
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        re.compile(r"scan|prefix|cumsum|cumulative", re.IGNORECASE),
    # Python line: ),
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    ),
    # Python line: (
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    (
        # Python line: "sorting",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "sorting",
        # Python line: re.compile(r"sort|topk|argsort|ranking", re.IGNORECASE),
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        re.compile(r"sort|topk|argsort|ranking", re.IGNORECASE),
    # Python line: ),
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    ),
    # Python line: (
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    (
        # Python line: "sparse",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "sparse",
        # Python line: re.compile(r"sparse|csr|coo", re.IGNORECASE),
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        re.compile(r"sparse|csr|coo", re.IGNORECASE),
    # Python line: ),
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    ),
# Python line: )
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
)


# Python line: @dataclass(frozen=True)
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
@dataclass(frozen=True)
# Python line: class PromptRecord:
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
class PromptRecord:
    """One prompt row normalized for stratification and downstream merge (§2.4)."""

    # Python line: id: str
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    id: str
    # Python line: source: str
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    source: str
    # Python line: family: str
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    family: str
    # Python line: complexity: str
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    complexity: str
    # Python line: precision: str
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    precision: str
    # Python line: prompt: str
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    prompt: str


# Python line: def _infer_kernelbench_family(*, name: str, prompt: str) -> str:
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
def _infer_kernelbench_family(*, name: str, prompt: str) -> str:
    """Map a KernelBench problem to a kernel-family label via keyword rules."""
    # Concatenate filename and NL prompt so keyword rules see both signals.
    # Python line: haystack = f"{name}\n{prompt}"
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    haystack = f"{name}\n{prompt}"
    # Walk ordered rules; first regex match wins (more specific families first).
    # Python line: for family, pattern in _KB_FAMILY_RULES:
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    for family, pattern in _KB_FAMILY_RULES:
        # Python line: if pattern.search(haystack):
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        if pattern.search(haystack):
            # Python line: return family
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            return family
    # Default bucket for unary/binary elementwise activations and pooling ops.
    # Python line: return "elementwise"
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    return "elementwise"


# Python line: def _load_jsonl(path: Path) -> List[dict]:
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
def _load_jsonl(path: Path) -> List[dict]:
    """Read one JSON object per line from a UTF-8 JSONL file."""
    # Python line: rows: List[dict] = []
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    rows: List[dict] = []
    # Python line: with path.open("r", encoding="utf-8") as handle:
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    with path.open("r", encoding="utf-8") as handle:
        # Python line: for line in handle:
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        for line in handle:
            # Python line: stripped = line.strip()
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            stripped = line.strip()
            # Python line: if stripped:
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            if stripped:
                # Python line: rows.append(json.loads(stripped))
                # stratified split.
                # Implements .cursorrules dense-comment policy for src/ code.
                rows.append(json.loads(stripped))
    # Python line: return rows
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    return rows


# Python line: def load_all_prompt_records(*, repo_root: Path) -> List[PromptRecord]:
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
def load_all_prompt_records(*, repo_root: Path) -> List[PromptRecord]:
    """Load KernelBench + both synthetic JSONL slices into normalized records."""
    # Python line: records: List[PromptRecord] = []
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    records: List[PromptRecord] = []
    # KernelBench index path from .
    # Python line: kb_path = repo_root / "data" / "prompts" / "kernelbench" / "index.jsonl"
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    kb_path = repo_root / "data" / "prompts" / "kernelbench" / "index.jsonl"
    # Python line: for row in _load_jsonl(kb_path):
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    for row in _load_jsonl(kb_path):
        # Python line: level = int(row["level"])
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        level = int(row["level"])
        # Python line: records.append(
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        records.append(
            # Python line: PromptRecord(
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            PromptRecord(
                # Python line: id=str(row["id"]),
                # stratified split.
                # Implements .cursorrules dense-comment policy for src/ code.
                id=str(row["id"]),
                # Python line: source=str(row["source"]),
                # stratified split.
                # Implements .cursorrules dense-comment policy for src/ code.
                source=str(row["source"]),
                # Python line: family=_infer_kernelbench_family(
                # stratified split.
                # Implements .cursorrules dense-comment policy for src/ code.
                family=_infer_kernelbench_family(
                    # Python line: name=str(row.get("name", "")),
                    # stratified split.
                    # Implements .cursorrules dense-comment policy for src/ code.
                    name=str(row.get("name", "")),
                    # Python line: prompt=str(row["prompt"]),
                    # stratified split.
                    # Implements .cursorrules dense-comment policy for src/ code.
                    prompt=str(row["prompt"]),
                # Python line: ),
                # stratified split.
                # Implements .cursorrules dense-comment policy for src/ code.
                ),
                # Python line: complexity=_LEVEL_TO_COMPLEXITY[level],
                # stratified split.
                # Implements .cursorrules dense-comment policy for src/ code.
                complexity=_LEVEL_TO_COMPLEXITY[level],
                # Python line: precision="FP32",
                # stratified split.
                # Implements .cursorrules dense-comment policy for src/ code.
                precision="FP32",
                # Python line: prompt=str(row["prompt"]),
                # stratified split.
                # Implements .cursorrules dense-comment policy for src/ code.
                prompt=str(row["prompt"]),
            # Python line: )
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            )
        # Python line: )
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        )
    # Both synthetic JSONL files share the same on-disk schema.
    # Python line: synthetic_paths = (
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    synthetic_paths = (
        # Python line: repo_root / "data" / "prompts" / "synthetic" / "claude_sonnet5.jsonl",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        repo_root / "data" / "prompts" / "synthetic" / "claude_sonnet5.jsonl",
        # Python line: repo_root / "data" / "prompts" / "synthetic" / "gpt_5_6_terra.jsonl",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        repo_root / "data" / "prompts" / "synthetic" / "gpt_5_6_terra.jsonl",
    # Python line: )
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: for syn_path in synthetic_paths:
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    for syn_path in synthetic_paths:
        # Python line: for row in _load_jsonl(syn_path):
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        for row in _load_jsonl(syn_path):
            # Python line: records.append(
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            records.append(
                # Python line: PromptRecord(
                # stratified split.
                # Implements .cursorrules dense-comment policy for src/ code.
                PromptRecord(
                    # Python line: id=str(row["id"]),
                    # stratified split.
                    # Implements .cursorrules dense-comment policy for src/ code.
                    id=str(row["id"]),
                    # Python line: source=str(row["source"]),
                    # stratified split.
                    # Implements .cursorrules dense-comment policy for src/ code.
                    source=str(row["source"]),
                    # Python line: family=str(row["family"]),
                    # stratified split.
                    # Implements .cursorrules dense-comment policy for src/ code.
                    family=str(row["family"]),
                    # Python line: complexity=str(row["complexity"]),
                    # stratified split.
                    # Implements .cursorrules dense-comment policy for src/ code.
                    complexity=str(row["complexity"]),
                    # Python line: precision=str(row["precision"]),
                    # stratified split.
                    # Implements .cursorrules dense-comment policy for src/ code.
                    precision=str(row["precision"]),
                    # Python line: prompt=str(row["prompt"]),
                    # stratified split.
                    # Implements .cursorrules dense-comment policy for src/ code.
                    prompt=str(row["prompt"]),
                # Python line: )
                # stratified split.
                # Implements .cursorrules dense-comment policy for src/ code.
                )
            # Python line: )
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            )
    # Python line: return records
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    return records


# Python line: def _stratum_key(record: PromptRecord) -> Tuple[str, str, str]:
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
def _stratum_key(record: PromptRecord) -> Tuple[str, str, str]:
    """Return the (source, family, complexity) tuple used for stratification."""
    # Python line: return (record.source, record.family, record.complexity)
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    return (record.source, record.family, record.complexity)


# Python line: def _stratum_shuffle_seed(stratum: Tuple[str, str, str]) -> int:
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
def _stratum_shuffle_seed(stratum: Tuple[str, str, str]) -> int:
    """Derive a deterministic sub-seed for one stratum from SPLIT_SEED."""
    # Python line: payload = f"{SPLIT_SEED}|{stratum[0]}|{stratum[1]}|{stratum[2]}"
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    payload = f"{SPLIT_SEED}|{stratum[0]}|{stratum[1]}|{stratum[2]}"
    # Python line: digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    # Python line: return int(digest[:16], 16)
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    return int(digest[:16], 16)


# Python line: def _hamilton_allocate(
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
def _hamilton_allocate(
    stratum_sizes: Dict[Tuple[str, str, str], int],
    *,
    total_slots: int,
) -> Dict[Tuple[str, str, str], int]:
    """Distribute total_slots across strata proportionally (Hamilton method)."""
    # Python line: if total_slots <= 0:
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    if total_slots <= 0:
        # Python line: return {key: 0 for key in stratum_sizes}
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        return {key: 0 for key in stratum_sizes}
    # Python line: pool = sum(stratum_sizes.values())
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    pool = sum(stratum_sizes.values())
    # Python line: if pool <= 0:
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    if pool <= 0:
        # Python line: return {key: 0 for key in stratum_sizes}
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        return {key: 0 for key in stratum_sizes}
    # Python line: raw = {
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    raw = {
        key: total_slots * size / pool for key, size in stratum_sizes.items()
    }
    # Python line: floors = {key: int(value) for key, value in raw.items()}
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    floors = {key: int(value) for key, value in raw.items()}
    # Python line: assigned = sum(floors.values())
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    assigned = sum(floors.values())
    # Python line: remainder = total_slots - assigned
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    remainder = total_slots - assigned
    # Python line: ranked = sorted(
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    ranked = sorted(
        raw.keys(),
        key=lambda key: (raw[key] - floors[key], key),
        reverse=True,
    )
    # Python line: for key in ranked:
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    for key in ranked:
        # Python line: if remainder <= 0:
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        if remainder <= 0:
            break
        floors[key] += 1
        remainder -= 1
    # Python line: return floors
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    return floors


# Python line: def _split_ids_in_stratum(ids: List[str], *, n: int) -> Tuple[int, int, int]:
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
def _split_counts_for_stratum(n: int) -> Tuple[int, int, int]:
    """Return (n_train, n_val, n_test) for a stratum of size n."""
    # Python line: if n <= 0:
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    if n <= 0:
        # Python line: return 0, 0, 0
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        return 0, 0, 0
    # Singleton strata always land in train (cannot subdivide further).
    # Python line: if n == 1:
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    if n == 1:
        # Python line: return 1, 0, 0
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        return 1, 0, 0
    # Two-item strata: one train, one val (no test without starving train/val).
    # Python line: if n == 2:
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    if n == 2:
        # Python line: return 1, 1, 0
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        return 1, 1, 0
    # Three-item strata: one ID per split to preserve all three buckets.
    # Python line: if n == 3:
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    if n == 3:
        # Python line: return 1, 1, 1
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        return 1, 1, 1
    # Round proportional counts for strata with n >= 4.
    # Python line: n_train = round(TRAIN_FRAC * n)
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    n_train = round(TRAIN_FRAC * n)
    # Python line: n_val = round(VAL_FRAC * n)
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    n_val = round(VAL_FRAC * n)
    # Python line: n_test = n - n_train - n_val
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    n_test = n - n_train - n_val
    # Guarantee at least one test example when the stratum is large enough.
    # Python line: if n_test < 1:
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    if n_test < 1:
        # Python line: if n_train > 1:
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        if n_train > 1:
            # Python line: n_train -= 1
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            n_train -= 1
            # Python line: n_test += 1
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            n_test += 1
        # Python line: elif n_val > 1:
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        elif n_val > 1:
            # Python line: n_val -= 1
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            n_val -= 1
            # Python line: n_test += 1
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            n_test += 1
    # Python line: return n_train, n_val, n_test
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    return n_train, n_val, n_test


# Python line: def stratified_split(
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
def stratified_split(
    records: Iterable[PromptRecord],
) -> Dict[SplitName, List[str]]:
    """Assign each prompt ID to train, val, or test within its stratum."""
    # Bucket records by (source, family, complexity) stratum key.
    # Python line: strata: Dict[Tuple[str, str, str], List[str]] = {}
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    strata: Dict[Tuple[str, str, str], List[str]] = {}
    # Python line: for record in records:
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    for record in records:
        # Python line: key = _stratum_key(record)
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        key = _stratum_key(record)
        # Python line: strata.setdefault(key, []).append(record.id)
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        strata.setdefault(key, []).append(record.id)
    # Global exact targets for 600 prompts at 70/15/15.
    # Python line: total = sum(len(ids) for ids in strata.values())
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    total = sum(len(ids) for ids in strata.values())
    # Python line: n_train_global = round(TRAIN_FRAC * total)
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    n_train_global = round(TRAIN_FRAC * total)
    # Python line: n_val_global = round(VAL_FRAC * total)
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    n_val_global = round(VAL_FRAC * total)
    # Python line: n_test_global = total - n_train_global - n_val_global
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    n_test_global = total - n_train_global - n_val_global
    # Per-stratum sizes for Hamilton quota allocation.
    # Python line: stratum_sizes = {key: len(ids) for key, ids in strata.items()}
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    stratum_sizes = {key: len(ids) for key, ids in strata.items()}
    # Allocate train slots first, then val from remainder, test gets the rest.
    # Python line: train_quota = _hamilton_allocate(stratum_sizes, total_slots=n_train_global)
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    train_quota = _hamilton_allocate(stratum_sizes, total_slots=n_train_global)
    # Python line: remaining_sizes = {
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    remaining_sizes = {
        # Python line: key: stratum_sizes[key] - train_quota[key] for key in stratum_sizes
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
        key: stratum_sizes[key] - train_quota[key] for key in stratum_sizes
    # Python line: }
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    }
    # Python line: val_quota = _hamilton_allocate(remaining_sizes, total_slots=n_val_global)
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    val_quota = _hamilton_allocate(remaining_sizes, total_slots=n_val_global)
    # Accumulate globally sorted ID lists per split name.
    # Python line: train_ids: List[str] = []
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    train_ids: List[str] = []
    # Python line: val_ids: List[str] = []
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    val_ids: List[str] = []
    # Python line: test_ids: List[str] = []
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    test_ids: List[str] = []
    # Process strata in sorted key order for reproducible tie-breaking.
    # Python line: for key in sorted(strata.keys()):
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    for key in sorted(strata.keys()):
        # Python line: ids = sorted(strata[key])
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        ids = sorted(strata[key])
        # Python line: rng = random.Random(_stratum_shuffle_seed(key))
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        rng = random.Random(_stratum_shuffle_seed(key))
        # Python line: rng.shuffle(ids)
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        rng.shuffle(ids)
        # Python line: n_train = train_quota[key]
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        n_train = train_quota[key]
        # Python line: n_val = val_quota[key]
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        n_val = val_quota[key]
        # Python line: n_test = len(ids) - n_train - n_val
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        n_test = len(ids) - n_train - n_val
        # Python line: train_ids.extend(ids[:n_train])
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        train_ids.extend(ids[:n_train])
        # Python line: val_ids.extend(ids[n_train : n_train + n_val])
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        val_ids.extend(ids[n_train : n_train + n_val])
        # Python line: test_ids.extend(ids[n_train + n_val :])
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        test_ids.extend(ids[n_train + n_val :])
    # Return sorted ID lists so split.json diffs are stable across runs.
    # Python line: return {
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    return {
        "train": sorted(train_ids),
        "val": sorted(val_ids),
        "test": sorted(test_ids),
    }


def _kv_sweep_shuffle_seed(
    stratum: Tuple[str, str, str],
    *,
    seed: int,
) -> int:
    """Derive a deterministic per-stratum RNG seed for the KV-cache sweep subset."""
    payload = f"{seed}|kv_cache_sweep|{stratum[0]}|{stratum[1]}|{stratum[2]}"
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    return int(digest[:16], 16)


def stratified_kv_cache_sweep_subset(
    records: Iterable[PromptRecord],
    *,
    total: int = 100,
    seed: int = SPLIT_SEED,
) -> frozenset[str]:
    """Return prompt IDs for the released full 3×3 KV-cache sweep (stratified subset)."""
    strata: Dict[Tuple[str, str, str], List[str]] = {}
    for record in records:
        key = _stratum_key(record)
        strata.setdefault(key, []).append(record.id)

    pool = sum(len(ids) for ids in strata.values())
    if total > pool:
        raise ValueError(
            f"kv_cache_sweep subset size {total} exceeds corpus size {pool}"
        )

    stratum_sizes = {key: len(ids) for key, ids in strata.items()}
    quota = _hamilton_allocate(stratum_sizes, total_slots=total)

    selected: List[str] = []
    leftovers: List[str] = []
    for key in sorted(strata.keys()):
        ids = sorted(strata[key])
        rng = random.Random(_kv_sweep_shuffle_seed(key, seed=seed))
        rng.shuffle(ids)
        take = min(quota.get(key, 0), len(ids))
        selected.extend(ids[:take])
        leftovers.extend(ids[take:])

    if len(selected) < total:
        for pid in leftovers:
            if len(selected) >= total:
                break
            if pid not in selected:
                selected.append(pid)

    if len(selected) > total:
        selected = sorted(selected)[:total]

    return frozenset(selected)


# Python line: def build_split_report(
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
def build_split_report(
    *,
    records: List[PromptRecord],
    splits: Dict[SplitName, List[str]],
) -> str:
    """Render markdown with global and per-stratum split counts."""
    # Reverse map: prompt id -> split label.
    # Python line: id_to_split: Dict[str, SplitName] = {}
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    id_to_split: Dict[str, SplitName] = {}
    # Python line: for split_name, ids in splits.items():
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    for split_name, ids in splits.items():
        # Python line: for prompt_id in ids:
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        for prompt_id in ids:
            # Python line: id_to_split[prompt_id] = split_name
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            id_to_split[prompt_id] = split_name
    # Python line: lines: List[str] = [
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    lines: List[str] = [
        # Python line: "# Stratified split report",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "# Stratified split report",
        # Python line: "",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "",
        # Python line: f"- Seed: **{SPLIT_SEED}**",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        f"- Seed: **{SPLIT_SEED}**",
        # Python line: f"- Ratios: train {TRAIN_FRAC:.0%}, val {VAL_FRAC:.0%}, test {TEST_FRAC:.0%}",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        f"- Ratios: train {TRAIN_FRAC:.0%}, val {VAL_FRAC:.0%}, test {TEST_FRAC:.0%}",
        # Python line: f"- Stratify on: `source` × `family` × `complexity`",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        f"- Stratify on: `source` × `family` × `complexity`",
        # Python line: f"- Total prompts: **{len(records)}**",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        f"- Total prompts: **{len(records)}**",
        # Python line: "",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "",
        # Python line: "## Global split counts",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "## Global split counts",
        # Python line: "",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "",
        # Python line: "| Split | Count | Fraction |",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "| Split | Count | Fraction |",
        # Python line: "|-------|------:|---------:|",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "|-------|------:|---------:|",
    ]
    # Python line: total = len(records)
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    total = len(records)
    # Python line: for split_name in ("train", "val", "test"):
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    for split_name in ("train", "val", "test"):
        # Python line: count = len(splits[split_name])
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        count = len(splits[split_name])
        # Python line: frac = count / total if total else 0.0
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        frac = count / total if total else 0.0
        # Python line: lines.append(f"| {split_name} | {count} | {frac:.1%} |")
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        lines.append(f"| {split_name} | {count} | {frac:.1%} |")
    # Per-stratum table header.
    # Python line: lines.extend(
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    lines.extend(
        [
            # Python line: "",
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            "",
            # Python line: "## Per-stratum counts",
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            "## Per-stratum counts",
            # Python line: "",
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            "",
            # Python line: "| source | family | complexity | train | val | test | total |",
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            "| source | family | complexity | train | val | test | total |",
            # Python line: "|--------|--------|------------|------:|----:|-----:|------:|",
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            "|--------|--------|------------|------:|----:|-----:|------:|",
        ]
    )
    # Tally per-stratum split counts.
    # Python line: stratum_counts: Dict[Tuple[str, str, str], Dict[str, int]] = {}
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    stratum_counts: Dict[Tuple[str, str, str], Dict[str, int]] = {}
    # Python line: for record in records:
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    for record in records:
        # Python line: key = _stratum_key(record)
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        key = _stratum_key(record)
        # Python line: bucket = stratum_counts.setdefault(
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        bucket = stratum_counts.setdefault(
            # Python line: key, {"train": 0, "val": 0, "test": 0, "total": 0}
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
            key, {"train": 0, "val": 0, "test": 0, "total": 0}
        # Python line: )
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        )
        # Python line: split_name = id_to_split[record.id]
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        split_name = id_to_split[record.id]
        # Python line: bucket[split_name] += 1
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        bucket[split_name] += 1
        # Python line: bucket["total"] += 1
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        bucket["total"] += 1
    # Python line: for key in sorted(stratum_counts.keys()):
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    for key in sorted(stratum_counts.keys()):
        # Python line: src, family, complexity = key
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        src, family, complexity = key
        # Python line: counts = stratum_counts[key]
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        counts = stratum_counts[key]
        # Python line: lines.append(
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        lines.append(
            # Python line: f"| {src} | {family} | {complexity} | "
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            f"| {src} | {family} | {complexity} | "
            # Python line: f"{counts['train']} | {counts['val']} | {counts['test']} | {counts['total']} |"
            # stratified split.
            # Implements .cursorrules dense-comment policy for src/ code.
            f"{counts['train']} | {counts['val']} | {counts['test']} | {counts['total']} |"
        # Python line: )
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        )
    # Python line: lines.append("")
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    lines.append("")
    # Python line: return "\n".join(lines)
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    return "\n".join(lines)


# Python line: def write_stratified_split(
# stratified split.
# Implements .cursorrules dense-comment policy for src/ code.
def write_stratified_split(
    *,
    repo_root: Path,
    split_path: Path | None = None,
    report_path: Path | None = None,
) -> Tuple[List[PromptRecord], Dict[SplitName, List[str]]]:
    """Load prompts, stratify-split, and persist data/split.json (+ report)."""
    # Default output path mandated by the execution guide.
    # Python line: if split_path is None:
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    if split_path is None:
        # Python line: split_path = repo_root / "data" / "split.json"
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        split_path = repo_root / "data" / "split.json"
    # Optional markdown report for human verification (used in overview).
    # Python line: if report_path is None:
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    if report_path is None:
        # Python line: report_path = repo_root / "data" / "split_report.md"
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        report_path = repo_root / "data" / "split_report.md"
    # Load all 600 prompt rows from the three slices.
    # Python line: records = load_all_prompt_records(repo_root=repo_root)
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    records = load_all_prompt_records(repo_root=repo_root)
    # Python line: splits = stratified_split(records)
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    splits = stratified_split(records)
    # Build JSON payload with metadata and ID lists.
    # Python line: payload = {
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    payload = {
        # Python line: "seed": SPLIT_SEED,
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "seed": SPLIT_SEED,
        # Python line: "train_fraction": TRAIN_FRAC,
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "train_fraction": TRAIN_FRAC,
        # Python line: "val_fraction": VAL_FRAC,
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "val_fraction": VAL_FRAC,
        # Python line: "test_fraction": TEST_FRAC,
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "test_fraction": TEST_FRAC,
        # Python line: "stratify_on": ["source", "family", "complexity"],
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "stratify_on": ["source", "family", "complexity"],
        # Python line: "total": len(records),
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "total": len(records),
        # Python line: "train": splits["train"],
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "train": splits["train"],
        # Python line: "val": splits["val"],
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "val": splits["val"],
        # Python line: "test": splits["test"],
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        "test": splits["test"],
    # Python line: }
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    }
    # Python line: split_path.parent.mkdir(parents=True, exist_ok=True)
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    split_path.parent.mkdir(parents=True, exist_ok=True)
    # Python line: split_path.write_text(
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    split_path.write_text(
        # Python line: json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
        # Python line: encoding="utf-8",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        encoding="utf-8",
    # Python line: )
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: report_path.write_text(
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    report_path.write_text(
        # Python line: build_split_report(records=records, splits=splits),
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        build_split_report(records=records, splits=splits),
        # Python line: encoding="utf-8",
        # stratified split.
        # Implements .cursorrules dense-comment policy for src/ code.
        encoding="utf-8",
    # Python line: )
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: return records, splits
    # stratified split.
    # Implements .cursorrules dense-comment policy for src/ code.
    return records, splits


# Python line: def load_splits_from_json(split_path: Path) -> Dict[SplitName, List[str]]:
# merged prompt corpus.
# Implements .cursorrules dense-comment policy for src/ code.
def load_splits_from_json(split_path: Path) -> Dict[SplitName, List[str]]:
    """Load train/val/test ID lists from an existing data/split.json file."""
    # Python line: payload = json.loads(split_path.read_text(encoding="utf-8"))
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    payload = json.loads(split_path.read_text(encoding="utf-8"))
    # Python line: return {
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    return {
        # Python line: "train": list(payload["train"]),
        # merged prompt corpus.
        # Implements .cursorrules dense-comment policy for src/ code.
        "train": list(payload["train"]),
        # Python line: "val": list(payload["val"]),
        # merged prompt corpus.
        # Implements .cursorrules dense-comment policy for src/ code.
        "val": list(payload["val"]),
        # Python line: "test": list(payload["test"]),
        # merged prompt corpus.
        # Implements .cursorrules dense-comment policy for src/ code.
        "test": list(payload["test"]),
    # Python line: }
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    }


# Python line: def _splits_to_id_map(splits: Dict[SplitName, List[str]]) -> Dict[str, SplitName]:
# merged prompt corpus.
# Implements .cursorrules dense-comment policy for src/ code.
def _splits_to_id_map(splits: Dict[SplitName, List[str]]) -> Dict[str, SplitName]:
    """Invert split-name → ID lists into prompt-id → split label."""
    # Python line: id_to_split: Dict[str, SplitName] = {}
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    id_to_split: Dict[str, SplitName] = {}
    # Python line: for split_name, ids in splits.items():
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    for split_name, ids in splits.items():
        # Python line: for prompt_id in ids:
        # merged prompt corpus.
        # Implements .cursorrules dense-comment policy for src/ code.
        for prompt_id in ids:
            # Python line: id_to_split[prompt_id] = split_name
            # merged prompt corpus.
            # Implements .cursorrules dense-comment policy for src/ code.
            id_to_split[prompt_id] = split_name
    # Python line: return id_to_split
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    return id_to_split


# Python line: def write_all_prompts_jsonl(
# merged prompt corpus.
# Implements .cursorrules dense-comment policy for src/ code.
def write_all_prompts_jsonl(
    *,
    records: List[PromptRecord],
    splits: Dict[SplitName, List[str]],
    output_path: Path,
) -> int:
    """Write data/prompts/all.jsonl with the schema (600 rows)."""
    # Python line: id_to_split = _splits_to_id_map(splits)
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    id_to_split = _splits_to_id_map(splits)
    # Python line: output_path.parent.mkdir(parents=True, exist_ok=True)
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    output_path.parent.mkdir(parents=True, exist_ok=True)
    # Python line: ordered = sorted(records, key=lambda rec: rec.id)
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    ordered = sorted(records, key=lambda rec: rec.id)
    # Python line: with output_path.open("w", encoding="utf-8") as handle:
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    with output_path.open("w", encoding="utf-8") as handle:
        # Python line: for record in ordered:
        # merged prompt corpus.
        # Implements .cursorrules dense-comment policy for src/ code.
        for record in ordered:
            # Python line: if record.id not in id_to_split:
            # merged prompt corpus.
            # Implements .cursorrules dense-comment policy for src/ code.
            if record.id not in id_to_split:
                # Python line: raise KeyError(f"Prompt id missing from split.json: {record.id}")
                # merged prompt corpus.
                # Implements .cursorrules dense-comment policy for src/ code.
                raise KeyError(f"Prompt id missing from split.json: {record.id}")
            # Python line: row = {
            # merged prompt corpus.
            # Implements .cursorrules dense-comment policy for src/ code.
            row = {
                # Python line: "id": record.id,
                # merged prompt corpus.
                # Implements .cursorrules dense-comment policy for src/ code.
                "id": record.id,
                # Python line: "source": record.source,
                # merged prompt corpus.
                # Implements .cursorrules dense-comment policy for src/ code.
                "source": record.source,
                # Python line: "family": record.family,
                # merged prompt corpus.
                # Implements .cursorrules dense-comment policy for src/ code.
                "family": record.family,
                # Python line: "complexity": record.complexity,
                # merged prompt corpus.
                # Implements .cursorrules dense-comment policy for src/ code.
                "complexity": record.complexity,
                # Python line: "precision": record.precision,
                # merged prompt corpus.
                # Implements .cursorrules dense-comment policy for src/ code.
                "precision": record.precision,
                # Python line: "prompt": record.prompt,
                # merged prompt corpus.
                # Implements .cursorrules dense-comment policy for src/ code.
                "prompt": record.prompt,
                # Python line: "split": id_to_split[record.id],
                # merged prompt corpus.
                # Implements .cursorrules dense-comment policy for src/ code.
                "split": id_to_split[record.id],
            # Python line: }
            # merged prompt corpus.
            # Implements .cursorrules dense-comment policy for src/ code.
            }
            # Python line: handle.write(json.dumps(row, ensure_ascii=False) + "\n")
            # merged prompt corpus.
            # Implements .cursorrules dense-comment policy for src/ code.
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    # Python line: return len(ordered)
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    return len(ordered)


# Python line: def build_phase2_deliverable(
# merged prompt corpus.
# Implements .cursorrules dense-comment policy for src/ code.
def build_phase2_deliverable(
    *,
    repo_root: Path,
    split_path: Path | None = None,
    all_path: Path | None = None,
    report_path: Path | None = None,
) -> Tuple[List[PromptRecord], Dict[SplitName, List[str]], Path]:
    """: merge prompts + splits into all.jsonl and refresh split_report.md."""
    # Python line: if split_path is None:
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    if split_path is None:
        # Python line: split_path = repo_root / "data" / "split.json"
        # merged prompt corpus.
        # Implements .cursorrules dense-comment policy for src/ code.
        split_path = repo_root / "data" / "split.json"
    # Python line: if all_path is None:
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    if all_path is None:
        # Python line: all_path = repo_root / "data" / "prompts" / "all.jsonl"
        # merged prompt corpus.
        # Implements .cursorrules dense-comment policy for src/ code.
        all_path = repo_root / "data" / "prompts" / "all.jsonl"
    # Python line: if report_path is None:
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    if report_path is None:
        # Python line: report_path = repo_root / "data" / "split_report.md"
        # merged prompt corpus.
        # Implements .cursorrules dense-comment policy for src/ code.
        report_path = repo_root / "data" / "split_report.md"
    # Python line: records = load_all_prompt_records(repo_root=repo_root)
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    records = load_all_prompt_records(repo_root=repo_root)
    # Reuse existing split.json when present; otherwise run §2.3 first.
    # Python line: if split_path.exists():
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    if split_path.exists():
        # Python line: splits = load_splits_from_json(split_path)
        # merged prompt corpus.
        # Implements .cursorrules dense-comment policy for src/ code.
        splits = load_splits_from_json(split_path)
    # Python line: else:
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    else:
        # Python line: records, splits = write_stratified_split(
        # merged prompt corpus.
        # Implements .cursorrules dense-comment policy for src/ code.
        records, splits = write_stratified_split(
            # Python line: repo_root=repo_root,
            # merged prompt corpus.
            # Implements .cursorrules dense-comment policy for src/ code.
            repo_root=repo_root,
            # Python line: split_path=split_path,
            # merged prompt corpus.
            # Implements .cursorrules dense-comment policy for src/ code.
            split_path=split_path,
            # Python line: report_path=report_path,
            # merged prompt corpus.
            # Implements .cursorrules dense-comment policy for src/ code.
            report_path=report_path,
        # Python line: )
        # merged prompt corpus.
        # Implements .cursorrules dense-comment policy for src/ code.
        )
    # Python line: row_count = write_all_prompts_jsonl(
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    row_count = write_all_prompts_jsonl(
        # Python line: records=records,
        # merged prompt corpus.
        # Implements .cursorrules dense-comment policy for src/ code.
        records=records,
        # Python line: splits=splits,
        # merged prompt corpus.
        # Implements .cursorrules dense-comment policy for src/ code.
        splits=splits,
        # Python line: output_path=all_path,
        # merged prompt corpus.
        # Implements .cursorrules dense-comment policy for src/ code.
        output_path=all_path,
    # Python line: )
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: if row_count != 600:
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    if row_count != 600:
        # Python line: raise RuntimeError(f"Expected 600 rows in all.jsonl, got {row_count}")
        # merged prompt corpus.
        # Implements .cursorrules dense-comment policy for src/ code.
        raise RuntimeError(f"Expected 600 rows in all.jsonl, got {row_count}")
    # Refresh split_report.md (per-strata counts are the report).
    # Python line: report_path.write_text(
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    report_path.write_text(
        # Python line: build_split_report(records=records, splits=splits),
        # merged prompt corpus.
        # Implements .cursorrules dense-comment policy for src/ code.
        build_split_report(records=records, splits=splits),
        # Python line: encoding="utf-8",
        # merged prompt corpus.
        # Implements .cursorrules dense-comment policy for src/ code.
        encoding="utf-8",
    # Python line: )
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: return records, splits, all_path
    # merged prompt corpus.
    # Implements .cursorrules dense-comment policy for src/ code.
    return records, splits, all_path
