"""
Extract KernelBench natural-language prompts and store reference code separately.

Phase 2.1: pull ScalingIntelligence/KernelBench (MIT) and write AgentK prompts
from docstrings only; PyTorch reference code is persisted for later correctness checks.
"""

# Python line: from __future__ import annotations
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
from __future__ import annotations

# ast parses KernelBench reference PyTorch modules for docstring extraction.
# Python line: import ast
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
import ast
# json serializes index.jsonl rows produced by the builder.
# Python line: import json
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
import json
# re humanizes filenames when a problem has no docstrings (e.g. level 4).
# Python line: import re
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
import re
# dataclass holds one normalized KernelBench row in memory before JSONL write.
# Python line: from dataclasses import dataclass
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
from dataclasses import dataclass
# Path joins output directories under data/prompts/kernelbench/.
# Python line: from pathlib import Path
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
from pathlib import Path
# Any used for HuggingFace dataset row typing without importing datasets here.
# Python line: from typing import Any, Iterator
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
from typing import Any, Iterator


# KernelBench ships four levels on HuggingFace as separate dataset splits.
# Python line: _LEVEL_SPLITS: tuple[str, ...] = ("level_1", "level_2", "level_3", "level_4")
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
_LEVEL_SPLITS: tuple[str, ...] = ("level_1", "level_2", "level_3", "level_4")
# Map HF split suffix to integer level id stored in index.jsonl metadata.
# Python line: _SPLIT_TO_LEVEL: dict[str, int] = {
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
_SPLIT_TO_LEVEL: dict[str, int] = {
    # Python line: "level_1": 1,
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    "level_1": 1,
    # Python line: "level_2": 2,
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    "level_2": 2,
    # Python line: "level_3": 3,
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    "level_3": 3,
    # Python line: "level_4": 4,
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    "level_4": 4,
# Python line: }
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
}


# Python line: @dataclass(frozen=True)
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
@dataclass(frozen=True)
# Python line: class KernelBenchRecord:
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
class KernelBenchRecord:
    """One KernelBench problem after NL extraction and reference path assignment."""

    # Stable id used across tracing and correctness harness joins.
    # Python line: id: str
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    id: str
    # Constant source tag for Phase 2 schema compatibility.
    # Python line: source: str
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    source: str
    # KernelBench level integer in {1,2,3,4}.
    # Python line: level: int
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    level: int
    # 1-indexed problem_id from the upstream dataset.
    # Python line: problem_id: int
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    problem_id: int
    # Original KernelBench filename, e.g. 1_Square_matrix_multiplication_.py.
    # Python line: name: str
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    name: str
    # Natural-language prompt passed to AgentK (no reference PyTorch code).
    # Python line: prompt: str
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    prompt: str
    # Repo-relative path where reference PyTorch code is stored on disk.
    # Python line: reference_path: str
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    reference_path: str
    # Upstream license string recorded for reproducibility statements.
    # Python line: license: str
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    license: str


# Python line: def _humanize_name(name: str) -> str:
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
def _humanize_name(name: str) -> str:
    """Convert a KernelBench filename stem into readable text when docstrings are absent."""
    # Strip the .py extension so we only humanize the descriptive portion.
    # Python line: stem = name[:-3] if name.endswith(".py") else name
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    stem = name[:-3] if name.endswith(".py") else name
    # Drop the numeric prefix (problem_id_) when present in KernelBench filenames.
    # Python line: if "_" in stem and stem.split("_", 1)[0].isdigit():
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    if "_" in stem and stem.split("_", 1)[0].isdigit():
        # Python line: stem = stem.split("_", 1)[1]
        # KernelBench Phase 2.1 prompt extraction (src/prompts).
        # Implements .cursorrules dense-comment policy for src/ code.
        stem = stem.split("_", 1)[1]
    # Replace underscores with spaces for a plain-language fallback title.
    # Python line: text = stem.replace("_", " ").strip()
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    text = stem.replace("_", " ").strip()
    # Collapse repeated whitespace so fallback prompts are single-spaced.
    # Python line: text = re.sub(r"\s+", " ", text)
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    text = re.sub(r"\s+", " ", text)
    # Return the fallback natural-language label for docstring-less problems.
    # Python line: return text
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    return text


# Python line: def extract_natural_language_prompt(code: str, name: str) -> str:
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
def extract_natural_language_prompt(code: str, name: str) -> str:
    """
    Extract natural-language problem text from a KernelBench reference module.

    Uses class/method docstrings on ``Model``; falls back to a humanized filename.
    """
    # Accumulate docstring fragments in encounter order for deterministic prompts.
    # Python line: parts: list[str] = []
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    parts: list[str] = []
    # Parse the reference module; on syntax failure use filename fallback only.
    # Python line: try:
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    try:
        # Python line: tree = ast.parse(code)
        # KernelBench Phase 2.1 prompt extraction (src/prompts).
        # Implements .cursorrules dense-comment policy for src/ code.
        tree = ast.parse(code)
    # Python line: except SyntaxError:
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    except SyntaxError:
        # Python line: return _humanize_name(name)
        # KernelBench Phase 2.1 prompt extraction (src/prompts).
        # Implements .cursorrules dense-comment policy for src/ code.
        return _humanize_name(name)
    # Walk AST nodes and collect docstrings attached to Model and its methods.
    # Python line: for node in ast.walk(tree):
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    for node in ast.walk(tree):
        # Python line: if not isinstance(node, ast.ClassDef):
        # KernelBench Phase 2.1 prompt extraction (src/prompts).
        # Implements .cursorrules dense-comment policy for src/ code.
        if not isinstance(node, ast.ClassDef):
            # Python line: continue
            # KernelBench Phase 2.1 prompt extraction (src/prompts).
            # Implements .cursorrules dense-comment policy for src/ code.
            continue
        # Python line: if node.name != "Model":
        # KernelBench Phase 2.1 prompt extraction (src/prompts).
        # Implements .cursorrules dense-comment policy for src/ code.
        if node.name != "Model":
            # Python line: continue
            # KernelBench Phase 2.1 prompt extraction (src/prompts).
            # Implements .cursorrules dense-comment policy for src/ code.
            continue
        # Prefer the class-level docstring when KernelBench authors provided one.
        # Python line: class_doc = ast.get_docstring(node)
        # KernelBench Phase 2.1 prompt extraction (src/prompts).
        # Implements .cursorrules dense-comment policy for src/ code.
        class_doc = ast.get_docstring(node)
        # Python line: if class_doc:
        # KernelBench Phase 2.1 prompt extraction (src/prompts).
        # Implements .cursorrules dense-comment policy for src/ code.
        if class_doc:
            # Python line: parts.append(class_doc.strip())
            # KernelBench Phase 2.1 prompt extraction (src/prompts).
            # Implements .cursorrules dense-comment policy for src/ code.
            parts.append(class_doc.strip())
        # Also include method docstrings (__init__, forward, etc.) on Model.
        # Python line: for item in node.body:
        # KernelBench Phase 2.1 prompt extraction (src/prompts).
        # Implements .cursorrules dense-comment policy for src/ code.
        for item in node.body:
            # Python line: if not isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
            # KernelBench Phase 2.1 prompt extraction (src/prompts).
            # Implements .cursorrules dense-comment policy for src/ code.
            if not isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                # Python line: continue
                # KernelBench Phase 2.1 prompt extraction (src/prompts).
                # Implements .cursorrules dense-comment policy for src/ code.
                continue
            # Python line: method_doc = ast.get_docstring(item)
            # KernelBench Phase 2.1 prompt extraction (src/prompts).
            # Implements .cursorrules dense-comment policy for src/ code.
            method_doc = ast.get_docstring(item)
            # Python line: if method_doc:
            # KernelBench Phase 2.1 prompt extraction (src/prompts).
            # Implements .cursorrules dense-comment policy for src/ code.
            if method_doc:
                # Python line: parts.append(method_doc.strip())
                # KernelBench Phase 2.1 prompt extraction (src/prompts).
                # Implements .cursorrules dense-comment policy for src/ code.
                parts.append(method_doc.strip())
    # If any docstrings were found, join them into one AgentK prompt body.
    # Python line: if parts:
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    if parts:
        # Python line: return "\n\n".join(parts)
        # KernelBench Phase 2.1 prompt extraction (src/prompts).
        # Implements .cursorrules dense-comment policy for src/ code.
        return "\n\n".join(parts)
    # Otherwise return a filename-derived description (common for level 4).
    # Python line: return _humanize_name(name)
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    return _humanize_name(name)


# Python line: def _make_prompt_id(level: int, problem_id: int) -> str:
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
def _make_prompt_id(level: int, problem_id: int) -> str:
    """Build a stable prompt id: kbench-l{level}-{problem_id:03d}."""
    # Python line: return f"kbench-l{level}-{problem_id:03d}"
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    return f"kbench-l{level}-{problem_id:03d}"


# Python line: def iter_kernelbench_records(
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
def iter_kernelbench_records(
    # Python line: *,
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    *,
    # Python line: dataset_rows: Iterator[dict[str, Any]],
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    dataset_rows: Iterator[dict[str, Any]],
    # Python line: level: int,
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    level: int,
    # Python line: reference_root: Path,
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    reference_root: Path,
    # Python line: repo_root: Path,
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    repo_root: Path,
# Python line: ) -> Iterator[KernelBenchRecord]:
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
) -> Iterator[KernelBenchRecord]:
    """
    Yield KernelBenchRecord objects for one level split.

    ``dataset_rows`` must provide keys: code, name, problem_id.
    """
    # Ensure reference output directory exists for this KernelBench level.
    # Python line: level_dir = reference_root / f"level{level}"
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    level_dir = reference_root / f"level{level}"
    # Python line: level_dir.mkdir(parents=True, exist_ok=True)
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    level_dir.mkdir(parents=True, exist_ok=True)
    # Iterate each HuggingFace row and emit one record per problem.
    # Python line: for row in dataset_rows:
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    for row in dataset_rows:
        # Read upstream identifiers and reference source from the dataset row.
        # Python line: problem_id = int(row["problem_id"])
        # KernelBench Phase 2.1 prompt extraction (src/prompts).
        # Implements .cursorrules dense-comment policy for src/ code.
        problem_id = int(row["problem_id"])
        # Python line: name = str(row["name"])
        # KernelBench Phase 2.1 prompt extraction (src/prompts).
        # Implements .cursorrules dense-comment policy for src/ code.
        name = str(row["name"])
        # HuggingFace rows omit the .py suffix; normalize to upstream repo filenames.
        if not name.endswith(".py"):
            name = f"{name}.py"
        # Python line: code = str(row["code"])
        # KernelBench Phase 2.1 prompt extraction (src/prompts).
        # Implements .cursorrules dense-comment policy for src/ code.
        code = str(row["code"])
        # Extract NL-only prompt text; discard code from the KC-facing prompt field.
        # Python line: prompt = extract_natural_language_prompt(code, name)
        # KernelBench Phase 2.1 prompt extraction (src/prompts).
        # Implements .cursorrules dense-comment policy for src/ code.
        prompt = extract_natural_language_prompt(code, name)
        # Persist reference PyTorch solution for Phase 3.5 numerical correctness only.
        # Python line: ref_path = level_dir / name
        # KernelBench Phase 2.1 prompt extraction (src/prompts).
        # Implements .cursorrules dense-comment policy for src/ code.
        ref_path = level_dir / name
        # Python line: ref_path.write_text(code, encoding="utf-8")
        # KernelBench Phase 2.1 prompt extraction (src/prompts).
        # Implements .cursorrules dense-comment policy for src/ code.
        ref_path.write_text(code, encoding="utf-8")
        # Store repo-relative reference path in the index for downstream harness code.
        # Python line: rel_ref = ref_path.relative_to(repo_root).as_posix()
        # KernelBench Phase 2.1 prompt extraction (src/prompts).
        # Implements .cursorrules dense-comment policy for src/ code.
        rel_ref = ref_path.relative_to(repo_root).as_posix()
        # Yield the normalized record for JSONL serialization.
        # Python line: yield KernelBenchRecord(
        # KernelBench Phase 2.1 prompt extraction (src/prompts).
        # Implements .cursorrules dense-comment policy for src/ code.
        yield KernelBenchRecord(
            # Python line: id=_make_prompt_id(level, problem_id),
            # KernelBench Phase 2.1 prompt extraction (src/prompts).
            # Implements .cursorrules dense-comment policy for src/ code.
            id=_make_prompt_id(level, problem_id),
            # Python line: source="kernelbench",
            # KernelBench Phase 2.1 prompt extraction (src/prompts).
            # Implements .cursorrules dense-comment policy for src/ code.
            source="kernelbench",
            # Python line: level=level,
            # KernelBench Phase 2.1 prompt extraction (src/prompts).
            # Implements .cursorrules dense-comment policy for src/ code.
            level=level,
            # Python line: problem_id=problem_id,
            # KernelBench Phase 2.1 prompt extraction (src/prompts).
            # Implements .cursorrules dense-comment policy for src/ code.
            problem_id=problem_id,
            # Python line: name=name,
            # KernelBench Phase 2.1 prompt extraction (src/prompts).
            # Implements .cursorrules dense-comment policy for src/ code.
            name=name,
            # Python line: prompt=prompt,
            # KernelBench Phase 2.1 prompt extraction (src/prompts).
            # Implements .cursorrules dense-comment policy for src/ code.
            prompt=prompt,
            # Python line: reference_path=rel_ref,
            # KernelBench Phase 2.1 prompt extraction (src/prompts).
            # Implements .cursorrules dense-comment policy for src/ code.
            reference_path=rel_ref,
            # Python line: license="MIT",
            # KernelBench Phase 2.1 prompt extraction (src/prompts).
            # Implements .cursorrules dense-comment policy for src/ code.
            license="MIT",
        # Python line: )
        # KernelBench Phase 2.1 prompt extraction (src/prompts).
        # Implements .cursorrules dense-comment policy for src/ code.
        )


# Python line: def load_kernelbench_dataset():
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
def load_kernelbench_dataset():
    """Load ScalingIntelligence/KernelBench from HuggingFace (all four level splits)."""
    # Import datasets lazily so non-prompt scripts avoid the HF dependency at import time.
    # Python line: from datasets import load_dataset
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    from datasets import load_dataset

    # Return the DatasetDict with level_1..level_4 splits (270 rows total).
    # Python line: return load_dataset("ScalingIntelligence/KernelBench")
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    return load_dataset("ScalingIntelligence/KernelBench")


# Python line: def build_kernelbench_index(
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
def build_kernelbench_index(
    # Python line: *,
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    *,
    # Python line: repo_root: Path,
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    repo_root: Path,
    # Python line: output_index: Path,
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    output_index: Path,
    # Python line: reference_root: Path,
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    reference_root: Path,
# Python line: ) -> list[KernelBenchRecord]:
# KernelBench Phase 2.1 prompt extraction (src/prompts).
# Implements .cursorrules dense-comment policy for src/ code.
) -> list[KernelBenchRecord]:
    """
    Pull all 270 KernelBench problems and write index + reference code files.

    Returns the in-memory list of records for reporting and tests.
    """
    # Load the upstream KernelBench dataset from HuggingFace.
    # Python line: dataset = load_kernelbench_dataset()
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    dataset = load_kernelbench_dataset()
    # Parent-create the JSONL output directory if the user passed a nested path.
    # Python line: output_index.parent.mkdir(parents=True, exist_ok=True)
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    output_index.parent.mkdir(parents=True, exist_ok=True)
    # Collect all records across levels before writing the JSONL index file.
    # Python line: all_records: list[KernelBenchRecord] = []
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    all_records: list[KernelBenchRecord] = []
    # Open the index JSONL once and append one JSON object per problem.
    # Python line: with output_index.open("w", encoding="utf-8") as out_f:
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    with output_index.open("w", encoding="utf-8") as out_f:
        # Process each level split in fixed order for reproducible file ordering.
        # Python line: for split in _LEVEL_SPLITS:
        # KernelBench Phase 2.1 prompt extraction (src/prompts).
        # Implements .cursorrules dense-comment policy for src/ code.
        for split in _LEVEL_SPLITS:
            # Map split name to integer level id used in prompt ids and folders.
            # Python line: level = _SPLIT_TO_LEVEL[split]
            # KernelBench Phase 2.1 prompt extraction (src/prompts).
            # Implements .cursorrules dense-comment policy for src/ code.
            level = _SPLIT_TO_LEVEL[split]
            # Convert the HF Dataset split to plain dict rows for the iterator helper.
            # Python line: rows = (dict(row) for row in dataset[split])
            # KernelBench Phase 2.1 prompt extraction (src/prompts).
            # Implements .cursorrules dense-comment policy for src/ code.
            rows = (dict(row) for row in dataset[split])
            # Build records for this level, writing reference .py files to disk.
            # Python line: for record in iter_kernelbench_records(
            # KernelBench Phase 2.1 prompt extraction (src/prompts).
            # Implements .cursorrules dense-comment policy for src/ code.
            for record in iter_kernelbench_records(
                # Python line: dataset_rows=rows,
                # KernelBench Phase 2.1 prompt extraction (src/prompts).
                # Implements .cursorrules dense-comment policy for src/ code.
                dataset_rows=rows,
                # Python line: level=level,
                # KernelBench Phase 2.1 prompt extraction (src/prompts).
                # Implements .cursorrules dense-comment policy for src/ code.
                level=level,
                # Python line: reference_root=reference_root,
                # KernelBench Phase 2.1 prompt extraction (src/prompts).
                # Implements .cursorrules dense-comment policy for src/ code.
                reference_root=reference_root,
                # Python line: repo_root=repo_root,
                # KernelBench Phase 2.1 prompt extraction (src/prompts).
                # Implements .cursorrules dense-comment policy for src/ code.
                repo_root=repo_root,
            # Python line: ):
            # KernelBench Phase 2.1 prompt extraction (src/prompts).
            # Implements .cursorrules dense-comment policy for src/ code.
            ):
                # Append to the aggregate list for count verification (expect 270).
                # Python line: all_records.append(record)
                # KernelBench Phase 2.1 prompt extraction (src/prompts).
                # Implements .cursorrules dense-comment policy for src/ code.
                all_records.append(record)
                # Serialize one index row; prompt only, not reference code body.
                # Python line: out_f.write(
                # KernelBench Phase 2.1 prompt extraction (src/prompts).
                # Implements .cursorrules dense-comment policy for src/ code.
                out_f.write(
                    # Python line: json.dumps(
                    # KernelBench Phase 2.1 prompt extraction (src/prompts).
                    # Implements .cursorrules dense-comment policy for src/ code.
                    json.dumps(
                        # Python line: {
                        # KernelBench Phase 2.1 prompt extraction (src/prompts).
                        # Implements .cursorrules dense-comment policy for src/ code.
                        {
                            # Python line: "id": record.id,
                            # KernelBench Phase 2.1 prompt extraction (src/prompts).
                            # Implements .cursorrules dense-comment policy for src/ code.
                            "id": record.id,
                            # Python line: "source": record.source,
                            # KernelBench Phase 2.1 prompt extraction (src/prompts).
                            # Implements .cursorrules dense-comment policy for src/ code.
                            "source": record.source,
                            # Python line: "level": record.level,
                            # KernelBench Phase 2.1 prompt extraction (src/prompts).
                            # Implements .cursorrules dense-comment policy for src/ code.
                            "level": record.level,
                            # Python line: "problem_id": record.problem_id,
                            # KernelBench Phase 2.1 prompt extraction (src/prompts).
                            # Implements .cursorrules dense-comment policy for src/ code.
                            "problem_id": record.problem_id,
                            # Python line: "name": record.name,
                            # KernelBench Phase 2.1 prompt extraction (src/prompts).
                            # Implements .cursorrules dense-comment policy for src/ code.
                            "name": record.name,
                            # Python line: "prompt": record.prompt,
                            # KernelBench Phase 2.1 prompt extraction (src/prompts).
                            # Implements .cursorrules dense-comment policy for src/ code.
                            "prompt": record.prompt,
                            # Python line: "reference_path": record.reference_path,
                            # KernelBench Phase 2.1 prompt extraction (src/prompts).
                            # Implements .cursorrules dense-comment policy for src/ code.
                            "reference_path": record.reference_path,
                            # Python line: "license": record.license,
                            # KernelBench Phase 2.1 prompt extraction (src/prompts).
                            # Implements .cursorrules dense-comment policy for src/ code.
                            "license": record.license,
                        # Python line: },
                        # KernelBench Phase 2.1 prompt extraction (src/prompts).
                        # Implements .cursorrules dense-comment policy for src/ code.
                        },
                        # Python line: ensure_ascii=False,
                        # KernelBench Phase 2.1 prompt extraction (src/prompts).
                        # Implements .cursorrules dense-comment policy for src/ code.
                        ensure_ascii=False,
                    # Python line: )
                    # KernelBench Phase 2.1 prompt extraction (src/prompts).
                    # Implements .cursorrules dense-comment policy for src/ code.
                    )
                    # Python line: + "\n"
                    # KernelBench Phase 2.1 prompt extraction (src/prompts).
                    # Implements .cursorrules dense-comment policy for src/ code.
                    + "\n"
                # Python line: )
                # KernelBench Phase 2.1 prompt extraction (src/prompts).
                # Implements .cursorrules dense-comment policy for src/ code.
                )
    # Return records so callers can assert counts and write summary reports.
    # Python line: return all_records
    # KernelBench Phase 2.1 prompt extraction (src/prompts).
    # Implements .cursorrules dense-comment policy for src/ code.
    return all_records
