"""
Build the configured VRAM sampler (pynvml primary, nvidia-smi Tier-1 fallback).
"""

from __future__ import annotations

# Any covers both sampler implementations with identical duck-typed methods.
from typing import Any, Dict, Optional, Set

# NvidiaSmiVramSampler implements F1 tier-1 subprocess polling + post-hoc join.
from src.tracing.nvidia_smi_sampler import NvidiaSmiVramSampler
# VramSampler is the default in-process pynvml poller from Phase 3.1.
from src.tracing.vram_sampler import VramSampler, resolve_vram_interval_ms


def build_vram_sampler(
    vram_cfg: Dict[str, Any],
    *,
    device_index: int = 0,
    prompt_id: Optional[str] = None,
    diagnostic_prompt_ids: Optional[Set[str]] = None,
) -> Any:
    """
    Instantiate a VRAM sampler from ``configs/tracing.yaml`` → ``vram_sampling``.

    ``method`` may be ``pynvml``, ``nvidia_smi``, or ``auto`` (try pynvml, else nvidia-smi).

    When ``diagnostic_subset_size`` is configured (v2), pass ``prompt_id`` and the
    precomputed ``diagnostic_prompt_ids`` set to select per-run poll cadence.
    """
    interval_ms = resolve_vram_interval_ms(
        vram_cfg,
        prompt_id=prompt_id,
        diagnostic_prompt_ids=diagnostic_prompt_ids,
    )
    method = str(vram_cfg.get("method", "pynvml")).strip().lower()
    fallback = str(vram_cfg.get("fallback_method", "nvidia_smi")).strip().lower()

    if method == "auto":
        if _pynvml_available(device_index):
            method = "pynvml"
        else:
            method = fallback

    if method == "nvidia_smi":
        return NvidiaSmiVramSampler(interval_ms=interval_ms, device_index=device_index)

    if method == "pynvml":
        try:
            return VramSampler(interval_ms=interval_ms, device_index=device_index)
        except Exception:
            if fallback == "nvidia_smi":
                return NvidiaSmiVramSampler(interval_ms=interval_ms, device_index=device_index)
            raise

    raise ValueError(f"Unknown vram_sampling.method={method!r} (expected pynvml|nvidia_smi|auto)")


def _pynvml_available(device_index: int) -> bool:
    """Return True when NVML can be initialized for ``device_index``."""
    try:
        import pynvml

        pynvml.nvmlInit()
        pynvml.nvmlDeviceGetHandleByIndex(device_index)
        return True
    except Exception:
        return False
