"""
F1 Tier-1 VRAM sampler — subprocess ``nvidia-smi -lms`` log joined post-hoc by wall-clock.

No in-process NVML polling; node boundaries record wall epoch only, then VRAM is
looked up from the sidecar CSV when ``stop()`` finalizes the run.
"""

from __future__ import annotations

# shutil copies the raw sidecar CSV beside the trace JSONL when requested.
import shutil
# subprocess launches the ``nvidia-smi`` polling loop outside Python.
import subprocess
# tempfile holds the raw CSV until post-hoc join at ``stop()``.
import tempfile
# time records wall-clock anchors for boundary joins.
import time
# List stores boundary markers and finalized VramSample rows.
from pathlib import Path
from typing import List, Optional, Tuple

# VramSample is shared with the pynvml sampler for identical trace JSONL schema.
from src.tracing.vram_join import build_vram_samples_from_nvidia_smi, peak_used_mb_from_samples
from src.tracing.vram_sampler import VramSample


def _query_gpu_total_mb(device_index: int) -> Optional[float]:
    """One-shot ``memory.total`` query via nvidia-smi (MiB)."""
    cmd = [
        "nvidia-smi",
        "--query-gpu=memory.total",
        "--format=csv,noheader,nounits",
        "-i",
        str(device_index),
    ]
    try:
        proc = subprocess.run(cmd, check=True, capture_output=True, text=True)
    except (OSError, subprocess.CalledProcessError):
        return None
    line = proc.stdout.strip().splitlines()[0] if proc.stdout.strip() else ""
    if not line:
        return None
    return float(line.strip())


class NvidiaSmiVramSampler:
    """Tier-1 F1 fallback: GPU-wide VRAM polling via external ``nvidia-smi`` subprocess."""

    method_name = "nvidia_smi"

    def __init__(self, *, interval_ms: int = 100, device_index: int = 0) -> None:
        # Poll interval forwarded to ``nvidia-smi -lms`` (guide default 100 ms).
        self._interval_ms = interval_ms
        # GPU index for both the loop query and one-shot total-memory query.
        self._device_index = device_index
        # Wall-clock origin captured in ``start()`` for relative ``t_ms`` conversion.
        self._wall_t0: Optional[float] = None
        # Running subprocess handle; None when not actively polling.
        self._proc: Optional[subprocess.Popen[str]] = None
        # Temp file path holding raw ``memory.used,timestamp`` CSV rows.
        self._raw_csv_path: Optional[Path] = None
        # Open file handle passed to Popen stdout (closed before parsing).
        self._raw_file = None
        # Boundary markers recorded during the KC run before join.
        self._boundaries: List[Tuple[str, float]] = []
        # Final joined samples produced in ``stop()`` for JSONL export.
        self._samples: List[VramSample] = []
        # Optional destination for persisting the raw sidecar beside the trace JSONL.
        self._persist_csv_path: Optional[Path] = None
        # Total VRAM in MiB for OOM labeling (queried once per sampler lifetime).
        self._vram_total_mb: Optional[float] = _query_gpu_total_mb(device_index)

    def start(self, *, persist_csv_path: Optional[Path] = None) -> None:
        """Spawn ``nvidia-smi -lms`` and begin recording boundary wall epochs."""
        if self._proc is not None:
            return
        self._persist_csv_path = persist_csv_path
        self._samples.clear()
        self._boundaries.clear()
        self._wall_t0 = time.time()
        self._boundaries.append(("run_start", self._wall_t0))
        tmp = tempfile.NamedTemporaryFile(
            mode="w+",
            suffix=".nvidia_smi.csv",
            delete=False,
            encoding="utf-8",
        )
        self._raw_file = tmp
        self._raw_csv_path = Path(tmp.name)
        cmd = [
            "nvidia-smi",
            "--query-gpu=memory.used,timestamp",
            "--format=csv,noheader,nounits",
            "-lms",
            str(self._interval_ms),
            "-i",
            str(self._device_index),
        ]
        self._proc = subprocess.Popen(
            cmd,
            stdout=tmp,
            stderr=subprocess.DEVNULL,
            text=True,
        )

    def stop(self) -> None:
        """Terminate nvidia-smi, parse CSV, join boundaries, optionally persist sidecar."""
        if self._proc is None:
            return
        self._boundaries.append(("run_end", time.time()))
        try:
            self._proc.terminate()
            self._proc.wait(timeout=5.0)
        except Exception:
            try:
                self._proc.kill()
            except Exception:
                pass
        self._proc = None
        if self._raw_file is not None:
            self._raw_file.flush()
            self._raw_file.close()
            self._raw_file = None
        csv_text = ""
        if self._raw_csv_path is not None and self._raw_csv_path.is_file():
            csv_text = self._raw_csv_path.read_text(encoding="utf-8")
        wall_t0 = self._wall_t0 if self._wall_t0 is not None else time.time()
        self._samples = build_vram_samples_from_nvidia_smi(
            csv_text=csv_text,
            wall_t0=wall_t0,
            boundaries=self._boundaries,
        )
        if self._persist_csv_path is not None and self._raw_csv_path is not None:
            self._persist_csv_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(self._raw_csv_path, self._persist_csv_path)

    def snapshot_boundary(self, label: str) -> VramSample:
        """Record a node boundary wall epoch; VRAM filled during ``stop()`` join."""
        wall = time.time()
        self._boundaries.append((label, wall))
        t_ms = (wall - (self._wall_t0 or wall)) * 1000.0
        return VramSample(t_ms=t_ms, vram_used_mb=0.0, boundary=label)

    def samples(self) -> List[VramSample]:
        """Return finalized samples (empty until ``stop()`` completes join)."""
        return list(self._samples)

    def peak_used_mb(self) -> float:
        """Peak used VRAM from joined nvidia-smi timeline."""
        return peak_used_mb_from_samples(self._samples)

    @property
    def vram_total_mb(self) -> Optional[float]:
        return self._vram_total_mb

    def boundary_trajectory(self) -> List[Tuple[str, float, float]]:
        return [
            (sample.boundary, sample.t_ms, sample.vram_used_mb)
            for sample in self._samples
            if sample.boundary is not None
        ]

    @property
    def wall_t0_epoch(self) -> Optional[float]:
        """Wall-clock epoch at run start (for post-hoc nvidia-smi joins)."""
        return self._wall_t0

    @property
    def raw_csv_path(self) -> Optional[Path]:
        return self._raw_csv_path
