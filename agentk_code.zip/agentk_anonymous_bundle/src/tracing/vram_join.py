"""
F1 Tier-1 — parse nvidia-smi CSV logs and join to AgentK node boundaries by wall-clock.

Used by ``NvidiaSmiVramSampler`` after each run and by ``scripts/rejoin_trace_vram.py``
for post-hoc label repair when a sidecar CSV already exists.
"""

from __future__ import annotations

# bisect finds the nearest nvidia-smi sample for each boundary timestamp.
import bisect
# datetime parses nvidia-smi ``timestamp`` query fields.
from datetime import datetime
# io decodes ZSTD-compressed trace bytes as UTF-8 text lines.
import io
# json parses each JSONL record from v1 or v2 trace files.
import json
# Path resolves trace artifacts on disk for join and rejoin scripts.
from pathlib import Path
# Iterator yields rows without loading entire traces into memory.
from typing import Any, Dict, Iterator, List, Optional, Sequence, Tuple

# zstandard decompresses v2 ``.jsonl.zst`` trace frames.
import zstandard

# Shared suffix constants keep read/write paths aligned across tracing modules.
from src.tracing.llm_recorder import (
    TRACE_JSONL_SUFFIX,
    TRACE_JSONL_ZST_SUFFIX,
    is_compressed_trace_path,
    trace_path_stem,
)

# VramSample is reused so join output matches pynvml sampler artifacts.
from src.tracing.vram_sampler import VramSample

# nvidia-smi timestamp format when ``--format=csv`` is used with the timestamp field.
_NVIDIA_SMI_TS_FMT = "%Y/%m/%d %H:%M:%S.%f"


def parse_nvidia_smi_timestamp(ts_text: str) -> float:
    """Parse ``YYYY/MM/DD HH:MM:SS.mmm`` from nvidia-smi into POSIX seconds."""
    # Strip whitespace because CSV rows may include leading spaces after the comma.
    cleaned = ts_text.strip()
    # strptime converts the driver-local wall clock into a datetime object.
    dt = datetime.strptime(cleaned, _NVIDIA_SMI_TS_FMT)
    # timestamp() yields float epoch seconds for alignment with ``time.time()``.
    return dt.timestamp()


def parse_nvidia_smi_csv(text: str) -> List[Tuple[float, float]]:
    """
    Parse nvidia-smi loop output: ``memory.used_mb, timestamp`` per line.

    Returns ``(wall_epoch_sec, vram_used_mb)`` rows sorted by time.
    """
    # Accumulate parsed rows before sorting for downstream bisect queries.
    rows: List[Tuple[float, float]] = []
    # Each physical line is one GPU poll from ``-lms`` mode.
    for line in text.splitlines():
        # Skip blank lines that sometimes appear when the subprocess is killed.
        stripped = line.strip()
        if not stripped:
            continue
        # Split on the first comma only; the timestamp string may contain commas in locales.
        if "," not in stripped:
            continue
        used_text, ts_text = stripped.split(",", 1)
        # memory.used is reported in MiB when ``nounits`` is set on the query.
        used_mb = float(used_text.strip())
        # Convert the textual timestamp into epoch seconds for wall-clock joins.
        wall_epoch = parse_nvidia_smi_timestamp(ts_text)
        rows.append((wall_epoch, used_mb))
    # Sort chronologically so nearest-neighbor lookup is well-defined.
    rows.sort(key=lambda pair: pair[0])
    return rows


def wall_epoch_to_relative_ms(wall_epoch: float, wall_t0: float) -> float:
    """Convert absolute wall epoch to milliseconds relative to run ``wall_t0``."""
    # Subtract origin and scale seconds to milliseconds for trace JSONL compatibility.
    return (wall_epoch - wall_t0) * 1000.0


def nearest_vram_mb(
    wall_epoch: float,
    timeline: Sequence[Tuple[float, float]],
) -> float:
    """Return VRAM used (MiB) at ``wall_epoch`` via nearest nvidia-smi sample."""
    # Empty sidecar means no GPU polls were captured for this run.
    if not timeline:
        return 0.0
    # Extract only timestamps for bisect on the sorted timeline.
    epochs = [row[0] for row in timeline]
    # bisect_left finds insertion point for the boundary wall time.
    idx = bisect.bisect_left(epochs, wall_epoch)
    # Clamp index to valid range when boundary is before the first sample.
    if idx <= 0:
        return float(timeline[0][1])
    # Clamp index when boundary is after the last sample.
    if idx >= len(timeline):
        return float(timeline[-1][1])
    # Compare distance to left vs right neighbor and pick the closer VRAM reading.
    left_epoch, left_mb = timeline[idx - 1]
    right_epoch, right_mb = timeline[idx]
    if abs(wall_epoch - left_epoch) <= abs(right_epoch - wall_epoch):
        return float(left_mb)
    return float(right_mb)


def build_vram_samples_from_nvidia_smi(
    *,
    csv_text: str,
    wall_t0: float,
    boundaries: Sequence[Tuple[str, float]],
) -> List[VramSample]:
    """
    Build ``VramSample`` rows from nvidia-smi CSV plus boundary wall epochs.

    ``boundaries`` is ``(label, wall_epoch_sec)`` recorded during the KC run.
    Poll rows become plain samples; boundary rows reuse nearest VRAM at that wall time.
    """
    # Parse the subprocess log into a sorted wall-clock timeline.
    timeline = parse_nvidia_smi_csv(csv_text)
    # Start with poll samples converted to relative ``t_ms`` for JSONL export.
    samples: List[VramSample] = []
    for wall_epoch, used_mb in timeline:
        samples.append(
            VramSample(
                t_ms=wall_epoch_to_relative_ms(wall_epoch, wall_t0),
                vram_used_mb=used_mb,
                boundary=None,
            )
        )
    # Join each node boundary marker to the nearest poll by absolute wall clock.
    for label, wall_epoch in boundaries:
        used_mb = nearest_vram_mb(wall_epoch, timeline)
        samples.append(
            VramSample(
                t_ms=wall_epoch_to_relative_ms(wall_epoch, wall_t0),
                vram_used_mb=used_mb,
                boundary=label,
            )
        )
    # Sort final timeline by ``t_ms`` so peak/trajectory helpers behave identically to pynvml.
    samples.sort(key=lambda sample: sample.t_ms)
    return samples


def peak_used_mb_from_samples(samples: Sequence[VramSample]) -> float:
    """Maximum used VRAM across samples (``M_peak_true`` helper)."""
    if not samples:
        return 0.0
    return max(sample.vram_used_mb for sample in samples)


def iter_trace_jsonl(path: Path) -> Iterator[Dict[str, Any]]:
    """
    Yield parsed JSON objects from a v1 ``.jsonl`` or v2 ``.jsonl.zst`` trace.

    Raises ``ValueError`` when the suffix is neither supported trace format.
    """
    path = Path(path)
    if is_compressed_trace_path(path):
        dctx = zstandard.ZstdDecompressor()
        with path.open("rb") as raw_in:
            with dctx.stream_reader(raw_in) as reader:
                text_in = io.TextIOWrapper(reader, encoding="utf-8")
                for line in text_in:
                    stripped = line.strip()
                    if stripped:
                        yield json.loads(stripped)
        return
    if str(path).endswith(TRACE_JSONL_SUFFIX):
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                yield json.loads(line)
        return
    raise ValueError(
        f"Unsupported trace format {path!s}; expected {TRACE_JSONL_SUFFIX!r} "
        f"or {TRACE_JSONL_ZST_SUFFIX!r}"
    )


def load_trace_jsonl(path: Path) -> List[Dict[str, Any]]:
    """Load all JSONL rows from a v1 or v2 trace file into a list."""
    return list(iter_trace_jsonl(path))


def resolve_trace_jsonl_path(base: Path) -> Optional[Path]:
    """
    Return an existing trace path preferring v2 ``.jsonl.zst`` over v1 ``.jsonl``.

    ``base`` may be a path with either suffix or a bare stem inside an agent dir.
    """
    base = Path(base)
    candidates: List[Path] = []
    name = base.name
    if name.endswith(TRACE_JSONL_ZST_SUFFIX) or name.endswith(TRACE_JSONL_SUFFIX):
        candidates.append(base)
    else:
        candidates.append(base.with_name(f"{name}{TRACE_JSONL_ZST_SUFFIX}"))
        candidates.append(base.with_name(f"{name}{TRACE_JSONL_SUFFIX}"))
    zst_variant = base.with_name(f"{trace_path_stem(base)}{TRACE_JSONL_ZST_SUFFIX}")
    jsonl_variant = base.with_name(f"{trace_path_stem(base)}{TRACE_JSONL_SUFFIX}")
    for candidate in (zst_variant, jsonl_variant, *candidates):
        if candidate.is_file():
            return candidate
    return None
