"""
Phase 3.1 — background VRAM polling via pynvml (100 ms cadence by default).

Samples ``(t_ms, vram_used_mb)`` relative to run start; optional boundary snapshots
are merged into the same timeline for node-aligned ``M_trajectory_true``.
"""

# Python line: from __future__ import annotations
# Phase 3.1 VRAM sampler (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
from __future__ import annotations

# threading runs the NVML poll loop without blocking the LangGraph main thread.
# Python line: import threading
# Phase 3.1 VRAM sampler (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
import threading
# time supplies monotonic clocks for sample timestamps and poll sleep.
# Python line: import time
# Phase 3.1 VRAM sampler (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
import time
# dataclass stores one VRAM sample row in the trace artifact.
# Python line: from dataclasses import dataclass
# Phase 3.1 VRAM sampler (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
from dataclasses import dataclass
# Path types the optional sidecar path accepted for sampler API parity.
from pathlib import Path
# List holds the growing sample buffer protected by a lock.
# Python line: from typing import AbstractSet, Dict, Iterable, List, Optional, Sequence, Set, Tuple
# Phase 3.1 VRAM sampler (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
from typing import AbstractSet, Dict, Iterable, List, Optional, Sequence, Set, Tuple


# Python line: @dataclass(frozen=True)
# Phase 3.1 VRAM sampler (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
@dataclass(frozen=True)
# Python line: class VramSample:
# Phase 3.1 VRAM sampler (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
class VramSample:
    """One VRAM observation: milliseconds since run start and used MiB."""

    # Python line: t_ms: float
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    t_ms: float
    # Python line: vram_used_mb: float
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    vram_used_mb: float
    # Python line: boundary: Optional[str] = None
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    boundary: Optional[str] = None


# Python line: class VramSampler:
# Phase 3.1 VRAM sampler (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
class VramSampler:
    """Poll device VRAM in a daemon thread until ``stop()`` is called."""

    method_name = "pynvml"

    # Python line: def __init__(self, *, interval_ms: int = 100, device_index: int = 0) -> None:
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def __init__(self, *, interval_ms: int = 100, device_index: int = 0) -> None:
        # Poll cadence from configs/tracing.yaml (default 100 ms per guide §3.1).
        # Python line: self._interval_ms = interval_ms
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._interval_ms = interval_ms
        # CUDA device index passed to NVML (usually 0 on single-GPU nodes).
        # Python line: self._device_index = device_index
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._device_index = device_index
        # Monotonic origin captured in ``start()`` for relative ``t_ms``.
        # Python line: self._t0: Optional[float] = None
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._t0: Optional[float] = None
        # Background poll thread handle; None until ``start()``.
        # Python line: self._thread: Optional[threading.Thread] = None
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._thread: Optional[threading.Thread] = None
        # Stop event signals the poll loop to exit cleanly.
        # Python line: self._stop = threading.Event()
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._stop = threading.Event()
        # Protects ``_samples`` against concurrent appends from poll + boundaries.
        # Python line: self._lock = threading.Lock()
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._lock = threading.Lock()
        # Accumulated VRAM samples written into the per-run JSONL artifact.
        # Python line: self._samples: List[VramSample] = []
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._samples: List[VramSample] = []
        # Total device VRAM in MiB (for OOM labeling in Phase 3.3).
        # Python line: self._vram_total_mb: Optional[float] = None
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._vram_total_mb: Optional[float] = None
        # Lazy NVML handle created on first query.
        # Python line: self._nvml_handle = None
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._nvml_handle = None

    # Python line: def _ensure_nvml(self) -> None:
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def _ensure_nvml(self) -> None:
        """Initialize NVML once and cache the device handle."""
        # Python line: if self._nvml_handle is not None:
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        if self._nvml_handle is not None:
            # Python line: return
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            return
        # Import pynvml lazily so import of tracing code works on CPU-only hosts.
        # Python line: import pynvml
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        import pynvml

        # Python line: pynvml.nvmlInit()
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        pynvml.nvmlInit()
        # Python line: self._nvml_handle = pynvml.nvmlDeviceGetHandleByIndex(self._device_index)
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._nvml_handle = pynvml.nvmlDeviceGetHandleByIndex(self._device_index)
        # Python line: mem = pynvml.nvmlDeviceGetMemoryInfo(self._nvml_handle)
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        mem = pynvml.nvmlDeviceGetMemoryInfo(self._nvml_handle)
        # Python line: self._vram_total_mb = mem.total / (1024.0 * 1024.0)
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._vram_total_mb = mem.total / (1024.0 * 1024.0)

    # Python line: def _read_used_mb(self) -> float:
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def _read_used_mb(self) -> float:
        """Return current device used VRAM in MiB."""
        # Python line: import pynvml
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        import pynvml

        # Python line: self._ensure_nvml()
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._ensure_nvml()
        # Python line: mem = pynvml.nvmlDeviceGetMemoryInfo(self._nvml_handle)
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        mem = pynvml.nvmlDeviceGetMemoryInfo(self._nvml_handle)
        # Python line: return mem.used / (1024.0 * 1024.0)
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return mem.used / (1024.0 * 1024.0)

    # Python line: def _relative_ms(self) -> float:
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def _relative_ms(self) -> float:
        """Milliseconds since ``start()`` was called."""
        # Python line: if self._t0 is None:
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        if self._t0 is None:
            # Python line: return 0.0
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            return 0.0
        # Python line: return (time.perf_counter() - self._t0) * 1000.0
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return (time.perf_counter() - self._t0) * 1000.0

    # Python line: def _append_sample(self, *, boundary: Optional[str] = None) -> VramSample:
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def _append_sample(self, *, boundary: Optional[str] = None) -> VramSample:
        """Read VRAM once and append to the protected sample list."""
        # Python line: used = self._read_used_mb()
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        used = self._read_used_mb()
        # Python line: sample = VramSample(t_ms=self._relative_ms(), vram_used_mb=used, boundary=boundary)
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        sample = VramSample(t_ms=self._relative_ms(), vram_used_mb=used, boundary=boundary)
        # Python line: with self._lock:
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        with self._lock:
            # Python line: self._samples.append(sample)
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            self._samples.append(sample)
        # Python line: return sample
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return sample

    # Python line: def _poll_loop(self) -> None:
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def _poll_loop(self) -> None:
        """Background loop: sample VRAM every ``interval_ms`` until stopped."""
        # Python line: while not self._stop.is_set():
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        while not self._stop.is_set():
            # Python line: try:
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            try:
                # Python line: self._append_sample()
                # Phase 3.1 VRAM sampler (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                self._append_sample()
            # Python line: except Exception:
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            except Exception:
                # NVML can fail transiently; skip sample rather than crash the run.
                # Python line: pass
                # Phase 3.1 VRAM sampler (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                pass
            # Python line: self._stop.wait(self._interval_ms / 1000.0)
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            self._stop.wait(self._interval_ms / 1000.0)

    # Python line: def start(self) -> None:
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def start(self, *, persist_csv_path: Optional[Path] = None) -> None:
        """Begin polling; safe to call only once per run."""
        # persist_csv_path is accepted for API compatibility with nvidia-smi sampler.
        _ = persist_csv_path
        # Python line: if self._thread is not None:
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        if self._thread is not None:
            # Python line: return
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            return
        # Clear samples from any prior run on this reused TraceSession object.
        self._samples.clear()
        # Python line: self._t0 = time.perf_counter()
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._t0 = time.perf_counter()
        # Python line: self._stop.clear()
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._stop.clear()
        # Seed timeline with an explicit t=0 sample before the poll loop runs.
        # Python line: self._append_sample(boundary="run_start")
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._append_sample(boundary="run_start")
        # Python line: self._thread = threading.Thread(target=self._poll_loop, daemon=True)
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._thread = threading.Thread(target=self._poll_loop, daemon=True)
        # Python line: self._thread.start()
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._thread.start()

    # Python line: def stop(self) -> None:
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def stop(self) -> None:
        """Stop polling and record a final boundary sample."""
        # Python line: if self._thread is None:
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        if self._thread is None:
            # Python line: return
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            return
        # Python line: self._stop.set()
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._stop.set()
        # Python line: self._thread.join(timeout=5.0)
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._thread.join(timeout=5.0)
        # Python line: try:
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        try:
            # Python line: self._append_sample(boundary="run_end")
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            self._append_sample(boundary="run_end")
        # Python line: except Exception:
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        except Exception:
            # Python line: pass
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            pass
        # Python line: self._thread = None
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._thread = None

    # Python line: def snapshot_boundary(self, label: str) -> VramSample:
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def snapshot_boundary(self, label: str) -> VramSample:
        """Explicit VRAM snapshot at a LangGraph node boundary (§3.1)."""
        # Python line: return self._append_sample(boundary=label)
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return self._append_sample(boundary=label)

    # Python line: def samples(self) -> List[VramSample]:
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def samples(self) -> List[VramSample]:
        """Return a copy of all VRAM samples collected so far."""
        # Python line: with self._lock:
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        with self._lock:
            # Python line: return list(self._samples)
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            return list(self._samples)

    # Python line: def peak_used_mb(self) -> float:
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def peak_used_mb(self) -> float:
        """Maximum observed used VRAM during the run (``M_peak_true``)."""
        # Python line: with self._lock:
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        with self._lock:
            # Python line: if not self._samples:
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            if not self._samples:
                # Python line: return 0.0
                # Phase 3.1 VRAM sampler (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                return 0.0
            # Python line: return max(s.vram_used_mb for s in self._samples)
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            return max(s.vram_used_mb for s in self._samples)

    # Python line: @property
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    @property
    # Python line: def vram_total_mb(self) -> Optional[float]:
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def vram_total_mb(self) -> Optional[float]:
        """Total device VRAM in MiB (None if NVML never initialized)."""
        # Python line: return self._vram_total_mb
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return self._vram_total_mb

    # Python line: def boundary_trajectory(self) -> List[Tuple[str, float, float]]:
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def boundary_trajectory(self) -> List[Tuple[str, float, float]]:
        """Return ``(boundary_label, t_ms, vram_used_mb)`` for node snapshots only."""
        # Python line: with self._lock:
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        with self._lock:
            # Python line: return [
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            return [
                # Python line: (s.boundary, s.t_ms, s.vram_used_mb)
                # Phase 3.1 VRAM sampler (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                (s.boundary, s.t_ms, s.vram_used_mb)
                # Python line: for s in self._samples
                # Phase 3.1 VRAM sampler (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                for s in self._samples
                # Python line: if s.boundary is not None
                # Phase 3.1 VRAM sampler (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                if s.boundary is not None
            # Python line: ]
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            ]


# Python line: def diagnostic_subset_prompt_ids(
# Phase 3.1 VRAM sampler (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def diagnostic_subset_prompt_ids(
    prompt_rows: Sequence[Dict[str, object]],
    *,
    total: int,
    seed: int,
) -> frozenset[str]:
    """
    Draw a stratified diagnostic subset from the val split (deterministic).

    Part-2 v2 keeps 30 val prompts at the legacy 100 ms cadence while the
    remaining runs use ``interval_ms`` (500 ms by default).
    """
    # Python line: import hashlib
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    import hashlib
    # Python line: from src.prompts.stratified_split import PromptRecord, stratified_kv_cache_sweep_subset
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    from src.prompts.stratified_split import PromptRecord, stratified_kv_cache_sweep_subset

    # Python line: val_rows = [row for row in prompt_rows if str(row.get("split", "")) == "val"]
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    val_rows = [row for row in prompt_rows if str(row.get("split", "")) == "val"]
    # Python line: if not val_rows:
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    if not val_rows:
        # Python line: raise ValueError("no val-split prompts available for VRAM diagnostic subset")
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        raise ValueError("no val-split prompts available for VRAM diagnostic subset")
    # Python line: records = [
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    records = [
        # Python line: PromptRecord(
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        PromptRecord(
            # Python line: id=str(row["id"]),
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            id=str(row["id"]),
            # Python line: source=str(row["source"]),
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            source=str(row["source"]),
            # Python line: family=str(row["family"]),
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            family=str(row["family"]),
            # Python line: complexity=str(row["complexity"]),
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            complexity=str(row["complexity"]),
            # Python line: precision=str(row.get("precision", "")),
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            precision=str(row.get("precision", "")),
            # Python line: prompt=str(row["prompt"]),
            # Phase 3.1 VRAM sampler (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            prompt=str(row["prompt"]),
        # Python line: )
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        )
        # Python line: for row in val_rows
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        for row in val_rows
    # Python line: ]
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    ]
    # Python line: diag_seed = int(
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    diag_seed = int(
        # Python line: hashlib.sha256(f"{seed}|vram_diagnostic".encode("utf-8")).hexdigest()[:16],
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        hashlib.sha256(f"{seed}|vram_diagnostic".encode("utf-8")).hexdigest()[:16],
        # Python line: 16,
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        16,
    # Python line: )
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: return stratified_kv_cache_sweep_subset(records, total=total, seed=diag_seed)
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    return stratified_kv_cache_sweep_subset(records, total=total, seed=diag_seed)


# Python line: def load_diagnostic_prompt_ids(
# Phase 3.1 VRAM sampler (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def load_diagnostic_prompt_ids(
    vram_cfg: Dict[str, object],
    prompt_rows: Sequence[Dict[str, object]],
    *,
    seed: int,
) -> Optional[frozenset[str]]:
    """Return diagnostic prompt ids when ``diagnostic_subset_size`` is configured."""
    # Python line: raw_size = vram_cfg.get("diagnostic_subset_size")
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    raw_size = vram_cfg.get("diagnostic_subset_size")
    # Python line: if raw_size is None:
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    if raw_size is None:
        # Python line: return None
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return None
    # Python line: return diagnostic_subset_prompt_ids(
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    return diagnostic_subset_prompt_ids(
        # Python line: prompt_rows, total=int(raw_size), seed=seed
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        prompt_rows,
        total=int(raw_size),
        seed=seed,
    # Python line: )
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    )


# Python line: def resolve_vram_interval_ms(
# Phase 3.1 VRAM sampler (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def resolve_vram_interval_ms(
    vram_cfg: Dict[str, object],
    *,
    prompt_id: Optional[str] = None,
    diagnostic_prompt_ids: Optional[AbstractSet[str]] = None,
) -> int:
    """Select per-run poll cadence: diagnostic (100 ms) vs default (500 ms in v2)."""
    # Python line: base_ms = int(vram_cfg.get("interval_ms", 100))
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    base_ms = int(vram_cfg.get("interval_ms", 100))
    # Python line: if not prompt_id or not diagnostic_prompt_ids:
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    if not prompt_id or not diagnostic_prompt_ids:
        # Python line: return base_ms
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return base_ms
    # Python line: if prompt_id in diagnostic_prompt_ids:
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    if prompt_id in diagnostic_prompt_ids:
        # Python line: return int(vram_cfg.get("diagnostic_interval_ms", base_ms))
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return int(vram_cfg.get("diagnostic_interval_ms", base_ms))
    # Python line: return base_ms
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    return base_ms


# Python line: def build_vram_sampler_for_run(
# Phase 3.1 VRAM sampler (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def build_vram_sampler_for_run(
    vram_cfg: Dict[str, object],
    *,
    prompt_id: str,
    diagnostic_prompt_ids: Optional[AbstractSet[str]] = None,
    device_index: int = 0,
) -> VramSampler:
    """Construct a ``VramSampler`` with the cadence appropriate for ``prompt_id``."""
    # Python line: interval_ms = resolve_vram_interval_ms(
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    interval_ms = resolve_vram_interval_ms(
        # Python line: vram_cfg,
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        vram_cfg,
        # Python line: prompt_id=prompt_id,
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        prompt_id=prompt_id,
        # Python line: diagnostic_prompt_ids=diagnostic_prompt_ids,
        # Phase 3.1 VRAM sampler (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        diagnostic_prompt_ids=diagnostic_prompt_ids,
    # Python line: )
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: return VramSampler(interval_ms=interval_ms, device_index=device_index)
    # Phase 3.1 VRAM sampler (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    return VramSampler(interval_ms=interval_ms, device_index=device_index)
