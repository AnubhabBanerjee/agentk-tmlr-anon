"""
record per-LLM-call token usage and attribute calls to graph nodes.

Uses a contextvar so wrapped ``get_llm`` invocations are attributed to the
currently executing LangGraph node (including ``generator@retry_k`` names).
"""

# Python line: from __future__ import annotations
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
from __future__ import annotations

# contextvars isolates per-run node attribution across concurrent threads.
# Python line: import contextvars
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
import contextvars
# dataclass stores one OpenAI-compatible completion usage row.
# Python line: from dataclasses import dataclass, field
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
from dataclasses import dataclass, field
# io wraps the ZSTD byte stream as UTF-8 text for incremental JSONL writes.
# Python line: import io
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
import io
# json serializes each trace record row before compression.
# Python line: import json
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
import json
# Path resolves trace output locations under data/traces_v2/.
# Python line: from pathlib import Path
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
from pathlib import Path
# typing annotates token buckets and the active node context handle.
# Python line: from typing import Any, Dict, Iterable, List, Optional, Union
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
from typing import Any, Dict, Iterable, List, Optional, Union

# zstandard streams ZSTD level-19 frames for released `.jsonl.zst` trace artifacts.
# Python line: import zstandard
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
import zstandard


# Active LangGraph node name while a wrapped node function executes.
# Python line: _ACTIVE_NODE: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
_ACTIVE_NODE: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    # Python line: "agentk_active_node", default=None
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    "agentk_active_node",
    default=None,
)


# Python line: @dataclass
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
@dataclass
# Python line: class LlmCallRecord:
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
class LlmCallRecord:
    """Token usage for one chat completion inside a graph node."""

    # Python line: node_name: Optional[str]
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    node_name: Optional[str]
    # Python line: tokens_prompt: int
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    tokens_prompt: int
    # Python line: tokens_completion: int
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    tokens_completion: int
    # Python line: tokens_in: int
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    tokens_in: int
    # Python line: tokens_out: int
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    tokens_out: int


# Python line: @dataclass
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
@dataclass
# Python line: class LlmCallRecorder:
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
class LlmCallRecorder:
    """Accumulates LLM token rows for one AgentK trace run."""

    # Python line: calls: List[LlmCallRecord] = field(default_factory=list)
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    calls: List[LlmCallRecord] = field(default_factory=list)

    # Python line: def set_active_node(self, node_name: Optional[str]):
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    def set_active_node(self, node_name: Optional[str]):
        """Context manager token for attributing subsequent LLM calls to a node."""
        # Python line: return _ACTIVE_NODE.set(node_name)
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        return _ACTIVE_NODE.set(node_name)

    # Python line: def reset_active_node(self, token) -> None:
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    def reset_active_node(self, token) -> None:
        """Restore previous active node after a wrapped node returns."""
        # Python line: _ACTIVE_NODE.reset(token)
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        _ACTIVE_NODE.reset(token)

    # Python line: def record_response(self, response: Any) -> LlmCallRecord:
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    def record_response(self, response: Any) -> LlmCallRecord:
        """Parse token usage from a LangChain AIMessage and append a row."""
        # Python line: prompt_t, completion_t = _extract_token_counts(response)
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        prompt_t, completion_t = _extract_token_counts(response)
        # Python line: row = LlmCallRecord(
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        row = LlmCallRecord(
            # Python line: node_name=_ACTIVE_NODE.get(),
            # LLM call recorder.
            # Implements .cursorrules dense-comment policy for src/ code.
            node_name=_ACTIVE_NODE.get(),
            # Python line: tokens_prompt=prompt_t,
            # LLM call recorder.
            # Implements .cursorrules dense-comment policy for src/ code.
            tokens_prompt=prompt_t,
            # Python line: tokens_completion=completion_t,
            # LLM call recorder.
            # Implements .cursorrules dense-comment policy for src/ code.
            tokens_completion=completion_t,
            # Python line: tokens_in=prompt_t,
            # LLM call recorder.
            # Implements .cursorrules dense-comment policy for src/ code.
            tokens_in=prompt_t,
            # Python line: tokens_out=completion_t,
            # LLM call recorder.
            # Implements .cursorrules dense-comment policy for src/ code.
            tokens_out=completion_t,
        # Python line: )
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        )
        # Python line: self.calls.append(row)
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        self.calls.append(row)
        # Python line: return row
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        return row

    # Python line: def totals_for_node(self, node_name: str) -> Dict[str, int]:
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    def totals_for_node(self, node_name: str) -> Dict[str, int]:
        """Sum token fields for all LLM calls attributed to ``node_name``."""
        # Python line: rows = [c for c in self.calls if c.node_name == node_name]
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        rows = [c for c in self.calls if c.node_name == node_name]
        # Python line: return {
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        return {
            # Python line: "tokens_prompt": sum(r.tokens_prompt for r in rows),
            # LLM call recorder.
            # Implements .cursorrules dense-comment policy for src/ code.
            "tokens_prompt": sum(r.tokens_prompt for r in rows),
            # Python line: "tokens_completion": sum(r.tokens_completion for r in rows),
            # LLM call recorder.
            # Implements .cursorrules dense-comment policy for src/ code.
            "tokens_completion": sum(r.tokens_completion for r in rows),
            # Python line: "tokens_in": sum(r.tokens_in for r in rows),
            # LLM call recorder.
            # Implements .cursorrules dense-comment policy for src/ code.
            "tokens_in": sum(r.tokens_in for r in rows),
            # Python line: "tokens_out": sum(r.tokens_out for r in rows),
            # LLM call recorder.
            # Implements .cursorrules dense-comment policy for src/ code.
            "tokens_out": sum(r.tokens_out for r in rows),
        # Python line: }
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        }


# Python line: def _extract_token_counts(response: Any) -> tuple[int, int]:
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
def _extract_token_counts(response: Any) -> tuple[int, int]:
    """Read prompt/completion token counts from LangChain / OpenAI metadata."""
    # Python line: prompt_tokens = 0
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    prompt_tokens = 0
    # Python line: completion_tokens = 0
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    completion_tokens = 0
    # Python line: usage_meta = getattr(response, "usage_metadata", None) or {}
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    usage_meta = getattr(response, "usage_metadata", None) or {}
    # Python line: if usage_meta:
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    if usage_meta:
        # Python line: prompt_tokens = int(
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        prompt_tokens = int(
            # Python line: usage_meta.get("input_tokens")
            # LLM call recorder.
            # Implements .cursorrules dense-comment policy for src/ code.
            usage_meta.get("input_tokens")
            # Python line: or usage_meta.get("prompt_tokens")
            # LLM call recorder.
            # Implements .cursorrules dense-comment policy for src/ code.
            or usage_meta.get("prompt_tokens")
            # Python line: or 0
            # LLM call recorder.
            # Implements .cursorrules dense-comment policy for src/ code.
            or 0
        # Python line: )
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        )
        # Python line: completion_tokens = int(
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        completion_tokens = int(
            # Python line: usage_meta.get("output_tokens")
            # LLM call recorder.
            # Implements .cursorrules dense-comment policy for src/ code.
            usage_meta.get("output_tokens")
            # Python line: or usage_meta.get("completion_tokens")
            # LLM call recorder.
            # Implements .cursorrules dense-comment policy for src/ code.
            or usage_meta.get("completion_tokens")
            # Python line: or 0
            # LLM call recorder.
            # Implements .cursorrules dense-comment policy for src/ code.
            or 0
        # Python line: )
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        )
    # Python line: meta = getattr(response, "response_metadata", None) or {}
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    meta = getattr(response, "response_metadata", None) or {}
    # Python line: usage = meta.get("token_usage") or meta.get("usage") or {}
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    usage = meta.get("token_usage") or meta.get("usage") or {}
    # Python line: if usage:
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    if usage:
        # Python line: prompt_tokens = int(usage.get("prompt_tokens") or prompt_tokens or 0)
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        prompt_tokens = int(usage.get("prompt_tokens") or prompt_tokens or 0)
        # Python line: completion_tokens = int(
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        completion_tokens = int(
            # Python line: usage.get("completion_tokens") or completion_tokens or 0
            # LLM call recorder.
            # Implements .cursorrules dense-comment policy for src/ code.
            usage.get("completion_tokens") or completion_tokens or 0
        # Python line: )
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        )
    # Char-based fallback when llama.cpp omits usage headers (common on local Q4).
    # Python line: if prompt_tokens == 0 and completion_tokens == 0:
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    if prompt_tokens == 0 and completion_tokens == 0:
        # Python line: content = getattr(response, "content", "") or ""
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        content = getattr(response, "content", "") or ""
        # Python line: completion_tokens = max(1, len(content) // 4) if content else 0
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        completion_tokens = max(1, len(content) // 4) if content else 0
    # Python line: return prompt_tokens, completion_tokens
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    return prompt_tokens, completion_tokens


# Python line: class TracingLlmWrapper:
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
class TracingLlmWrapper:
    """Transparent ChatOpenAI wrapper that records token usage on ``invoke``."""

    # Python line: def __init__(self, llm: Any, recorder: LlmCallRecorder) -> None:
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    def __init__(self, llm: Any, recorder: LlmCallRecorder) -> None:
        # Python line: self._llm = llm
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        self._llm = llm
        # Python line: self._recorder = recorder
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        self._recorder = recorder

    # Python line: def invoke(self, input: Any, config: Any = None, **kwargs: Any) -> Any:
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    def invoke(self, input: Any, config: Any = None, **kwargs: Any) -> Any:
        """Delegate to the underlying LLM and record token usage from the response."""
        # Python line: out = self._llm.invoke(input, config=config, **kwargs)
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        out = self._llm.invoke(input, config=config, **kwargs)
        # Python line: self._recorder.record_response(out)
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        self._recorder.record_response(out)
        # Python line: return out
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        return out

    # Python line: def bind(self, **kwargs: Any) -> "TracingLlmWrapper":
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    def bind(self, **kwargs: Any) -> "TracingLlmWrapper":
        """Preserve tracing when AgentK shim calls ``llm.bind(...)``."""
        # Python line: return TracingLlmWrapper(self._llm.bind(**kwargs), self._recorder)
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        return TracingLlmWrapper(self._llm.bind(**kwargs), self._recorder)

    # Python line: def __getattr__(self, name: str) -> Any:
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    def __getattr__(self, name: str) -> Any:
        """Forward Runnable/LCEL helpers (``|``, batch, etc.) to the inner LLM."""
        # Python line: return getattr(self._llm, name)
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        return getattr(self._llm, name)


def install_global_chatopenai_tracing(recorder: LlmCallRecorder) -> Optional[Any]:
    """
    Patch ``ChatOpenAI.invoke`` so shim nodes that bypass ``get_llm`` are still traced.

    Returns the original ``invoke`` for restoration, or None if already patched.
    """
    # Python line: from langchain_openai import ChatOpenAI
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    from langchain_openai import ChatOpenAI

    # Python line: if getattr(ChatOpenAI, "_mcai_tracing_installed", False):
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    if getattr(ChatOpenAI, "_mcai_tracing_installed", False):
        # Python line: ChatOpenAI._mcai_active_recorder = recorder  # type: ignore[attr-defined]
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        ChatOpenAI._mcai_active_recorder = recorder  # type: ignore[attr-defined]
        # Python line: return getattr(ChatOpenAI, "_mcai_orig_invoke", None)
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        return getattr(ChatOpenAI, "_mcai_orig_invoke", None)

    # Python line: orig_invoke = ChatOpenAI.invoke
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    orig_invoke = ChatOpenAI.invoke

    # Python line: def traced_invoke(self, input, config=None, **kwargs):  # type: ignore[no-untyped-def]
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    def traced_invoke(self, input, config=None, **kwargs):  # type: ignore[no-untyped-def]
        # Python line: out = orig_invoke(self, input, config=config, **kwargs)
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        out = orig_invoke(self, input, config=config, **kwargs)
        # Python line: active = getattr(ChatOpenAI, "_mcai_active_recorder", None)
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        active = getattr(ChatOpenAI, "_mcai_active_recorder", None)
        # Python line: if active is not None:
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        if active is not None:
            # Python line: active.record_response(out)
            # LLM call recorder.
            # Implements .cursorrules dense-comment policy for src/ code.
            active.record_response(out)
        # Python line: return out
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        return out

    # Python line: ChatOpenAI.invoke = traced_invoke  # type: ignore[method-assign]
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    ChatOpenAI.invoke = traced_invoke  # type: ignore[method-assign]
    # Python line: ChatOpenAI._mcai_tracing_installed = True  # type: ignore[attr-defined]
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    ChatOpenAI._mcai_tracing_installed = True  # type: ignore[attr-defined]
    # Python line: ChatOpenAI._mcai_orig_invoke = orig_invoke  # type: ignore[attr-defined]
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    ChatOpenAI._mcai_orig_invoke = orig_invoke  # type: ignore[attr-defined]
    # Python line: ChatOpenAI._mcai_active_recorder = recorder  # type: ignore[attr-defined]
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    ChatOpenAI._mcai_active_recorder = recorder  # type: ignore[attr-defined]
    # Python line: return orig_invoke
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    return orig_invoke


# Python line: def set_active_chatopenai_recorder(recorder: LlmCallRecorder) -> None:
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
def set_active_chatopenai_recorder(recorder: LlmCallRecorder) -> None:
    """Point the global ChatOpenAI patch at the current run's recorder."""
    # Python line: from langchain_openai import ChatOpenAI
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    from langchain_openai import ChatOpenAI

    # Python line: ChatOpenAI._mcai_active_recorder = recorder  # type: ignore[attr-defined]
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    ChatOpenAI._mcai_active_recorder = recorder  # type: ignore[attr-defined]


# Python line: def install_traced_get_llm(recorder: LlmCallRecorder) -> Any:
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
def install_traced_get_llm(recorder: LlmCallRecorder) -> Any:
    """
    Wrap AgentK ``src.config.get_llm`` so every completion is token-logged.

    Returns the previous ``get_llm`` callable for restoration after a trace run.
    """
    # Python line: import src.config as agentk_config
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.config as agentk_config

    # Python line: previous = agentk_config.get_llm
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    previous = agentk_config.get_llm

    # Python line: def traced_get_llm(temperature: float = 0.0):
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    def traced_get_llm(temperature: float = 0.0):
        # Python line: return TracingLlmWrapper(previous(temperature=temperature), recorder)
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        return TracingLlmWrapper(previous(temperature=temperature), recorder)

    # Python line: agentk_config.get_llm = traced_get_llm
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    agentk_config.get_llm = traced_get_llm
    # Python line: return previous
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    return previous


# legacy traces use plain UTF-8 JSONL; released uses ZSTD-compressed JSONL.
# Python line: TRACE_JSONL_SUFFIX = ".jsonl"
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
TRACE_JSONL_SUFFIX = ".jsonl"
# Python line: TRACE_JSONL_ZST_SUFFIX = ".jsonl.zst"
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
TRACE_JSONL_ZST_SUFFIX = ".jsonl.zst"
# Python line: ZSTD_COMPRESSION_LEVEL = 19
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
ZSTD_COMPRESSION_LEVEL = 19


# Python line: def is_compressed_trace_path(path: Union[str, Path]) -> bool:
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
def is_compressed_trace_path(path: Union[str, Path]) -> bool:
    """Return True when ``path`` ends with the v2 ``.jsonl.zst`` suffix."""
    # Python line: return str(path).endswith(TRACE_JSONL_ZST_SUFFIX)
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    return str(path).endswith(TRACE_JSONL_ZST_SUFFIX)


# Python line: def trace_path_stem(path: Union[str, Path]) -> str:
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
def trace_path_stem(path: Union[str, Path]) -> str:
    """Strip ``.jsonl`` or ``.jsonl.zst`` from a trace filename (prompt_id stem)."""
    # Python line: name = Path(path).name
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    name = Path(path).name
    # Python line: if name.endswith(TRACE_JSONL_ZST_SUFFIX):
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    if name.endswith(TRACE_JSONL_ZST_SUFFIX):
        # Python line: return name[: -len(TRACE_JSONL_ZST_SUFFIX)]
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        return name[: -len(TRACE_JSONL_ZST_SUFFIX)]
    # Python line: if name.endswith(TRACE_JSONL_SUFFIX):
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    if name.endswith(TRACE_JSONL_SUFFIX):
        # Python line: return name[: -len(TRACE_JSONL_SUFFIX)]
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        return name[: -len(TRACE_JSONL_SUFFIX)]
    # Python line: return Path(path).stem
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    return Path(path).stem


# Python line: def nvidia_smi_sidecar_path(trace_path: Union[str, Path]) -> Path:
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
def nvidia_smi_sidecar_path(trace_path: Union[str, Path]) -> Path:
    """Return ``{prompt_id}.nvidia_smi.csv`` beside a plain or compressed trace file."""
    # Python line: path = Path(trace_path)
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    path = Path(trace_path)
    # Python line: return path.parent / f"{trace_path_stem(path)}.nvidia_smi.csv"
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    return path.parent / f"{trace_path_stem(path)}.nvidia_smi.csv"


# Python line: def write_trace_jsonl_file(
# LLM call recorder.
# Implements .cursorrules dense-comment policy for src/ code.
def write_trace_jsonl_file(
    path: Path,
    rows: Iterable[Dict[str, Any]],
) -> None:
    """
    Persist trace rows as JSONL (v1) or ZSTD-compressed JSONL .

    Compression is selected by the ``.jsonl.zst`` suffix; v1 uses plain ``.jsonl``.
    """
    # Python line: path.parent.mkdir(parents=True, exist_ok=True)
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    path.parent.mkdir(parents=True, exist_ok=True)
    # Python line: if is_compressed_trace_path(path):
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    if is_compressed_trace_path(path):
        # Python line: cctx = zstandard.ZstdCompressor(level=ZSTD_COMPRESSION_LEVEL)
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        cctx = zstandard.ZstdCompressor(level=ZSTD_COMPRESSION_LEVEL)
        # Python line: with path.open("wb") as raw_out:
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        with path.open("wb") as raw_out:
            # Python line: with cctx.stream_writer(raw_out) as compressor:
            # LLM call recorder.
            # Implements .cursorrules dense-comment policy for src/ code.
            with cctx.stream_writer(raw_out) as compressor:
                # Python line: text_out = io.TextIOWrapper(
                # LLM call recorder.
                # Implements .cursorrules dense-comment policy for src/ code.
                text_out = io.TextIOWrapper(
                    # Python line: compressor, encoding="utf-8", write_through=True
                    # LLM call recorder.
                    # Implements .cursorrules dense-comment policy for src/ code.
                    compressor,
                    encoding="utf-8",
                    write_through=True,
                # Python line: )
                # LLM call recorder.
                # Implements .cursorrules dense-comment policy for src/ code.
                )
                # Python line: for row in rows:
                # LLM call recorder.
                # Implements .cursorrules dense-comment policy for src/ code.
                for row in rows:
                    # Python line: text_out.write(json.dumps(row, ensure_ascii=False) + "\n")
                    # LLM call recorder.
                    # Implements .cursorrules dense-comment policy for src/ code.
                    text_out.write(json.dumps(row, ensure_ascii=False) + "\n")
                # Python line: text_out.flush()
                # LLM call recorder.
                # Implements .cursorrules dense-comment policy for src/ code.
                text_out.flush()
        # Python line: return
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        return
    # Python line: with path.open("w", encoding="utf-8") as handle:
    # LLM call recorder.
    # Implements .cursorrules dense-comment policy for src/ code.
    with path.open("w", encoding="utf-8") as handle:
        # Python line: for row in rows:
        # LLM call recorder.
        # Implements .cursorrules dense-comment policy for src/ code.
        for row in rows:
            # Python line: handle.write(json.dumps(row, ensure_ascii=False) + "\n")
            # LLM call recorder.
            # Implements .cursorrules dense-comment policy for src/ code.
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
