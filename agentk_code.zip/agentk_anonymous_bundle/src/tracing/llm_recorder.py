"""
Phase 3.1 — record per-LLM-call token usage and attribute calls to graph nodes.

Uses a contextvar so wrapped ``get_llm`` invocations are attributed to the
currently executing LangGraph node (including ``generator@retry_k`` names).
"""

# Python line: from __future__ import annotations
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
from __future__ import annotations

# contextvars isolates per-run node attribution across concurrent threads.
# Python line: import contextvars
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
import contextvars
# dataclass stores one OpenAI-compatible completion usage row.
# Python line: from dataclasses import dataclass, field
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
from dataclasses import dataclass, field
# io wraps the ZSTD byte stream as UTF-8 text for incremental JSONL writes.
# Python line: import io
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
import io
# json serializes each trace record row before compression.
# Python line: import json
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
import json
# Path resolves trace output locations under data/traces_v2/.
# Python line: from pathlib import Path
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
from pathlib import Path
# typing annotates token buckets and the active node context handle.
# Python line: from typing import Any, Dict, Iterable, List, Optional, Union
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
from typing import Any, Dict, Iterable, List, Optional, Union

# zstandard streams ZSTD level-19 frames for v2 `.jsonl.zst` trace artifacts.
# Python line: import zstandard
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
import zstandard


# Active LangGraph node name while a wrapped node function executes.
# Python line: _ACTIVE_NODE: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
_ACTIVE_NODE: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    # Python line: "kc_active_node", default=None
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    "kc_active_node",
    default=None,
)


# Python line: @dataclass
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
@dataclass
# Python line: class LlmCallRecord:
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
class LlmCallRecord:
    """Token usage for one chat completion inside a graph node."""

    # Python line: node_name: Optional[str]
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    node_name: Optional[str]
    # Python line: tokens_prompt: int
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    tokens_prompt: int
    # Python line: tokens_completion: int
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    tokens_completion: int
    # Python line: tokens_in: int
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    tokens_in: int
    # Python line: tokens_out: int
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    tokens_out: int


# Python line: @dataclass
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
@dataclass
# Python line: class LlmCallRecorder:
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
class LlmCallRecorder:
    """Accumulates LLM token rows for one AgentK trace run."""

    # Python line: calls: List[LlmCallRecord] = field(default_factory=list)
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    calls: List[LlmCallRecord] = field(default_factory=list)

    # Python line: def set_active_node(self, node_name: Optional[str]):
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def set_active_node(self, node_name: Optional[str]):
        """Context manager token for attributing subsequent LLM calls to a node."""
        # Python line: return _ACTIVE_NODE.set(node_name)
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return _ACTIVE_NODE.set(node_name)

    # Python line: def reset_active_node(self, token) -> None:
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def reset_active_node(self, token) -> None:
        """Restore previous active node after a wrapped node returns."""
        # Python line: _ACTIVE_NODE.reset(token)
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        _ACTIVE_NODE.reset(token)

    # Python line: def record_response(self, response: Any) -> LlmCallRecord:
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def record_response(self, response: Any) -> LlmCallRecord:
        """Parse token usage from a LangChain AIMessage and append a row."""
        # Python line: prompt_t, completion_t = _extract_token_counts(response)
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        prompt_t, completion_t = _extract_token_counts(response)
        # Python line: row = LlmCallRecord(
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        row = LlmCallRecord(
            # Python line: node_name=_ACTIVE_NODE.get(),
            # Phase 3.1 LLM call recorder (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            node_name=_ACTIVE_NODE.get(),
            # Python line: tokens_prompt=prompt_t,
            # Phase 3.1 LLM call recorder (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            tokens_prompt=prompt_t,
            # Python line: tokens_completion=completion_t,
            # Phase 3.1 LLM call recorder (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            tokens_completion=completion_t,
            # Python line: tokens_in=prompt_t,
            # Phase 3.1 LLM call recorder (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            tokens_in=prompt_t,
            # Python line: tokens_out=completion_t,
            # Phase 3.1 LLM call recorder (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            tokens_out=completion_t,
        # Python line: )
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        )
        # Python line: self.calls.append(row)
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self.calls.append(row)
        # Python line: return row
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return row

    # Python line: def totals_for_node(self, node_name: str) -> Dict[str, int]:
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def totals_for_node(self, node_name: str) -> Dict[str, int]:
        """Sum token fields for all LLM calls attributed to ``node_name``."""
        # Python line: rows = [c for c in self.calls if c.node_name == node_name]
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        rows = [c for c in self.calls if c.node_name == node_name]
        # Python line: return {
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return {
            # Python line: "tokens_prompt": sum(r.tokens_prompt for r in rows),
            # Phase 3.1 LLM call recorder (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            "tokens_prompt": sum(r.tokens_prompt for r in rows),
            # Python line: "tokens_completion": sum(r.tokens_completion for r in rows),
            # Phase 3.1 LLM call recorder (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            "tokens_completion": sum(r.tokens_completion for r in rows),
            # Python line: "tokens_in": sum(r.tokens_in for r in rows),
            # Phase 3.1 LLM call recorder (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            "tokens_in": sum(r.tokens_in for r in rows),
            # Python line: "tokens_out": sum(r.tokens_out for r in rows),
            # Phase 3.1 LLM call recorder (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            "tokens_out": sum(r.tokens_out for r in rows),
        # Python line: }
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        }


# Python line: def _extract_token_counts(response: Any) -> tuple[int, int]:
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def _extract_token_counts(response: Any) -> tuple[int, int]:
    """Read prompt/completion token counts from LangChain / OpenAI metadata."""
    # Python line: prompt_tokens = 0
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    prompt_tokens = 0
    # Python line: completion_tokens = 0
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    completion_tokens = 0
    # Python line: usage_meta = getattr(response, "usage_metadata", None) or {}
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    usage_meta = getattr(response, "usage_metadata", None) or {}
    # Python line: if usage_meta:
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    if usage_meta:
        # Python line: prompt_tokens = int(
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        prompt_tokens = int(
            # Python line: usage_meta.get("input_tokens")
            # Phase 3.1 LLM call recorder (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            usage_meta.get("input_tokens")
            # Python line: or usage_meta.get("prompt_tokens")
            # Phase 3.1 LLM call recorder (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            or usage_meta.get("prompt_tokens")
            # Python line: or 0
            # Phase 3.1 LLM call recorder (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            or 0
        # Python line: )
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        )
        # Python line: completion_tokens = int(
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        completion_tokens = int(
            # Python line: usage_meta.get("output_tokens")
            # Phase 3.1 LLM call recorder (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            usage_meta.get("output_tokens")
            # Python line: or usage_meta.get("completion_tokens")
            # Phase 3.1 LLM call recorder (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            or usage_meta.get("completion_tokens")
            # Python line: or 0
            # Phase 3.1 LLM call recorder (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            or 0
        # Python line: )
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        )
    # Python line: meta = getattr(response, "response_metadata", None) or {}
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    meta = getattr(response, "response_metadata", None) or {}
    # Python line: usage = meta.get("token_usage") or meta.get("usage") or {}
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    usage = meta.get("token_usage") or meta.get("usage") or {}
    # Python line: if usage:
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    if usage:
        # Python line: prompt_tokens = int(usage.get("prompt_tokens") or prompt_tokens or 0)
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        prompt_tokens = int(usage.get("prompt_tokens") or prompt_tokens or 0)
        # Python line: completion_tokens = int(
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        completion_tokens = int(
            # Python line: usage.get("completion_tokens") or completion_tokens or 0
            # Phase 3.1 LLM call recorder (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            usage.get("completion_tokens") or completion_tokens or 0
        # Python line: )
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        )
    # Char-based fallback when llama.cpp omits usage headers (common on local Q4).
    # Python line: if prompt_tokens == 0 and completion_tokens == 0:
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    if prompt_tokens == 0 and completion_tokens == 0:
        # Python line: content = getattr(response, "content", "") or ""
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        content = getattr(response, "content", "") or ""
        # Python line: completion_tokens = max(1, len(content) // 4) if content else 0
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        completion_tokens = max(1, len(content) // 4) if content else 0
    # Python line: return prompt_tokens, completion_tokens
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    return prompt_tokens, completion_tokens


# Python line: class TracingLlmWrapper:
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
class TracingLlmWrapper:
    """Transparent ChatOpenAI wrapper that records token usage on ``invoke``."""

    # Python line: def __init__(self, llm: Any, recorder: LlmCallRecorder) -> None:
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def __init__(self, llm: Any, recorder: LlmCallRecorder) -> None:
        # Python line: self._llm = llm
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._llm = llm
        # Python line: self._recorder = recorder
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._recorder = recorder

    # Python line: def invoke(self, input: Any, config: Any = None, **kwargs: Any) -> Any:
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def invoke(self, input: Any, config: Any = None, **kwargs: Any) -> Any:
        """Delegate to the underlying LLM and record token usage from the response."""
        # Python line: out = self._llm.invoke(input, config=config, **kwargs)
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        out = self._llm.invoke(input, config=config, **kwargs)
        # Python line: self._recorder.record_response(out)
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self._recorder.record_response(out)
        # Python line: return out
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return out

    # Python line: def bind(self, **kwargs: Any) -> "TracingLlmWrapper":
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def bind(self, **kwargs: Any) -> "TracingLlmWrapper":
        """Preserve tracing when AgentK shim calls ``llm.bind(...)``."""
        # Python line: return TracingLlmWrapper(self._llm.bind(**kwargs), self._recorder)
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return TracingLlmWrapper(self._llm.bind(**kwargs), self._recorder)

    # Python line: def __getattr__(self, name: str) -> Any:
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def __getattr__(self, name: str) -> Any:
        """Forward Runnable/LCEL helpers (``|``, batch, etc.) to the inner LLM."""
        # Python line: return getattr(self._llm, name)
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return getattr(self._llm, name)


def install_global_chatopenai_tracing(recorder: LlmCallRecorder) -> Optional[Any]:
    """
    Patch ``ChatOpenAI.invoke`` so shim nodes that bypass ``get_llm`` are still traced.

    Returns the original ``invoke`` for restoration, or None if already patched.
    """
    # Python line: from langchain_openai import ChatOpenAI
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    from langchain_openai import ChatOpenAI

    # Python line: if getattr(ChatOpenAI, "_mcai_tracing_installed", False):
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    if getattr(ChatOpenAI, "_mcai_tracing_installed", False):
        # Python line: ChatOpenAI._mcai_active_recorder = recorder  # type: ignore[attr-defined]
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        ChatOpenAI._mcai_active_recorder = recorder  # type: ignore[attr-defined]
        # Python line: return getattr(ChatOpenAI, "_mcai_orig_invoke", None)
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return getattr(ChatOpenAI, "_mcai_orig_invoke", None)

    # Python line: orig_invoke = ChatOpenAI.invoke
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    orig_invoke = ChatOpenAI.invoke

    # Python line: def traced_invoke(self, input, config=None, **kwargs):  # type: ignore[no-untyped-def]
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def traced_invoke(self, input, config=None, **kwargs):  # type: ignore[no-untyped-def]
        # Python line: out = orig_invoke(self, input, config=config, **kwargs)
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        out = orig_invoke(self, input, config=config, **kwargs)
        # Python line: active = getattr(ChatOpenAI, "_mcai_active_recorder", None)
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        active = getattr(ChatOpenAI, "_mcai_active_recorder", None)
        # Python line: if active is not None:
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        if active is not None:
            # Python line: active.record_response(out)
            # Phase 3.1 LLM call recorder (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            active.record_response(out)
        # Python line: return out
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return out

    # Python line: ChatOpenAI.invoke = traced_invoke  # type: ignore[method-assign]
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    ChatOpenAI.invoke = traced_invoke  # type: ignore[method-assign]
    # Python line: ChatOpenAI._mcai_tracing_installed = True  # type: ignore[attr-defined]
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    ChatOpenAI._mcai_tracing_installed = True  # type: ignore[attr-defined]
    # Python line: ChatOpenAI._mcai_orig_invoke = orig_invoke  # type: ignore[attr-defined]
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    ChatOpenAI._mcai_orig_invoke = orig_invoke  # type: ignore[attr-defined]
    # Python line: ChatOpenAI._mcai_active_recorder = recorder  # type: ignore[attr-defined]
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    ChatOpenAI._mcai_active_recorder = recorder  # type: ignore[attr-defined]
    # Python line: return orig_invoke
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    return orig_invoke


# Python line: def set_active_chatopenai_recorder(recorder: LlmCallRecorder) -> None:
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def set_active_chatopenai_recorder(recorder: LlmCallRecorder) -> None:
    """Point the global ChatOpenAI patch at the current run's recorder."""
    # Python line: from langchain_openai import ChatOpenAI
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    from langchain_openai import ChatOpenAI

    # Python line: ChatOpenAI._mcai_active_recorder = recorder  # type: ignore[attr-defined]
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    ChatOpenAI._mcai_active_recorder = recorder  # type: ignore[attr-defined]


# Python line: def install_traced_get_llm(recorder: LlmCallRecorder) -> Any:
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def install_traced_get_llm(recorder: LlmCallRecorder) -> Any:
    """
    Wrap AgentK ``src.config.get_llm`` so every completion is token-logged.

    Returns the previous ``get_llm`` callable for restoration after a trace run.
    """
    # Python line: import src.config as kc_config
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.config as kc_config

    # Python line: previous = kc_config.get_llm
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    previous = kc_config.get_llm

    # Python line: def traced_get_llm(temperature: float = 0.0):
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def traced_get_llm(temperature: float = 0.0):
        # Python line: return TracingLlmWrapper(previous(temperature=temperature), recorder)
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return TracingLlmWrapper(previous(temperature=temperature), recorder)

    # Python line: kc_config.get_llm = traced_get_llm
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    kc_config.get_llm = traced_get_llm
    # Python line: return previous
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    return previous


# v1 traces use plain UTF-8 JSONL; v2 uses ZSTD-compressed JSONL.
# Python line: TRACE_JSONL_SUFFIX = ".jsonl"
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
TRACE_JSONL_SUFFIX = ".jsonl"
# Python line: TRACE_JSONL_ZST_SUFFIX = ".jsonl.zst"
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
TRACE_JSONL_ZST_SUFFIX = ".jsonl.zst"
# Python line: ZSTD_COMPRESSION_LEVEL = 19
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
ZSTD_COMPRESSION_LEVEL = 19


# Python line: def is_compressed_trace_path(path: Union[str, Path]) -> bool:
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def is_compressed_trace_path(path: Union[str, Path]) -> bool:
    """Return True when ``path`` ends with the v2 ``.jsonl.zst`` suffix."""
    # Python line: return str(path).endswith(TRACE_JSONL_ZST_SUFFIX)
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    return str(path).endswith(TRACE_JSONL_ZST_SUFFIX)


# Python line: def trace_path_stem(path: Union[str, Path]) -> str:
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def trace_path_stem(path: Union[str, Path]) -> str:
    """Strip ``.jsonl`` or ``.jsonl.zst`` from a trace filename (prompt_id stem)."""
    # Python line: name = Path(path).name
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    name = Path(path).name
    # Python line: if name.endswith(TRACE_JSONL_ZST_SUFFIX):
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    if name.endswith(TRACE_JSONL_ZST_SUFFIX):
        # Python line: return name[: -len(TRACE_JSONL_ZST_SUFFIX)]
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return name[: -len(TRACE_JSONL_ZST_SUFFIX)]
    # Python line: if name.endswith(TRACE_JSONL_SUFFIX):
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    if name.endswith(TRACE_JSONL_SUFFIX):
        # Python line: return name[: -len(TRACE_JSONL_SUFFIX)]
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return name[: -len(TRACE_JSONL_SUFFIX)]
    # Python line: return Path(path).stem
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    return Path(path).stem


# Python line: def nvidia_smi_sidecar_path(trace_path: Union[str, Path]) -> Path:
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def nvidia_smi_sidecar_path(trace_path: Union[str, Path]) -> Path:
    """Return ``{prompt_id}.nvidia_smi.csv`` beside a v1 or v2 trace file."""
    # Python line: path = Path(trace_path)
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    path = Path(trace_path)
    # Python line: return path.parent / f"{trace_path_stem(path)}.nvidia_smi.csv"
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    return path.parent / f"{trace_path_stem(path)}.nvidia_smi.csv"


# Python line: def write_trace_jsonl_file(
# Phase 3.1 LLM call recorder (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def write_trace_jsonl_file(
    path: Path,
    rows: Iterable[Dict[str, Any]],
) -> None:
    """
    Persist trace rows as JSONL (v1) or ZSTD-compressed JSONL (v2).

    Compression is selected by the ``.jsonl.zst`` suffix; v1 uses plain ``.jsonl``.
    """
    # Python line: path.parent.mkdir(parents=True, exist_ok=True)
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    path.parent.mkdir(parents=True, exist_ok=True)
    # Python line: if is_compressed_trace_path(path):
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    if is_compressed_trace_path(path):
        # Python line: cctx = zstandard.ZstdCompressor(level=ZSTD_COMPRESSION_LEVEL)
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        cctx = zstandard.ZstdCompressor(level=ZSTD_COMPRESSION_LEVEL)
        # Python line: with path.open("wb") as raw_out:
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        with path.open("wb") as raw_out:
            # Python line: with cctx.stream_writer(raw_out) as compressor:
            # Phase 3.1 LLM call recorder (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            with cctx.stream_writer(raw_out) as compressor:
                # Python line: text_out = io.TextIOWrapper(
                # Phase 3.1 LLM call recorder (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                text_out = io.TextIOWrapper(
                    # Python line: compressor, encoding="utf-8", write_through=True
                    # Phase 3.1 LLM call recorder (src/tracing).
                    # Implements .cursorrules dense-comment policy for src/ code.
                    compressor,
                    encoding="utf-8",
                    write_through=True,
                # Python line: )
                # Phase 3.1 LLM call recorder (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                )
                # Python line: for row in rows:
                # Phase 3.1 LLM call recorder (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                for row in rows:
                    # Python line: text_out.write(json.dumps(row, ensure_ascii=False) + "\n")
                    # Phase 3.1 LLM call recorder (src/tracing).
                    # Implements .cursorrules dense-comment policy for src/ code.
                    text_out.write(json.dumps(row, ensure_ascii=False) + "\n")
                # Python line: text_out.flush()
                # Phase 3.1 LLM call recorder (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                text_out.flush()
        # Python line: return
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return
    # Python line: with path.open("w", encoding="utf-8") as handle:
    # Phase 3.1 LLM call recorder (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    with path.open("w", encoding="utf-8") as handle:
        # Python line: for row in rows:
        # Phase 3.1 LLM call recorder (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        for row in rows:
            # Python line: handle.write(json.dumps(row, ensure_ascii=False) + "\n")
            # Phase 3.1 LLM call recorder (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
