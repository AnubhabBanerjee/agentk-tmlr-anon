"""
Phase 3.1 — AgentK tracing hooks + per-run JSONL artifact writer.

Wraps LangGraph nodes for wall-clock + VRAM boundary snapshots, hooks ``get_llm``
for token accounting, and computes proxy ground-truth labels after each invoke.
"""

# Python line: from __future__ import annotations
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
from __future__ import annotations

# json serializes per-run trace records to data/traces/.../*.jsonl.
# Python line: import json
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
import json
# subprocess captures ``nvcc --version`` for run metadata.
# Python line: import subprocess
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
import subprocess
# time records per-node wall-clock intervals.
# Python line: import time
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
import time
# dataclass holds one node event row mandated by guide §3.1.
# Python line: from collections import Counter
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
from collections import Counter
# dataclass stores node events and run-level counters.
# Python line: from dataclasses import dataclass, field
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
from dataclasses import dataclass, field
# Path writes trace JSONL under data/traces/{agent}/{prompt_id}.jsonl.
# Python line: from pathlib import Path
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
from pathlib import Path
# typing annotates LangGraph state dicts and hook restore handles.
# Python line: from typing import Any, Callable, Dict, List, Mapping, Optional, Tuple
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
from typing import Any, Callable, Dict, List, Mapping, Optional, Tuple

# VramSampler polls NVML during each AgentK run.
# Python line: from src.tracing.llm_recorder import LlmCallRecorder, install_traced_get_llm
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
from src.tracing.llm_recorder import (
    LlmCallRecorder,
    install_global_chatopenai_tracing,
    install_traced_get_llm,
    nvidia_smi_sidecar_path,
    set_active_chatopenai_recorder,
    trace_path_stem,
    write_trace_jsonl_file,
)
# write_cuda_sidecar must import before KC ``src`` shadows repo ``src`` on sys.path.
# Python line: from src.correctness.cuda_sidecar import write_cuda_sidecar
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
from src.correctness.cuda_sidecar import write_cuda_sidecar
# agentk_llama_compat applies llama.cpp patches and rebuilds the LangGraph app.
# Python line: from src.tracing.agentk_llama_compat import apply_agentk_llama_shim, build_agentk_app
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
from src.tracing.agentk_llama_compat import apply_agentk_llama_shim, build_agentk_app
# VramSampler provides per-step VRAM samples for M_peak / M_trajectory labels.
# Python line: from src.tracing.vram_sampler import VramSampler
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
from src.tracing.vram_sampler import VramSampler
# Q4_K_M closed-form VRAM accounting payload for trace metadata (§3.2).
# Python line: from src.forecast.q4_km_accounting import (
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
from src.forecast.q4_km_accounting import (
    # Python line: closed_form_accounting_payload,
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    closed_form_accounting_payload,
    # Python line: closed_form_peak_labels,
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    closed_form_peak_labels,
    # Python line: load_model_calibration,
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    load_model_calibration,
)


from src.tracing.n_labels import compute_n_e_labels
# Python line: _BASE_NODE_TYPES: Tuple[str, ...] = (
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
_BASE_NODE_TYPES: Tuple[str, ...] = (
    # Python line: "planner",
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    "planner",
    # Python line: "analyzer",
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    "analyzer",
    # Python line: "optimizer",
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    "optimizer",
    # Python line: "generator",
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    "generator",
    # Python line: "critic",
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    "critic",
# Python line: )
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
)


# Python line: @dataclass
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
@dataclass
# Python line: class NodeEvent:
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
class NodeEvent:
    """Per-node event log row from step_by_step_execution_guide §3.1."""

    # Python line: node_name: str
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    node_name: str
    # Python line: t_wall_start: float
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    t_wall_start: float
    # Python line: t_wall_end: float
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    t_wall_end: float
    # Python line: tokens_in: int
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    tokens_in: int
    # Python line: tokens_out: int
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    tokens_out: int
    # Python line: tokens_prompt: int
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    tokens_prompt: int
    # Python line: tokens_completion: int
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    tokens_completion: int

    # Python line: def to_dict(self) -> Dict[str, Any]:
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to the JSON field names required by §3.1."""
        # Python line: return {
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return {
            # Python line: "node_name": self.node_name,
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            "node_name": self.node_name,
            # Python line: "t_wall_start": self.t_wall_start,
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            "t_wall_start": self.t_wall_start,
            # Python line: "t_wall_end": self.t_wall_end,
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            "t_wall_end": self.t_wall_end,
            # Python line: "tokens_in": self.tokens_in,
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            "tokens_in": self.tokens_in,
            # Python line: "tokens_out": self.tokens_out,
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            "tokens_out": self.tokens_out,
            # Python line: "tokens_prompt": self.tokens_prompt,
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            "tokens_prompt": self.tokens_prompt,
            # Python line: "tokens_completion": self.tokens_completion,
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            "tokens_completion": self.tokens_completion,
        # Python line: }
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        }


# Python line: @dataclass
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
@dataclass
# Python line: class TraceSession:
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
class TraceSession:
    """Mutable collector for one AgentK traced run."""

    # Python line: vram: VramSampler
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    vram: Any
    # Python line: llm: LlmCallRecorder = field(default_factory=LlmCallRecorder)
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    llm: LlmCallRecorder = field(default_factory=LlmCallRecorder)
    # Python line: node_events: List[NodeEvent] = field(default_factory=list)
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    node_events: List[NodeEvent] = field(default_factory=list)
    # Python line: n_compile_attempts: int = 0
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    n_compile_attempts: int = 0
    # Python line: run_t0: float = 0.0
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    run_t0: float = 0.0
    # Python line: timeout: bool = False
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    timeout: bool = False
    # Python line: oom: bool = False
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    oom: bool = False
    # Python line: error: Optional[str] = None
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    error: Optional[str] = None
    # Python line: node_invocation_counts: Counter[str] = field(default_factory=Counter)
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    node_invocation_counts: Counter[str] = field(default_factory=Counter)

    # Python line: def reset_for_new_run(self) -> None:
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def reset_for_new_run(self) -> None:
        """Clear per-run buffers before the next (agent_llm, prompt_id) invoke."""
        # Python line: self.node_events.clear()
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self.node_events.clear()
        # Python line: self.llm.calls.clear()
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self.llm.calls.clear()
        # Python line: self.n_compile_attempts = 0
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self.n_compile_attempts = 0
        # Python line: self.node_invocation_counts.clear()
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self.node_invocation_counts.clear()
        # Python line: self.timeout = False
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self.timeout = False
        # Python line: self.oom = False
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self.oom = False
        # Python line: self.error = None
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        self.error = None


# Python line: def _base_node_name(node_name: str) -> str:
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def _base_node_name(node_name: str) -> str:
    """Strip ``@retry_k`` suffix for T_true aggregation."""
    # Python line: if "@retry_" in node_name:
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    if "@retry_" in node_name:
        # Python line: return node_name.split("@retry_", 1)[0]
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return node_name.split("@retry_", 1)[0]
    # Python line: return node_name
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    return node_name


# Python line: def _logical_node_name(base: str, invocation_idx: int) -> str:
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def _logical_node_name(base: str, invocation_idx: int) -> str:
    """First call uses base name; retries use ``base@retry_k`` (§3.1)."""
    # Python line: if invocation_idx <= 0:
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    if invocation_idx <= 0:
        # Python line: return base
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return base
    # Python line: return f"{base}@retry_{invocation_idx}"
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    return f"{base}@retry_{invocation_idx}"


# Python line: def _wrap_node_for_tracing(
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def _wrap_node_for_tracing(
    *,
    base_name: str,
    node_fn: Callable[[Any], dict],
    session: TraceSession,
    is_critic: bool = False,
) -> Callable[[Any], dict]:
    """Return a node wrapper that logs timing, VRAM boundaries, and tokens."""

    # Python line: def wrapped(state: Any) -> dict:
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    def wrapped(state: Any) -> dict:
        # Python line: idx = session.node_invocation_counts[base_name]
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        idx = session.node_invocation_counts[base_name]
        # Python line: session.node_invocation_counts[base_name] += 1
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        session.node_invocation_counts[base_name] += 1
        # Python line: logical = _logical_node_name(base_name, idx)
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        logical = _logical_node_name(base_name, idx)
        # Python line: token = session.llm.set_active_node(logical)
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        token = session.llm.set_active_node(logical)
        # Python line: t_start = time.perf_counter()
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        t_start = time.perf_counter()
        # Python line: session.vram.snapshot_boundary(f"{logical}:start")
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        session.vram.snapshot_boundary(f"{logical}:start")
        # Python line: try:
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        try:
            # Python line: result = node_fn(state)
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            result = node_fn(state)
        # Python line: finally:
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        finally:
            # Python line: session.llm.reset_active_node(token)
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            session.llm.reset_active_node(token)
        # Python line: t_end = time.perf_counter()
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        t_end = time.perf_counter()
        # Python line: session.vram.snapshot_boundary(f"{logical}:end")
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        session.vram.snapshot_boundary(f"{logical}:end")
        # Python line: totals = session.llm.totals_for_node(logical)
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        totals = session.llm.totals_for_node(logical)
        # Python line: session.node_events.append(
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        session.node_events.append(
            # Python line: NodeEvent(
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            NodeEvent(
                # Python line: node_name=logical,
                # Phase 3.1 KC trace integration (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                node_name=logical,
                # Python line: t_wall_start=round(t_start - session.run_t0, 6),
                # Phase 3.1 KC trace integration (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                t_wall_start=round(t_start - session.run_t0, 6),
                # Python line: t_wall_end=round(t_end - session.run_t0, 6),
                # Phase 3.1 KC trace integration (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                t_wall_end=round(t_end - session.run_t0, 6),
                # Python line: tokens_in=totals["tokens_in"],
                # Phase 3.1 KC trace integration (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                tokens_in=totals["tokens_in"],
                # Python line: tokens_out=totals["tokens_out"],
                # Phase 3.1 KC trace integration (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                tokens_out=totals["tokens_out"],
                # Python line: tokens_prompt=totals["tokens_prompt"],
                # Phase 3.1 KC trace integration (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                tokens_prompt=totals["tokens_prompt"],
                # Python line: tokens_completion=totals["tokens_completion"],
                # Phase 3.1 KC trace integration (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                tokens_completion=totals["tokens_completion"],
            # Python line: )
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            )
        # Python line: )
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        )
        # Python line: if is_critic:
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        if is_critic:
            # Each critic invocation runs one ``nvcc -c`` attempt.
            # Python line: session.n_compile_attempts += 1
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            session.n_compile_attempts += 1
        # Python line: return result
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return result

    # Python line: return wrapped
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    return wrapped


# Python line: def install_agentk_tracing(session: TraceSession) -> Dict[str, Callable[..., Any]]:
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def install_agentk_tracing(session: TraceSession) -> Dict[str, Callable[..., Any]]:
    """
    Wrap AgentK node callables and ``get_llm`` for one trace session.

    Returns a restore dict with original callables for cleanup after the run.
    """
    # Python line: import src.config as agentk_config
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.config as agentk_config
    # Python line: import src.nodes.analyzer as analyzer_mod
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.nodes.analyzer as analyzer_mod
    # Python line: import src.nodes.critic as critic_mod
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.nodes.critic as critic_mod
    # Python line: import src.nodes.generator as generator_mod
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.nodes.generator as generator_mod
    # Python line: import src.nodes.optimizer as optimizer_mod
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.nodes.optimizer as optimizer_mod
    # Python line: import src.nodes.planner as planner_mod
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.nodes.planner as planner_mod

    # Python line: restore: Dict[str, Callable[..., Any]] = {
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    restore: Dict[str, Callable[..., Any]] = {
        "get_llm": install_traced_get_llm(session.llm),
        "chatopenai_invoke": install_global_chatopenai_tracing(session.llm),
        # Python line: "planner": planner_mod.planner_node,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "planner": planner_mod.planner_node,
        # Python line: "analyzer": analyzer_mod.analyzer_node,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "analyzer": analyzer_mod.analyzer_node,
        # Python line: "optimizer": optimizer_mod.optimizer_node,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "optimizer": optimizer_mod.optimizer_node,
        # Python line: "generator": generator_mod.generator_node,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "generator": generator_mod.generator_node,
        # Python line: "critic": critic_mod.critic_node,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "critic": critic_mod.critic_node,
    # Python line: }
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    }
    # Python line: counter: Counter[str] = Counter()
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    planner_mod.planner_node = _wrap_node_for_tracing(
        base_name="planner",
        node_fn=restore["planner"],
        session=session,
    )
    analyzer_mod.analyzer_node = _wrap_node_for_tracing(
        base_name="analyzer",
        node_fn=restore["analyzer"],
        session=session,
    )
    optimizer_mod.optimizer_node = _wrap_node_for_tracing(
        base_name="optimizer",
        node_fn=restore["optimizer"],
        session=session,
    )
    generator_mod.generator_node = _wrap_node_for_tracing(
        base_name="generator",
        node_fn=restore["generator"],
        session=session,
    )
    critic_mod.critic_node = _wrap_node_for_tracing(
        base_name="critic",
        node_fn=restore["critic"],
        session=session,
        is_critic=True,
    )
    # Python line: return restore
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    return restore


# Python line: def restore_agentk_tracing(restore: Dict[str, Callable[..., Any]]) -> None:
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def restore_agentk_tracing(restore: Dict[str, Callable[..., Any]]) -> None:
    """Undo tracing monkey-patches so the next run starts from a clean KC state."""
    # Python line: import src.config as agentk_config
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.config as agentk_config
    # Python line: import src.nodes.analyzer as analyzer_mod
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.nodes.analyzer as analyzer_mod
    # Python line: import src.nodes.critic as critic_mod
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.nodes.critic as critic_mod
    # Python line: import src.nodes.generator as generator_mod
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.nodes.generator as generator_mod
    # Python line: import src.nodes.optimizer as optimizer_mod
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.nodes.optimizer as optimizer_mod
    # Python line: import src.nodes.planner as planner_mod
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.nodes.planner as planner_mod

    # Python line: agentk_config.get_llm = restore["get_llm"]
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    agentk_config.get_llm = restore["get_llm"]
    # Python line: planner_mod.planner_node = restore["planner"]
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    planner_mod.planner_node = restore["planner"]
    # Python line: analyzer_mod.analyzer_node = restore["analyzer"]
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    analyzer_mod.analyzer_node = restore["analyzer"]
    # Python line: optimizer_mod.optimizer_node = restore["optimizer"]
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    optimizer_mod.optimizer_node = restore["optimizer"]
    # Python line: generator_mod.generator_node = restore["generator"]
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    generator_mod.generator_node = restore["generator"]
    # Python line: critic_mod.critic_node = restore["critic"]
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    critic_mod.critic_node = restore["critic"]


# Python line: def build_traced_agentk_app(*, session: TraceSession, max_retries: int):
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def build_traced_agentk_app(*, session: TraceSession, max_retries: int):
    """Apply llama.cpp shim, install tracing hooks, compile LangGraph app."""
    # Shim must run before tracing wraps the patched node callables.
    # Python line: apply_agentk_llama_shim(smoke_fallback=False)
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    apply_agentk_llama_shim(smoke_fallback=False)
    # Python line: install_agentk_tracing(session)
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    install_agentk_tracing(session)
    # Python line: return build_agentk_app(max_retries=max_retries)
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    return build_agentk_app(max_retries=max_retries)


# Python line: def _nvcc_version() -> str:
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def _nvcc_version() -> str:
    """Best-effort ``nvcc --version`` string for trace metadata."""
    # Python line: try:
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    try:
        # Python line: proc = subprocess.run(
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        proc = subprocess.run(
            # Python line: ["nvcc", "--version"],
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            ["nvcc", "--version"],
            # Python line: capture_output=True,
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            capture_output=True,
            # Python line: text=True,
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            text=True,
            # Python line: check=False,
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            check=False,
        # Python line: )
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        )
        # Python line: return (proc.stdout or proc.stderr or "").strip()
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return (proc.stdout or proc.stderr or "").strip()
    # Python line: except Exception:
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    except Exception:
        # Python line: return "unknown"
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return "unknown"


# Python line: def _hardware_id() -> str:
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def _hardware_id() -> str:
    """Return GPU product name via NVML for metadata."""
    # Python line: try:
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    try:
        # Python line: import pynvml
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        import pynvml

        # Python line: pynvml.nvmlInit()
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        pynvml.nvmlInit()
        # Python line: handle = pynvml.nvmlDeviceGetHandleByIndex(0)
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        handle = pynvml.nvmlDeviceGetHandleByIndex(0)
        # Python line: return pynvml.nvmlDeviceGetName(handle).decode("utf-8")
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return pynvml.nvmlDeviceGetName(handle).decode("utf-8")
    # Python line: except Exception:
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    except Exception:
        # Python line: return "unknown"
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return "unknown"


# Python line: def compute_ground_truth_labels(session: TraceSession) -> Dict[str, Any]:
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def compute_ground_truth_labels(session: TraceSession) -> Dict[str, Any]:
    """Compute N_true (F2: total completion tokens), T_true, E_true, M_peak, trajectory."""
    total_completion = sum(e.tokens_completion for e in session.node_events)
    n_labels = compute_n_e_labels(
        [
            {
                "tokens_completion": e.tokens_completion,
            }
            for e in session.node_events
        ]
    )
    n_true = int(n_labels["N_true"])
    n_nodes_true = int(n_labels["N_nodes_true"])
    e_true = float(n_labels["E_true"])
    # Python line: t_true: Dict[str, Dict[str, Any]] = {}
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    t_true: Dict[str, Dict[str, Any]] = {}
    # Python line: for base in _BASE_NODE_TYPES:
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    for base in _BASE_NODE_TYPES:
        # Python line: rows = [e for e in session.node_events if _base_node_name(e.node_name) == base]
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        rows = [e for e in session.node_events if _base_node_name(e.node_name) == base]
        # Python line: executed = len(rows)
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        executed = len(rows)
        # Python line: avg_out = (
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        avg_out = (
            # Python line: sum(r.tokens_completion for r in rows) / executed if executed else 0.0
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            sum(r.tokens_completion for r in rows) / executed if executed else 0.0
        # Python line: )
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        )
        # Python line: t_true[base] = {"executed": executed, "avg_tokens_out": round(avg_out, 3)}
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        t_true[base] = {"executed": executed, "avg_tokens_out": round(avg_out, 3)}
    # Python line: m_peak = session.vram.peak_used_mb()
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    m_peak = session.vram.peak_used_mb()
    # Python line: if session.oom and session.vram.vram_total_mb is not None:
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    if session.oom and session.vram.vram_total_mb is not None:
        # Python line: m_peak = session.vram.vram_total_mb
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        m_peak = session.vram.vram_total_mb
    # Python line: trajectory = [
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    trajectory = [
        # Python line: {"boundary": label, "t_ms": t_ms, "vram_used_mb": vram}
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        {"boundary": label, "t_ms": t_ms, "vram_used_mb": vram}
        # Python line: for label, t_ms, vram in session.vram.boundary_trajectory()
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        for label, t_ms, vram in session.vram.boundary_trajectory()
    # Python line: ]
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    ]
    # Python line: return {
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    return {
        # Python line: "N_true": n_true,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "N_true": n_true,
        "N_nodes_true": n_nodes_true,
        # Python line: "T_true": t_true,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "T_true": t_true,
        "t_true_semantics": "avg_completion_tokens_per_node_f3",
        # Python line: "E_true": round(e_true, 6),
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "E_true": round(e_true, 6),
        # Python line: "M_peak_true": round(m_peak, 3),
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "M_peak_true": round(m_peak, 3),
        # Python line: "M_trajectory_true": trajectory,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "M_trajectory_true": trajectory,
    # Python line: }
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    }


# Python line: def _vram_at_generator_start_from_session(session: TraceSession) -> Optional[float]:
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def _vram_at_generator_start_from_session(session: TraceSession) -> Optional[float]:
    """Return VRAM (MiB) at the first generator node boundary in this run."""
    # Python line: for label, _t_ms, vram in session.vram.boundary_trajectory():
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    for label, _t_ms, vram in session.vram.boundary_trajectory():
        # Python line: if label == "generator:start" or (
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        if label == "generator:start" or (
            # Python line: label.startswith("generator@retry_") and label.endswith(":start")
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            label.startswith("generator@retry_") and label.endswith(":start")
        # Python line: ):
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        ):
            # Python line: return float(vram)
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            return float(vram)
    # Python line: return None
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    return None


# Python line: def enrich_labels_with_closed_form(
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def enrich_labels_with_closed_form(
    *,
    session: TraceSession,
    labels: Dict[str, Any],
    accounting: Mapping[str, Any],
) -> Dict[str, Any]:
    """Attach Q4_K_M closed-form peak VRAM fields to the trace summary (§3.2)."""
    # Python line: n_steps = int(labels.get("N_true", 0))
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    n_steps = int(labels.get("N_nodes_true", labels.get("N_true", 0)))
    # Python line: l_base = float(session.node_events[0].tokens_in) if session.node_events else 0.0
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    l_base = float(session.node_events[0].tokens_in) if session.node_events else 0.0
    # Python line: e_hat = float(labels.get("E_true", 0.0))
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    e_hat = float(labels.get("E_true", 0.0))
    # Python line: gen_vram = _vram_at_generator_start_from_session(session)
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    gen_vram = _vram_at_generator_start_from_session(session)
    # Python line: peak_fields = closed_form_peak_labels(
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    peak_fields = closed_form_peak_labels(
        # Python line: accounting=accounting,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        accounting=accounting,
        # Python line: n_steps=n_steps,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        n_steps=n_steps,
        # Python line: l_base=l_base,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        l_base=l_base,
        # Python line: e_hat=e_hat,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        e_hat=e_hat,
        # Python line: vram_at_generator_start_mb=gen_vram,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        vram_at_generator_start_mb=gen_vram,
    # Python line: )
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: return {**labels, **peak_fields}
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    return {**labels, **peak_fields}


# Python line: def write_trace_jsonl(
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def write_trace_jsonl(
    *,
    output_path: Path,
    metadata: Dict[str, Any],
    session: TraceSession,
    final_state: Dict[str, Any],
    labels: Dict[str, Any],
) -> None:
    """Persist one traced run as multi-line JSONL (metadata, events, samples, summary)."""
    # Python line: output_path.parent.mkdir(parents=True, exist_ok=True)
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    output_path.parent.mkdir(parents=True, exist_ok=True)
    # Python line: accounting = metadata.get("closed_form_accounting")
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    accounting = metadata.get("closed_form_accounting")
    # Python line: if isinstance(accounting, dict) and accounting:
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    if isinstance(accounting, dict) and accounting:
        # Python line: labels = enrich_labels_with_closed_form(
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        labels = enrich_labels_with_closed_form(
            # Python line: session=session,
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            session=session,
            # Python line: labels=labels,
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            labels=labels,
            # Python line: accounting=accounting,
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            accounting=accounting,
        # Python line: )
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        )
    # Python line: compile_success = bool(final_state.get("compilation_success"))
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    compile_success = bool(final_state.get("compilation_success"))
    # Python line: final_err = final_state.get("compiler_error") or ""
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    final_err = final_state.get("compiler_error") or ""
    # Python line: if not compile_success and not final_err:
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    if not compile_success and not final_err:
        # Python line: final_err = final_state.get("nvcc_diagnostic_log") or ""
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        final_err = final_state.get("nvcc_diagnostic_log") or ""
    # Python line: summary = {
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    summary = {
        # Python line: **labels,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        **labels,
        # Python line: "compile_success": compile_success,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "compile_success": compile_success,
        # Python line: "n_compile_attempts": session.n_compile_attempts,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "n_compile_attempts": session.n_compile_attempts,
        # Python line: "final_compile_error": (final_err[:1024] if final_err else None),
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "final_compile_error": (final_err[:1024] if final_err else None),
        # Python line: "retry_count": int(final_state.get("retry_count", 0)),
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "retry_count": int(final_state.get("retry_count", 0)),
        # Python line: "timeout": session.timeout,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "timeout": session.timeout,
        # Python line: "oom": session.oom,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "oom": session.oom,
        # Python line: "error": session.error,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "error": session.error,
    # Python line: }
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    }
    # Python line: lines: List[Dict[str, Any]] = [
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    vram_method = getattr(session.vram, "method_name", "pynvml")
    metadata = {**metadata, "vram_sampler": vram_method}
    wall_t0 = getattr(session.vram, "wall_t0_epoch", None)
    if wall_t0 is not None:
        metadata["vram_wall_t0_epoch"] = float(wall_t0)
    sidecar_path = nvidia_smi_sidecar_path(output_path)
    if sidecar_path.is_file():
        metadata["nvidia_smi_sidecar"] = str(sidecar_path.name)
    lines: List[Dict[str, Any]] = [
        {"record": "metadata", **metadata},
    ]
    # Python line: for event in session.node_events:
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    for event in session.node_events:
        # Python line: lines.append({"record": "node_event", **event.to_dict()})
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        lines.append({"record": "node_event", **event.to_dict()})
    # Python line: for sample in session.vram.samples():
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    for sample in session.vram.samples():
        # Python line: lines.append(
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        lines.append(
            # Python line: {
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            {
                # Python line: "record": "vram_sample",
                # Phase 3.1 KC trace integration (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                "record": "vram_sample",
                # Python line: "t_ms": sample.t_ms,
                # Phase 3.1 KC trace integration (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                "t_ms": sample.t_ms,
                # Python line: "vram_used_mb": sample.vram_used_mb,
                # Phase 3.1 KC trace integration (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                "vram_used_mb": sample.vram_used_mb,
                # Python line: "boundary": sample.boundary,
                # Phase 3.1 KC trace integration (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                "boundary": sample.boundary,
            # Python line: }
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            }
        # Python line: )
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        )
    # Python line: lines.append({"record": "summary", **summary})
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    lines.append({"record": "summary", **summary})

    # Phase 3.5: persist final emitted CUDA for KernelBench harness (§3.5 sidecar).
    # Python line: source_code = final_state.get("source_code")
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    source_code = final_state.get("source_code")
    # Python line: if isinstance(source_code, str) and source_code.strip():
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    if isinstance(source_code, str) and source_code.strip():
        # Python line: agent_llm_id = str(metadata.get("agent_llm_id", output_path.parent.name))
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        agent_llm_id = str(metadata.get("agent_llm_id", output_path.parent.name))
        # Python line: prompt_id = str(metadata.get("prompt_id", output_path.stem))
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        prompt_id = str(metadata.get("prompt_id", trace_path_stem(output_path)))
        # Python line: repo_root = output_path.parents[3]
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        repo_root = output_path.parents[3]
        # Python line: sidecar_path = write_cuda_sidecar(
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        sidecar_path = write_cuda_sidecar(
            # Python line: repo_root=repo_root,
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            repo_root=repo_root,
            # Python line: agent_llm=agent_llm_id,
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            agent_llm=agent_llm_id,
            # Python line: prompt_id=prompt_id,
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            prompt_id=prompt_id,
            # Python line: source_code=source_code,
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            source_code=source_code,
        # Python line: )
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        )
        # Python line: summary["cuda_sidecar"] = str(sidecar_path.relative_to(repo_root).as_posix())
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        summary["cuda_sidecar"] = str(sidecar_path.relative_to(repo_root).as_posix())
        # Python line: lines[-1] = {"record": "summary", **summary}
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        lines[-1] = {"record": "summary", **summary}

    # Phase 3.5 guard: compile-successful KernelBench runs must persist CUDA for harness.
    # Python line: if metadata.get("prompt_source") == "kernelbench" and summary.get("compile_success"):
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    if metadata.get("prompt_source") == "kernelbench" and summary.get("compile_success"):
        # Python line: if not summary.get("cuda_sidecar"):
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        if not summary.get("cuda_sidecar"):
            # Python line: raise RuntimeError(
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            raise RuntimeError(
                f"compile_success KernelBench trace missing CUDA sidecar: "
                f"{metadata.get('agent_llm_id')}/{metadata.get('prompt_id')}"
            )

    # Python line: with output_path.open("w", encoding="utf-8") as handle:
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    write_trace_jsonl_file(output_path, lines)


# Python line: def run_traced_agentk(
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def run_traced_agentk(
    *,
    agentk_app: Any,
    prompt: str,
    session: TraceSession,
    timeout_sec: int,
    vram_sidecar_path: Optional[Path] = None,
) -> Dict[str, Any]:
    """Invoke AgentK with VRAM sampling and optional wall-clock timeout."""
    # Python line: import concurrent.futures
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    import concurrent.futures

    # Python line: state = {
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    state = {
        # Python line: "task": prompt,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "task": prompt,
        # Python line: "retry_count": 0,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "retry_count": 0,
        # Python line: "compilation_success": False,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "compilation_success": False,
        # Python line: "nvcc_diagnostic_log": None,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "nvcc_diagnostic_log": None,
    # Python line: }
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    }
    # Python line: session.run_t0 = time.perf_counter()
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    session.reset_for_new_run()
    set_active_chatopenai_recorder(session.llm)
    # Python line: session.run_t0 = time.perf_counter()
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    session.run_t0 = time.perf_counter()
    # Python line: session.vram.start()
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    session.vram.start(persist_csv_path=vram_sidecar_path)
    # Python line: try:
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    try:
        # Python line: with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            # Python line: future = pool.submit(agentk_app.invoke, state)
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            future = pool.submit(agentk_app.invoke, state)
            # Python line: try:
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            try:
                # Python line: return future.result(timeout=timeout_sec)
                # Phase 3.1 KC trace integration (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                return future.result(timeout=timeout_sec)
            # Python line: except concurrent.futures.TimeoutError:
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            except concurrent.futures.TimeoutError:
                # Python line: session.timeout = True
                # Phase 3.1 KC trace integration (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                session.timeout = True
                # Python line: session.error = f"timeout after {timeout_sec}s"
                # Phase 3.1 KC trace integration (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                session.error = f"timeout after {timeout_sec}s"
                # Python line: return {
                # Phase 3.1 KC trace integration (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                return {
                    # Python line: **state,
                    # Phase 3.1 KC trace integration (src/tracing).
                    # Implements .cursorrules dense-comment policy for src/ code.
                    **state,
                    # Python line: "compilation_success": False,
                    # Phase 3.1 KC trace integration (src/tracing).
                    # Implements .cursorrules dense-comment policy for src/ code.
                    "compilation_success": False,
                # Python line: }
                # Phase 3.1 KC trace integration (src/tracing).
                # Implements .cursorrules dense-comment policy for src/ code.
                }
    # Python line: except Exception as exc:
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    except Exception as exc:
        # Python line: msg = str(exc).lower()
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        msg = str(exc).lower()
        # Python line: if "out of memory" in msg or "oom" in msg or "cuda" in msg and "memory" in msg:
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        if "out of memory" in msg or "oom" in msg or ("cuda" in msg and "memory" in msg):
            # Python line: session.oom = True
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            session.oom = True
        # Python line: session.error = str(exc)
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        session.error = str(exc)
        # Python line: return {**state, "compilation_success": False}
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        return {**state, "compilation_success": False}
    # Python line: finally:
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    finally:
        # Python line: session.vram.stop()
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        session.vram.stop()


# Python line: def build_run_metadata(
# Phase 3.1 KC trace integration (src/tracing).
# Implements .cursorrules dense-comment policy for src/ code.
def build_run_metadata(
    *,
    agent_llm_id: str,
    prompt_id: str,
    model_cfg: Dict[str, Any],
    seed: int,
    calibration_path: Optional[Path] = None,
) -> Dict[str, Any]:
    """Assemble global run metadata required by §3.1 and Q4 accounting (§3.2)."""
    # Python line: calibration = (
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    calibration = (
        # Python line: load_model_calibration(calibration_path, agent_llm_id)
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        load_model_calibration(
            calibration_path,
            agent_llm_id,
            cache_type_k=str(model_cfg.get("cache_type_k", "f16")),
            cache_type_v=str(model_cfg.get("cache_type_v", "f16")),
        )
        # Python line: if calibration_path is not None
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        if calibration_path is not None
        # Python line: else {}
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        else {}
    # Python line: )
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: closed_form: Dict[str, Any] = {}
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    closed_form: Dict[str, Any] = {}
    # Python line: if all(k in model_cfg for k in ("n_layers", "n_kv_heads", "d_head", "gguf_path")):
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    if all(k in model_cfg for k in ("n_layers", "n_kv_heads", "d_head", "gguf_path")):
        # Python line: closed_form = closed_form_accounting_payload(
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        closed_form = closed_form_accounting_payload(
            # Python line: model_cfg=model_cfg,
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            model_cfg=model_cfg,
            # Python line: calibration=calibration,
            # Phase 3.1 KC trace integration (src/tracing).
            # Implements .cursorrules dense-comment policy for src/ code.
            calibration=calibration,
        # Python line: )
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        )
    # Python line: return {
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    return {
        # Python line: "agent_llm_id": agent_llm_id,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "agent_llm_id": agent_llm_id,
        # Python line: "prompt_id": prompt_id,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "prompt_id": prompt_id,
        # Python line: "quantization": model_cfg.get("quantization", "Q4_K_M"),
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "quantization": model_cfg.get("quantization", "Q4_K_M"),
        # Python line: "n_ctx": model_cfg.get("n_ctx"),
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "n_ctx": model_cfg.get("n_ctx"),
        # Python line: "n_batch": model_cfg.get("n_batch"),
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "n_batch": model_cfg.get("n_batch"),
        # Python line: "cache_type_k": model_cfg.get("cache_type_k", "f16"),
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "cache_type_k": model_cfg.get("cache_type_k", "f16"),
        # Python line: "cache_type_v": model_cfg.get("cache_type_v", "f16"),
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "cache_type_v": model_cfg.get("cache_type_v", "f16"),
        # Python line: "b_precision": closed_form.get("b_precision"),
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "b_precision": closed_form.get("b_precision"),
        # Python line: "closed_form_accounting": closed_form,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "closed_form_accounting": closed_form,
        # Python line: "seed": seed,
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "seed": seed,
        # Python line: "nvcc_version": _nvcc_version(),
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "nvcc_version": _nvcc_version(),
        # Python line: "hardware_id": _hardware_id(),
        # Phase 3.1 KC trace integration (src/tracing).
        # Implements .cursorrules dense-comment policy for src/ code.
        "hardware_id": _hardware_id(),
    # Python line: }
    # Phase 3.1 KC trace integration (src/tracing).
    # Implements .cursorrules dense-comment policy for src/ code.
    }
