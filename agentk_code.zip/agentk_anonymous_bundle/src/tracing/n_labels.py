"""
F2 — ``N_true`` as total completion tokens across all AgentK nodes.

Preserves ``N_nodes_true`` (node execution count) for closed-form trajectory math.
"""

from __future__ import annotations

from typing import Any, Dict, List, Mapping, Sequence


def node_events_total_completion(node_events: Sequence[Mapping[str, Any]]) -> int:
    """Sum ``tokens_completion`` over all logged node events."""
    return int(sum(int(e.get("tokens_completion", 0) or 0) for e in node_events))


def compute_n_e_labels(
  node_events: Sequence[Mapping[str, Any]],
) -> Dict[str, Any]:
  """
  F2 ground-truth scalars for the step head and expansion head.

  - ``N_true``: total completion tokens (Poisson proxy target).
  - ``N_nodes_true``: node execution count (closed-form trajectory index).
  - ``E_true``: mean completion tokens per node execution.
  """
  n_nodes = len(node_events)
  total_completion = node_events_total_completion(node_events)
  e_true = (total_completion / n_nodes) if n_nodes else 0.0
  return {
    "N_true": int(total_completion),
    "N_nodes_true": int(n_nodes),
    "E_true": round(e_true, 6),
  }


def summary_from_node_event_records(
  records: List[Dict[str, Any]],
) -> Dict[str, int]:
  """Recompute F2 ``N_true`` / ``N_nodes_true`` from JSONL ``node_event`` rows."""
  events = [r for r in records if r.get("record") == "node_event"]
  labels = compute_n_e_labels(events)
  return {
    "N_true": int(labels["N_true"]),
    "N_nodes_true": int(labels["N_nodes_true"]),
  }
