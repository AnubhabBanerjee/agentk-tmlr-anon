"""
Part 2 / Plan A — v2 trace run planning (base + 3-corner sweep).

Replaces the v1 Cartesian ``cache_type_k_sweep × cache_type_v_sweep`` grid with an
explicit list of (k, v) corners and agent/prompt subset guards.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

from src.prompts.stratified_split import PromptRecord, stratified_kv_cache_sweep_subset

LEGACY_SWEEP_KEYS: Tuple[str, ...] = (
    "cache_type_k_sweep",
    "cache_type_v_sweep",
    "kv_cache_sweep_subset_size",
)


@dataclass(frozen=True)
class V2SweepConfig:
    """Resolved Part-2 sweep axes (from YAML + optional CLI overrides)."""

    n_ctx_sweep: Tuple[int, ...]
    cache_type_sweep: Tuple[Tuple[str, str], ...]
    sweep_subset_prompts: int
    sweep_subset_agents: frozenset[str]
    baseline_k: str
    baseline_v: str
    base_n_ctx: int


@dataclass(frozen=True)
class TraceRunSpec:
    """One planned (agent, prompt, server config) trace execution."""

    model_id: str
    prompt_id: str
    n_ctx: int
    cache_type_k: str
    cache_type_v: str
    sweep: bool


def uses_v2_sweep_schema(tracing_cfg: Dict[str, Any]) -> bool:
    """Return True when the tracing config defines the v2 ``cache_type_sweep`` key."""
    return "cache_type_sweep" in tracing_cfg


def reject_legacy_sweep_keys(tracing_cfg: Dict[str, Any]) -> None:
    """Raise KeyError if deprecated Cartesian sweep keys are still present."""
    for key in LEGACY_SWEEP_KEYS:
        if key in tracing_cfg:
            raise KeyError(
                f"legacy sweep key {key!r} is not supported with the v2 schema; "
                "use cache_type_sweep, sweep_subset_prompts, and sweep_subset_agents"
            )


def _parse_int_list(raw: Any, *, field: str) -> List[int]:
    if raw is None:
        raise KeyError(f"missing required sweep field {field!r}")
    return [int(v) for v in raw]


def _parse_cache_type_sweep(raw: Any) -> List[Tuple[str, str]]:
    if raw is None:
        raise KeyError("missing required sweep field 'cache_type_sweep'")
    pairs: List[Tuple[str, str]] = []
    for item in raw:
        if not isinstance(item, (list, tuple)) or len(item) != 2:
            raise ValueError(
                "cache_type_sweep entries must be length-2 lists like [f16, f16]"
            )
        pairs.append((str(item[0]), str(item[1])))
    if not pairs:
        raise ValueError("cache_type_sweep must contain at least one (k, v) pair")
    return pairs


def parse_int_list_override(value: str, *, field: str) -> List[int]:
    """Parse CLI override: JSON array or comma-separated integers."""
    text = value.strip()
    if text.startswith("["):
        parsed = json.loads(text)
        if not isinstance(parsed, list):
            raise ValueError(f"{field} JSON override must be a list")
        return [int(v) for v in parsed]
    return [int(part.strip()) for part in text.split(",") if part.strip()]


def parse_cache_type_sweep_override(value: str) -> List[Tuple[str, str]]:
    """Parse CLI ``--cache-type-sweep`` JSON like '[["f16","f16"],...]'."""
    parsed = json.loads(value.strip())
    if not isinstance(parsed, list):
        raise ValueError("--cache-type-sweep must be a JSON list of [k, v] pairs")
    return _parse_cache_type_sweep(parsed)


def parse_agent_list_override(value: str) -> List[str]:
    """Parse comma-separated agent ids."""
    return [part.strip() for part in value.split(",") if part.strip()]


def load_v2_sweep_config(
    tracing_cfg: Dict[str, Any],
    *,
    n_ctx_sweep_override: Optional[str] = None,
    cache_type_sweep_override: Optional[str] = None,
    sweep_subset_prompts_override: Optional[int] = None,
    sweep_subset_agents_override: Optional[str] = None,
    base_n_ctx: int = 8192,
) -> V2SweepConfig:
    """Load and validate the v2 sweep schema from YAML (+ optional CLI overrides)."""
    reject_legacy_sweep_keys(tracing_cfg)

    if n_ctx_sweep_override is not None:
        n_ctx_values = parse_int_list_override(
            n_ctx_sweep_override, field="n_ctx_sweep"
        )
    else:
        n_ctx_values = _parse_int_list(tracing_cfg.get("n_ctx_sweep"), field="n_ctx_sweep")

    if cache_type_sweep_override is not None:
        cache_pairs = parse_cache_type_sweep_override(cache_type_sweep_override)
    else:
        cache_pairs = _parse_cache_type_sweep(tracing_cfg.get("cache_type_sweep"))

    if sweep_subset_prompts_override is not None:
        subset_n = int(sweep_subset_prompts_override)
    else:
        if "sweep_subset_prompts" not in tracing_cfg:
            raise KeyError("missing required sweep field 'sweep_subset_prompts'")
        subset_n = int(tracing_cfg["sweep_subset_prompts"])

    if sweep_subset_agents_override is not None:
        agent_ids = parse_agent_list_override(sweep_subset_agents_override)
    else:
        raw_agents = tracing_cfg.get("sweep_subset_agents")
        if not raw_agents:
            raise KeyError("missing required sweep field 'sweep_subset_agents'")
        agent_ids = [str(a) for a in raw_agents]

    baseline_k = str(tracing_cfg.get("kv_cache_baseline_k", "f16"))
    baseline_v = str(tracing_cfg.get("kv_cache_baseline_v", "f16"))

    return V2SweepConfig(
        n_ctx_sweep=tuple(n_ctx_values),
        cache_type_sweep=tuple(cache_pairs),
        sweep_subset_prompts=subset_n,
        sweep_subset_agents=frozenset(agent_ids),
        baseline_k=baseline_k,
        baseline_v=baseline_v,
        base_n_ctx=int(base_n_ctx),
    )


def sweep_subset_prompt_ids(
    prompt_rows: Sequence[Dict[str, Any]],
    *,
    total: int,
    seed: int,
) -> Set[str]:
    """Stratified sweep-subset prompt ids drawn with ``split.seed`` from tracing_v2."""
    records = [
        PromptRecord(
            id=str(row["id"]),
            source=str(row["source"]),
            family=str(row["family"]),
            complexity=str(row["complexity"]),
            precision=str(row.get("precision", "")),
            prompt=str(row["prompt"]),
        )
        for row in prompt_rows
    ]
    return set(
        stratified_kv_cache_sweep_subset(records, total=total, seed=seed)
    )


def enumerate_v2_trace_runs(
    *,
    model_ids: Sequence[str],
    prompt_rows: Sequence[Dict[str, Any]],
    sweep_cfg: V2SweepConfig,
    sweep_prompt_ids: Set[str],
) -> List[TraceRunSpec]:
    """
    Enumerate base + sweep runs for the Part-2 v2 batch.

    Base: every agent × every prompt × (base_n_ctx, baseline_k, baseline_v).
    Sweep: sweep_subset_agents × sweep_prompt_ids × n_ctx_sweep × cache_type_sweep.
    """
    runs: List[TraceRunSpec] = []
    prompt_ids = [str(row["id"]) for row in prompt_rows]

    for model_id in model_ids:
        for prompt_id in prompt_ids:
            runs.append(
                TraceRunSpec(
                    model_id=model_id,
                    prompt_id=prompt_id,
                    n_ctx=sweep_cfg.base_n_ctx,
                    cache_type_k=sweep_cfg.baseline_k,
                    cache_type_v=sweep_cfg.baseline_v,
                    sweep=False,
                )
            )

        if model_id not in sweep_cfg.sweep_subset_agents:
            continue

        for prompt_id in sorted(sweep_prompt_ids):
            if prompt_id not in prompt_ids:
                continue
            for n_ctx in sweep_cfg.n_ctx_sweep:
                for cache_k, cache_v in sweep_cfg.cache_type_sweep:
                    runs.append(
                        TraceRunSpec(
                            model_id=model_id,
                            prompt_id=prompt_id,
                            n_ctx=int(n_ctx),
                            cache_type_k=cache_k,
                            cache_type_v=cache_v,
                            sweep=True,
                        )
                    )

    return runs


def count_v2_trace_runs(
    *,
    n_agents: int,
    n_prompts: int,
    sweep_cfg: V2SweepConfig,
) -> Tuple[int, int, int]:
    """Return (base_count, sweep_count, total) for the canonical v2 formula."""
    base = n_agents * n_prompts
    sweep = (
        len(sweep_cfg.sweep_subset_agents)
        * sweep_cfg.sweep_subset_prompts
        * len(sweep_cfg.n_ctx_sweep)
        * len(sweep_cfg.cache_type_sweep)
    )
    return base, sweep, base + sweep


def format_v2_dry_run_summary(
    *,
    n_agents: int,
    n_prompts: int,
    sweep_cfg: V2SweepConfig,
    planned_total: int,
) -> str:
    """Human-readable dry-run summary matching the §A1 1920-run budget."""
    base, sweep, formula_total = count_v2_trace_runs(
        n_agents=n_agents,
        n_prompts=n_prompts,
        sweep_cfg=sweep_cfg,
    )
    n_sweep_agents = len(sweep_cfg.sweep_subset_agents)
    n_ctx_n = len(sweep_cfg.n_ctx_sweep)
    n_cache_n = len(sweep_cfg.cache_type_sweep)
    lines = [
        f"Planned v2 trace runs: {planned_total}",
        (
            f"  base: {n_agents} agents × {n_prompts} prompts × 1 base config "
            f"(n_ctx={sweep_cfg.base_n_ctx}, {sweep_cfg.baseline_k}/{sweep_cfg.baseline_v}) "
            f"= {base}"
        ),
        (
            f"  sweep: {n_sweep_agents} sweep agents × {sweep_cfg.sweep_subset_prompts} prompts "
            f"× {n_ctx_n} n_ctx × {n_cache_n} cache_type = {sweep}"
        ),
        (
            f"  formula check: {base} + {sweep} = {formula_total}"
            + (" OK" if formula_total == planned_total else " MISMATCH")
        ),
    ]
    return "\n".join(lines)


def trace_output_path_v2(
    trace_root,
    *,
    model_id: str,
    prompt_id: str,
    n_ctx: int,
    cache_type_k: str,
    cache_type_v: str,
    sweep: bool,
) -> Any:
    """Return output path for a v2 base or sweep trace."""
    from pathlib import Path

    root = Path(trace_root)
    if sweep:
        stem = (
            f"{prompt_id}__ctx{n_ctx}__k{cache_type_k}__v{cache_type_v}"
        )
        return root / model_id / "sweep" / f"{stem}.jsonl.zst"
    return root / model_id / f"{prompt_id}.jsonl.zst"


def filter_run_specs(
    runs: Iterable[TraceRunSpec],
    *,
    model_id: Optional[str] = None,
    prompt_ids: Optional[Set[str]] = None,
    limit: Optional[int] = None,
) -> List[TraceRunSpec]:
    """Apply CLI filters (--model, --prompt-ids, --limit on prompt corpus)."""
    filtered: List[TraceRunSpec] = []
    allowed_prompts: Optional[Set[str]] = None
    if limit is not None:
        # --limit trims the prompt *corpus* (first N ids in file order).
        ordered = sorted({r.prompt_id for r in runs})
        allowed_prompts = set(ordered[:limit])
    if prompt_ids is not None:
        allowed_prompts = (
            prompt_ids if allowed_prompts is None else allowed_prompts & prompt_ids
        )

    for spec in runs:
        if model_id is not None and spec.model_id != model_id:
            continue
        if allowed_prompts is not None and spec.prompt_id not in allowed_prompts:
            continue
        filtered.append(spec)
    return filtered
