"""
Compatibility shim: AgentK + llama.cpp OpenAI-compatible server.

AgentK uses LangChain ``with_structured_output`` (json_schema), which
llama.cpp does not implement. This module patches Planner/Analyzer/Optimizer
nodes to use plain chat completions + robust JSON parsing/normalization.
"""

# Python line: from __future__ import annotations
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
from __future__ import annotations

# Standard library imports for JSON repair, regex extraction, and typing.
# Python line: import json
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
import json
# Python line: import re
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
import re
# Python line: import sys
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
import sys
# Python line: from typing import Any, Callable, Optional
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
from typing import Any, Callable, Optional

# Chat prompt template used by all patched AgentK nodes.
# Python line: from langchain_core.prompts import ChatPromptTemplate
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
from langchain_core.prompts import ChatPromptTemplate


# Regex that locates the first JSON object in a free-form LLM response.
# Python line: _JSON_OBJECT_RE = re.compile(r"\{.*\}", re.DOTALL)
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
_JSON_OBJECT_RE = re.compile(r"\{.*\}", re.DOTALL)

# Minimal nvcc-clean kernels for Phase 1 smoke tests when local Q4 models stall.
# Used only when ``smoke_fallback=True`` after ``smoke_fallback_after`` critic failures.
_SMOKE_KERNEL_VECTOR_ADD = r"""
// CUDA line: #include <cuda_runtime.h>
// Part of smoke-test fallback kernel (agentk_llama_compat).
// Must compile with nvcc -c on local H100 without arch flags.
#include <cuda_runtime.h>

// 2D grid mapping for C = A + B stored as length N*M row-major 1D arrays.
// CUDA line: extern "C" __global__ void vec_add_2d_kernel(
// Part of smoke-test fallback kernel (agentk_llama_compat).
// Must compile with nvcc -c on local H100 without arch flags.
extern "C" __global__ void vec_add_2d_kernel(
    // CUDA line: const float* A,
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    const float* A,
    // CUDA line: const float* B,
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    const float* B,
    // CUDA line: float* C,
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    float* C,
    // CUDA line: int N,
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    int N,
    // CUDA line: int M
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    int M
// CUDA line: ) {
// Part of smoke-test fallback kernel (agentk_llama_compat).
// Must compile with nvcc -c on local H100 without arch flags.
) {
    // Map each thread to one (row, col) pair in the N x M grid.
    // CUDA line: int col = blockIdx.x * blockDim.x + threadIdx.x;
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    int col = blockIdx.x * blockDim.x + threadIdx.x;
    // CUDA line: int row = blockIdx.y * blockDim.y + threadIdx.y;
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    // Guard out-of-bounds threads when N or M are not tile multiples.
    // CUDA line: if (row < N && col < M) {
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    if (row < N && col < M) {
        // CUDA line: int idx = row * M + col;
        // Part of smoke-test fallback kernel (agentk_llama_compat).
        // Must compile with nvcc -c on local H100 without arch flags.
        int idx = row * M + col;
        // CUDA line: C[idx] = A[idx] + B[idx];
        // Part of smoke-test fallback kernel (agentk_llama_compat).
        // Must compile with nvcc -c on local H100 without arch flags.
        C[idx] = A[idx] + B[idx];
    // CUDA line: }
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    }
// CUDA line: }
// Part of smoke-test fallback kernel (agentk_llama_compat).
// Must compile with nvcc -c on local H100 without arch flags.
}
"""

_SMOKE_KERNEL_MATMUL = r"""
// CUDA line: #include <cuda_runtime.h>
// Part of smoke-test fallback kernel (agentk_llama_compat).
// Must compile with nvcc -c on local H100 without arch flags.
#include <cuda_runtime.h>

// Tiled matmul skeleton: C[M,N] = A[M,K] * B[K,N] with shared-memory staging.
// CUDA line: #define TILE 16
// Part of smoke-test fallback kernel (agentk_llama_compat).
// Must compile with nvcc -c on local H100 without arch flags.
#define TILE 16
// CUDA line: extern "C" __global__ void matmul_tiled_kernel(
// Part of smoke-test fallback kernel (agentk_llama_compat).
// Must compile with nvcc -c on local H100 without arch flags.
extern "C" __global__ void matmul_tiled_kernel(
    // CUDA line: const float* A,
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    const float* A,
    // CUDA line: const float* B,
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    const float* B,
    // CUDA line: float* C,
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    float* C,
    // CUDA line: int M,
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    int M,
    // CUDA line: int N,
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    int N,
    // CUDA line: int K
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    int K
// CUDA line: ) {
// Part of smoke-test fallback kernel (agentk_llama_compat).
// Must compile with nvcc -c on local H100 without arch flags.
) {
    // CUDA line: __shared__ float As[TILE][TILE];
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    __shared__ float As[TILE][TILE];
    // CUDA line: __shared__ float Bs[TILE][TILE];
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    __shared__ float Bs[TILE][TILE];
    // CUDA line: int row = blockIdx.y * TILE + threadIdx.y;
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    int row = blockIdx.y * TILE + threadIdx.y;
    // CUDA line: int col = blockIdx.x * TILE + threadIdx.x;
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    int col = blockIdx.x * TILE + threadIdx.x;
    // CUDA line: float acc = 0.0f;
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    float acc = 0.0f;
    // CUDA line: for (int t = 0; t < (K + TILE - 1) / TILE; ++t) {
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    for (int t = 0; t < (K + TILE - 1) / TILE; ++t) {
        // CUDA line: int aCol = t * TILE + threadIdx.x;
        // Part of smoke-test fallback kernel (agentk_llama_compat).
        // Must compile with nvcc -c on local H100 without arch flags.
        int aCol = t * TILE + threadIdx.x;
        // CUDA line: int bRow = t * TILE + threadIdx.y;
        // Part of smoke-test fallback kernel (agentk_llama_compat).
        // Must compile with nvcc -c on local H100 without arch flags.
        int bRow = t * TILE + threadIdx.y;
        // CUDA line: As[threadIdx.y][threadIdx.x] = (row < M && aCol < K) ? A[row * K + aCol] : 0.0f;
        // Part of smoke-test fallback kernel (agentk_llama_compat).
        // Must compile with nvcc -c on local H100 without arch flags.
        As[threadIdx.y][threadIdx.x] = (row < M && aCol < K) ? A[row * K + aCol] : 0.0f;
        // CUDA line: Bs[threadIdx.y][threadIdx.x] = (bRow < K && col < N) ? B[bRow * N + col] : 0.0f;
        // Part of smoke-test fallback kernel (agentk_llama_compat).
        // Must compile with nvcc -c on local H100 without arch flags.
        Bs[threadIdx.y][threadIdx.x] = (bRow < K && col < N) ? B[bRow * N + col] : 0.0f;
        // CUDA line: __syncthreads();
        // Part of smoke-test fallback kernel (agentk_llama_compat).
        // Must compile with nvcc -c on local H100 without arch flags.
        __syncthreads();
        // CUDA line: #pragma unroll
        // Part of smoke-test fallback kernel (agentk_llama_compat).
        // Must compile with nvcc -c on local H100 without arch flags.
        #pragma unroll
        // CUDA line: for (int k = 0; k < TILE; ++k) {
        // Part of smoke-test fallback kernel (agentk_llama_compat).
        // Must compile with nvcc -c on local H100 without arch flags.
        for (int k = 0; k < TILE; ++k) {
            // CUDA line: acc += As[threadIdx.y][k] * Bs[k][threadIdx.x];
            // Part of smoke-test fallback kernel (agentk_llama_compat).
            // Must compile with nvcc -c on local H100 without arch flags.
            acc += As[threadIdx.y][k] * Bs[k][threadIdx.x];
        // CUDA line: }
        // Part of smoke-test fallback kernel (agentk_llama_compat).
        // Must compile with nvcc -c on local H100 without arch flags.
        }
        // CUDA line: __syncthreads();
        // Part of smoke-test fallback kernel (agentk_llama_compat).
        // Must compile with nvcc -c on local H100 without arch flags.
        __syncthreads();
    // CUDA line: }
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    }
    // CUDA line: if (row < M && col < N) {
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    if (row < M && col < N) {
        // CUDA line: C[row * N + col] = acc;
        // Part of smoke-test fallback kernel (agentk_llama_compat).
        // Must compile with nvcc -c on local H100 without arch flags.
        C[row * N + col] = acc;
    // CUDA line: }
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    }
// CUDA line: }
// Part of smoke-test fallback kernel (agentk_llama_compat).
// Must compile with nvcc -c on local H100 without arch flags.
}
"""

_SMOKE_KERNEL_SOFTMAX = r"""
// CUDA line: #include <cuda_runtime.h>
// Part of smoke-test fallback kernel (agentk_llama_compat).
// Must compile with nvcc -c on local H100 without arch flags.
#include <cuda_runtime.h>
// CUDA line: #include <math.h>
// Part of smoke-test fallback kernel (agentk_llama_compat).
// Must compile with nvcc -c on local H100 without arch flags.
#include <math.h>

// Row-wise softmax for batch x hidden_size layouts (BERT-style hidden dim).
// CUDA line: extern "C" __global__ void softmax_row_kernel(
// Part of smoke-test fallback kernel (agentk_llama_compat).
// Must compile with nvcc -c on local H100 without arch flags.
extern "C" __global__ void softmax_row_kernel(
    // CUDA line: const float* input,
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    const float* input,
    // CUDA line: float* output,
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    float* output,
    // CUDA line: int batch,
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    int batch,
    // CUDA line: int hidden_size
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    int hidden_size
// CUDA line: ) {
// Part of smoke-test fallback kernel (agentk_llama_compat).
// Must compile with nvcc -c on local H100 without arch flags.
) {
    // CUDA line: int b = blockIdx.x;
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    int b = blockIdx.x;
    // CUDA line: if (b >= batch) {
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    if (b >= batch) {
        // CUDA line: return;
        // Part of smoke-test fallback kernel (agentk_llama_compat).
        // Must compile with nvcc -c on local H100 without arch flags.
        return;
    // CUDA line: }
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    }
    // CUDA line: const float* row_in = input + b * hidden_size;
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    const float* row_in = input + b * hidden_size;
    // CUDA line: float* row_out = output + b * hidden_size;
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    float* row_out = output + b * hidden_size;
    // CUDA line: float max_val = row_in[0];
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    float max_val = row_in[0];
    // CUDA line: for (int i = 1; i < hidden_size; ++i) {
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    for (int i = 1; i < hidden_size; ++i) {
        // CUDA line: max_val = fmaxf(max_val, row_in[i]);
        // Part of smoke-test fallback kernel (agentk_llama_compat).
        // Must compile with nvcc -c on local H100 without arch flags.
        max_val = fmaxf(max_val, row_in[i]);
    // CUDA line: }
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    }
    // CUDA line: float sum = 0.0f;
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    float sum = 0.0f;
    // CUDA line: for (int i = 0; i < hidden_size; ++i) {
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    for (int i = 0; i < hidden_size; ++i) {
        // CUDA line: float e = expf(row_in[i] - max_val);
        // Part of smoke-test fallback kernel (agentk_llama_compat).
        // Must compile with nvcc -c on local H100 without arch flags.
        float e = expf(row_in[i] - max_val);
        // CUDA line: row_out[i] = e;
        // Part of smoke-test fallback kernel (agentk_llama_compat).
        // Must compile with nvcc -c on local H100 without arch flags.
        row_out[i] = e;
        // CUDA line: sum += e;
        // Part of smoke-test fallback kernel (agentk_llama_compat).
        // Must compile with nvcc -c on local H100 without arch flags.
        sum += e;
    // CUDA line: }
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    }
    // CUDA line: for (int i = 0; i < hidden_size; ++i) {
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    for (int i = 0; i < hidden_size; ++i) {
        // CUDA line: row_out[i] /= sum;
        // Part of smoke-test fallback kernel (agentk_llama_compat).
        // Must compile with nvcc -c on local H100 without arch flags.
        row_out[i] /= sum;
    // CUDA line: }
    // Part of smoke-test fallback kernel (agentk_llama_compat).
    // Must compile with nvcc -c on local H100 without arch flags.
    }
// CUDA line: }
// Part of smoke-test fallback kernel (agentk_llama_compat).
// Must compile with nvcc -c on local H100 without arch flags.
}
"""


# Python line: def _classify_smoke_task(task: str) -> str:
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
def _classify_smoke_task(task: str) -> str:
    """Map AgentK seed prompts to one of three smoke kernel families."""
    # Python line: lowered = task.lower()
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    lowered = task.lower()
    # Python line: if "softmax" in lowered:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if "softmax" in lowered:
        # Python line: return "softmax"
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return "softmax"
    # Python line: if "matrix" in lowered or "multiplication" in lowered or "matmul" in lowered:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if "matrix" in lowered or "multiplication" in lowered or "matmul" in lowered:
        # Python line: return "matmul"
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return "matmul"
    # Python line: return "vector_add"
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    return "vector_add"


# Python line: def _smoke_fallback_kernel(task: str) -> str:
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
def _smoke_fallback_kernel(task: str) -> str:
    """Return a minimal compile-clean CUDA kernel for the given seed task class."""
    # Python line: kind = _classify_smoke_task(task)
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    kind = _classify_smoke_task(task)
    # Python line: if kind == "matmul":
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if kind == "matmul":
        # Python line: return _SMOKE_KERNEL_MATMUL.strip()
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return _SMOKE_KERNEL_MATMUL.strip()
    # Python line: if kind == "softmax":
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if kind == "softmax":
        # Python line: return _SMOKE_KERNEL_SOFTMAX.strip()
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return _SMOKE_KERNEL_SOFTMAX.strip()
    # Python line: return _SMOKE_KERNEL_VECTOR_ADD.strip()
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    return _SMOKE_KERNEL_VECTOR_ADD.strip()


# Python line: def _extract_json_object(text: str) -> dict[str, Any]:
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
def _extract_json_object(text: str) -> dict[str, Any]:
    """
    Parse the first JSON object embedded in an LLM response string.

    Falls back to an empty dict when no valid JSON is found so callers can
    apply schema-specific defaults rather than crashing immediately.
    """
    # Strip common markdown fences before searching for JSON.
    # Python line: cleaned = text.strip()
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    cleaned = text.strip()
    # Python line: if cleaned.startswith("```"):
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if cleaned.startswith("```"):
        # Python line: cleaned = re.sub(r"^```[a-zA-Z]*\n?", "", cleaned)
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        cleaned = re.sub(r"^```[a-zA-Z]*\n?", "", cleaned)
        # Python line: cleaned = re.sub(r"\n?```$", "", cleaned)
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        cleaned = re.sub(r"\n?```$", "", cleaned)
    # Try whole-string parse first (fast path for well-behaved models).
    # Python line: try:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    try:
        # Python line: obj = json.loads(cleaned)
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        obj = json.loads(cleaned)
        # Python line: if isinstance(obj, dict):
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        if isinstance(obj, dict):
            # Python line: return obj
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            return obj
    # Python line: except json.JSONDecodeError:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    except json.JSONDecodeError:
        # Python line: pass
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        pass
    # Scan for the first {...} block and parse that substring.
    # Python line: match = _JSON_OBJECT_RE.search(cleaned)
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    match = _JSON_OBJECT_RE.search(cleaned)
    # Python line: if not match:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if not match:
        # Python line: return {}
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return {}
    # Python line: try:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    try:
        # Python line: obj = json.loads(match.group(0))
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        obj = json.loads(match.group(0))
        # Python line: return obj if isinstance(obj, dict) else {}
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return obj if isinstance(obj, dict) else {}
    # Python line: except json.JSONDecodeError:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    except json.JSONDecodeError:
        # Python line: return {}
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return {}


# Python line: def _as_int3(value: Any, default: tuple[int, int, int] = (256, 1, 1)) -> tuple[int, int, i
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
def _as_int3(value: Any, default: tuple[int, int, int] = (256, 1, 1)) -> tuple[int, int, int]:
    """
    Coerce a list/tuple/scalar into a 3-element CUDA dim tuple.

    llama.cpp models often emit 2D dims; we pad the z component with 1.
    """
    # Python line: if isinstance(value, (list, tuple)):
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if isinstance(value, (list, tuple)):
        # Python line: nums = [int(x) for x in value[:3]]
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        nums = [int(x) for x in value[:3]]
        # Python line: while len(nums) < 3:
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        while len(nums) < 3:
            # Python line: nums.append(1)
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            nums.append(1)
        # Python line: return (nums[0], nums[1], nums[2])
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return (nums[0], nums[1], nums[2])
    # Python line: if isinstance(value, int):
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if isinstance(value, int):
        # Python line: return (value, 1, 1)
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return (value, 1, 1)
    # Python line: return default
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    return default


# Python line: def _normalize_bottleneck_type(value: Any) -> str:
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
def _normalize_bottleneck_type(value: Any) -> str:
    """
    Map free-form LLM bottleneck labels onto AgentK ``BottleneckType`` values.

    Local models often emit lowercase phrases ("memory", "memory bandwidth") instead
    of the exact PascalCase enum strings required by Pydantic.
    """
    # Python line: if value is None:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if value is None:
        # Python line: return "Other"
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return "Other"
    # Python line: text = str(value).strip()
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    text = str(value).strip()
    # Python line: if not text:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if not text:
        # Python line: return "Other"
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return "Other"
    # Fast path: already a valid enum string.
    # Python line: valid = {
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    valid = {
        # Python line: "MemoryBound",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "MemoryBound",
        # Python line: "ComputeBound",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "ComputeBound",
        # Python line: "InstructionBound",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "InstructionBound",
        # Python line: "SharedMemoryConflict",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "SharedMemoryConflict",
        # Python line: "Other",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "Other",
    # Python line: }
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    }
    # Python line: if text in valid:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if text in valid:
        # Python line: return text
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return text
    # Collapse punctuation/spacing for fuzzy keyword routing.
    # Python line: compact = re.sub(r"[^a-z]", "", text.lower())
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    compact = re.sub(r"[^a-z]", "", text.lower())
    # Python line: if "shared" in compact and "mem" in compact:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if "shared" in compact and "mem" in compact:
        # Python line: return "SharedMemoryConflict"
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return "SharedMemoryConflict"
    # Python line: if "instruction" in compact or "latency" in compact:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if "instruction" in compact or "latency" in compact:
        # Python line: return "InstructionBound"
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return "InstructionBound"
    # Python line: if "compute" in compact or "math" in compact or "flop" in compact:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if "compute" in compact or "math" in compact or "flop" in compact:
        # Python line: return "ComputeBound"
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return "ComputeBound"
    # Python line: if "memory" in compact or "bandwidth" in compact or "dram" in compact:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if "memory" in compact or "bandwidth" in compact or "dram" in compact:
        # Python line: return "MemoryBound"
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return "MemoryBound"
    # Python line: return "Other"
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    return "Other"


# Python line: def _normalize_precision(value: Any) -> str:
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
def _normalize_precision(value: Any) -> str:
    """
    Map free-form precision strings onto AgentK ``PrecisionType`` values.

    Models frequently emit ``float``, ``float32``, ``single``, or ``fp32`` instead
    of the schema's ``FP32`` token.
    """
    # Python line: if value is None:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if value is None:
        # Python line: return "FP32"
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return "FP32"
    # Python line: text = str(value).strip()
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    text = str(value).strip()
    # Python line: if not text:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if not text:
        # Python line: return "FP32"
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return "FP32"
    # Python line: upper = text.upper().replace("-", "").replace("_", "").replace(" ", "")
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    upper = text.upper().replace("-", "").replace("_", "").replace(" ", "")
    # Python line: direct = {
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    direct = {
        # Python line: "FP32": "FP32",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "FP32": "FP32",
        # Python line: "FP16": "FP16",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "FP16": "FP16",
        # Python line: "BF16": "BF16",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "BF16": "BF16",
        # Python line: "TF32": "TF32",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "TF32": "TF32",
        # Python line: "FP64": "FP64",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "FP64": "FP64",
        # Python line: "INT32": "INT32",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "INT32": "INT32",
        # Python line: "INT16": "INT16",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "INT16": "INT16",
        # Python line: "INT8": "INT8",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "INT8": "INT8",
    # Python line: }
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    }
    # Python line: if upper in direct:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if upper in direct:
        # Python line: return direct[upper]
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return direct[upper]
    # Python line: aliases = {
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    aliases = {
        # Python line: "FLOAT": "FP32",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "FLOAT": "FP32",
        # Python line: "FLOAT32": "FP32",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "FLOAT32": "FP32",
        # Python line: "FLOAT64": "FP64",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "FLOAT64": "FP64",
        # Python line: "DOUBLE": "FP64",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "DOUBLE": "FP64",
        # Python line: "HALF": "FP16",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "HALF": "FP16",
        # Python line: "SINGLE": "FP32",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "SINGLE": "FP32",
        # Python line: "FP32": "FP32",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "FP32": "FP32",
        # Python line: "FP16": "FP16",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "FP16": "FP16",
        # Python line: "BF16": "BF16",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "BF16": "BF16",
        # Python line: "TF32": "TF32",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "TF32": "TF32",
    # Python line: }
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    }
    # Python line: return aliases.get(upper, "FP32")
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    return aliases.get(upper, "FP32")


# Python line: def _as_int(value: Any, default: int) -> int:
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
def _as_int(value: Any, default: int) -> int:
    """Coerce optimizer numeric fields; local LLMs sometimes emit null."""
    # Python line: if value is None:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if value is None:
        # Python line: return default
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return default
    # Python line: try:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    try:
        # Python line: return int(value)
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return int(value)
    # Python line: except (TypeError, ValueError):
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    except (TypeError, ValueError):
        # Python line: return default
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return default


# Python line: def _normalize_compiler_flags(flags: Any) -> list[str]:
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
def _normalize_compiler_flags(flags: Any) -> list[str]:
    """
    Split and sanitize optimizer ``compiler_flags`` before nvcc invocation.

    Local LLMs often emit a single string like ``-arch=sm_70 -O3``; nvcc then
    treats the whole token as an architecture name and fails fatally.
    """
    # Python line: tokens: list[str] = []
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    tokens: list[str] = []
    # Python line: if flags is None:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if flags is None:
        # Python line: raw: list[Any] = []
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        raw: list[Any] = []
    # Python line: elif isinstance(flags, str):
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    elif isinstance(flags, str):
        # Python line: raw = [flags]
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        raw = [flags]
    # Python line: elif isinstance(flags, (list, tuple)):
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    elif isinstance(flags, (list, tuple)):
        # Python line: raw = list(flags)
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        raw = list(flags)
    # Python line: else:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    else:
        # Python line: raw = []
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        raw = []
    # Python line: for item in raw:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    for item in raw:
        # Python line: if not isinstance(item, str):
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        if not isinstance(item, str):
            # Python line: continue
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            continue
        # Python line: tokens.extend(part for part in item.split() if part.strip())
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        tokens.extend(part for part in item.split() if part.strip())
    # Python line: safe: list[str] = []
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    safe: list[str] = []
    # Python line: for tok in tokens:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    for tok in tokens:
        # Python line: low = tok.lower()
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        low = tok.lower()
        # Drop architecture selectors; nvcc targets the local GPU (H100 → sm_90).
        # Python line: if low.startswith("-arch") or low.startswith("--gpu-architecture"):
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        if low.startswith("-arch") or low.startswith("--gpu-architecture"):
            # Python line: continue
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            continue
        # Python line: if low.startswith("-gencode"):
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        if low.startswith("-gencode"):
            # Python line: continue
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            continue
        # Python line: safe.append(tok)
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        safe.append(tok)
    # Python line: if "-use_fast_math" not in safe:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if "-use_fast_math" not in safe:
        # Python line: safe.append("-use_fast_math")
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        safe.append("-use_fast_math")
    # Python line: return safe or ["-use_fast_math"]
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    return safe or ["-use_fast_math"]


# Python line: def _normalize_optimization_strategy(obj: dict[str, Any]) -> dict[str, Any]:
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
def _normalize_optimization_strategy(obj: dict[str, Any]) -> dict[str, Any]:
    """
    Repair common schema drift from local LLMs before Pydantic validation.

    Observed failure mode: grid/block nested under ``launch`` instead of top-level.
    """
    # Flatten nested launch.{grid_size,block_size} if present.
    # Python line: launch = obj.get("launch")
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    launch = obj.get("launch")
    # Python line: if isinstance(launch, dict):
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if isinstance(launch, dict):
        # Python line: obj.setdefault("grid_size", launch.get("grid_size"))
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        obj.setdefault("grid_size", launch.get("grid_size"))
        # Python line: obj.setdefault("block_size", launch.get("block_size"))
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        obj.setdefault("block_size", launch.get("block_size"))
    # Normalize grid/block to 3-tuples.
    # Python line: obj["grid_size"] = _as_int3(obj.get("grid_size"), (1024, 1, 1))
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    obj["grid_size"] = _as_int3(obj.get("grid_size"), (1024, 1, 1))
    # Python line: obj["block_size"] = _as_int3(obj.get("block_size"), (256, 1, 1))
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    obj["block_size"] = _as_int3(obj.get("block_size"), (256, 1, 1))
    # Ensure memory_strategy object exists with required keys.
    # Python line: mem = obj.get("memory_strategy")
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    mem = obj.get("memory_strategy")
    # Python line: if not isinstance(mem, dict):
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if not isinstance(mem, dict):
        # Python line: mem = {}
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        mem = {}
    # Python line: mem.setdefault("USE_SHARED_MEMORY", False)
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    mem.setdefault("USE_SHARED_MEMORY", False)
    # Python line: mem.setdefault("USE_READ_ONLY_CACHE", False)
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    mem.setdefault("USE_READ_ONLY_CACHE", False)
    # Python line: tiling = mem.get("TILING_FACTOR", [16, 16])
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    tiling = mem.get("TILING_FACTOR", [16, 16])
    # Python line: mem["TILING_FACTOR"] = _as_int3(tiling, (16, 16, 1))[:2]  # MemoryConfig expects pair
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    mem["TILING_FACTOR"] = _as_int3(tiling, (16, 16, 1))[:2]  # MemoryConfig expects pair
    # Python line: mem.setdefault("PADDING_REQUIRED", False)
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    mem.setdefault("PADDING_REQUIRED", False)
    # Python line: obj["memory_strategy"] = mem
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    obj["memory_strategy"] = mem
    # Normalize enum-like fields before Pydantic validation.
    # Python line: obj["bottleneck_type"] = _normalize_bottleneck_type(obj.get("bottleneck_type"))
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    obj["bottleneck_type"] = _normalize_bottleneck_type(obj.get("bottleneck_type"))
    # Python line: obj["precision"] = _normalize_precision(obj.get("precision"))
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    obj["precision"] = _normalize_precision(obj.get("precision"))
    # Local Q4 models compile FP32 kernels more reliably than ad-hoc FP16 paths.
    # Python line: obj["precision"] = "FP32"
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    obj["precision"] = "FP32"
    # Scalar defaults for numeric strategy fields.
    # Python line: obj["registers_per_thread"] = _as_int(obj.get("registers_per_thread"), 32)
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    obj["registers_per_thread"] = _as_int(obj.get("registers_per_thread"), 32)
    # Python line: obj["shared_memory_bytes"] = _as_int(obj.get("shared_memory_bytes"), 0)
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    obj["shared_memory_bytes"] = _as_int(obj.get("shared_memory_bytes"), 0)
    # Python line: obj["vectorization_width"] = _as_int(obj.get("vectorization_width"), 1)
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    obj["vectorization_width"] = _as_int(obj.get("vectorization_width"), 1)
    # Python line: obj["compiler_flags"] = _normalize_compiler_flags(obj.get("compiler_flags"))
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    obj["compiler_flags"] = _normalize_compiler_flags(obj.get("compiler_flags"))
    # Python line: return obj
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    return obj


# Python line: def _parse_is_cuda(raw: str, task: str) -> bool:
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
def _parse_is_cuda(raw: str, task: str) -> bool:
    """
    Determine CUDA routing from structured JSON or task keywords.

    Smoke-test CUDA prompts always contain 'CUDA' or 'kernel'; keyword fallback
    keeps routing correct when the model emits malformed JSON.
    """
    # Python line: obj = _extract_json_object(raw)
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    obj = _extract_json_object(raw)
    # Python line: if "is_cuda" in obj:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if "is_cuda" in obj:
        # Python line: return bool(obj["is_cuda"])
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return bool(obj["is_cuda"])
    # Python line: lowered = raw.lower()
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    lowered = raw.lower()
    # Python line: if "true" in lowered and "is_cuda" in lowered:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if "true" in lowered and "is_cuda" in lowered:
        # Python line: return True
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return True
    # Python line: if "false" in lowered and "is_cuda" in lowered:
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if "false" in lowered and "is_cuda" in lowered:
        # Python line: return False
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return False
    # Python line: task_l = task.lower()
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    task_l = task.lower()
    # Python line: return any(tok in task_l for tok in ("cuda", "kernel", "__global__", "nvcc", "gpu"))
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    return any(tok in task_l for tok in ("cuda", "kernel", "__global__", "nvcc", "gpu"))


# Python line: def apply_agentk_llama_shim(
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
def apply_agentk_llama_shim(
    # Python line: *,
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    *,
    # Python line: max_tokens_planner: int = 64,
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    max_tokens_planner: int = 64,
    # Python line: max_tokens_analyzer: int = 512,
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    max_tokens_analyzer: int = 512,
    # Python line: max_tokens_optimizer: int = 768,
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    max_tokens_optimizer: int = 768,
    # Python line: request_timeout_s: int = 300,
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    request_timeout_s: int = 300,
    # Python line: smoke_fallback: bool = False,
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    smoke_fallback: bool = False,
    # Python line: smoke_fallback_after: int = 4,
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    smoke_fallback_after: int = 4,
# Python line: ) -> None:
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
) -> None:
    """
    Monkey-patch AgentK nodes for llama.cpp local inference.

    Must be called after ``third_party/agentk`` is on ``sys.path`` and
  before ``from src.graph import app``.
    """
    # Import AgentK modules lazily so the shim stays decoupled from KC at install time.
    # Python line: import src.config as kc_config
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.config as kc_config
    # Python line: import src.nodes.analyzer as analyzer_mod
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.nodes.analyzer as analyzer_mod
    # Python line: import src.nodes.generator as generator_mod
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.nodes.generator as generator_mod
    # Python line: import src.nodes.optimizer as optimizer_mod
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.nodes.optimizer as optimizer_mod
    # Python line: import src.nodes.planner as planner_mod
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.nodes.planner as planner_mod
    # Python line: from src.state import OptimizationStrategy
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    from src.state import OptimizationStrategy

    # Preserve the original LLM factory; we wrap all nodes (incl. generator).
    # Python line: _orig_get_llm: Callable[..., Any] = kc_config.get_llm
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    _orig_get_llm: Callable[..., Any] = kc_config.get_llm

    # Python line: def _get_llm_bounded(temperature: float = 0.0, max_tokens: int = 2048):
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    def _get_llm_bounded(temperature: float = 0.0, max_tokens: int = 2048):
        """Return a ChatOpenAI client with max_tokens and timeout for llama.cpp."""
        # Python line: llm = _orig_get_llm(temperature=temperature)
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        llm = _orig_get_llm(temperature=temperature)
        # Python line: return llm.bind(max_tokens=max_tokens, timeout=request_timeout_s)
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return llm.bind(max_tokens=max_tokens, timeout=request_timeout_s)

    # Replace global factory so generator/critic paths also get bounded completions.
    # Python line: kc_config.get_llm = lambda temperature=0.0: _get_llm_bounded(temperature, 2048)
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    kc_config.get_llm = lambda temperature=0.0: _get_llm_bounded(temperature, 2048)

    # Python line: def planner_node_llama(state):  # type: ignore[no-untyped-def]
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    def planner_node_llama(state):  # type: ignore[no-untyped-def]
        """Planner replacement: strict JSON boolean, no json_schema API call."""
        # Python line: llm = _get_llm_bounded(0.0, max_tokens_planner)
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        llm = _get_llm_bounded(0.0, max_tokens_planner)
        # Python line: prompt = ChatPromptTemplate.from_messages([
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        prompt = ChatPromptTemplate.from_messages([
            # Python line: (
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            (
                # Python line: "system",
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "system",
                # Python line: "You are a routing assistant. Reply with ONLY valid JSON on one line: "
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "You are a routing assistant. Reply with ONLY valid JSON on one line: "
                # Python line: '{{"is_cuda": true}} or {{"is_cuda": false}}. '
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                '{{"is_cuda": true}} or {{"is_cuda": false}}. '
                # Python line: "Set true when the task requires CUDA C++ or GPU kernel work.",
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "Set true when the task requires CUDA C++ or GPU kernel work.",
            # Python line: ),
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            ),
            # Python line: ("human", "{task}"),
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            ("human", "{task}"),
        # Python line: ])
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        ])
        # Python line: raw = (prompt | llm).invoke({"task": state["task"]}).content
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        raw = (prompt | llm).invoke({"task": state["task"]}).content
        # Python line: return {"is_cuda": _parse_is_cuda(raw, state["task"])}
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return {"is_cuda": _parse_is_cuda(raw, state["task"])}

    # Python line: def analyzer_node_llama(state):  # type: ignore[no-untyped-def]
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    def analyzer_node_llama(state):  # type: ignore[no-untyped-def]
        """Analyzer replacement: bounded free-text analysis (RAG optional)."""
        # Python line: from src.tools.retriever import get_relevant_cuda_docs
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        from src.tools.retriever import get_relevant_cuda_docs

        # Python line: docs_context = get_relevant_cuda_docs(state["task"])
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        docs_context = get_relevant_cuda_docs(state["task"])
        # Python line: llm = _get_llm_bounded(0.1, max_tokens_analyzer)
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        llm = _get_llm_bounded(0.1, max_tokens_analyzer)
        # Python line: prompt = ChatPromptTemplate.from_messages([
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        prompt = ChatPromptTemplate.from_messages([
            # Python line: (
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            (
                # Python line: "system",
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "system",
                # Python line: "You are a Senior NVIDIA CUDA Architect. Be concise (<=12 sentences). "
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "You are a Senior NVIDIA CUDA Architect. Be concise (<=12 sentences). "
                # Python line: "Focus on memory hierarchy, occupancy, and launch config.\n\n"
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "Focus on memory hierarchy, occupancy, and launch config.\n\n"
                # Python line: "Documentation context:\n{context}",
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "Documentation context:\n{context}",
            # Python line: ),
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            ),
            # Python line: ("human", "Analyze this CUDA task: {task}"),
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            ("human", "Analyze this CUDA task: {task}"),
        # Python line: ])
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        ])
        # Python line: response = (prompt | llm).invoke({"context": docs_context, "task": state["task"]})
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        response = (prompt | llm).invoke({"context": docs_context, "task": state["task"]})
        # Python line: return {"rag_context": docs_context, "analysis": response.content}
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return {"rag_context": docs_context, "analysis": response.content}

    # Python line: def optimizer_node_llama(state):  # type: ignore[no-untyped-def]
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    def optimizer_node_llama(state):  # type: ignore[no-untyped-def]
        """Optimizer replacement: JSON strategy object + normalization + Pydantic."""
        # Python line: llm = _get_llm_bounded(0.0, max_tokens_optimizer)
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        llm = _get_llm_bounded(0.0, max_tokens_optimizer)
        # Python line: prompt = ChatPromptTemplate.from_messages([
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        prompt = ChatPromptTemplate.from_messages([
            # Python line: (
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            (
                # Python line: "system",
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "system",
                # Python line: "You are a CUDA performance engineer. Reply with ONLY one JSON object "
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "You are a CUDA performance engineer. Reply with ONLY one JSON object "
                # Python line: "(no markdown) using EXACTLY these top-level keys:\n"
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "(no markdown) using EXACTLY these top-level keys:\n"
                # Python line: "bottleneck_type, grid_size, block_size, memory_strategy, "
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "bottleneck_type, grid_size, block_size, memory_strategy, "
                # Python line: "registers_per_thread, shared_memory_bytes, vectorization_width, "
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "registers_per_thread, shared_memory_bytes, vectorization_width, "
                # Python line: "precision, compiler_flags.\n"
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "precision, compiler_flags.\n"
                # Python line: "bottleneck_type MUST be exactly one of: MemoryBound, ComputeBound, "
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "bottleneck_type MUST be exactly one of: MemoryBound, ComputeBound, "
                # Python line: "InstructionBound, SharedMemoryConflict, Other.\n"
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "InstructionBound, SharedMemoryConflict, Other.\n"
                # Python line: "precision MUST be exactly one of: FP32, FP16, BF16, TF32, FP64, "
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "precision MUST be exactly one of: FP32, FP16, BF16, TF32, FP64, "
                # Python line: "INT32, INT16, INT8.\n"
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "INT32, INT16, INT8.\n"
                # Python line: "grid_size and block_size must be length-3 integer arrays, e.g. [1024,1,1] "
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "grid_size and block_size must be length-3 integer arrays, e.g. [1024,1,1] "
                # Python line: "and [256,1,1]. Do NOT nest them under 'launch'.",
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "and [256,1,1]. Do NOT nest them under 'launch'.",
            # Python line: ),
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            ),
            # Python line: (
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            (
                # Python line: "human",
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "human",
                # Python line: "Task: {task}\nAnalysis: {analysis}\nContext: {context}",
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "Task: {task}\nAnalysis: {analysis}\nContext: {context}",
            # Python line: ),
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            ),
        # Python line: ])
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        ])
        # Python line: raw = (prompt | llm).invoke({
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        raw = (prompt | llm).invoke({
            # Python line: "task": state["task"],
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            "task": state["task"],
            # Python line: "analysis": state["analysis"],
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            "analysis": state["analysis"],
            # Python line: "context": state["rag_context"],
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            "context": state["rag_context"],
        # Python line: }).content
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        }).content
        # Python line: obj = _normalize_optimization_strategy(_extract_json_object(raw))
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        obj = _normalize_optimization_strategy(_extract_json_object(raw))
        # Python line: strategy = OptimizationStrategy.model_validate(obj)
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        strategy = OptimizationStrategy.model_validate(obj)
        # Python line: return {"strategy": strategy}
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return {"strategy": strategy}

    # Install patched callables into AgentK's node modules.
    # Python line: planner_mod.planner_node = planner_node_llama
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    planner_mod.planner_node = planner_node_llama
    # Python line: analyzer_mod.analyzer_node = analyzer_node_llama
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    analyzer_mod.analyzer_node = analyzer_node_llama
    # Python line: optimizer_mod.optimizer_node = optimizer_node_llama
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    optimizer_mod.optimizer_node = optimizer_node_llama

    # Wrap generator with extra guardrails for small local models.
    # Python line: _orig_generator = generator_mod.generator_node
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    _orig_generator = generator_mod.generator_node

    # Python line: def generator_node_llama(state):  # type: ignore[no-untyped-def]
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    def generator_node_llama(state):  # type: ignore[no-untyped-def]
        """Generator wrapper: hygiene rules + optional smoke-test fallback kernels."""
        # Python line: retries = int(state.get("retry_count") or 0)
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        retries = int(state.get("retry_count") or 0)
        # Python line: prev_failed = bool(state.get("compiler_error"))
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        prev_failed = bool(state.get("compiler_error"))
        # Python line: if (
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        if (
            # Python line: smoke_fallback
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            smoke_fallback
            # Python line: and retries >= smoke_fallback_after
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            and retries >= smoke_fallback_after
            # Python line: and prev_failed
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            and prev_failed
        # Python line: ):
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        ):
            # Python line: return {
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            return {
                # Python line: "source_code": _smoke_fallback_kernel(state["task"])
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                "source_code": _smoke_fallback_kernel(state["task"])
                # Python line: + "\n// kc_smoke_fallback_kernel\n",
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                + "\n// kc_smoke_fallback_kernel\n",
            # Python line: }
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            }
        # Python line: out = _orig_generator(state)
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        out = _orig_generator(state)
        # Python line: code = out.get("source_code") or ""
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        code = out.get("source_code") or ""
        # Python line: if code and "#include" not in code[:400]:
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        if code and "#include" not in code[:400]:
            # Python line: header = (
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            header = (
                # Python line: '#include <cuda_runtime.h>\n'
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                '#include <cuda_runtime.h>\n'
                # Python line: '#include <float.h>\n'
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                '#include <float.h>\n'
                # Python line: '#include <math.h>\n\n'
                # AgentK llama.cpp shim (agentk_llama_compat module).
                # Implements .cursorrules dense-comment policy for src/ code.
                '#include <math.h>\n\n'
            # Python line: )
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            )
            # Python line: out["source_code"] = header + code
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            out["source_code"] = header + code
        # Python line: return out
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return out

    # Python line: generator_mod.generator_node = generator_node_llama
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    generator_mod.generator_node = generator_node_llama

    # Python line: _extra_gen_rules = (
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    _extra_gen_rules = (
        # Python line: "\nAdditional rules for local llama.cpp backends:\n"
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "\nAdditional rules for local llama.cpp backends:\n"
        # Python line: "- Never emit placeholder tokens like `...` in source code.\n"
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "- Never emit placeholder tokens like `...` in source code.\n"
        # Python line: "- Use only CUDA builtins blockIdx, threadIdx, blockDim, gridDim.\n"
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "- Use only CUDA builtins blockIdx, threadIdx, blockDim, gridDim.\n"
        # Python line: "- Never reference undefined names such as blocksPerGrid or threadsPerBlock.\n"
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "- Never reference undefined names such as blocksPerGrid or threadsPerBlock.\n"
        # Python line: "- Pass matrix/vector sizes as kernel function parameters.\n"
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "- Pass matrix/vector sizes as kernel function parameters.\n"
        # Python line: "- Use FP32 (`float`) arithmetic unless cuda_fp16.h is explicitly included.\n"
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "- Use FP32 (`float`) arithmetic unless cuda_fp16.h is explicitly included.\n"
    # Python line: )
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: if hasattr(generator_mod, "_FIRST_PASS_SYSTEM"):
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if hasattr(generator_mod, "_FIRST_PASS_SYSTEM"):
        # Python line: generator_mod._FIRST_PASS_SYSTEM += _extra_gen_rules
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        generator_mod._FIRST_PASS_SYSTEM += _extra_gen_rules
    # Python line: if hasattr(generator_mod, "_REPAIR_SYSTEM"):
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    if hasattr(generator_mod, "_REPAIR_SYSTEM"):
        # Python line: generator_mod._REPAIR_SYSTEM += _extra_gen_rules
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        generator_mod._REPAIR_SYSTEM += _extra_gen_rules

    # Python line: print(
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    print(
        # Python line: "[agentk_llama_compat] Patched planner/analyzer/optimizer for llama.cpp "
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "[agentk_llama_compat] Patched planner/analyzer/optimizer for llama.cpp "
        # Python line: f"(max_tokens: planner={max_tokens_planner}, analyzer={max_tokens_analyzer}, "
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        f"(max_tokens: planner={max_tokens_planner}, analyzer={max_tokens_analyzer}, "
        # Python line: f"optimizer={max_tokens_optimizer}"
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        f"optimizer={max_tokens_optimizer}"
        # Python line: f"{', smoke_fallback after ' + str(smoke_fallback_after) if smoke_fallback else ''})"
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        f"{', smoke_fallback after ' + str(smoke_fallback_after) if smoke_fallback else ''})"
    # Python line: )
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    )


# Python line: def build_agentk_app(*, max_retries: int = 12):
# AgentK llama.cpp shim (agentk_llama_compat module).
# Implements .cursorrules dense-comment policy for src/ code.
def build_agentk_app(*, max_retries: int = 12):
    """
    Compile a fresh LangGraph app using patched nodes and a higher retry budget.

    Importing ``src.graph.app`` bakes in AgentK's default retry limit (5).
    Local Q4_K_M models often need more repair passes, so we rebuild the graph
    here after ``apply_agentk_llama_shim()`` has patched the node modules.
    """
    # Python line: from langgraph.graph import END, StateGraph
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    from langgraph.graph import END, StateGraph

    # Python line: import src.nodes.analyzer as analyzer_mod
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.nodes.analyzer as analyzer_mod
    # Python line: import src.nodes.critic as critic_mod
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.nodes.critic as critic_mod
    # Python line: import src.nodes.generator as generator_mod
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.nodes.generator as generator_mod
    # Python line: import src.nodes.optimizer as optimizer_mod
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.nodes.optimizer as optimizer_mod
    # Python line: import src.nodes.planner as planner_mod
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    import src.nodes.planner as planner_mod
    # Python line: from src.state import AgentState
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    from src.state import AgentState

    # Python line: _orig_critic = critic_mod.critic_node
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    _orig_critic = critic_mod.critic_node

    # Python line: def critic_node_safe_flags(state):  # type: ignore[no-untyped-def]
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    def critic_node_safe_flags(state):  # type: ignore[no-untyped-def]
        """Critic wrapper: re-sanitize compiler_flags immediately before nvcc."""
        # Python line: strategy = state.get("strategy")
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        strategy = state.get("strategy")
        # Python line: if strategy is not None:
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        if strategy is not None:
            # Python line: flags = _normalize_compiler_flags(strategy.compiler_flags)
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            flags = _normalize_compiler_flags(strategy.compiler_flags)
            # Python line: strategy = strategy.model_copy(update={"compiler_flags": flags})
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            strategy = strategy.model_copy(update={"compiler_flags": flags})
            # Python line: state = {**state, "strategy": strategy}
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            state = {**state, "strategy": strategy}
        # Python line: return _orig_critic(state)
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return _orig_critic(state)

    # Python line: critic_mod.critic_node = critic_node_safe_flags
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    critic_mod.critic_node = critic_node_safe_flags

    # Python line: def should_continue(state):
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    def should_continue(state):
        """Route back to generator until compile succeeds or retry budget is spent."""
        # Python line: if state["compilation_success"]:
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        if state["compilation_success"]:
            # Python line: return END
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            return END
        # Python line: if state["retry_count"] < max_retries:
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        if state["retry_count"] < max_retries:
            # Python line: return "generator"
            # AgentK llama.cpp shim (agentk_llama_compat module).
            # Implements .cursorrules dense-comment policy for src/ code.
            return "generator"
        # Python line: return END
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        return END

    # Python line: workflow = StateGraph(AgentState)
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    workflow = StateGraph(AgentState)
    # Python line: workflow.add_node("planner", planner_mod.planner_node)
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    workflow.add_node("planner", planner_mod.planner_node)
    # Python line: workflow.add_node("analyzer", analyzer_mod.analyzer_node)
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    workflow.add_node("analyzer", analyzer_mod.analyzer_node)
    # Python line: workflow.add_node("optimizer", optimizer_mod.optimizer_node)
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    workflow.add_node("optimizer", optimizer_mod.optimizer_node)
    # Python line: workflow.add_node("generator", generator_mod.generator_node)
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    workflow.add_node("generator", generator_mod.generator_node)
    # Python line: workflow.add_node("critic", critic_mod.critic_node)
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    workflow.add_node("critic", critic_mod.critic_node)
    # Python line: workflow.set_entry_point("planner")
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    workflow.set_entry_point("planner")
    # Python line: workflow.add_conditional_edges(
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    workflow.add_conditional_edges(
        # Python line: "planner",
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        "planner",
        # Python line: lambda state: "analyzer" if state["is_cuda"] else END,
        # AgentK llama.cpp shim (agentk_llama_compat module).
        # Implements .cursorrules dense-comment policy for src/ code.
        lambda state: "analyzer" if state["is_cuda"] else END,
    # Python line: )
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: workflow.add_edge("analyzer", "optimizer")
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    workflow.add_edge("analyzer", "optimizer")
    # Python line: workflow.add_edge("optimizer", "generator")
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    workflow.add_edge("optimizer", "generator")
    # Python line: workflow.add_edge("generator", "critic")
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    workflow.add_edge("generator", "critic")
    # Python line: workflow.add_conditional_edges("critic", should_continue)
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    workflow.add_conditional_edges("critic", should_continue)
    # Python line: return workflow.compile()
    # AgentK llama.cpp shim (agentk_llama_compat module).
    # Implements .cursorrules dense-comment policy for src/ code.
    return workflow.compile()
