"""Closed-form VRAM trajectory and KV-cache accounting (project_plan.md §3.1–§3.2)."""

# Python line: from src.forecast.q4_km_accounting import (
# Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
from src.forecast.q4_km_accounting import (
    # Python line: agentic_context_length_tokens,
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    agentic_context_length_tokens,
    # Python line: b_precision_from_cache_types,
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    b_precision_from_cache_types,
    # Python line: closed_form_accounting_payload,
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    closed_form_accounting_payload,
    # Python line: closed_form_peak_labels,
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    closed_form_peak_labels,
    # Python line: gguf_on_disk_mb,
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    gguf_on_disk_mb,
    # Python line: load_model_calibration,
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    load_model_calibration,
    # Python line: llama_cpp_kv_type_id,
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    llama_cpp_kv_type_id,
    # Python line: m_kv_mb,
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    m_kv_mb,
    # Python line: m_vram_mb,
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    m_vram_mb,
    # Python line: m_weights_reported_mb,
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    m_weights_reported_mb,
    # Python line: measure_m_act_mb,
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    measure_m_act_mb,
    # Python line: vram_at_generator_start_mb,
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    vram_at_generator_start_mb,
)

# Python line: __all__ = [
# Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
__all__ = [
    # Python line: "agentic_context_length_tokens",
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "agentic_context_length_tokens",
    # Python line: "b_precision_from_cache_types",
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "b_precision_from_cache_types",
    # Python line: "closed_form_accounting_payload",
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "closed_form_accounting_payload",
    # Python line: "closed_form_peak_labels",
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "closed_form_peak_labels",
    # Python line: "gguf_on_disk_mb",
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "gguf_on_disk_mb",
    # Python line: "load_model_calibration",
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "load_model_calibration",
    # Python line: "llama_cpp_kv_type_id",
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "llama_cpp_kv_type_id",
    # Python line: "m_kv_mb",
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "m_kv_mb",
    # Python line: "m_vram_mb",
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "m_vram_mb",
    # Python line: "m_weights_reported_mb",
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "m_weights_reported_mb",
    # Python line: "measure_m_act_mb",
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "measure_m_act_mb",
    # Python line: "vram_at_generator_start_mb",
    # Phase 3.2 Q4_K_M VRAM accounting package exports (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "vram_at_generator_start_mb",
]
