"""
Phase 3.2 — Q4_K_M-aware closed-form VRAM accounting (extension to plan §3.1.2).

Provides M_weights from GGUF on-disk size + runtime overhead, M_KV(L) with
cache-type-dependent b_precision, and per-model M_act calibration constants.
"""

# Python line: from __future__ import annotations
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
from __future__ import annotations

# math supplies isfinite for safe float handling in trajectory evaluation.
# Python line: import math
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
import math
# Path reads GGUF files for on-disk weight footprint in MiB.
# Python line: from pathlib import Path
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
from pathlib import Path
# typing annotates architecture dicts and trajectory point lists.
# Python line: from typing import Any, Dict, List, Mapping, Optional
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
from typing import Any, Dict, List, Mapping, Optional


# Map llama.cpp KV cache type strings to bytes per element (plan §3.1.2 b_precision).
# Python line: _CACHE_TYPE_BYTES: Dict[str, float] = {
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
_CACHE_TYPE_BYTES: Dict[str, float] = {
    # Python line: "f16": 2.0,
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "f16": 2.0,
    # Python line: "fp16": 2.0,
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "fp16": 2.0,
    # Python line: "bf16": 2.0,
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "bf16": 2.0,
    # Python line: "q8_0": 1.0,
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "q8_0": 1.0,
    # Python line: "q4_0": 0.5,
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "q4_0": 0.5,
    # Python line: "q4_1": 0.5,
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "q4_1": 0.5,
# Python line: }
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
}


# Map human-readable cache type labels to llama-cpp-python GGML type integers.
# Python line: _LLAMA_CPP_KV_TYPE_ID: Dict[str, int] = {
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
_LLAMA_CPP_KV_TYPE_ID: Dict[str, int] = {
    # Python line: "f16": 1,
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "f16": 1,
    # Python line: "fp16": 1,
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "fp16": 1,
    # Python line: "bf16": 1,
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "bf16": 1,
    # Python line: "q8_0": 8,
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "q8_0": 8,
    # Python line: "q4_0": 2,
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    "q4_0": 2,
# Python line: }
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
}


# Python line: def llama_cpp_kv_type_id(cache_type: str) -> Optional[int]:
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
def llama_cpp_kv_type_id(cache_type: str) -> Optional[int]:
    """Return llama-cpp-python ``--type_k`` / ``--type_v`` integer for a cache label."""
    # Python line: return _LLAMA_CPP_KV_TYPE_ID.get(normalize_cache_type(cache_type))
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    return _LLAMA_CPP_KV_TYPE_ID.get(normalize_cache_type(cache_type))


# Python line: def normalize_cache_type(name: str) -> str:
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
def normalize_cache_type(name: str) -> str:
    """Normalize llama.cpp cache type labels to lowercase keys."""
    # Python line: return str(name).strip().lower()
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    return str(name).strip().lower()


# Python line: def b_precision_from_cache_types(
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
def b_precision_from_cache_types(
    *,
    cache_type_k: str,
    cache_type_v: str,
) -> float:
    """
    Return b_precision for the KV closed form (§3.1.2).

    Uses the max bytes/element across K and V cache types when they differ.
    """
    # Python line: k = normalize_cache_type(cache_type_k)
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    k = normalize_cache_type(cache_type_k)
    # Python line: v = normalize_cache_type(cache_type_v)
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    v = normalize_cache_type(cache_type_v)
    # Python line: bk = _CACHE_TYPE_BYTES.get(k)
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    bk = _CACHE_TYPE_BYTES.get(k)
    # Python line: bv = _CACHE_TYPE_BYTES.get(v)
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    bv = _CACHE_TYPE_BYTES.get(v)
    # Python line: if bk is None or bv is None:
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    if bk is None or bv is None:
        # Python line: known = ", ".join(sorted(_CACHE_TYPE_BYTES))
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        known = ", ".join(sorted(_CACHE_TYPE_BYTES))
        # Python line: raise ValueError(
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        raise ValueError(
            # Python line: f"Unknown cache type k={cache_type_k!r} v={cache_type_v!r}; known: {known}"
            # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
            # Implements .cursorrules dense-comment policy for src/ code.
            f"Unknown cache type k={cache_type_k!r} v={cache_type_v!r}; known: {known}"
        # Python line: )
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        )
    # Python line: return max(bk, bv)
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    return max(bk, bv)


# Python line: def gguf_on_disk_mb(gguf_path: Path) -> float:
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
def gguf_on_disk_mb(gguf_path: Path) -> float:
    """Return GGUF file size in MiB (reported on-disk weight footprint)."""
    # Python line: size_bytes = gguf_path.stat().st_size
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    size_bytes = gguf_path.stat().st_size
    # Python line: return size_bytes / (1024.0 * 1024.0)
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    return size_bytes / (1024.0 * 1024.0)


# Python line: def m_weights_reported_mb(
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
def m_weights_reported_mb(
    *,
    gguf_path: Path,
    runtime_overhead_mb: float,
) -> float:
    """
    Q4_K_M weight term: on-disk GGUF size + llama.cpp runtime overhead (§3.2).

    Do NOT use n_params × 2 B for Q4_K_M models.
    """
    # Python line: return gguf_on_disk_mb(gguf_path) + float(runtime_overhead_mb)
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    return gguf_on_disk_mb(gguf_path) + float(runtime_overhead_mb)


# Python line: def m_kv_mb(
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
def m_kv_mb(
    *,
    context_length_tokens: float,
    n_layers: int,
    n_kv_heads: int,
    d_head: int,
    b_precision: float,
) -> float:
    """
    KV-cache footprint at context length L (plan §3.1.2).

    M_KV = 2 × L × n_layers × n_kv_heads × d_head × b_precision  (bytes → MiB)
    """
    # Python line: if context_length_tokens < 0:
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    if context_length_tokens < 0:
        # Python line: raise ValueError("context_length_tokens must be non-negative")
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        raise ValueError("context_length_tokens must be non-negative")
    # Python line: bytes_total = (
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    bytes_total = (
        # Python line: 2.0
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        2.0
        # Python line: * float(context_length_tokens)
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        * float(context_length_tokens)
        # Python line: * float(n_layers)
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        * float(n_layers)
        # Python line: * float(n_kv_heads)
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        * float(n_kv_heads)
        # Python line: * float(d_head)
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        * float(d_head)
        # Python line: * float(b_precision)
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        * float(b_precision)
    # Python line: )
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: return bytes_total / (1024.0 * 1024.0)
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    return bytes_total / (1024.0 * 1024.0)


# Python line: def m_vram_mb(
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
def m_vram_mb(
    *,
    context_length_tokens: float,
    m_weights_mb: float,
    m_act_mb: float,
    n_layers: int,
    n_kv_heads: int,
    d_head: int,
    b_precision: float,
) -> float:
    """Total VRAM envelope M_weights + M_KV(L) + M_act (plan §3.1.3)."""
    # Python line: return (
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    return (
        # Python line: float(m_weights_mb)
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        float(m_weights_mb)
        # Python line: + m_kv_mb(
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        + m_kv_mb(
            # Python line: context_length_tokens=context_length_tokens,
            # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
            # Implements .cursorrules dense-comment policy for src/ code.
            context_length_tokens=context_length_tokens,
            # Python line: n_layers=n_layers,
            # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
            # Implements .cursorrules dense-comment policy for src/ code.
            n_layers=n_layers,
            # Python line: n_kv_heads=n_kv_heads,
            # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
            # Implements .cursorrules dense-comment policy for src/ code.
            n_kv_heads=n_kv_heads,
            # Python line: d_head=d_head,
            # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
            # Implements .cursorrules dense-comment policy for src/ code.
            d_head=d_head,
            # Python line: b_precision=b_precision,
            # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
            # Implements .cursorrules dense-comment policy for src/ code.
            b_precision=b_precision,
        # Python line: )
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        )
        # Python line: + float(m_act_mb)
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        + float(m_act_mb)
    # Python line: )
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    )


# Python line: def peak_context_length_tokens(
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
def peak_context_length_tokens(
    *,
    l_base: float,
    total_completion_tokens: float,
    expected_tool_tokens: float = 0.0,
) -> float:
    """F2 peak context length: L_base + total agent completion tokens + tools."""
    return float(l_base) + max(0.0, float(total_completion_tokens)) + float(expected_tool_tokens)


# Python line: def agentic_context_length_tokens(
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
def agentic_context_length_tokens(
    *,
    step_index: int,
    n_steps: int,
    l_base: float,
    e_hat: float,
    expected_tool_tokens: float = 0.0,
) -> float:
    """
  Compute L(t) from plan §3.1.1 for step_index in [0, n_steps].

    Simplified single-agent form without per-tool breakdown when
    expected_tool_tokens aggregates the tool term.
    """
    # Python line: if n_steps <= 0:
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    if n_steps <= 0:
        # Python line: return float(l_base)
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        return float(l_base)
    # Python line: t = max(0, min(int(step_index), int(n_steps)))
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    t = max(0, min(int(step_index), int(n_steps)))
    # Python line: tool_term = (t / float(n_steps)) * float(expected_tool_tokens)
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    tool_term = (t / float(n_steps)) * float(expected_tool_tokens)
    # Python line: return float(l_base) + t * float(e_hat) + tool_term
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    return float(l_base) + t * float(e_hat) + tool_term


# Python line: def closed_form_accounting_payload(
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
def closed_form_accounting_payload(
    *,
    model_cfg: Mapping[str, Any],
    calibration: Mapping[str, Any],
) -> Dict[str, Any]:
    """
    Build trace metadata fields for Q4_K_M closed-form accounting (§3.2).

    Merges per-model architecture, cache types, and calibrated M_weights/M_act.
    """
    # Python line: gguf_path = Path(str(model_cfg["gguf_path"]))
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    gguf_path = Path(str(model_cfg["gguf_path"]))
    # Python line: cache_type_k = str(model_cfg.get("cache_type_k", "f16"))
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    cache_type_k = str(model_cfg.get("cache_type_k", "f16"))
    # Python line: cache_type_v = str(model_cfg.get("cache_type_v", "f16"))
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    cache_type_v = str(model_cfg.get("cache_type_v", "f16"))
    # Python line: b_precision = b_precision_from_cache_types(
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    b_precision = b_precision_from_cache_types(
        # Python line: cache_type_k=cache_type_k,
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        cache_type_k=cache_type_k,
        # Python line: cache_type_v=cache_type_v,
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        cache_type_v=cache_type_v,
    # Python line: )
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: runtime_overhead_mb = float(
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    runtime_overhead_mb = float(
        # Python line: calibration.get(
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        calibration.get(
            # Python line: "runtime_overhead_mb",
            # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
            # Implements .cursorrules dense-comment policy for src/ code.
            "runtime_overhead_mb",
            # Python line: model_cfg.get("runtime_overhead_mb", 0.0),
            # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
            # Implements .cursorrules dense-comment policy for src/ code.
            model_cfg.get("runtime_overhead_mb", 0.0),
        # Python line: )
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        )
    # Python line: )
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: m_weights = m_weights_reported_mb(
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    m_weights = m_weights_reported_mb(
        # Python line: gguf_path=gguf_path,
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        gguf_path=gguf_path,
        # Python line: runtime_overhead_mb=runtime_overhead_mb,
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        runtime_overhead_mb=runtime_overhead_mb,
    # Python line: )
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: m_act = float(calibration.get("M_act_mb", model_cfg.get("M_act_mb", 0.0)))
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    m_act = float(calibration.get("M_act_mb", model_cfg.get("M_act_mb", 0.0)))
    # Python line: return {
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    return {
        # Python line: "gguf_on_disk_mb": round(gguf_on_disk_mb(gguf_path), 3),
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        "gguf_on_disk_mb": round(gguf_on_disk_mb(gguf_path), 3),
        # Python line: "runtime_overhead_mb": round(runtime_overhead_mb, 3),
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        "runtime_overhead_mb": round(runtime_overhead_mb, 3),
        # Python line: "M_weights_reported_mb": round(m_weights, 3),
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        "M_weights_reported_mb": round(m_weights, 3),
        # Python line: "M_act_mb": round(m_act, 3),
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        "M_act_mb": round(m_act, 3),
        # Python line: "b_precision": b_precision,
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        "b_precision": b_precision,
        # Python line: "cache_type_k": cache_type_k,
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        "cache_type_k": cache_type_k,
        # Python line: "cache_type_v": cache_type_v,
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        "cache_type_v": cache_type_v,
        # Python line: "n_layers": int(model_cfg["n_layers"]),
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        "n_layers": int(model_cfg["n_layers"]),
        # Python line: "n_kv_heads": int(model_cfg["n_kv_heads"]),
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        "n_kv_heads": int(model_cfg["n_kv_heads"]),
        # Python line: "d_head": int(model_cfg["d_head"]),
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        "d_head": int(model_cfg["d_head"]),
    # Python line: }
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    }


# Python line: def vram_at_generator_start_mb(trace_jsonl: Path) -> Optional[float]:
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
def vram_at_generator_start_mb(trace_jsonl: Path) -> Optional[float]:
    """Read VRAM (MiB) at the first ``generator:start`` boundary from a trace file."""
    # Python line: from src.tracing.vram_join import iter_trace_jsonl
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    from src.tracing.vram_join import iter_trace_jsonl

    # Python line: if not Path(trace_jsonl).is_file():
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    if not Path(trace_jsonl).is_file():
        # Python line: return None
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        return None

    # Python line: for row in iter_trace_jsonl(Path(trace_jsonl)):
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    for row in iter_trace_jsonl(Path(trace_jsonl)):
        # Python line: if row.get("record") != "vram_sample":
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        if row.get("record") != "vram_sample":
            # Python line: continue
            # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
            # Implements .cursorrules dense-comment policy for src/ code.
            continue
        # Python line: boundary = str(row.get("boundary", ""))
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        boundary = str(row.get("boundary", ""))
        # Python line: if boundary == "generator:start" or boundary.startswith("generator@retry_") and boundary.endswith(":start"):
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        if boundary == "generator:start" or (
            boundary.startswith("generator@retry_") and boundary.endswith(":start")
        ):
            # Python line: return float(row["vram_used_mb"])
            # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
            # Implements .cursorrules dense-comment policy for src/ code.
            return float(row["vram_used_mb"])
    # Python line: return None
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    return None


# Python line: def measure_m_act_mb(
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
def measure_m_act_mb(
    *,
    vram_at_generator_start_mb: float,
    m_weights_reported_mb: float,
) -> float:
    """Empirical M_act per §3.2: VRAM at generator start minus reported weights."""
    # Python line: return max(0.0, float(vram_at_generator_start_mb) - float(m_weights_reported_mb))
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    return max(0.0, float(vram_at_generator_start_mb) - float(m_weights_reported_mb))


# Python line: def load_model_calibration(
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
def load_model_calibration(
    calibration_path: Path,
    model_id: str,
    *,
    cache_type_k: str = "f16",
    cache_type_v: str = "f16",
) -> Dict[str, Any]:
    """Load per-model Q4 calibration from v1 or v2 YAML (optional KV-cache pair)."""
    # Python line: if not calibration_path.is_file():
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    if not calibration_path.is_file():
        # Python line: return {}
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        return {}
    # Python line: import yaml
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    import yaml

    # Python line: data = yaml.safe_load(calibration_path.read_text(encoding="utf-8")) or {}
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    data = yaml.safe_load(calibration_path.read_text(encoding="utf-8")) or {}
    # Python line: models = data.get("models", {})
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    models = data.get("models", {})
    # Python line: row = models.get(model_id, {})
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    row = models.get(model_id, {})
    # Python line: if not isinstance(row, dict):
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    if not isinstance(row, dict):
        # Python line: return {}
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        return {}
    # Python line: if "gguf_on_disk_mb" in row:
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    if "gguf_on_disk_mb" in row:
        # Python line: return dict(row)
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        return dict(row)
    # Python line: pair_key = f"{cache_type_k}/{cache_type_v}"
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    pair_key = f"{cache_type_k}/{cache_type_v}"
    # Python line: cache_pairs = row.get("cache_pairs", {})
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    cache_pairs = row.get("cache_pairs", {})
    # Python line: nested = cache_pairs.get(pair_key, {}) if isinstance(cache_pairs, dict) else {}
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    nested = cache_pairs.get(pair_key, {}) if isinstance(cache_pairs, dict) else {}
    # Python line: return dict(nested) if isinstance(nested, dict) else {}
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    return dict(nested) if isinstance(nested, dict) else {}


# Python line: def closed_form_peak_labels(
# Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
# Implements .cursorrules dense-comment policy for src/ code.
def closed_form_peak_labels(
    *,
    accounting: Mapping[str, Any],
    n_steps: int,
    l_base: float,
    e_hat: float,
    vram_at_generator_start_mb: Optional[float] = None,
) -> Dict[str, Any]:
    """
    Compute closed-form VRAM at peak context L(N) for trace summary (§3.2).

    When generator-start VRAM is available, also reports per-run M_act_observed_mb.
    """
    # Python line: l_peak = agentic_context_length_tokens(
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    l_peak = agentic_context_length_tokens(
        # Python line: step_index=n_steps,
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        step_index=n_steps,
        # Python line: n_steps=n_steps,
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        n_steps=n_steps,
        # Python line: l_base=l_base,
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        l_base=l_base,
        # Python line: e_hat=e_hat,
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        e_hat=e_hat,
    # Python line: )
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: m_weights = float(accounting["M_weights_reported_mb"])
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    m_weights = float(accounting["M_weights_reported_mb"])
    # Python line: m_act = float(accounting["M_act_mb"])
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    m_act = float(accounting["M_act_mb"])
    # Python line: b_precision = float(accounting["b_precision"])
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    b_precision = float(accounting["b_precision"])
    # Python line: m_kv_peak = m_kv_mb(
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    m_kv_peak = m_kv_mb(
        # Python line: context_length_tokens=l_peak,
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        context_length_tokens=l_peak,
        # Python line: n_layers=int(accounting["n_layers"]),
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        n_layers=int(accounting["n_layers"]),
        # Python line: n_kv_heads=int(accounting["n_kv_heads"]),
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        n_kv_heads=int(accounting["n_kv_heads"]),
        # Python line: d_head=int(accounting["d_head"]),
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        d_head=int(accounting["d_head"]),
        # Python line: b_precision=b_precision,
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        b_precision=b_precision,
    # Python line: )
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: m_closed = m_vram_mb(
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    m_closed = m_vram_mb(
        # Python line: context_length_tokens=l_peak,
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        context_length_tokens=l_peak,
        # Python line: m_weights_mb=m_weights,
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        m_weights_mb=m_weights,
        # Python line: m_act_mb=m_act,
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        m_act_mb=m_act,
        # Python line: n_layers=int(accounting["n_layers"]),
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        n_layers=int(accounting["n_layers"]),
        # Python line: n_kv_heads=int(accounting["n_kv_heads"]),
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        n_kv_heads=int(accounting["n_kv_heads"]),
        # Python line: d_head=int(accounting["d_head"]),
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        d_head=int(accounting["d_head"]),
        # Python line: b_precision=b_precision,
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        b_precision=b_precision,
    # Python line: )
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: out: Dict[str, Any] = {
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    out: Dict[str, Any] = {
        # Python line: "L_peak_tokens": round(l_peak, 3),
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        "L_peak_tokens": round(l_peak, 3),
        # Python line: "M_kv_peak_mb": round(m_kv_peak, 3),
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        "M_kv_peak_mb": round(m_kv_peak, 3),
        # Python line: "M_closed_form_peak_mb": round(m_closed, 3),
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        "M_closed_form_peak_mb": round(m_closed, 3),
    # Python line: }
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    }
    # Python line: if vram_at_generator_start_mb is not None:
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    if vram_at_generator_start_mb is not None:
        # Python line: out["M_act_observed_mb"] = round(
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        out["M_act_observed_mb"] = round(
            # Python line: measure_m_act_mb(
            # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
            # Implements .cursorrules dense-comment policy for src/ code.
            measure_m_act_mb(
                # Python line: vram_at_generator_start_mb=vram_at_generator_start_mb,
                # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
                # Implements .cursorrules dense-comment policy for src/ code.
                vram_at_generator_start_mb=vram_at_generator_start_mb,
                # Python line: m_weights_reported_mb=m_weights,
                # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
                # Implements .cursorrules dense-comment policy for src/ code.
                m_weights_reported_mb=m_weights,
            # Python line: ),
            # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
            # Implements .cursorrules dense-comment policy for src/ code.
            ),
            # Python line: 3,
            # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
            # Implements .cursorrules dense-comment policy for src/ code.
            3,
        # Python line: )
        # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
        # Implements .cursorrules dense-comment policy for src/ code.
        )
    # Python line: return out
    # Phase 3.2 Q4_K_M VRAM accounting (src/forecast).
    # Implements .cursorrules dense-comment policy for src/ code.
    return out
