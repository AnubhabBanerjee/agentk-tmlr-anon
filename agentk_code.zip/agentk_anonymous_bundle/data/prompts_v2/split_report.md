# Stratified split report (Phase 2.4)

- Seed: **20260715**
- Ratios: train 70%, val 15%, test 15%
- Stratify on: `source` × `family` × `complexity`
- Total prompts: **300**

## Global split counts

| Split | Count | Fraction |
|-------|------:|---------:|
| train | 210 | 70.0% |
| val | 45 | 15.0% |
| test | 45 | 15.0% |

## Per-stratum counts

| source | family | complexity | train | val | test | total |
|--------|--------|------------|------:|----:|-----:|------:|
| clean_synthetic | GEMM | advanced | 3 | 0 | 1 | 4 |
| clean_synthetic | GEMM | beginner | 2 | 0 | 1 | 3 |
| clean_synthetic | GEMM | intermediate | 3 | 0 | 1 | 4 |
| clean_synthetic | convolution | advanced | 2 | 0 | 1 | 3 |
| clean_synthetic | convolution | beginner | 3 | 0 | 1 | 4 |
| clean_synthetic | convolution | intermediate | 2 | 0 | 1 | 3 |
| clean_synthetic | distractor | advanced | 1 | 0 | 1 | 2 |
| clean_synthetic | distractor | beginner | 3 | 0 | 1 | 4 |
| clean_synthetic | distractor | intermediate | 3 | 0 | 1 | 4 |
| clean_synthetic | elementwise | advanced | 3 | 0 | 1 | 4 |
| clean_synthetic | elementwise | beginner | 3 | 0 | 1 | 4 |
| clean_synthetic | elementwise | intermediate | 3 | 0 | 1 | 4 |
| clean_synthetic | reduction | advanced | 3 | 0 | 1 | 4 |
| clean_synthetic | reduction | beginner | 3 | 0 | 1 | 4 |
| clean_synthetic | reduction | intermediate | 3 | 0 | 1 | 4 |
| clean_synthetic | scan | advanced | 3 | 0 | 1 | 4 |
| clean_synthetic | scan | beginner | 2 | 0 | 1 | 3 |
| clean_synthetic | scan | intermediate | 3 | 0 | 1 | 4 |
| clean_synthetic | sorting | advanced | 3 | 0 | 1 | 4 |
| clean_synthetic | sorting | beginner | 3 | 0 | 1 | 4 |
| clean_synthetic | sorting | intermediate | 3 | 1 | 0 | 4 |
| clean_synthetic | sparse | advanced | 2 | 1 | 0 | 3 |
| clean_synthetic | sparse | beginner | 3 | 1 | 0 | 4 |
| clean_synthetic | sparse | intermediate | 3 | 1 | 0 | 4 |
| clean_synthetic | transformer-attention | advanced | 3 | 1 | 0 | 4 |
| clean_synthetic | transformer-attention | beginner | 2 | 1 | 0 | 3 |
| clean_synthetic | transformer-attention | intermediate | 3 | 1 | 0 | 4 |
| kernelbench | GEMM | beginner | 4 | 1 | 1 | 6 |
| kernelbench | GEMM | intermediate | 5 | 2 | 1 | 8 |
| kernelbench | convolution | advanced | 3 | 1 | 1 | 5 |
| kernelbench | convolution | beginner | 8 | 2 | 1 | 11 |
| kernelbench | convolution | intermediate | 10 | 3 | 2 | 15 |
| kernelbench | elementwise | advanced | 8 | 2 | 1 | 11 |
| kernelbench | elementwise | adversarial-broken-spec | 8 | 2 | 1 | 11 |
| kernelbench | elementwise | beginner | 1 | 1 | 0 | 2 |
| kernelbench | reduction | advanced | 1 | 0 | 0 | 1 |
| kernelbench | reduction | beginner | 5 | 1 | 1 | 7 |
| kernelbench | transformer-attention | advanced | 6 | 2 | 1 | 9 |
| kernelbench | transformer-attention | adversarial-broken-spec | 6 | 2 | 1 | 9 |
| kernelbench | transformer-attention | beginner | 1 | 1 | 0 | 2 |
| kernelbench | transformer-attention | intermediate | 2 | 1 | 0 | 3 |
| retry_provoking_synthetic | GEMM | adversarial-broken-spec | 7 | 2 | 1 | 10 |
| retry_provoking_synthetic | convolution | adversarial-broken-spec | 10 | 2 | 2 | 14 |
| retry_provoking_synthetic | distractor | adversarial-broken-spec | 4 | 1 | 1 | 6 |
| retry_provoking_synthetic | elementwise | adversarial-broken-spec | 5 | 2 | 1 | 8 |
| retry_provoking_synthetic | reduction | adversarial-broken-spec | 8 | 2 | 2 | 12 |
| retry_provoking_synthetic | scan | adversarial-broken-spec | 10 | 2 | 2 | 14 |
| retry_provoking_synthetic | sorting | adversarial-broken-spec | 8 | 2 | 2 | 12 |
| retry_provoking_synthetic | sparse | adversarial-broken-spec | 9 | 2 | 2 | 13 |
| retry_provoking_synthetic | transformer-attention | adversarial-broken-spec | 8 | 2 | 1 | 11 |
