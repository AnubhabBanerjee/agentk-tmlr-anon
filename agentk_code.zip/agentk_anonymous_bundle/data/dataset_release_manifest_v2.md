# Dataset release manifest — `agentk-vram-released`

| Field | Value |
|-------|-------|
| **Dataset name** | `agentk-vram-v2` |
| **Release version** | `v2.0.0` |
| **Freeze git SHA** | `3d4dee6c7071e3881335306e5dd876ee71c95d6f` |
| **Generated** | 2026-07-23 (UTC) |
| **License** | Apache-2.0 |

All artifacts below were hashed at freeze time with `git rev-parse HEAD` =
`3d4dee6c7071e3881335306e5dd876ee71c95d6f`. The `sha256` column lists the
first 16 hexadecimal digits of each file's SHA-256 digest (full digests available
on request).

## Per-artifact inventory

| path | git_sha | row_count | sha256 | bytes |
|------|---------|----------:|--------|------:|
| `data/traces_v2/index.parquet` | `3d4dee6c7071e3881335306e5dd876ee71c95d6f` | 1920 | `c5e4f9f2a4df9c5a` | 935913 |
| `data/labels_v2/phi-4-mini.parquet` | `3d4dee6c7071e3881335306e5dd876ee71c95d6f` | 300 | `c7c163cce33f9b3b` | 162555 |
| `data/labels_v2/qwen2.5-coder-7b.parquet` | `3d4dee6c7071e3881335306e5dd876ee71c95d6f` | 540 | `c3b6f2c28b45b363` | 208656 |
| `data/labels_v2/qwen2.5-coder-14b.parquet` | `3d4dee6c7071e3881335306e5dd876ee71c95d6f` | 540 | `481e02e99699c710` | 224390 |
| `data/labels_v2/mistral-7b-instruct-v0.3.parquet` | `3d4dee6c7071e3881335306e5dd876ee71c95d6f` | 540 | `91ee9f40b9907bc3` | 178022 |
| `data/correctness_v2/kernelbench.parquet` | `3d4dee6c7071e3881335306e5dd876ee71c95d6f` | 1920 | `34f9d8639f19843f` | 28826 |
| `data/prompts_v2/all.jsonl` | `3d4dee6c7071e3881335306e5dd876ee71c95d6f` | 300 | `2387eef3de6be99e` | 161929 |
| `data/prompts_v2/split.json` | `3d4dee6c7071e3881335306e5dd876ee71c95d6f` | — | `2ccaac6a3a82eb39` | 6230 |
| `configs/tracing_v2.yaml` | `3d4dee6c7071e3881335306e5dd876ee71c95d6f` | — | `44f1df73f2b6dd84` | 1265 |
| `configs/agent_llms_v2.yaml` | `3d4dee6c7071e3881335306e5dd876ee71c95d6f` | — | `b32b66885c4275ef` | 2311 |
| `configs/q4_vram_calibration_v2.yaml` | `3d4dee6c7071e3881335306e5dd876ee71c95d6f` | — | `7057e60972a5810c` | 4262 |
| `configs/model_manifest.yaml` | `3d4dee6c7071e3881335306e5dd876ee71c95d6f` | — | `6763a0e19a7ffaed` | 2389 |

**Row-count notes.**

- `index.parquet`: 1920 traced runs (4 agents × 300 prompts × sweep replicates where applicable).
- Label shards: Phi 300 rows; Qwen-7B, Qwen-14B, Mistral 540 rows each (matches per-agent trace budget).
- `kernelbench.parquet`: one correctness row per traced run (1920).
- `all.jsonl`: 300 unique prompt definitions.

## Reproducibility recipe

From a clean checkout of the freeze commit:

```bash
git checkout 3d4dee6c7071e3881335306e5dd876ee71c95d6f
bash scripts/01_download_models.sh
make trace-batch-v2 CONFIG=configs/tracing_v2.yaml
```

Expected wall time: **~57 GPU-hours on 1× NVIDIA H100** (full v2 trace batch).

## License

Released under the **Apache License 2.0**.
