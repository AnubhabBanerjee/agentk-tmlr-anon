# Reproduction Notes

This note orients a reader inside the code artifact. It does not replace the
paper; it is a map of which files matter for checking the specific numbers in
Table 2 and the surrounding text, and a short note about code style.

## Fastest path to reproducing Table 2

No GPU, no retraining, no network access required:

```
python scripts/reproduce_table2.py
# or: make reproduce-table2
```

This reads the frozen test-split predictions in
`data/frozen_predictions_table2/{agent_llm}/{method}/test.parquet`
(shipped in this bundle) plus the released `data/labels_v2/` and
`data/traces_v2/index.parquet`, and reprints Table 2's numbers and LaTeX. See
the paper's "Reproducing Table 2 Without a GPU" appendix for the full
explanation, including how B2's training-time randomness is seeded
(`B2_RANDOM_SEED` in `src/baselines/b2_direct_regression.py`) and where the
seed used for the shipped predictions is recorded
(`data/frozen_predictions_table2/{agent_llm}/B2/fit_meta.json`).

To re-check Table 4's per-backbone `N_true` summary (mean/median/max) directly
against the released trace index:

```
python scripts/verify_paper_numbers.py
# or: make verify-paper-numbers
```

## Files most relevant to the paper tables

These are the files to read carefully if you are checking a specific number in
the paper; everything else in `src/` is supporting plumbing.

| Paper item | File(s) |
|---|---|
| B0/B5 closed-form accounting, calibration constants | `src/forecast/q4_km_accounting.py`, `configs/q4_vram_calibration_v2.yaml` |
| B0 undercoverage definition (no z_alpha interval) | `src/baselines/b0_max_context.py` |
| B5 undercoverage definition (no z_alpha interval) | `src/baselines/b5_oracle.py` |
| B2 seeding / reproducibility | `src/baselines/b2_direct_regression.py` |
| Table 2 metric definitions (MAPE, MAE, undercoverage, OAW) | `src/eval/metrics.py` |
| Table 6 variance-decomposition ANOVA (`retry_count` grouping) | `src/eval/variance_decomposition.py` |
| Table 4 regeneration from the release | `scripts/verify_paper_numbers.py` |
| Table 2 regeneration from frozen predictions | `scripts/reproduce_table2.py` |
| KernelBench correctness failure taxonomy (149 `False` rows) | `data/correctness_v2/kernelbench.parquet` (see `wrap_error`, `harness_status` columns) |

## A note on code style

`src/` carries dense inline comments throughout. The files in the table above
are the ones that directly define the paper's reported metrics and baselines;
other modules are supporting infrastructure.
