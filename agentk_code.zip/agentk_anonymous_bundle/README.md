# Memory Constrained Agentic AI

Research codebase for forecasting VRAM trajectories in single-agent LangGraph CUDA workflows.

## Overview

This repository implements:

- Execution tracing over a LangGraph-based CUDA agent (AgentK)
- A lightweight multi-task proxy that maps prompts to structural execution parameters
- Closed-form VRAM trajectory forecasting with Q4_K_M-aware accounting
- Baselines, evaluation metrics, and paper figures for a  submission


## Repository layout

```text
configs/          YAML configuration for LLMs, proxy backbones, and tracing
data/             Prompts, traces, labels, and correctness outputs (gitignored)
scripts/          Phase scripts (download, trace, train, evaluate, figures)
src/              Python package (tracing, proxy, baselines, forecast, eval, viz)
paper/             LaTeX sources
tests/            Unit tests (forecast formulas first)
notebooks/        Exploratory analysis only
```

## Setup

This project uses the **global conda Python** at `/opt/conda/bin/python3` (3.10.14) on the target machine. A local `venv` is optional.

```bash
# Install only packages not already present globally.
pip install -r requirements.txt

# Verify imports and GPU visibility.
python3 scripts/check_environment.py
```

`requirements.txt` pins exact versions verified on the target machine (see compatibility notes at the top of that file).

`llama-cpp-python` must be built with CUDA support on the target GPU machine (already present globally as 0.3.33).

## AgentK

AgentK is vendored as a **git submodule** at `third_party/agentk`, pinned in `configs/agentk_version.txt`.

```bash
# After git clone, initialize the submodule:
git -c http.sslBackend=gnutls submodule update --init third_party/agentk

# Or run the setup helper:
bash scripts/setup_agentk.sh
```

License: **Polyform Noncommercial 1.0.0** (planned on the AgentK repo). Sufficient for  academic review and noncommercial reproduction; not for commercial redistribution without a separate license.

Local mode uses `ACTIVE_ENV=local` with a llama.cpp OpenAI-compatible server — see `configs/agentk.env.example`.
