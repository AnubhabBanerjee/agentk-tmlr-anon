#!/usr/bin/env python3
"""
F2 Tier-1 — redefine N_true as total completion tokens in existing trace JSONL files.

Reads ``node_event`` rows (no re-tracing), updates summary ``N_true`` / ``N_nodes_true``,
then rebuilds index + labels when ``--rebuild`` is set.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

_REPO = Path(__file__).resolve().parents[1]
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from src.tracing.n_labels import summary_from_node_event_records


def apply_f2_to_jsonl(path: Path, *, dry_run: bool = False) -> dict:
    """Rewrite one trace JSONL summary with F2 ``N_true`` semantics."""
    lines = [ln for ln in path.read_text(encoding="utf-8").splitlines() if ln.strip()]
    records = [json.loads(ln) for ln in lines]
    summary_idx = next((i for i, r in enumerate(records) if r.get("record") == "summary"), None)
    if summary_idx is None:
        raise ValueError(f"No summary record in {path}")
    old_n = int(records[summary_idx].get("N_true", 0))
    recomputed = summary_from_node_event_records(records)
    records[summary_idx]["N_true"] = recomputed["N_true"]
    records[summary_idx]["N_nodes_true"] = recomputed["N_nodes_true"]
    records[summary_idx]["n_true_semantics"] = "total_completion_tokens_f2"
    if not dry_run:
        path.write_text(
            "\n".join(json.dumps(r, ensure_ascii=False) for r in records) + "\n",
            encoding="utf-8",
        )
    return {
        "path": str(path),
        "N_true_old": old_n,
        "N_true_new": recomputed["N_true"],
        "N_nodes_true": recomputed["N_nodes_true"],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Apply F2 N_true relabeling to trace JSONL files.")
    parser.add_argument("--repo-root", type=Path, default=_REPO)
    parser.add_argument("--trace-root", type=Path, default=None, help="Default: data/traces")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--rebuild", action="store_true", help="Run build_trace_index + build_labels after.")
    args = parser.parse_args()
    trace_root = args.trace_root or (args.repo_root / "data" / "traces")
    paths = sorted(trace_root.rglob("*.jsonl"))
    if not paths:
        raise SystemExit(f"No JSONL traces under {trace_root}")
    changed = 0
    for path in paths:
        stats = apply_f2_to_jsonl(path, dry_run=args.dry_run)
        if stats["N_true_old"] != stats["N_true_new"]:
            changed += 1
    print(json.dumps({"traces": len(paths), "n_changed": changed, "dry_run": args.dry_run}, indent=2))
    if args.rebuild and not args.dry_run:
        import subprocess

        subprocess.run([sys.executable, str(args.repo_root / "scripts" / "build_trace_index.py")], check=True)
        subprocess.run([sys.executable, str(args.repo_root / "scripts" / "build_labels.py")], check=True)
        print("Rebuilt index.parquet and label parquets.")


if __name__ == "__main__":
    main()
