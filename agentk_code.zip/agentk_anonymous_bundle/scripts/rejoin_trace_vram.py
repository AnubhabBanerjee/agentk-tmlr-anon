#!/usr/bin/env python3
"""
F1 Tier-1 — post-hoc rejoin nvidia-smi sidecar CSV to an existing trace JSONL.

Rebuilds ``vram_sample`` rows and ``M_peak_true`` from:
  - ``{prompt_id}.nvidia_smi.csv`` (or path in metadata)
  - node boundary wall times derived from ``node_event`` rows + ``vram_wall_t0_epoch``

Usage:
  python3 scripts/rejoin_trace_vram.py --trace data/traces/qwen2.5-coder-7b/p001.jsonl
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

_REPO = Path(__file__).resolve().parents[1]
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from src.tracing.vram_join import (
    build_vram_samples_from_nvidia_smi,
    load_trace_jsonl,
    peak_used_mb_from_samples,
)
from src.tracing.llm_recorder import nvidia_smi_sidecar_path, write_trace_jsonl_file


def _boundaries_from_node_events(
    node_events: List[Dict[str, Any]],
    wall_t0: float,
) -> List[Tuple[str, float]]:
    boundaries: List[Tuple[str, float]] = [("run_start", wall_t0)]
    for event in node_events:
        name = str(event["node_name"])
        boundaries.append((f"{name}:start", wall_t0 + float(event["t_wall_start"])))
        boundaries.append((f"{name}:end", wall_t0 + float(event["t_wall_end"])))
    return boundaries


def rejoin_trace_vram(
    *,
    trace_path: Path,
    sidecar_path: Path | None = None,
    dry_run: bool = False,
) -> Dict[str, Any]:
    """Rewrite trace JSONL vram_sample rows from nvidia-smi sidecar."""
    rows = load_trace_jsonl(trace_path)
    metadata = next((r for r in rows if r.get("record") == "metadata"), None)
    if metadata is None:
        raise ValueError(f"No metadata record in {trace_path}")
    sidecar = sidecar_path
    if sidecar is None:
        rel = metadata.get("nvidia_smi_sidecar")
        if rel:
            sidecar = trace_path.parent / str(rel)
        else:
            sidecar = nvidia_smi_sidecar_path(trace_path)
    if not sidecar.is_file():
        raise FileNotFoundError(f"Missing nvidia-smi sidecar: {sidecar}")
    wall_t0 = metadata.get("vram_wall_t0_epoch")
    if wall_t0 is None:
        raise ValueError(
            "metadata lacks vram_wall_t0_epoch; re-run trace with nvidia_smi sampler "
            "or pass a trace that recorded wall-clock origin."
        )
    node_events = [r for r in rows if r.get("record") == "node_event"]
    boundaries = _boundaries_from_node_events(node_events, float(wall_t0))
    boundaries.append(("run_end", boundaries[-1][1] if boundaries else float(wall_t0)))
    csv_text = sidecar.read_text(encoding="utf-8")
    samples = build_vram_samples_from_nvidia_smi(
        csv_text=csv_text,
        wall_t0=float(wall_t0),
        boundaries=boundaries,
    )
    m_peak = peak_used_mb_from_samples(samples)
    kept = [r for r in rows if r.get("record") not in ("vram_sample", "summary")]
    new_rows: List[Dict[str, Any]] = []
    for row in kept:
        if row.get("record") == "metadata":
            meta = dict(row)
            meta["vram_sampler"] = "nvidia_smi"
            meta["nvidia_smi_sidecar"] = sidecar.name
            new_rows.append(meta)
        else:
            new_rows.append(row)
    for sample in samples:
        new_rows.append(
            {
                "record": "vram_sample",
                "t_ms": sample.t_ms,
                "vram_used_mb": sample.vram_used_mb,
                "boundary": sample.boundary,
            }
        )
    summary = next((r for r in rows if r.get("record") == "summary"), {})
    summary = dict(summary)
    summary["M_peak_true"] = round(m_peak, 3)
    traj = [
        {"boundary": s.boundary, "t_ms": s.t_ms, "vram_used_mb": s.vram_used_mb}
        for s in samples
        if s.boundary is not None
    ]
    summary["M_trajectory_true"] = traj
    new_rows.append({"record": "summary", **summary})
    if not dry_run:
        write_trace_jsonl_file(trace_path, new_rows)
    return {
        "trace": str(trace_path),
        "sidecar": str(sidecar),
        "n_vram_samples": len(samples),
        "M_peak_true": m_peak,
        "dry_run": dry_run,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Rejoin nvidia-smi VRAM sidecar to trace JSONL.")
    parser.add_argument("--trace", type=Path, required=True, help="Path to trace JSONL.")
    parser.add_argument("--sidecar", type=Path, default=None, help="Override nvidia-smi CSV path.")
    parser.add_argument("--dry-run", action="store_true", help="Compute metrics without writing.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    result = rejoin_trace_vram(
        trace_path=args.trace,
        sidecar_path=args.sidecar,
        dry_run=args.dry_run,
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
