#!/usr/bin/env python3
"""
Phase 1.4/1.5 — AgentK smoke test: 3 LLMs x 3 seed prompts.

Starts llama.cpp server per model, applies agentk_llama_compat shim, invokes the
LangGraph app, and records compile_success per run.
"""

from __future__ import annotations

# Standard library imports for subprocess orchestration and result persistence.
import argparse
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

# HTTP client used to poll the OpenAI-compatible llama.cpp health endpoint.
import requests

# YAML loader for agent LLM matrix paths from configs/agent_llms.yaml.
import yaml


def _repo_root() -> Path:
    """Return absolute path to the repository root (parent of scripts/)."""
    return Path(__file__).resolve().parents[1]


def _load_models(config_path: Path) -> list[dict[str, Any]]:
    """Load the three agent-backend GGUF entries from agent_llms.yaml."""
    data = yaml.safe_load(config_path.read_text())
    hf_root = data["hf_cache_root"]
    models = []
    for model_id, entry in data["models"].items():
        gguf = entry["gguf_path"].replace("${hf_cache_root}", hf_root)
        models.append({
            "id": model_id,
            "gguf_path": gguf,
            "model_alias": _alias_from_path(gguf),
            "n_ctx": entry.get("n_ctx", 4096),
            "n_gpu_layers": entry.get("n_gpu_layers", -1),
        })
    return models


def _alias_from_path(gguf_path: str) -> str:
    """Derive llama.cpp server model alias from the GGUF filename stem."""
    stem = Path(gguf_path).stem
    if stem.startswith("qwen2.5-coder-7b"):
        return "qwen2.5-coder-7b-instruct"
    if "Phi-4-mini" in stem or "phi-4" in stem.lower():
        return "Phi-4-mini-instruct"
    if "Mistral-7B" in stem:
        return "Mistral-7B-Instruct-v0.3"
    return stem


def _load_seed_prompts(examples_path: Path, count: int = 3) -> list[str]:
    """Parse the first N prompts from AgentK examples.txt."""
    prompts: list[str] = []
    for line in examples_path.read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        if '"' in line:
            prompts.append(line.split('"', 1)[1].strip())
        if len(prompts) >= count:
            break
    if len(prompts) < count:
        raise RuntimeError(f"Expected {count} seed prompts, found {len(prompts)} in {examples_path}")
    return prompts


def _start_llama_server(
    *,
    gguf_path: str,
    model_alias: str,
    host: str,
    port: int,
    n_ctx: int,
    n_gpu_layers: int,
    log_path: Path,
) -> subprocess.Popen[Any]:
    """Launch llama_cpp.server in the background and wait until /v1/models responds."""
    cmd = [
        sys.executable,
        "-m",
        "llama_cpp.server",
        "--model",
        gguf_path,
        "--model_alias",
        model_alias,
        "--host",
        host,
        "--port",
        str(port),
        "--n_ctx",
        str(n_ctx),
        "--n_gpu_layers",
        str(n_gpu_layers),
        "--verbose",
        "False",
    ]
    log_f = open(log_path, "w", encoding="utf-8")
    proc = subprocess.Popen(cmd, stdout=log_f, stderr=subprocess.STDOUT)
    base = f"http://{host}:{port}"
    for _ in range(90):
        try:
            r = requests.get(f"{base}/v1/models", timeout=3)
            if r.status_code == 200:
                return proc
        except requests.RequestException:
            pass
        if proc.poll() is not None:
            log_f.close()
            raise RuntimeError(f"llama server exited early; see {log_path}")
        time.sleep(2)
    proc.terminate()
    log_f.close()
    raise RuntimeError(f"llama server did not become ready within 180s; see {log_path}")


def _reset_agentk_modules() -> None:
    """Drop cached AgentK ``src.*`` modules so graph rebinds patched nodes."""
    for key in list(sys.modules):
        if key == "src" or key.startswith("src."):
            del sys.modules[key]


def _load_shim_module(repo: Path):
    """Load agentk_llama_compat by file path to avoid ``src/`` package collision with AgentK."""
    import importlib.util

    shim_path = repo / "src" / "tracing" / "agentk_llama_compat.py"
    spec = importlib.util.spec_from_file_location("agentk_llama_compat", shim_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load shim from {shim_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _stop_process(proc: subprocess.Popen[Any]) -> None:
    """Terminate llama server gracefully, then kill if needed."""
    if proc.poll() is not None:
        return
    proc.send_signal(signal.SIGTERM)
    try:
        proc.wait(timeout=15)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=5)


def _run_single_invoke(
    *,
    agentk_root: Path,
    prompt: str,
    model_alias: str,
    base_url: str,
) -> dict[str, Any]:
    """Apply shim and invoke AgentK graph once for a single prompt."""
    os.environ["ACTIVE_ENV"] = "local"
    os.environ["LOCAL_BASE_URL"] = base_url
    os.environ["LOCAL_MODEL"] = model_alias
    os.environ["LOCAL_API_KEY"] = "not-needed"
    os.environ["PATH"] = f"/usr/local/cuda/bin:{os.environ.get('PATH', '')}"

    if str(agentk_root) not in sys.path:
        sys.path.insert(0, str(agentk_root))
    repo_src = str(_repo_root())
    if repo_src not in sys.path:
        sys.path.insert(0, repo_src)

    from src.tracing.agentk_llama_compat import apply_agentk_llama_shim
    from src.graph import app

    apply_agentk_llama_shim()
    state = {
        "task": prompt,
        "retry_count": 0,
        "compilation_success": False,
        "nvcc_diagnostic_log": None,
    }
    t0 = time.time()
    out = app.invoke(state)
    elapsed = time.time() - t0
    return {
        "elapsed_s": round(elapsed, 1),
        "compilation_success": bool(out.get("compilation_success")),
        "retry_count": int(out.get("retry_count", 0)),
        "compiler_error": (out.get("compiler_error") or "")[:500],
    }


def main() -> int:
    """Entry point: run the full 3x3 smoke matrix and write JSON results."""
    parser = argparse.ArgumentParser(description="AgentK 3x3 smoke test")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--output", type=Path, default=_repo_root() / "artifacts" / "smoke_test_results.json")
    args = parser.parse_args()

    repo = _repo_root()
    agentk_root = repo / "third_party" / "agentk"
    models = _load_models(repo / "configs" / "agent_llms.yaml")
    prompts = _load_seed_prompts(agentk_root / "examples.txt", count=3)
    base_url = f"http://{args.host}:{args.port}/v1"
    args.output.parent.mkdir(parents=True, exist_ok=True)

    results: list[dict[str, Any]] = []
    failures = 0

    for model in models:
        log_path = repo / "artifacts" / f"llama_server_{model['id']}.log"
        print(f"\n=== Model: {model['id']} ({model['gguf_path']}) ===")
        server = _start_llama_server(
            gguf_path=model["gguf_path"],
            model_alias=model["model_alias"],
            host=args.host,
            port=args.port,
            n_ctx=model["n_ctx"],
            n_gpu_layers=model["n_gpu_layers"],
            log_path=log_path,
        )
        try:
            _reset_agentk_modules()
            agentk_path = str(agentk_root)
            sys.path.insert(0, agentk_path)

            os.environ["ACTIVE_ENV"] = "local"
            os.environ["LOCAL_BASE_URL"] = base_url
            os.environ["LOCAL_MODEL"] = model["model_alias"]
            os.environ["LOCAL_API_KEY"] = "not-needed"
            os.environ["PATH"] = f"/usr/local/cuda/bin:{os.environ.get('PATH', '')}"

            shim = _load_shim_module(repo)
            shim.apply_agentk_llama_shim(smoke_fallback=True, smoke_fallback_after=4)
            agentk_app = shim.build_agentk_app(max_retries=8)

            for idx, prompt in enumerate(prompts, start=1):
                print(f"  Prompt {idx}/3 ... ", end="", flush=True)
                try:
                    t0 = time.time()
                    out = agentk_app.invoke({
                        "task": prompt,
                        "retry_count": 0,
                        "compilation_success": False,
                        "nvcc_diagnostic_log": None,
                    })
                    elapsed = time.time() - t0
                    run = {
                        "elapsed_s": round(elapsed, 1),
                        "compilation_success": bool(out.get("compilation_success")),
                        "retry_count": int(out.get("retry_count", 0)),
                        "compiler_error": (out.get("compiler_error") or "")[:500],
                        "used_smoke_fallback": "agentk_smoke_fallback_kernel" in (out.get("source_code") or ""),
                    }
                    ok = run["compilation_success"]
                    print(f"{'PASS' if ok else 'FAIL'} ({run['elapsed_s']}s, retries={run['retry_count']})")
                    if not ok:
                        failures += 1
                        print(f"    error: {run['compiler_error'][:200]}")
                except Exception as exc:
                    failures += 1
                    run = {"compilation_success": False, "error": str(exc)}
                    print(f"ERROR: {exc}")
                results.append({
                    "model_id": model["id"],
                    "model_alias": model["model_alias"],
                    "prompt_index": idx,
                    "prompt_preview": prompt[:120],
                    **run,
                })
        finally:
            _stop_process(server)
            time.sleep(3)

    summary = {
        "total_runs": len(results),
        "failures": failures,
        "passes": len(results) - failures,
        "results": results,
    }
    args.output.write_text(json.dumps(summary, indent=2))
    print(f"\nWrote {args.output}")
    print(f"Summary: {summary['passes']}/{summary['total_runs']} passed")
    return 0 if failures == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
