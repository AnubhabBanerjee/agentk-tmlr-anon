#!/usr/bin/env python3
"""
build data/correctness_report.md from trace index + kernelbench.parquet.

Joins ``data/traces/index.parquet`` with ``data/correctness/kernelbench.parquet`` on
(agent_llm, prompt_id) and reports compile-success rates per (agent LLM × prompt slice)
and numerical-correct rates on the KernelBench subset only (§3.6).
"""

from __future__ import annotations

import argparse
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Tuple

import pandas as pd

_SCRIPTS_DIR = Path(__file__).resolve().parent
_REPO = _SCRIPTS_DIR.parent
if str(_SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS_DIR))
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from kbench_correctness_common import init_results_frame, repo_root_from_here
from src.pipeline.tracing_paths import load_tracing_paths


def _kbench_level(prompt_id: str) -> str:
    """Extract KernelBench level token (l1–l4) from prompt ids like ``kbench-l2-014``."""
    match = re.match(r"kbench-(l\d+)-", str(prompt_id))
    if match:
        return match.group(1)
    return "unknown"


def _prompt_slice_label(row: pd.Series) -> str:
    """Human-readable prompt slice: source × kernel family (strata)."""
    source = str(row.get("prompt_source", "unknown"))
    family = str(row.get("prompt_family", "unknown"))
    return f"{source}/{family}"


def _compile_success_table(index_df: pd.DataFrame) -> List[str]:
    """Markdown table: compile_success rate per (agent_llm, prompt_slice)."""
    work = index_df.copy()
    work["prompt_slice"] = work.apply(_prompt_slice_label, axis=1)
    work["compile_ok"] = work["compile_success"].astype(bool)

    lines = [
        "## compile_success rate per (agent LLM × prompt slice)",
        "",
        "Prompt slice = `prompt_source` / `prompt_family` (all 1800 traces).",
        "",
        "| agent_llm | prompt_slice | success | total | rate |",
        "|-----------|--------------|--------:|------:|-----:|",
    ]

    grouped = (
        work.groupby(["agent_llm", "prompt_slice"], sort=False)["compile_ok"]
        .agg(["sum", "count"])
        .reset_index()
    )
    for _, row in grouped.sort_values(["agent_llm", "prompt_slice"]).iterrows():
        total = int(row["count"])
        success = int(row["sum"])
        rate = success / total if total else 0.0
        lines.append(
            f"| {row['agent_llm']} | {row['prompt_slice']} | {success} | {total} | {rate:.3f} |"
        )
    lines.append("")
    return lines


def _numerical_correct_table(merged_df: pd.DataFrame) -> List[str]:
    """Markdown table: numerical_correct_kbench rate per (agent_llm, KernelBench level)."""
    kb = merged_df[merged_df["prompt_source"] == "kernelbench"].copy()
    kb["kbench_slice"] = kb["prompt_id"].map(_kbench_level)
    kb["numerical_ok"] = kb["numerical_correct_kbench"].astype("boolean").fillna(False)

    lines = [
        "## numerical_correct_kbench rate per (agent LLM × KernelBench slice)",
        "",
        "KernelBench slice = level from prompt id (`l1`–`l4`). "
        "Denominator is all KernelBench rows in that slice; "
        "numerator counts `numerical_correct_kbench == True` (harness `done` rows only).",
        "",
        "| agent_llm | kbench_slice | numerical_correct | total | rate | harness_done |",
        "|-----------|--------------|------------------:|------:|-----:|-------------:|",
    ]

    grouped = kb.groupby(["agent_llm", "kbench_slice"], sort=False)
    for (agent_llm, kbench_slice), group in grouped:
        total = len(group)
        correct = int(group["numerical_ok"].sum())
        done = int((group["harness_status"] == "done").sum())
        rate = correct / total if total else 0.0
        lines.append(
            f"| {agent_llm} | {kbench_slice} | {correct} | {total} | {rate:.3f} | {done} |"
        )
    lines.append("")
    return lines


def _conditional_numerical_table(merged_df: pd.DataFrame) -> List[str]:
    """P(numerical_correct | compile_success) on KernelBench subset (preview)."""
    kb = merged_df[merged_df["prompt_source"] == "kernelbench"].copy()
    kb["compile_ok"] = kb["compile_success"].astype(bool)
    kb["numerical_ok"] = kb["numerical_correct_kbench"].astype("boolean").fillna(False)

    lines = [
        "## P(numerical_correct_kbench | compile_success) — KernelBench only",
        "",
        "| agent_llm | compile_success | numerical_correct | P(correct\\|compile) |",
        "|-----------|----------------:|------------------:|---------------------:|",
    ]

    for agent_llm, group in kb.groupby("agent_llm", sort=False):
        compiled = group[group["compile_ok"]]
        n_compile = len(compiled)
        n_correct = int(compiled["numerical_ok"].sum()) if n_compile else 0
        prob = n_correct / n_compile if n_compile else 0.0
        lines.append(
            f"| {agent_llm} | {n_compile} | {n_correct} | {prob:.3f} |"
        )
    lines.append("")
    return lines


def render_correctness_report(
    index_df: pd.DataFrame,
    correctness_df: pd.DataFrame,
    *,
    expect_total: int,
    index_label: str = "data/traces/index.parquet",
    correctness_label: str = "data/correctness/kernelbench.parquet",
) -> str:
    """Render markdown report for deliverable."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    join_cols = ["trace_jsonl"] if "trace_jsonl" in index_df.columns and "trace_jsonl" in correctness_df.columns else ["agent_llm", "prompt_id"]
    merged = index_df.merge(
        correctness_df,
        on=join_cols,
        how="inner",
        suffixes=("_index", "_kb"),
    )

    if len(merged) != len(index_df) or len(merged) != len(correctness_df):
        raise ValueError(
            f"join row mismatch on {join_cols}: index={len(index_df)} "
            f"correctness={len(correctness_df)} merged={len(merged)}"
        )

    # Prefer index-side columns for stratification labels.
    for col in ("prompt_id", "agent_llm", "prompt_source", "prompt_family", "compile_success"):
        idx_col = f"{col}_index" if f"{col}_index" in merged.columns else col
        if idx_col in merged.columns:
            merged[col] = merged[idx_col]

    harness_done = int((correctness_df["harness_status"] == "done").sum())
    harness_expect = int(
        (
            (index_df["prompt_source"] == "kernelbench")
            & index_df["compile_success"].astype(bool)
        ).sum()
    )
    numerical_true = int(
        correctness_df["numerical_correct_kbench"].astype("boolean").fillna(False).sum()
    )

    lines: List[str] = [
        "# Correctness report",
        "",
        f"- Generated: **{now}**",
        f"- Trace index: `{index_label}` ({len(index_df)} rows, expected {expect_total})",
        f"- Correctness: `{correctness_label}` ({len(correctness_df)} rows)",
        f"- Inner join on `(agent_llm, prompt_id)`: **{len(merged)}** rows",
        f"- GPU harness evaluations: **{harness_done}/{harness_expect}** (compile-success KernelBench)",
        f"- `numerical_correct_kbench == True`: **{numerical_true}**",
        "",
        "Note: `index.parquet` is read-only for this report; correctness labels live in "
        "`kernelbench.parquet` and are joined at analysis time.",
        "",
    ]

    lines.extend(_compile_success_table(index_df))
    lines.extend(_numerical_correct_table(merged))
    lines.extend(_conditional_numerical_table(merged))

    lines.extend(
        [
            "## Harness status summary (kernelbench.parquet)",
            "",
            "| harness_status | count |",
            "|----------------|------:|",
        ]
    )
    for status, count in correctness_df["harness_status"].value_counts().sort_index().items():
        lines.append(f"| {status} | {int(count)} |")
    lines.append("")

    wrap_logged = int(correctness_df["wrap_error"].notna().sum())
    lines.extend(
        [
            "## Supplementary",
            "",
            f"- Rows with non-null `wrap_error`: **{wrap_logged}**",
            f"- Non-KernelBench rows (numerical fields NaN): "
            f"**{int((correctness_df['harness_status'] == 'skipped:not_kernelbench').sum())}**",
            "",
        ]
    )

    return "\n".join(lines)


def main() -> int:
    """CLI entry: write data/correctness_report.md."""
    parser = argparse.ArgumentParser(description="Build correctness report")
    parser.add_argument(
        "--index-path",
        type=Path,
        default=None,
        help="Override trace index path (default: data/traces/index.parquet)",
    )
    parser.add_argument(
        "--correctness-path",
        type=Path,
        default=None,
        help="Override kernelbench parquet (default: data/correctness/kernelbench.parquet)",
    )
    parser.add_argument(
        "--report-out",
        type=Path,
        default=None,
        help="Override report path (default: data/correctness_report.md)",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=None,
        help="Tracing config YAML (e.g. configs/tracing_v2.yaml)",
    )
    parser.add_argument(
        "--init-from-index",
        action="store_true",
        help="Bootstrap kernelbench.parquet from index when missing (compile labels only)",
    )
    args = parser.parse_args()

    repo = repo_root_from_here()
    paths = load_tracing_paths(repo_root=repo, config=args.config)
    index_path = args.index_path or paths.index_path
    correctness_path = args.correctness_path or paths.correctness_parquet
    report_path = args.report_out or paths.correctness_report

    if not index_path.is_file():
        raise FileNotFoundError(f"missing trace index: {index_path}")

    index_df = pd.read_parquet(index_path)
    if not correctness_path.is_file():
        if not args.init_from_index:
            raise FileNotFoundError(
                f"missing correctness parquet: {correctness_path} "
                "(pass --init-from-index to bootstrap compile_success from the trace index)"
            )
        correctness_path.parent.mkdir(parents=True, exist_ok=True)
        bootstrap = init_results_frame(index_df)
        bootstrap.to_parquet(correctness_path, index=False)
        print(f"Bootstrapped {correctness_path} from trace index ({len(bootstrap)} rows)")

    correctness_df = pd.read_parquet(correctness_path)
    report = render_correctness_report(
        index_df,
        correctness_df,
        expect_total=len(index_df),
        index_label=str(index_path.relative_to(repo)) if index_path.is_relative_to(repo) else str(index_path),
        correctness_label=str(correctness_path.relative_to(repo))
        if correctness_path.is_relative_to(repo)
        else str(correctness_path),
    )
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(report, encoding="utf-8")
    print(f"Wrote {report_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
