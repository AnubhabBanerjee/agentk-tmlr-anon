#!/usr/bin/env python3
"""Preflight checks for Phase 3.5 KernelBench correctness harness."""

# Python line: from __future__ import annotations
# Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
from __future__ import annotations

# sys prepends scripts/ so shared batch helper imports resolve from repo root.
# Python line: import sys
# Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
import argparse
import os
import shutil
import sys
# Path resolves trace index, CUDA sidecars, and KernelBench reference tree paths.
# Python line: from pathlib import Path
# Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
from pathlib import Path

# pandas reads compile_success flags from the Phase 3.4 trace index artifact.
# Python line: import pandas as pd
# Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
import pandas as pd
# torch verifies CUDA is available before launching the numerical harness driver.
# Python line: import torch
# Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
import torch

# Python line: _SCRIPTS = Path(__file__).resolve().parent
# Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
_SCRIPTS = Path(__file__).resolve().parent
# Python line: if str(_SCRIPTS) not in sys.path:
# Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
if str(_SCRIPTS) not in sys.path:
    # Python line: sys.path.insert(0, str(_SCRIPTS))
    # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    sys.path.insert(0, str(_SCRIPTS))

# Python line: from kbench_correctness_common import expect_harness_runs, repo_root_from_here
# Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
from kbench_correctness_common import expect_harness_runs, repo_root_from_here

# Repo root must precede src.* imports when executing from scripts/.
_repo = repo_root_from_here()
if str(_repo) not in sys.path:
    sys.path.insert(0, str(_repo))

from src.pipeline.tracing_paths import load_tracing_paths
from src.correctness.cuda_sidecar import load_cuda_sidecar


def _check_nvcc() -> bool:
    """Return True when nvcc is on PATH (required for torch cpp_extension builds)."""
    nvcc = shutil.which("nvcc")
    if not nvcc:
        fallback = Path("/usr/local/cuda/bin/nvcc")
        if fallback.is_file():
            os.environ["PATH"] = f"/usr/local/cuda/bin:{os.environ.get('PATH', '')}"
            nvcc = str(fallback)
    if nvcc:
        print(f"OK: nvcc found at {nvcc}")
        return True
    print("FAIL: nvcc not found on PATH (add /usr/local/cuda/bin)")
    return False


def _check_ld_library_path() -> bool:
    """Warn when CUDA runtime libs may be invisible to the harness subprocess."""
    ld = os.environ.get("LD_LIBRARY_PATH", "")
    cuda_roots = ("/usr/local/cuda/lib64", "/usr/local/cuda/lib")
    if any(root in ld for root in cuda_roots):
        print(f"OK: LD_LIBRARY_PATH includes a CUDA lib dir")
        return True
    print(
        "WARN: LD_LIBRARY_PATH does not mention /usr/local/cuda/lib64 — "
        "harness may still work if ldconfig resolves CUDA; export if load_inline fails"
    )
    return True


def _sidecar_present(repo: Path, row: pd.Series) -> bool:
    """True when the trace row's CUDA sidecar exists on disk."""
    rel = row.get("cuda_sidecar")
    if isinstance(rel, str) and rel.strip():
        path = repo / rel if not Path(rel).is_absolute() else Path(rel)
        if path.is_file():
            return True
    return bool(
        load_cuda_sidecar(
            repo_root=repo,
            agent_llm=str(row["agent_llm"]),
            prompt_id=str(row["prompt_id"]),
        )
    )


# Python line: def main() -> int:
# Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
def main() -> int:
    """Run fast preflight checks; return non-zero on failure."""
    parser = argparse.ArgumentParser(description="Preflight KernelBench correctness harness")
    parser.add_argument(
        "--config",
        type=Path,
        default=None,
        help="Tracing config YAML (e.g. configs/tracing_v2.yaml)",
    )
    args = parser.parse_args()

    repo = repo_root_from_here()
    paths = load_tracing_paths(repo_root=repo, config=args.config)
    index_path = paths.index_path
    kb_index = repo / "data" / "prompts" / "kernelbench" / "index.jsonl"
    agentk_root = repo / "third_party" / "agentk"

    if not _check_nvcc():
        return 1
    _check_ld_library_path()

    if not agentk_root.is_dir():
        print(f"FAIL: missing AgentK submodule at {agentk_root}")
        return 1
    print(f"OK: AgentK submodule at {agentk_root}")
    print(f"OK: trace index {index_path.relative_to(repo)}")
    print(f"OK: correctness parquet target {paths.correctness_parquet.relative_to(repo)}")

    # Python line: if not index_path.is_file():
    # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if not index_path.is_file():
        # Python line: print(f"FAIL: missing {index_path}")
        # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        print(f"FAIL: missing {index_path}")
        # Python line: return 1
        # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        return 1
    # Python line: if not kb_index.is_file():
    # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if not kb_index.is_file():
        # Python line: print(f"FAIL: missing {kb_index}")
        # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        print(f"FAIL: missing {kb_index}")
        # Python line: return 1
        # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        return 1
    # Python line: if not torch.cuda.is_available():
    # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if not torch.cuda.is_available():
        # Python line: print("FAIL: CUDA not available")
        # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        print("FAIL: CUDA not available")
        # Python line: return 1
        # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        return 1

    # Python line: index_df = pd.read_parquet(index_path)
    # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    index_df = pd.read_parquet(index_path)
    # Python line: expect_eval = expect_harness_runs(index_df)
    # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    expect_eval = expect_harness_runs(index_df)
    # Python line: missing = 0
    # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    missing = 0
    # Python line: for _, row in index_df[
    # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    for _, row in index_df[
        (index_df["prompt_source"] == "kernelbench") & index_df["compile_success"].astype(bool)
    ].iterrows():
        # Python line: if not load_cuda_sidecar(
        # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        if not _sidecar_present(repo, row):
            # Python line: missing += 1
            # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            missing += 1

    # Python line: print(f"OK: index rows={len(index_df)} expect_gpu_eval={expect_eval}")
    # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    print(f"OK: index rows={len(index_df)} expect_gpu_eval={expect_eval}")
    # Python line: print(f"CUDA sidecars missing for compile-success KernelBench rows: {missing}/{expect_eval}")
    # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    print(f"CUDA sidecars missing for compile-success KernelBench rows: {missing}/{expect_eval}")
    # Python line: if missing > 0:
    # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if missing > 0:
        # Python line: print("WARN: run scripts/backfill_cuda_sidecars.py (with watcher) before harness for best results")
        # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        print("WARN: run make run-cuda-sidecar-backfill (nohup) before harness for best results")
    # Python line: return 0
    # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return 0


# Python line: if __name__ == "__main__":
# Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
if __name__ == "__main__":
    # Python line: raise SystemExit(main())
    # Phase 3.5 harness preflight (scripts/preflight_kbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    raise SystemExit(main())
