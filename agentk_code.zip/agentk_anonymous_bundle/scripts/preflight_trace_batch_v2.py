#!/usr/bin/env python3
"""Preflight for released v2 trace batch (5 agents, n_ctx + KV sweeps)."""

from __future__ import annotations

import warnings

warnings.filterwarnings("ignore", category=FutureWarning)

import argparse
import subprocess
import sys
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
from trace_batch_common import (  # noqa: E402
    check_disk_guard_batch,
    check_disk_guard_preflight,
    count_complete_base_traces_glob,
    count_complete_sweep_traces_glob,
    expected_v2_base_total,
    expected_v2_sweep_only_total,
    expected_v2_sweep_total,
    kill_stray_llama_servers,
    load_model_ids,
    load_sweep_agent_ids,
    repo_root_from_here,
    workspace_disk_free_gb,
)


def main() -> int:
    parser = argparse.ArgumentParser(description="Preflight released trace batch v2")
    parser.add_argument("--min-disk-gb", type=float, default=15.0)
    parser.add_argument("--min-vram-gb", type=float, default=40.0)
    parser.add_argument(
        "--base-only",
        action="store_true",
        help="Expect v2 base tracing only (1200 runs, not 1920).",
    )
    parser.add_argument(
        "--sweep-only",
        action="store_true",
        help="Expect hardware sweep tracing only (720 runs).",
    )
    args = parser.parse_args()
    if args.base_only and args.sweep_only:
        print("Cannot pass both --base-only and --sweep-only")
        return 1

    repo = repo_root_from_here()
    tracing_path = repo / "configs" / "tracing_v2.yaml"
    agent_path = repo / "configs" / "agent_llms_v2.yaml"
    failures: list[str] = []

    if not tracing_path.is_file():
        failures.append(f"missing {tracing_path}")
    if not agent_path.is_file():
        failures.append(f"missing {agent_path}")

    prompts = repo / "data" / "prompts_v2" / "all.jsonl"
    if not prompts.is_file():
        failures.append(f"missing {prompts}")
    else:
        n_prompts = sum(1 for line in prompts.read_text().splitlines() if line.strip())
        if n_prompts != 300:
            failures.append(f"expected 300 prompts in prompts_v2, found {n_prompts}")

    ws_free_gb = workspace_disk_free_gb()
    print(f"Disk free (/workspace): {ws_free_gb:.1f} GB (need ≥{args.min_disk_gb:.0f} GB)")
    disk_guard_err = check_disk_guard_preflight()
    if disk_guard_err is not None:
        failures.append(disk_guard_err)

    if args.base_only:
        expect_total = expected_v2_base_total(
            repo, agent_config=agent_path, tracing_config=tracing_path
        )
    elif args.sweep_only:
        expect_total = expected_v2_sweep_only_total(
            repo, agent_config=agent_path, tracing_config=tracing_path
        )
    else:
        expect_total = expected_v2_sweep_total(
            repo, agent_config=agent_path, tracing_config=tracing_path
        )
    est_gb = expect_total * 0.5 / 1024.0  # ~500 KB/trace compressed target
    print(f"Expected v2 runs: {expect_total} (est. batch ~{est_gb:.1f} GB compressed)")

    agent_cfg = yaml.safe_load(agent_path.read_text(encoding="utf-8"))
    hf_root = Path(str(agent_cfg.get("hf_cache_root", "[REDACTED_PATH]")))
    for model_id in load_model_ids(agent_path):
        entry = agent_cfg["models"][model_id]
        gguf = Path(str(entry["gguf_path"]).replace("${hf_cache_root}", str(hf_root)))
        if not gguf.is_file():
            failures.append(f"missing GGUF for {model_id}: {gguf}")
        else:
            print(f"OK GGUF {model_id}: {gguf.name} ({gguf.stat().st_size / 1e9:.2f} GB)")

    try:
        import torch

        if torch.cuda.is_available():
            vram_gb = torch.cuda.get_device_properties(0).total_memory / (1024**3)
            print(f"GPU VRAM: {vram_gb:.1f} GB")
            if vram_gb < args.min_vram_gb:
                failures.append(f"VRAM {vram_gb:.1f} GB < min {args.min_vram_gb:.1f} GB")
        else:
            failures.append("CUDA not available")
    except Exception as exc:
        failures.append(f"torch CUDA check failed: {exc}")

    nvcc_bin = Path("/usr/local/cuda/bin/nvcc")
    if nvcc_bin.is_file():
        subprocess.run([str(nvcc_bin), "--version"], check=True, capture_output=True, text=True)
        print("OK nvcc")
    else:
        failures.append(f"nvcc not found at {nvcc_bin}")

    killed = kill_stray_llama_servers()
    if killed:
        print(f"Killed {killed} stray llama server(s)")

    (repo / "data" / "traces_v2").mkdir(parents=True, exist_ok=True)
    done = None
    if args.base_only:
        done = count_complete_base_traces_glob(
            trace_root=repo / "data" / "traces_v2",
            model_ids=load_model_ids(agent_path),
        )
        print(f"Already complete (base only): {done}/{expect_total}")
    elif args.sweep_only:
        done = count_complete_sweep_traces_glob(
            trace_root=repo / "data" / "traces_v2",
            model_ids=load_sweep_agent_ids(tracing_path),
        )
        print(f"Already complete (sweep only): {done}/{expect_total}")
    else:
        print(f"Expected v2 runs: {expect_total}")

    if failures:
        print("\nPREFLIGHT FAILED:")
        for item in failures:
            print(f"  - {item}")
        return 1

    print("\nPREFLIGHT OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
