#!/usr/bin/env python3
"""
preflight — verify disk, VRAM, GGUFs, and corpus before 1800-run batch.

Exit 0 = healthy; non-zero = abort batch (report facts, do not sugarcoat).
"""

# Python line: from __future__ import annotations
# preflight checks (scripts/preflight_trace_batch.py).
# Implements .cursorrules dense-comment policy for Python code.
from __future__ import annotations

# argparse accepts --min-disk-gb and --min-vram-gb thresholds.
# Python line: import argparse
# preflight checks (scripts/preflight_trace_batch.py).
# Implements .cursorrules dense-comment policy for Python code.
import argparse
# shutil reports free disk bytes on /workspace.
# Python line: import shutil
# preflight checks (scripts/preflight_trace_batch.py).
# Implements .cursorrules dense-comment policy for Python code.
import shutil
# subprocess runs nvcc --version for CUDA toolchain check.
# Python line: import subprocess
# preflight checks (scripts/preflight_trace_batch.py).
# Implements .cursorrules dense-comment policy for Python code.
import subprocess
# sys exits with the number of failed checks.
# Python line: import sys
# preflight checks (scripts/preflight_trace_batch.py).
# Implements .cursorrules dense-comment policy for Python code.
import sys
# Path resolves GGUF paths and submodule locations.
# Python line: from pathlib import Path
# preflight checks (scripts/preflight_trace_batch.py).
# Implements .cursorrules dense-comment policy for Python code.
from pathlib import Path
# typing collects human-readable failure messages.
# Python line: from typing import List
# preflight checks (scripts/preflight_trace_batch.py).
# Implements .cursorrules dense-comment policy for Python code.
from typing import List

# yaml loads hf_cache_root and per-model GGUF paths.
# Python line: import yaml
# preflight checks (scripts/preflight_trace_batch.py).
# Implements .cursorrules dense-comment policy for Python code.
import yaml

# Python line: sys.path.insert(0, str(Path(__file__).resolve().parent))
# preflight checks (scripts/preflight_trace_batch.py).
# Implements .cursorrules dense-comment policy for Python code.
sys.path.insert(0, str(Path(__file__).resolve().parent))
# Python line: from trace_batch_common import (
# preflight checks (scripts/preflight_trace_batch.py).
# Implements .cursorrules dense-comment policy for Python code.
from trace_batch_common import (
    EXPECTED_TOTAL_RUNS,
    batch_inventory,
    check_disk_guard_preflight,
    count_complete_traces,
    kill_stray_llama_servers,
    repo_root_from_here,
    workspace_disk_free_gb,
)


# Python line: def _vram_free_mb() -> float:
# preflight checks (scripts/preflight_trace_batch.py).
# Implements .cursorrules dense-comment policy for Python code.
def _vram_free_mb() -> float:
    """Return free GPU VRAM in MiB via pynvml (0.0 if unavailable)."""
    # Python line: try:
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    try:
        # Python line: import pynvml
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        import pynvml

        # Python line: pynvml.nvmlInit()
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        pynvml.nvmlInit()
        # Python line: handle = pynvml.nvmlDeviceGetHandleByIndex(0)
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        handle = pynvml.nvmlDeviceGetHandleByIndex(0)
        # Python line: mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
        # Python line: return mem.free / (1024.0 * 1024.0)
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        return mem.free / (1024.0 * 1024.0)
    # Python line: except Exception:
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    except Exception:
        # Python line: return 0.0
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        return 0.0


# Python line: def main() -> int:
# preflight checks (scripts/preflight_trace_batch.py).
# Implements .cursorrules dense-comment policy for Python code.
def main() -> int:
    """Run all preflight checks; print a factual summary."""
    # Python line: parser = argparse.ArgumentParser(description="Preflight for 1800-run trace batch")
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    parser = argparse.ArgumentParser(description="Preflight for 1800-run trace batch")
    # Python line: parser.add_argument("--min-disk-gb", type=float, default=10.0)
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    parser.add_argument("--min-disk-gb", type=float, default=10.0)
    # Python line: parser.add_argument("--min-vram-gb", type=float, default=20.0)
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    parser.add_argument("--min-vram-gb", type=float, default=20.0)
    # Python line: args = parser.parse_args()
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    args = parser.parse_args()
    # Python line: repo = repo_root_from_here()
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    repo = repo_root_from_here()
    # Python line: failures: List[str] = []
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    failures: List[str] = []

    # Python line: print("=== preflight ===")
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    print("=== preflight ===")

    # Python line: killed = kill_stray_llama_servers()
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    killed = kill_stray_llama_servers()
    # Python line: if killed:
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if killed:
        # Python line: print(f"Killed {killed} stray llama_cpp.server process(es)")
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        print(f"Killed {killed} stray llama_cpp.server process(es)")

    # Python line: disk = shutil.disk_usage(str(repo))
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    disk = shutil.disk_usage(str(repo))
    # Python line: free_gb = disk.free / (1024**3)
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    free_gb = disk.free / (1024**3)
    # Python line: print(f"Disk free: {free_gb:.1f} GiB (need >= {args.min_disk_gb:.1f} GiB)")
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    print(f"Disk free (repo): {free_gb:.1f} GiB (need >= {args.min_disk_gb:.1f} GiB)")
    # Python line: if free_gb < args.min_disk_gb:
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if free_gb < args.min_disk_gb:
        # Python line: failures.append(f"disk free {free_gb:.1f} GiB < {args.min_disk_gb} GiB")
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        failures.append(f"disk free {free_gb:.1f} GiB < {args.min_disk_gb} GiB")

    # released §A1: abort batch launch when /workspace has < 15 GiB free.
    ws_free_gb = workspace_disk_free_gb()
    ws_abort_gb = 15.0
    print(f"Disk free (/workspace): {ws_free_gb:.1f} GiB (need >= {ws_abort_gb:.0f} GiB)")
    disk_guard_err = check_disk_guard_preflight()
    if disk_guard_err is not None:
        failures.append(disk_guard_err)

    # Python line: vram_free = _vram_free_mb()
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    vram_free = _vram_free_mb()
    # Python line: vram_free_gb = vram_free / 1024.0
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    vram_free_gb = vram_free / 1024.0
    # Python line: print(f"VRAM free: {vram_free:.0f} MiB ({vram_free_gb:.1f} GiB); need >= {args.min_vram_gb:.1f} GiB")
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    print(f"VRAM free: {vram_free:.0f} MiB ({vram_free_gb:.1f} GiB); need >= {args.min_vram_gb:.1f} GiB")
    # Python line: if vram_free_gb < args.min_vram_gb:
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if vram_free_gb < args.min_vram_gb:
        # Python line: failures.append(f"VRAM free {vram_free_gb:.1f} GiB < {args.min_vram_gb} GiB")
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        failures.append(f"VRAM free {vram_free_gb:.1f} GiB < {args.min_vram_gb} GiB")

    # Python line: model_ids, prompt_ids, expect = batch_inventory(repo)
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    model_ids, prompt_ids, expect = batch_inventory(repo)
    # Python line: print(f"Corpus: {len(prompt_ids)} prompts × {len(model_ids)} models = {expect} runs")
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    print(f"Corpus: {len(prompt_ids)} prompts × {len(model_ids)} models = {expect} runs")
    # Python line: if expect != EXPECTED_TOTAL_RUNS:
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if expect != EXPECTED_TOTAL_RUNS:
        # Python line: failures.append(f"expected {EXPECTED_TOTAL_RUNS} runs, inventory gives {expect}")
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        failures.append(f"expected {EXPECTED_TOTAL_RUNS} runs, inventory gives {expect}")

    # Python line: agent = yaml.safe_load((repo / "configs" / "agent_llms.yaml").read_text())
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    agent = yaml.safe_load((repo / "configs" / "agent_llms.yaml").read_text())
    # Python line: hf_root = agent["hf_cache_root"]
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    hf_root = agent["hf_cache_root"]
    # Python line: for model_id, entry in agent["models"].items():
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    for model_id, entry in agent["models"].items():
        # Python line: gguf = Path(entry["gguf_path"].replace("${hf_cache_root}", hf_root))
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        gguf = Path(entry["gguf_path"].replace("${hf_cache_root}", hf_root))
        # Python line: if not gguf.is_file():
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        if not gguf.is_file():
            # Python line: failures.append(f"missing GGUF for {model_id}: {gguf}")
            # preflight checks (scripts/preflight_trace_batch.py).
            # Implements .cursorrules dense-comment policy for Python code.
            failures.append(f"missing GGUF for {model_id}: {gguf}")
        # Python line: else:
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        else:
            # Python line: size_gb = gguf.stat().st_size / (1024**3)
            # preflight checks (scripts/preflight_trace_batch.py).
            # Implements .cursorrules dense-comment policy for Python code.
            size_gb = gguf.stat().st_size / (1024**3)
            # Python line: print(f"  GGUF {model_id}: {size_gb:.2f} GiB")
            # preflight checks (scripts/preflight_trace_batch.py).
            # Implements .cursorrules dense-comment policy for Python code.
            print(f"  GGUF {model_id}: {size_gb:.2f} GiB")

    # Python line: kc = repo / "third_party" / "agentk"
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    kc = repo / "third_party" / "agentk"
    # Python line: if not (kc / "src").is_dir():
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if not (kc / "src").is_dir():
        # Python line: failures.append(f"AgentK submodule missing at {kc}")
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        failures.append(f"AgentK submodule missing at {kc}")

    # Python line: nvcc_candidates = ["nvcc", "/usr/local/cuda/bin/nvcc"]
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    nvcc_candidates = ["nvcc", "/usr/local/cuda/bin/nvcc"]
    # Python line: nvcc_ok = False
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    nvcc_ok = False
    # Python line: for nvcc_bin in nvcc_candidates:
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    for nvcc_bin in nvcc_candidates:
        # Python line: try:
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        try:
            # Python line: subprocess.check_output(
            # preflight checks (scripts/preflight_trace_batch.py).
            # Implements .cursorrules dense-comment policy for Python code.
            subprocess.check_output([nvcc_bin, "--version"], stderr=subprocess.STDOUT, text=True)
            # Python line: print(f"nvcc: OK ({nvcc_bin})")
            # preflight checks (scripts/preflight_trace_batch.py).
            # Implements .cursorrules dense-comment policy for Python code.
            print(f"nvcc: OK ({nvcc_bin})")
            # Python line: nvcc_ok = True
            # preflight checks (scripts/preflight_trace_batch.py).
            # Implements .cursorrules dense-comment policy for Python code.
            nvcc_ok = True
            # Python line: break
            # preflight checks (scripts/preflight_trace_batch.py).
            # Implements .cursorrules dense-comment policy for Python code.
            break
        # Python line: except (subprocess.CalledProcessError, FileNotFoundError):
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        except (subprocess.CalledProcessError, FileNotFoundError):
            # Python line: continue
            # preflight checks (scripts/preflight_trace_batch.py).
            # Implements .cursorrules dense-comment policy for Python code.
            continue
    # Python line: if not nvcc_ok:
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if not nvcc_ok:
        # Python line: failures.append("nvcc not available on PATH or /usr/local/cuda/bin/nvcc")
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        failures.append("nvcc not available on PATH or /usr/local/cuda/bin/nvcc")

    # Python line: cal = repo / "configs" / "q4_vram_calibration.yaml"
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    cal = repo / "configs" / "q4_vram_calibration.yaml"
    # Python line: if not cal.is_file():
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if not cal.is_file():
        # Python line: print("WARN: configs/q4_vram_calibration.yaml missing — run make calibrate-q4-vram")
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        print("WARN: configs/q4_vram_calibration.yaml missing — run make calibrate-q4-vram")

    # Python line: trace_root = repo / "data" / "traces"
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    trace_root = repo / "data" / "traces"
    # Python line: done = count_complete_traces(
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    done = count_complete_traces(
        # Python line: trace_root=trace_root,
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        trace_root=trace_root,
        # Python line: model_ids=model_ids,
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        model_ids=model_ids,
        # Python line: prompt_ids=prompt_ids,
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        prompt_ids=prompt_ids,
    # Python line: )
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    )
    # Python line: print(f"Already complete: {done}/{expect}")
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    print(f"Already complete: {done}/{expect}")

    # Python line: if failures:
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if failures:
        # Python line: print("\nPREFLIGHT FAILED:")
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        print("\nPREFLIGHT FAILED:")
        # Python line: for item in failures:
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        for item in failures:
            # Python line: print(f"  - {item}")
            # preflight checks (scripts/preflight_trace_batch.py).
            # Implements .cursorrules dense-comment policy for Python code.
            print(f"  - {item}")
        # Python line: return 1
        # preflight checks (scripts/preflight_trace_batch.py).
        # Implements .cursorrules dense-comment policy for Python code.
        return 1

    # Python line: print("\nPREFLIGHT OK — safe to start 1800-run batch")
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    print("\nPREFLIGHT OK — safe to start 1800-run batch")
    # Python line: return 0
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return 0


# Python line: if __name__ == "__main__":
# preflight checks (scripts/preflight_trace_batch.py).
# Implements .cursorrules dense-comment policy for Python code.
if __name__ == "__main__":
    # Python line: raise SystemExit(main())
    # preflight checks (scripts/preflight_trace_batch.py).
    # Implements .cursorrules dense-comment policy for Python code.
    raise SystemExit(main())
