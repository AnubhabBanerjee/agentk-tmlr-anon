#!/usr/bin/env python3
"""
Reproduce Table 2 (primary test-set forecast metrics) from the frozen B0-B5
test-split prediction parquets shipped in this artifact, with no retraining
and no GPU required. Reads ``data/frozen_predictions_table2/`` plus the
released ``data/`` labels and trace index, and prints the same numbers as
the paper's Table 2 without re-running B2 training (which needs a GPU and
the pinned ``B2_RANDOM_SEED`` in ``src/baselines/b2_direct_regression.py``).

Usage (from repo root):
    python scripts/reproduce_table2.py
    python scripts/reproduce_table2.py --predictions-root data/frozen_predictions_table2
    make reproduce-table2

Prints one row per (agent_llm, method) with MAPE / MAE / undercoverage rate /
OAW, and the exact LaTeX table body.
"""

from __future__ import annotations

# argparse drives the CLI flag (--predictions-root); os sets an env var default
# before any repo module is imported (see below); sys is used both for the
# repo-root import-path hack and for the process exit code in __main__.
import argparse
import os
import sys
# Path gives us a portable, OS-independent way to build the repo-relative
# default location of the frozen predictions without hardcoding "/" or "\\".
from pathlib import Path
# List is only used for the type annotation on the row-accumulator list below;
# kept explicit (rather than the bare built-in) to match this repo's existing
# typing style in src/baselines and src/eval.
from typing import List

# pandas is the sole third-party dependency: every parquet read/merge/print in
# this script goes through a pandas DataFrame, mirroring how the rest of the
# eval pipeline (src/eval/*) already represents predictions and metrics.
import pandas as pd

# __file__ is this script's own path; .parent twice walks scripts/ -> repo
# root, so the script works regardless of the caller's current directory.
REPO_ROOT = Path(__file__).resolve().parent.parent
# Prepend the repo root to sys.path so the "src.*" absolute imports below
# resolve correctly even when this script is invoked as `python scripts/foo.py`
# from an arbitrary working directory (Python does not add the script's own
# parent's parent to sys.path automatically).
sys.path.insert(0, str(REPO_ROOT))

# Default tracing config for the four-backbone released dataset layout.
os.environ.setdefault("TRACING_CONFIG", "configs/tracing_v2.yaml")

# These four imports must come after the sys.path insert and the
# os.environ.setdefault() call above: load_baseline_frame/tracing_paths_from_env
# read TRACING_CONFIG lazily inside their own function bodies (not at import
# time), but importing them before sys.path is patched would raise
# ModuleNotFoundError when this file is run directly as a script.
from src.baselines.common import AGENT_LLMS, load_baseline_frame, split_frame  # noqa: E402
from src.eval.metrics import summarize_predictions  # noqa: E402
from src.eval.tables import render_primary_results_tex  # noqa: E402
from src.pipeline.tracing_paths import tracing_paths_from_env  # noqa: E402

# The five methods actually reported in Table 2 (B4 was defined but never
# trained -- see the paper's experiments section -- so it is intentionally
# excluded here rather than silently skipped inside the loop below).
METHODS: tuple[str, ...] = ("B0", "B1", "B2", "B3", "B5")


def _load_frozen_prediction(predictions_root: Path, agent_llm: str, method: str) -> pd.DataFrame:
    """Read one shipped, frozen test.parquet (no retraining, no GPU)."""
    # Layout convention shared with artifacts_v2/predictions/: one directory
    # per (agent_llm, method) pair, each holding a single test.parquet file.
    path = predictions_root / agent_llm / method / "test.parquet"
    # Fail loudly and specifically (which file, which path) rather than letting
    # pandas raise a generic, harder-to-diagnose error deeper in the call stack.
    if not path.is_file():
        raise FileNotFoundError(f"Missing frozen prediction file: {path}")
    # Predictions are stored as columns Mpeak_pred / Mupper_pred; no ground
    # truth yet -- that gets attached separately in _attach_ground_truth below.
    return pd.read_parquet(path)


def _attach_ground_truth(
    repo_root: Path,
    agent_llm: str,
    pred: pd.DataFrame,
) -> pd.DataFrame:
    """
    Re-derive the exact test-row order used at prediction time (deterministic
    given the shipped ``data/labels_v2`` and ``data/traces_v2/index.parquet``
    files) and attach ``M_peak_true`` positionally, matching how the
    predictions were originally written by ``predict_b0``/``predict_b1``/etc.
    (one row appended per ``test.iterrows()`` call, in order).
    """
    # tracing_paths_from_env() reads the TRACING_CONFIG env var we defaulted
    # above, and resolves the released labels/index/prompts paths relative to repo_root.
    layout = tracing_paths_from_env(repo_root=repo_root)
    # Rebuilds the same labels+index+prompt-text join used at prediction time;
    # this join is a pure function of the shipped, versioned data files, so it
    # reproduces byte-for-byte given the same repo checkout.
    frame = load_baseline_frame(repo_root=repo_root, agent_llm=agent_llm, paths=layout)
    # split_frame() applies the fixed, seeded 70/15/15 split; we only need the
    # test partition here (train/val are discarded via the underscore names).
    _train, _val, test = split_frame(frame)
    # Row-count mismatch means the shipped data/ directory does not match the
    # frozen predictions (different split or label release).
    if len(test) != len(pred):
        raise RuntimeError(
            f"Frozen prediction row count for {agent_llm} ({len(pred)}) does not match "
            f"the test split derived from the shipped labels/index ({len(test)}). The "
            "released data/ directory may not match the one used to freeze predictions."
        )
    # Copy-then-assign (rather than mutating `pred` in place) so callers of
    # this function never observe a partially-populated frame on error paths.
    out = pred.copy()
    # Positional alignment: both `pred` and `test` were produced by iterating
    # the same split_frame() output in the same order, so row i in one
    # corresponds to row i in the other even though `pred` has no id column.
    out["M_peak_true"] = test["y_Mpeak"].to_numpy()
    return out


def build_table2_from_frozen_predictions(
    repo_root: Path,
    predictions_root: Path,
) -> pd.DataFrame:
    """One row per (agent_llm, method), computed only from shipped, frozen parquets."""
    # Accumulate one metrics dict per (agent, method) pair; converted to a
    # DataFrame once at the end rather than appending rows to a DataFrame
    # in the loop (which would be quadratic in pandas).
    rows: List[dict] = []
    # AGENT_LLMS is the canonical four-backbone list used everywhere else in
    # src/baselines, so iterating it here keeps this script's coverage in
    # lock-step with the rest of the pipeline if a backbone is ever added.
    for agent_llm in AGENT_LLMS:
        for method in METHODS:
            # Step 1: read the frozen point/upper predictions for this cell.
            pred = _load_frozen_prediction(predictions_root, agent_llm, method)
            # Step 2: attach the matching ground-truth M_peak_true column.
            merged = _attach_ground_truth(repo_root, agent_llm, pred)
            # Step 3: compute MAPE/MAE/undercoverage/OAW with the exact same
            # function the original evaluation pipeline used (src/eval/metrics.py),
            # so this script cannot silently drift from the paper's definitions.
            rows.append(
                summarize_predictions(
                    merged, agent_llm=agent_llm, method=method, split="test", z_alpha=1.96
                )
            )
    return pd.DataFrame(rows)


def main() -> int:
    # Reuse this module's docstring as the CLI --help text, so usage
    # instructions live in exactly one place.
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--predictions-root",
        type=Path,
        default=REPO_ROOT / "data" / "frozen_predictions_table2",
        help="Directory containing frozen {agent_llm}/{method}/test.parquet files.",
    )
    args = parser.parse_args()

    # Build the metrics table, then sort for a stable, paper-matching row order
    # (agent_llm, then method) rather than relying on dict/loop iteration order.
    df = build_table2_from_frozen_predictions(REPO_ROOT, args.predictions_root)
    df = df.sort_values(["agent_llm", "method"]).reset_index(drop=True)

    # Widen pandas' default print width so no column wraps mid-row in the
    # terminal, which would make eyeballing a diff against the paper harder.
    pd.set_option("display.width", 160)
    print(df[["agent_llm", "method", "n_rows", "mape_pct", "mae_peak_mb",
               "undercoverage_rate", "oaw_pct_ceiling"]].to_string(index=False))
    # Blank line separates the human-readable table from the LaTeX dump below.
    print()
    # render_primary_results_tex() is the exact function the original pipeline
    # used to emit Table 2's LaTeX body, so this output can be pasted directly
    # over the table in results.tex if a discrepancy needs correcting.
    print(render_primary_results_tex(df))
    return 0


if __name__ == "__main__":
    # sys.exit() with an int makes the shell-visible exit code match main()'s
    # return value (0 = success), which `make reproduce-table2` relies on.
    sys.exit(main())
