#!/usr/bin/env bash
# resilient watcher for hardware sweep tracing only (720 runs).
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

export PYTHONWARNINGS="${PYTHONWARNINGS:-ignore::FutureWarning}"

POLL_SEC=60
STALL_SEC=900
PORT="${TRACE_BATCH_V2_SWEEP_PORT:-8080}"
PROGRESS_FILE="${REPO_ROOT}/artifacts/trace_batch_v2_sweep_progress.json"
DRIVER_LOG="${REPO_ROOT}/artifacts/trace_batch_v2_sweep_driver.log"
WATCHER_LOG="${REPO_ROOT}/artifacts/trace_batch_v2_sweep_watcher.log"
TRACING_CONFIG="${REPO_ROOT}/configs/tracing_v2.yaml"
AGENT_CONFIG="${REPO_ROOT}/configs/agent_llms_v2.yaml"

mkdir -p "${REPO_ROOT}/artifacts" "${REPO_ROOT}/data/traces_v2"

log() {
  echo "[$(date -Iseconds)] $*" | tee -a "${WATCHER_LOG}"
}

count_done() {
  python3 - <<'PY'
import sys
from pathlib import Path
import yaml
sys.path.insert(0, str(Path("scripts").resolve()))
from trace_batch_common import count_complete_sweep_traces_glob, load_sweep_agent_ids, repo_root_from_here
repo = repo_root_from_here()
tracing_path = repo / "configs" / "tracing_v2.yaml"
tracing = yaml.safe_load(tracing_path.read_text())
trace_root = repo / tracing["trace_output"]["root_dir"]
model_ids = load_sweep_agent_ids(tracing_path)
print(count_complete_sweep_traces_glob(trace_root=trace_root, model_ids=model_ids))
PY
}

expect_total() {
  python3 - <<'PY'
import sys
from pathlib import Path
sys.path.insert(0, str(Path("scripts").resolve()))
from trace_batch_common import expected_v2_sweep_only_total, repo_root_from_here
repo = repo_root_from_here()
print(expected_v2_sweep_only_total(
    repo,
    agent_config=repo / "configs" / "agent_llms_v2.yaml",
    tracing_config=repo / "configs" / "tracing_v2.yaml",
))
PY
}

driver_running() {
  pgrep -f "python3 scripts/03_run_traces.py.*tracing_v2.yaml.*--sweep-only" >/dev/null 2>&1
}

kill_driver_and_servers() {
  if driver_running; then
    pkill -f "python3 scripts/03_run_traces.py.*tracing_v2.yaml.*--sweep-only" || true
    sleep 2
  fi
  python3 - <<'PY'
import sys
from pathlib import Path
sys.path.insert(0, str(Path("scripts").resolve()))
from trace_batch_common import kill_stray_llama_servers
kill_stray_llama_servers()
PY
}

progress_age_sec() {
  if [[ ! -f "${PROGRESS_FILE}" ]]; then
    echo 999999
    return
  fi
  python3 - <<PY
import json, time
from pathlib import Path
p = Path("${PROGRESS_FILE}")
row = json.loads(p.read_text())
print(int(time.time() - float(row.get("timestamp_unix", 0))))
PY
}

write_snapshot() {
  python3 scripts/write_trace_v2_snapshot.py --sweep-only --quiet >>"${WATCHER_LOG}" 2>&1 || true
}

disk_guard_ok() {
  python3 - <<'PY'
import sys
from pathlib import Path
sys.path.insert(0, str(Path("scripts").resolve()))
from trace_batch_common import check_disk_guard_batch
ok, msg = check_disk_guard_batch()
if not ok:
    print(msg)
    raise SystemExit(1)
PY
}

EXPECT_TOTAL="$(expect_total)"
LAST_DONE=-1
SNAPSHOT_EVERY=10

log "hardware sweep watcher starting (expect ${EXPECT_TOTAL} runs, port ${PORT})"
write_snapshot

while true; do
  DONE="$(count_done)"
  if [[ "${DONE}" != "${LAST_DONE}" ]]; then
    log "Progress: ${DONE}/${EXPECT_TOTAL} complete (sweep only)"
    if [[ "${DONE}" -gt 0 ]] && (( DONE % SNAPSHOT_EVERY == 0 )); then
      write_snapshot
    elif [[ "${DONE}" -gt 0 ]]; then
      write_snapshot
    fi
    LAST_DONE="${DONE}"
  fi

  if [[ "${DONE}" -ge "${EXPECT_TOTAL}" ]]; then
    log "All ${EXPECT_TOTAL} sweep runs complete"
    write_snapshot
    log "Watcher exiting"
    exit 0
  fi

  if driver_running; then
    AGE="$(progress_age_sec)"
    if [[ "${AGE}" -gt "${STALL_SEC}" ]]; then
      log "STALL detected (${AGE}s since last progress) — killing driver and llama servers"
      kill_driver_and_servers
      sleep 10
    else
      sleep "${POLL_SEC}"
      continue
    fi
  fi

  if ! disk_guard_ok >>"${WATCHER_LOG}" 2>&1; then
    log "Disk guard blocked driver restart — waiting ${POLL_SEC}s"
    sleep "${POLL_SEC}"
    continue
  fi

  log "Starting hardware sweep driver (resume)"
  kill_driver_and_servers
  sleep 5

  set +e
  python3 scripts/03_run_traces.py \
    --resume \
    --sweep-only \
    --config "${TRACING_CONFIG}" \
    --agent-config "${AGENT_CONFIG}" \
    --port "${PORT}" \
    --progress-file "${PROGRESS_FILE}" \
    >>"${DRIVER_LOG}" 2>&1
  RC=$?
  set -e

  log "Driver exited with code ${RC}"
  if [[ "${RC}" -eq 2 ]]; then
    log "Driver halted by disk guard (< 10 GiB free on /workspace)"
  fi
  write_snapshot
  kill_driver_and_servers
  sleep 10
done
