#!/usr/bin/env python3
"""Phase 5.3/5.4 — train one multi-task VRAM proxy and write deliverables."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import torch

_REPO = Path(__file__).resolve().parents[1]
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from src.proxy.training import train_proxy_model


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train multi-task VRAM proxy models.")
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=_REPO,
        help="Repository root directory.",
    )
    parser.add_argument(
        "--agent-llm",
        type=str,
        required=True,
        choices=["qwen2.5-coder-7b", "phi-4-mini", "mistral-7b-instruct-v0.3"],
        help="Agent backend whose traces supervise the proxy.",
    )
    parser.add_argument(
        "--backbone",
        type=str,
        required=True,
        choices=["minilm-l12", "deberta-v3-base", "unixcoder"],
        help="Proxy encoder backbone.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Override deliverable directory (default: artifacts/proxies/{agent}/{backbone}).",
    )
    parser.add_argument(
        "--enable-stretch-heads",
        action="store_true",
        help="Enable compile/numcorrect stretch heads (off by default).",
    )
    parser.add_argument(
        "--device",
        type=str,
        default="cuda" if torch.cuda.is_available() else "cpu",
        help="Torch device for training.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    out = args.output_dir
    if out is None:
        out = args.repo_root / "artifacts" / "proxies" / args.agent_llm / args.backbone
    metrics = train_proxy_model(
        repo_root=args.repo_root,
        agent_llm=args.agent_llm,
        backbone_id=args.backbone,
        output_dir=out,
        enable_stretch_heads=args.enable_stretch_heads,
        device=torch.device(args.device),
    )
    print(json.dumps({k: metrics[k] for k in ("agent_llm", "backbone", "best_epoch", "val_mape", "val_oom_rate", "inference_vram_mb")}, indent=2))
    print(f"Wrote {out / 'model.safetensors'}")
    print(f"Wrote {out / 'metrics.json'}")


if __name__ == "__main__":
    main()
