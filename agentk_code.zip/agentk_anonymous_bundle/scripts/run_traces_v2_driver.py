"""Part-2 v2 trace batch driver (base + 3-corner sweep plan)."""

from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from src.tracing.llm_recorder import nvidia_smi_sidecar_path
from src.tracing.sweep_plan import (
    TraceRunSpec,
    enumerate_v2_trace_runs,
    filter_run_specs,
    format_v2_dry_run_summary,
    load_v2_sweep_config,
    sweep_subset_prompt_ids,
    trace_output_path_v2,
)
from src.tracing.vram_sampler import load_diagnostic_prompt_ids


def _prompt_lookup(prompts: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    return {str(row["id"]): row for row in prompts}


def _group_run_specs(
    specs: List[TraceRunSpec],
    *,
    cache_type_order: Optional[Tuple[Tuple[str, str], ...]] = None,
) -> List[Tuple[TraceRunSpec, List[TraceRunSpec]]]:
    """Group runs that share one llama-server configuration."""
    cache_rank: Dict[Tuple[str, str], int] = {}
    if cache_type_order is not None:
        cache_rank = {pair: idx for idx, pair in enumerate(cache_type_order)}

    def _sort_key(key: Tuple[str, int, str, str]) -> Tuple[Any, ...]:
        model_id, n_ctx, cache_k, cache_v = key
        return (
            model_id,
            n_ctx,
            cache_rank.get((cache_k, cache_v), 999),
            cache_k,
            cache_v,
        )

    buckets: Dict[Tuple[str, int, str, str], List[TraceRunSpec]] = {}
    for spec in specs:
        key = (spec.model_id, spec.n_ctx, spec.cache_type_k, spec.cache_type_v)
        buckets.setdefault(key, []).append(spec)
    groups: List[Tuple[TraceRunSpec, List[TraceRunSpec]]] = []
    for key in sorted(buckets, key=_sort_key):
        group = buckets[key]
        groups.append((group[0], group))
    return groups


def run_v2_batch(
    *,
    args: Any,
    repo: Path,
    tracing_cfg: Dict[str, Any],
    tracing_path: Path,
    trace_batch_common: Any,
    build_vram_sampler: Any,
    delete_cuda_sidecar: Any,
    kill_stray_llama_servers: Any,
    release_gpu_memory: Any,
    write_progress: Any,
    count_complete_traces_glob: Any,
    _load_models: Any,
    _load_prompts: Any,
    _start_llama_server: Any,
    _stop_process: Any,
    _reset_agentk_modules: Any,
    default_agent_config_path: Any,
    prompts_jsonl_path: Any,
) -> int:
    """Execute or dry-run the Part-2 v2 trace plan (1920 full or 1200 base-only)."""
    from src.tracing import agentk_trace

    base_only = bool(getattr(args, "base_only", False))
    sweep_only = bool(getattr(args, "sweep_only", False))
    if base_only and sweep_only:
        raise ValueError("Cannot pass both --base-only and --sweep-only")
    check_disk_guard_batch = trace_batch_common.check_disk_guard_batch
    count_complete_base_traces_glob = trace_batch_common.count_complete_base_traces_glob
    count_complete_sweep_traces_glob = trace_batch_common.count_complete_sweep_traces_glob
    agent_config_path = (
        args.agent_config
        if args.agent_config is not None
        else default_agent_config_path(repo, tracing_path)
    ).resolve()

    timeout_sec = int(tracing_cfg["agentk"]["run_timeout_sec"])
    retry_budget = int(tracing_cfg["agentk"]["retry_budget"])
    trace_root = repo / tracing_cfg["trace_output"]["root_dir"]
    seed = int(tracing_cfg["split"]["seed"])
    agentk_root = repo / "third_party" / "agentk"
    base_url = f"http://{args.host}:{args.port}/v1"

    corpus_prompts = _load_prompts(prompts_jsonl_path(repo, tracing_cfg))
    models = _load_models(agent_config_path)
    if args.model:
        models = [m for m in models if m["id"] == args.model]
        if not models:
            raise RuntimeError(f"Unknown --model {args.model!r}")

    probe_n_ctx = int(models[0].get("n_ctx", 8192)) if models else 8192
    sweep_cfg = load_v2_sweep_config(
        tracing_cfg,
        n_ctx_sweep_override=args.n_ctx_sweep,
        cache_type_sweep_override=args.cache_type_sweep,
        sweep_subset_prompts_override=args.sweep_subset_prompts,
        sweep_subset_agents_override=args.sweep_subset_agents,
        base_n_ctx=probe_n_ctx,
    )

    subset_ids = sweep_subset_prompt_ids(
        corpus_prompts,
        total=sweep_cfg.sweep_subset_prompts,
        seed=seed,
    )
    diagnostic_prompt_ids = load_diagnostic_prompt_ids(
        tracing_cfg["vram_sampling"],
        corpus_prompts,
        seed=seed,
    )
    model_ids = [str(m["id"]) for m in models]
    full_plan = enumerate_v2_trace_runs(
        model_ids=model_ids,
        prompt_rows=corpus_prompts,
        sweep_cfg=sweep_cfg,
        sweep_prompt_ids=subset_ids,
    )
    if base_only:
        full_plan = [spec for spec in full_plan if not spec.sweep]
        print(
            f"Base-only mode: {len(full_plan)} runs "
            f"({len(model_ids)} agents × {len(corpus_prompts)} prompts × "
            f"n_ctx={sweep_cfg.base_n_ctx}, {sweep_cfg.baseline_k}/{sweep_cfg.baseline_v})"
        )
    elif sweep_only:
        full_plan = [spec for spec in full_plan if spec.sweep]
        print(
            f"Sweep-only mode: {len(full_plan)} runs "
            f"({len(sweep_cfg.sweep_subset_agents)} sweep agents × "
            f"{sweep_cfg.sweep_subset_prompts} prompts × "
            f"{len(sweep_cfg.n_ctx_sweep)} n_ctx × "
            f"{len(sweep_cfg.cache_type_sweep)} cache_type)"
        )
    else:
        print(
            format_v2_dry_run_summary(
                n_agents=len(model_ids),
                n_prompts=len(corpus_prompts),
                sweep_cfg=sweep_cfg,
                planned_total=len(full_plan),
            )
        )

    if args.dry_run:
        if args.limit is not None or args.split or args.prompt_ids:
            wanted_ids: Optional[Set[str]] = None
            if args.prompt_ids:
                wanted_ids = {
                    pid.strip() for pid in args.prompt_ids.split(",") if pid.strip()
                }
            trimmed = filter_run_specs(
                full_plan,
                model_id=args.model,
                prompt_ids=wanted_ids,
                limit=args.limit,
            )
            print(f"After CLI filters: {len(trimmed)} runs would execute")
        return 0

    prompt_ids_filter: Optional[Set[str]] = None
    if args.prompt_ids:
        prompt_ids_filter = {
            pid.strip() for pid in args.prompt_ids.split(",") if pid.strip()
        }
    filtered_prompts = list(corpus_prompts)
    if args.split:
        filtered_prompts = [
            p for p in filtered_prompts if p.get("split") == args.split
        ]
    if args.limit is not None:
        filtered_prompts = filtered_prompts[: args.limit]
    allowed_prompt_ids = {str(p["id"]) for p in filtered_prompts}

    run_plan = [
        spec
        for spec in full_plan
        if spec.prompt_id in allowed_prompt_ids
        and (args.model is None or spec.model_id == args.model)
    ]
    expect_total = len(run_plan)
    if args.expect_total is not None:
        expect_total = int(args.expect_total)

    progress_path = args.progress_file or (
        repo / "artifacts" / (
            "trace_batch_v2_base_progress.json"
            if base_only
            else (
                "trace_batch_v2_sweep_progress.json"
                if sweep_only
                else "trace_batch_v2_progress.json"
            )
        )
    )
    progress_path.parent.mkdir(parents=True, exist_ok=True)

    if sweep_only:
        inventory_model_ids = sorted(sweep_cfg.sweep_subset_agents)
    else:
        inventory_model_ids = model_ids
    if base_only:
        count_done = count_complete_base_traces_glob
    elif sweep_only:
        count_done = count_complete_sweep_traces_glob
    else:
        count_done = count_complete_traces_glob
    done_at_start = count_done(
        trace_root=trace_root, model_ids=inventory_model_ids
    )
    print(f"Batch progress at start: {done_at_start}/{expect_total}")

    prompt_by_id = _prompt_lookup(corpus_prompts)
    model_by_id = {str(m["id"]): m for m in models}
    completed = 0
    skipped = 0
    failed = 0

    groups = _group_run_specs(
        run_plan,
        cache_type_order=sweep_cfg.cache_type_sweep,
    )
    for _head, group in groups:
        model = model_by_id[group[0].model_id]
        n_ctx = group[0].n_ctx
        cache_type_k = group[0].cache_type_k
        cache_type_v = group[0].cache_type_v

        pending_group: List[TraceRunSpec] = []
        for spec in group:
            out_path = trace_output_path_v2(
                trace_root,
                model_id=spec.model_id,
                prompt_id=spec.prompt_id,
                n_ctx=spec.n_ctx,
                cache_type_k=spec.cache_type_k,
                cache_type_v=spec.cache_type_v,
                sweep=spec.sweep,
            )
            if args.resume and trace_batch_common.trace_is_complete(out_path):
                skipped += 1
                continue
            pending_group.append(spec)

        if not pending_group:
            print(
                f"\n=== Agent LLM: {model['id']} "
                f"(n_ctx={n_ctx}, k={cache_type_k}, v={cache_type_v}, "
                f"{len(group)} runs) — all complete, skipping ==="
            )
            continue

        print(
            f"\n=== Agent LLM: {model['id']} "
            f"(n_ctx={n_ctx}, k={cache_type_k}, v={cache_type_v}, "
            f"{len(pending_group)} pending / {len(group)} total) ==="
        )
        log_path = repo / "artifacts" / f"llama_server_{model['id']}.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        kill_stray_llama_servers()
        server = _start_llama_server(
            gguf_path=model["gguf_path"],
            model_alias=model["model_alias"],
            host=args.host,
            port=args.port,
            n_ctx=n_ctx,
            n_gpu_layers=int(model.get("n_gpu_layers", -1)),
            log_path=log_path,
            cache_type_k=cache_type_k,
            cache_type_v=cache_type_v,
        )
        try:
            _reset_agentk_modules()
            agentk_path = str(agentk_root)
            if agentk_path not in sys.path:
                sys.path.insert(0, agentk_path)
            os.environ["ACTIVE_ENV"] = "local"
            os.environ["LOCAL_BASE_URL"] = base_url
            os.environ["LOCAL_MODEL"] = model["model_alias"]
            os.environ["LOCAL_API_KEY"] = "not-needed"
            os.environ["PATH"] = f"/usr/local/cuda/bin:{os.environ.get('PATH', '')}"

            model_run_cfg = {
                **model,
                "n_ctx": n_ctx,
                "cache_type_k": cache_type_k,
                "cache_type_v": cache_type_v,
            }
            session = agentk_trace.TraceSession(
                vram=build_vram_sampler(
                    tracing_cfg["vram_sampling"],
                    prompt_id=group[0].prompt_id,
                    diagnostic_prompt_ids=diagnostic_prompt_ids,
                )
            )
            agentk_app = agentk_trace.build_traced_agentk_app(
                session=session, max_retries=retry_budget
            )

            for spec in pending_group:
                prompt_row = prompt_by_id[spec.prompt_id]
                prompt_id = spec.prompt_id
                out_path = trace_output_path_v2(
                    trace_root,
                    model_id=spec.model_id,
                    prompt_id=prompt_id,
                    n_ctx=spec.n_ctx,
                    cache_type_k=spec.cache_type_k,
                    cache_type_v=spec.cache_type_v,
                    sweep=spec.sweep,
                )
                out_path.parent.mkdir(parents=True, exist_ok=True)

                disk_ok, disk_msg = check_disk_guard_batch()
                if not disk_ok:
                    print(disk_msg)
                    write_progress(
                        progress_path=progress_path,
                        completed_total=done_at_start + completed,
                        expect_total=expect_total,
                        model_id=str(model["id"]),
                        prompt_id=prompt_id,
                        status="disk_guard_halt",
                        extra={"disk_guard": disk_msg},
                    )
                    return 2

                if args.resume and out_path.exists() and not trace_batch_common.trace_is_complete(out_path):
                    out_path.unlink()
                    delete_cuda_sidecar(
                        repo_root=repo,
                        agent_llm=model["id"],
                        prompt_id=prompt_id,
                    )

                print(
                    f"  [{done_at_start + completed + 1}/{expect_total}] "
                    f"trace {model['id']}/{prompt_id}"
                    + (" [sweep]" if spec.sweep else " [base]")
                    + f" ctx={spec.n_ctx} k={spec.cache_type_k} v={spec.cache_type_v} ... ",
                    end="",
                    flush=True,
                )
                try:
                    session.vram = build_vram_sampler(
                        tracing_cfg["vram_sampling"],
                        prompt_id=prompt_id,
                        diagnostic_prompt_ids=diagnostic_prompt_ids,
                    )
                    metadata = agentk_trace.build_run_metadata(
                        agent_llm_id=model["id"],
                        prompt_id=prompt_id,
                        model_cfg=model_run_cfg,
                        seed=seed,
                        calibration_path=repo / "configs" / "q4_vram_calibration_v2.yaml",
                    )
                    metadata["prompt_split"] = prompt_row.get("split")
                    metadata["prompt_source"] = prompt_row.get("source")
                    metadata["n_ctx"] = int(spec.n_ctx)
                    metadata["cache_type_k"] = spec.cache_type_k
                    metadata["cache_type_v"] = spec.cache_type_v
                    metadata["trace_kind"] = "sweep" if spec.sweep else "base"

                    final_state = agentk_trace.run_traced_agentk(
                        agentk_app=agentk_app,
                        prompt=str(prompt_row["prompt"]),
                        session=session,
                        timeout_sec=timeout_sec,
                        vram_sidecar_path=nvidia_smi_sidecar_path(out_path),
                    )
                    labels = agentk_trace.compute_ground_truth_labels(session)
                    agentk_trace.write_trace_jsonl(
                        output_path=out_path,
                        metadata=metadata,
                        session=session,
                        final_state=final_state,
                        labels=labels,
                    )
                    completed += 1
                    done_now = done_at_start + completed
                    ok = bool(final_state.get("compilation_success"))
                    if session.timeout:
                        status = "timeout"
                    elif session.oom:
                        status = "oom"
                    else:
                        status = "ok" if ok else "compile_fail"
                    write_progress(
                        progress_path=progress_path,
                        completed_total=done_now,
                        expect_total=expect_total,
                        model_id=str(model["id"]),
                        prompt_id=prompt_id,
                        status=status,
                        extra={
                            "N_true": labels.get("N_true"),
                            "M_peak_true": labels.get("M_peak_true"),
                            "compile_success": ok,
                            "timeout": session.timeout,
                            "oom": session.oom,
                            "n_ctx": spec.n_ctx,
                            "cache_type_k": spec.cache_type_k,
                            "cache_type_v": spec.cache_type_v,
                            "trace_kind": metadata["trace_kind"],
                        },
                    )
                    if "traces_v2" in str(trace_root):
                        snapshot_args = [sys.executable, str(repo / "scripts" / "write_trace_v2_snapshot.py"), "--quiet"]
                        if base_only:
                            snapshot_args.append("--base-only")
                        elif sweep_only:
                            snapshot_args.append("--sweep-only")
                        subprocess.run(
                            snapshot_args,
                            cwd=str(repo),
                            check=False,
                        )
                    print(status)
                    release_gpu_memory()
                except Exception as exc:
                    failed += 1
                    print(f"DRIVER_ERROR {exc!r}")
                    write_progress(
                        progress_path=progress_path,
                        completed_total=done_at_start + completed,
                        expect_total=expect_total,
                        model_id=str(model["id"]),
                        prompt_id=prompt_id,
                        status="driver_error",
                        extra={"error": str(exc)},
                    )
                    release_gpu_memory()
        finally:
            _stop_process(server)
            release_gpu_memory()
            time.sleep(5)

    done_final = count_done(
        trace_root=trace_root, model_ids=inventory_model_ids
    )
    print(
        f"\nDone: completed_this_pass={completed}, skipped={skipped}, "
        f"driver_errors={failed}, total_complete={done_final}/{expect_total}"
    )
    return 0 if done_final >= expect_total else 1
