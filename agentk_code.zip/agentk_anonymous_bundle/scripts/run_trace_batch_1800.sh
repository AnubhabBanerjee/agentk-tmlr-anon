#!/usr/bin/env bash
# Phase 3.3 — one-shot launcher for the 1800-run trace batch with watcher.
# Usage (from repo root):
#   nohup bash scripts/run_trace_batch_1800.sh > artifacts/trace_batch_nohup.log 2>&1 & disown
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

mkdir -p artifacts

echo "=== Phase 3.3 batch launcher ==="
echo "Repo: ${REPO_ROOT}"
echo "Runs: 3 agent LLMs × 600 prompts = 1800"
echo ""

python3 scripts/preflight_trace_batch.py
echo ""

echo "Starting watcher (logs: artifacts/trace_batch_watcher.log, artifacts/trace_batch_driver.log)"
exec bash scripts/watch_trace_batch.sh
