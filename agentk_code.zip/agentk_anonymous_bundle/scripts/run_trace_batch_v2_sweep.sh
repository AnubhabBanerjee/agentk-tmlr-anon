#!/usr/bin/env bash
# nohup launcher for hardware sweep tracing (3 agents × 40 prompts × 2 n_ctx × 3 cache = 720 runs).
#
# Usage (from repo root):
#   nohup bash scripts/run_trace_batch_v2_sweep.sh > artifacts/trace_batch_v2_sweep_nohup.log 2>&1 & disown
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

# Keep batch logs readable: torch (pynvml) and transformers emit noisy FutureWarnings.
export PYTHONWARNINGS="${PYTHONWARNINGS:-ignore::FutureWarning}"

mkdir -p artifacts data/traces_v2 data/labels_v2 data/correctness_v2

echo "=== trace batch hardware sweep launcher ==="
echo "Repo: ${REPO_ROOT}"
echo "Agent config: configs/agent_llms_v2.yaml"
echo "Tracing config: configs/tracing_v2.yaml"
echo "Output: data/traces_v2/{agent}/sweep/{prompt_id}__ctx{n_ctx}__k{cache_k}__v{cache_v}.jsonl.zst"
echo "Runs: 720 sweep (3 agents × 40 prompts × 2 n_ctx × 3 cache_type)"
echo ""

python3 - <<'PY'
import subprocess
import sys
from pathlib import Path
sys.path.insert(0, str(Path("scripts").resolve()))
from trace_batch_common import kill_stray_llama_servers
for pattern in (
    "watch_trace_batch_v2_sweep.sh",
    "python3 scripts/03_run_traces.py",
):
    subprocess.run(["pkill", "-f", pattern], check=False)
kill_stray_llama_servers()
PY
sleep 2

python3 scripts/preflight_trace_batch_v2.py --sweep-only
echo ""

python3 scripts/write_trace_v2_snapshot.py --sweep-only
echo ""

echo "Starting hardware sweep watcher (logs: artifacts/trace_batch_v2_sweep_watcher.log, artifacts/trace_batch_v2_sweep_driver.log)"
exec bash scripts/watch_trace_batch_v2_sweep.sh
