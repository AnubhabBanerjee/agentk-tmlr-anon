#!/usr/bin/env bash
# resilient watcher for KernelBench correctness harness (§3.5).
# Restarts scripts/05_run_kernelbench_correctness.py --resume until all rows terminal.
#
# released: TRACING_CONFIG=configs/tracing_v2.yaml (set by make run-kbench-correctness CONFIG=...)
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

CONFIG="${TRACING_CONFIG:-}"
if [[ -n "${CONFIG}" ]]; then
  ARTIFACTS_DIR="${REPO_ROOT}/artifacts_v2"
  CONFIG_ARGS=(--config "${CONFIG}")
else
  ARTIFACTS_DIR="${REPO_ROOT}/artifacts"
  CONFIG_ARGS=()
fi

POLL_SEC=60
STALL_SEC=300
PROGRESS_FILE="${ARTIFACTS_DIR}/kbench_correctness_progress.json"
DRIVER_LOG="${ARTIFACTS_DIR}/kbench_correctness_driver.log"
WATCHER_LOG="${ARTIFACTS_DIR}/kbench_correctness_watcher.log"

mkdir -p "${ARTIFACTS_DIR}"

log() {
  echo "[$(date -Iseconds)] $*" | tee -a "${WATCHER_LOG}"
}

count_done() {
  python3 - <<PY
import os
import sys
from pathlib import Path
import pandas as pd

sys.path.insert(0, str(Path("${REPO_ROOT}") / "scripts"))
sys.path.insert(0, "${REPO_ROOT}")
from kbench_correctness_common import count_harness_done, repo_root_from_here
from src.pipeline.tracing_paths import tracing_paths_from_env

repo = repo_root_from_here()
paths = tracing_paths_from_env(repo_root=repo)
parquet = paths.correctness_parquet
if not parquet.is_file():
    print(0)
else:
    print(count_harness_done(pd.read_parquet(parquet)))
PY
}

expect_total() {
  python3 - <<PY
import sys
from pathlib import Path
import pandas as pd

sys.path.insert(0, "${REPO_ROOT}")
from src.pipeline.tracing_paths import tracing_paths_from_env

repo = Path("${REPO_ROOT}")
paths = tracing_paths_from_env(repo_root=repo)
print(len(pd.read_parquet(paths.index_path)))
PY
}

driver_running() {
  pgrep -f "python3 scripts/05_run_kernelbench_correctness.py" >/dev/null 2>&1
}

kill_driver() {
  if driver_running; then
    pkill -f "python3 scripts/05_run_kernelbench_correctness.py" || true
    sleep 2
  fi
}

progress_age_sec() {
  if [[ ! -f "${PROGRESS_FILE}" ]]; then
    echo 999999
    return
  fi
  python3 - <<PY
import json, time
from pathlib import Path
p = Path("${PROGRESS_FILE}")
row = json.loads(p.read_text())
print(int(time.time() - float(row.get("timestamp_unix", 0))))
PY
}

EXPECT_TOTAL="$(expect_total)"
log "Watcher starting (expect ${EXPECT_TOTAL} terminal harness rows; CONFIG=${CONFIG:-v1})"

if ! python3 scripts/preflight_kbench_correctness.py "${CONFIG_ARGS[@]}" >>"${WATCHER_LOG}" 2>&1; then
  log "Preflight failed — watcher exiting"
  exit 1
fi

while true; do
  DONE="$(count_done)"
  log "Progress: ${DONE}/${EXPECT_TOTAL} terminal rows"

  if [[ "${DONE}" -ge "${EXPECT_TOTAL}" ]]; then
    log "All ${EXPECT_TOTAL} harness rows terminal — watcher exiting"
    exit 0
  fi

  if driver_running; then
    AGE="$(progress_age_sec)"
    if [[ "${AGE}" -gt "${STALL_SEC}" ]]; then
      log "STALL detected (${AGE}s since last progress) — killing driver"
      kill_driver
      sleep 10
    else
      sleep "${POLL_SEC}"
      continue
    fi
  fi

  log "Starting driver: python3 scripts/05_run_kernelbench_correctness.py --resume ${CONFIG_ARGS[*]}"
  kill_driver
  sleep 5

  set +e
  python3 scripts/05_run_kernelbench_correctness.py --resume \
    --progress-file "${PROGRESS_FILE}" \
    "${CONFIG_ARGS[@]}" \
    >>"${DRIVER_LOG}" 2>&1
  RC=$?
  set -e

  log "Driver exited with code ${RC}"
  sleep 10
done
