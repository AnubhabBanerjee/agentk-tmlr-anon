#!/usr/bin/env python3
"""Part 2 / A1+A2 — build the 300-prompt v2 corpus (data/prompts_v2/)."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def _repo_root() -> Path:
    """Return repository root (parent of scripts/)."""
    return Path(__file__).resolve().parents[1]


def _parse_split(value: str) -> tuple[int, int, int]:
    """Parse '210/45/45' into integer train/val/test counts."""
    parts = value.strip().split("/")
    if len(parts) != 3:
        raise argparse.ArgumentTypeError("split must look like 210/45/45")
    try:
        train, val, test = (int(p) for p in parts)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("split components must be integers") from exc
    return train, val, test


def parse_args() -> argparse.Namespace:
    """CLI for scripts/02b_regenerate_synthetic_prompts.py (guide §7.1 step 12)."""
    parser = argparse.ArgumentParser(
        description="Build Part-2 v2 prompt set (300 stratified prompts)."
    )
    parser.add_argument("--repo-root", type=Path, default=_repo_root())
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("configs/tracing_v2.yaml"),
        help="Tracing config (seed fallback; file may be absent during early A1).",
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=Path("data/prompts_v2/all.jsonl"),
        help="Output JSONL path.",
    )
    parser.add_argument("--n-kbench", type=int, default=100)
    parser.add_argument("--n-clean", type=int, default=100)
    parser.add_argument("--n-retry-provoking", type=int, default=100)
    parser.add_argument("--split", type=_parse_split, default=(210, 45, 45))
    parser.add_argument("--seed", type=int, default=20260715)
    parser.add_argument("--per-level-kbench", type=int, default=25)
    parser.add_argument("--jaccard-threshold", type=float, default=0.85)
    return parser.parse_args()


def main() -> int:
    """Entry point: write data/prompts_v2/all.jsonl and split.json."""
    args = parse_args()
    repo_root = args.repo_root.resolve()
    repo_str = str(repo_root)
    if repo_str not in sys.path:
        sys.path.insert(0, repo_str)

    from src.prompts.prompt_set_v2 import V2BuildConfig, build_prompt_set_v2, source_counts

    out_path = args.out
    if not out_path.is_absolute():
        out_path = repo_root / out_path

    seed = args.seed
    config_path = args.config
    if not config_path.is_absolute():
        config_path = repo_root / config_path
    if config_path.is_file():
        import yaml

        tracing = yaml.safe_load(config_path.read_text(encoding="utf-8"))
        seed = int(tracing.get("split", {}).get("seed", seed))

    train, val, test = args.split
    cfg = V2BuildConfig(
        repo_root=repo_root,
        out_path=out_path,
        n_kbench=args.n_kbench,
        n_clean=args.n_clean,
        n_retry=args.n_retry_provoking,
        per_level_kbench=args.per_level_kbench,
        split_train=train,
        split_val=val,
        split_test=test,
        seed=seed,
        jaccard_threshold=args.jaccard_threshold,
    )

    records, splits, written = build_prompt_set_v2(cfg)
    counts = source_counts(records)
    print(f"Wrote {len(records)} prompts to {written}")
    print(
        f"  split: train={len(splits['train'])}, "
        f"val={len(splits['val'])}, test={len(splits['test'])}"
    )
    print(f"  source counts: {counts}")
    split_path = written.parent / "split.json"
    print(f"  split file: {split_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
