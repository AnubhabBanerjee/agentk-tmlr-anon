#!/usr/bin/env bash
# resilient watcher for CUDA sidecar backfill (§3.5 prep).
# Restarts scripts/backfill_cuda_sidecars.py --resume until all compile-success
# KernelBench rows have CUDA sidecars on disk.
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

POLL_SEC=60
STALL_SEC=900
PROGRESS_FILE="${REPO_ROOT}/artifacts/cuda_sidecar_backfill_progress.json"
DRIVER_LOG="${REPO_ROOT}/artifacts/cuda_sidecar_backfill_driver.log"
WATCHER_LOG="${REPO_ROOT}/artifacts/cuda_sidecar_backfill_watcher.log"
PORT="${CUDA_SIDECAR_BACKFILL_PORT:-8080}"

mkdir -p "${REPO_ROOT}/artifacts"

log() {
  echo "[$(date -Iseconds)] $*" | tee -a "${WATCHER_LOG}"
}

count_done() {
  python3 - <<'PY'
import sys
from pathlib import Path
import pandas as pd
sys.path.insert(0, str(Path("scripts").resolve()))
from kbench_correctness_common import repo_root_from_here
repo = repo_root_from_here()
sys.path.insert(0, str(repo))
from src.correctness.cuda_sidecar import load_cuda_sidecar
index_df = pd.read_parquet(repo / "data" / "traces" / "index.parquet")
targets = index_df[
    (index_df["prompt_source"] == "kernelbench") & index_df["compile_success"].astype(bool)
]
done = 0
for _, row in targets.iterrows():
    if load_cuda_sidecar(
        repo_root=repo,
        agent_llm=str(row["agent_llm"]),
        prompt_id=str(row["prompt_id"]),
    ):
        done += 1
print(done)
PY
}

expect_total() {
  python3 - <<'PY'
import sys
from pathlib import Path
import pandas as pd
sys.path.insert(0, str(Path("scripts").resolve()))
from kbench_correctness_common import expect_harness_runs, repo_root_from_here
repo = repo_root_from_here()
index_df = pd.read_parquet(repo / "data" / "traces" / "index.parquet")
print(expect_harness_runs(index_df))
PY
}

driver_running() {
  pgrep -f "python3 scripts/backfill_cuda_sidecars.py" >/dev/null 2>&1
}

kill_driver_and_servers() {
  if driver_running; then
    pkill -f "python3 scripts/backfill_cuda_sidecars.py" || true
    sleep 2
  fi
  python3 - <<'PY'
import sys
from pathlib import Path
sys.path.insert(0, str(Path("scripts").resolve()))
from trace_batch_common import kill_stray_llama_servers
kill_stray_llama_servers()
PY
}

progress_age_sec() {
  if [[ ! -f "${PROGRESS_FILE}" ]]; then
    echo 999999
    return
  fi
  python3 - <<PY
import json, time
from pathlib import Path
p = Path("${PROGRESS_FILE}")
row = json.loads(p.read_text())
print(int(time.time() - float(row.get("timestamp_unix", 0))))
PY
}

EXPECT_TOTAL="$(expect_total)"
log "Watcher starting (expect ${EXPECT_TOTAL} CUDA sidecars, port ${PORT})"

while true; do
  DONE="$(count_done)"
  log "Progress: ${DONE}/${EXPECT_TOTAL} sidecars on disk"

  if [[ "${DONE}" -ge "${EXPECT_TOTAL}" ]]; then
    log "All ${EXPECT_TOTAL} CUDA sidecars present — watcher exiting"
    exit 0
  fi

  if driver_running; then
    AGE="$(progress_age_sec)"
    if [[ "${AGE}" -gt "${STALL_SEC}" ]]; then
      log "STALL detected (${AGE}s since last progress) — killing driver and llama servers"
      kill_driver_and_servers
      sleep 10
    else
      sleep "${POLL_SEC}"
      continue
    fi
  fi

  log "Starting driver: python3 scripts/backfill_cuda_sidecars.py --resume --port ${PORT}"
  kill_driver_and_servers
  sleep 5

  set +e
  python3 scripts/backfill_cuda_sidecars.py --resume --port "${PORT}" \
    >>"${DRIVER_LOG}" 2>&1
  RC=$?
  set -e

  log "Driver exited with code ${RC}"
  kill_driver_and_servers
  sleep 10
done
