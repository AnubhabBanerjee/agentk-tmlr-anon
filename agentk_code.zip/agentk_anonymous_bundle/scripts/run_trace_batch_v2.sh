#!/usr/bin/env bash
# Part 2 — nohup launcher for the v2 trace batch (5 agents × n_ctx × KV sweep).
#
# Usage (from repo root):
#   nohup bash scripts/run_trace_batch_v2.sh > artifacts/trace_batch_v2_nohup.log 2>&1 & disown
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

mkdir -p artifacts data/traces_v2 data/labels_v2 data/correctness_v2

echo "=== Part 2 trace batch v2 launcher ==="
echo "Repo: ${REPO_ROOT}"
echo "Agent config: configs/agent_llms_v2.yaml"
echo "Tracing config: configs/tracing_v2.yaml"
echo "Output: data/traces_v2/"
echo ""

# Stale drivers/llama servers only (do not pkill this launcher script).
python3 - <<'PY'
import sys
from pathlib import Path
sys.path.insert(0, str(Path("scripts").resolve()))
from trace_batch_common import kill_stray_llama_servers
import subprocess
for pattern in (
    "watch_trace_batch_v2.sh",
    "python3 scripts/03_run_traces.py",
):
    subprocess.run(["pkill", "-f", pattern], check=False)
kill_stray_llama_servers()
PY
sleep 2

python3 scripts/preflight_trace_batch_v2.py
echo ""

python3 scripts/write_trace_v2_snapshot.py --rebuild-index
echo ""

echo "Starting v2 watcher (logs: artifacts/trace_batch_v2_watcher.log, artifacts/trace_batch_v2_driver.log)"
exec bash scripts/watch_trace_batch_v2.sh
