#!/usr/bin/env bash
# Part 2 — nohup launcher for v2 BASE tracing (4 agents × 300 prompts = 1200 runs).
#
# Usage (from repo root):
#   nohup bash scripts/run_trace_batch_v2_base.sh > artifacts/trace_batch_v2_base_nohup.log 2>&1 & disown
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

mkdir -p artifacts data/traces_v2 data/labels_v2 data/correctness_v2

echo "=== Part 2 trace batch v2 BASE launcher ==="
echo "Repo: ${REPO_ROOT}"
echo "Agent config: configs/agent_llms_v2.yaml"
echo "Tracing config: configs/tracing_v2.yaml"
echo "Output: data/traces_v2/{agent}/{prompt_id}.jsonl.zst"
echo "Runs: 1200 base (n_ctx=8192, f16/f16)"
echo ""

python3 - <<'PY'
import subprocess
import sys
from pathlib import Path
sys.path.insert(0, str(Path("scripts").resolve()))
from trace_batch_common import kill_stray_llama_servers
for pattern in (
    "watch_trace_batch_v2_base.sh",
    "python3 scripts/03_run_traces.py",
):
    subprocess.run(["pkill", "-f", pattern], check=False)
kill_stray_llama_servers()
PY
sleep 2

python3 scripts/preflight_trace_batch_v2.py --base-only
echo ""

python3 scripts/write_trace_v2_snapshot.py --base-only --rebuild-index
echo ""

echo "Starting v2 BASE watcher (logs: artifacts/trace_batch_v2_base_watcher.log, artifacts/trace_batch_v2_base_driver.log)"
exec bash scripts/watch_trace_batch_v2_base.sh
