#!/usr/bin/env bash
# Route A — initialize AgentK git submodule and local .env.

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
AGENTK_DIR="${REPO_ROOT}/third_party/agentk"
VERSION_FILE="${REPO_ROOT}/configs/agentk_version.txt"
ENV_EXAMPLE="${REPO_ROOT}/configs/agentk.env.example"
ENV_TARGET="${AGENTK_DIR}/.env"

log() { echo "[setup_agentk] $*"; }

# Step 1: init/update submodule (Route A).
log "Initializing git submodule at third_party/agentk ..."
cd "${REPO_ROOT}"
git -c http.sslBackend=gnutls submodule update --init --recursive third_party/agentk

# Step 2: verify pinned commit matches configs/agentk_version.txt.
EXPECTED_SHA="$(grep '^commit_sha=' "${VERSION_FILE}" | cut -d= -f2)"
ACTUAL_SHA="$(cd "${AGENTK_DIR}" && git rev-parse HEAD)"
if [[ "${ACTUAL_SHA}" != "${EXPECTED_SHA}" ]]; then
  log "WARN: submodule at ${ACTUAL_SHA}, manifest expects ${EXPECTED_SHA}"
  log "      Run: cd third_party/agentk && git checkout ${EXPECTED_SHA}"
else
  log "OK  submodule pinned at ${ACTUAL_SHA}"
fi

# Step 3: install AgentK Python dependencies into the active environment.
log "Installing AgentK requirements ..."
pip3 install -r "${AGENTK_DIR}/requirements.txt" -q
pip3 install langchain-openai tiktoken -q

# Step 4: copy .env if missing (never overwrite an existing .env).
if [[ ! -f "${ENV_TARGET}" ]]; then
  cp "${ENV_EXAMPLE}" "${ENV_TARGET}"
  log "Created ${ENV_TARGET} from template"
else
  log "SKIP .env copy (already exists at ${ENV_TARGET})"
fi

# Step 5: pre-flight tool checks.
if command -v nvcc >/dev/null 2>&1; then
  log "OK  nvcc: $(nvcc --version | grep release)"
else
  log "WARN: nvcc not on PATH — AgentK Critic node will fail until CUDA toolkit is installed"
fi

log "AgentK Route A setup complete."
log "Next: start llama.cpp on port 8080, then run smoke-test."
