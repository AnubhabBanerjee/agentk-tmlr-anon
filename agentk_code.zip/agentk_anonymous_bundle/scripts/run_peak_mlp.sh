#!/usr/bin/env bash
#  G3 — train peak MLP for all 9 (agent × backbone) configs with frozen proxies.
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

LOG_DIR="${REPO_ROOT}/artifacts/peak_mlp_training"
mkdir -p "$LOG_DIR"
mkdir -p "${REPO_ROOT}/artifacts/peak_mlp"

AGENTS=(
  "qwen2.5-coder-7b"
  "phi-4-mini"
  "mistral-7b-instruct-v0.3"
)
BACKBONES=(
  "minilm-l12"
  "deberta-v3-base"
  "unixcoder"
)

for agent in "${AGENTS[@]}"; do
  for backbone in "${BACKBONES[@]}"; do
    tag="${agent}__${backbone}"
    log="${LOG_DIR}/${tag}.log"
    echo "[peak-mlp] training ${tag}"
    python3 scripts/04b_train_peak_mlp.py \
      --agent-llm "$agent" \
      --backbone "$backbone" \
      2>&1 | tee "$log"
  done
done

echo "[peak-mlp] done — deliverables under artifacts/peak_mlp/"
