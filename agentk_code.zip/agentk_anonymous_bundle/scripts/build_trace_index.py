#!/usr/bin/env python3
"""
build data/traces/index.parquet and data/trace_report.md from JSONL traces.

One index row per (agent_llm, prompt_id) with ground-truth labels, metadata, and a
relative pointer to the per-run JSONL under data/traces/{agent_llm}/{prompt_id}.jsonl.
"""

# Python line: from __future__ import annotations
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
from __future__ import annotations

# argparse exposes --trace-root and --output overrides for ad-hoc rebuilds.
# Python line: import argparse
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
import argparse
# json parses metadata and summary records from each trace JSONL file.
# Python line: import json
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
import json
# sys prepends scripts/ so trace_batch_common helpers import without install.
# Python line: import sys
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
import sys
# datetime stamps the generated trace_report.md header for auditability.
# Python line: from datetime import datetime, timezone
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
from datetime import datetime, timezone
# Path resolves repo-relative trace paths and output artifact locations.
# Python line: from pathlib import Path
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
from pathlib import Path
# typing annotates nested dict payloads parsed from JSONL trace records.
# Python line: from typing import Any, Dict, List, Optional, Tuple
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
from typing import Any, Dict, List, Optional, Tuple

# pandas materialises the flat index table and writes Parquet via pyarrow.
# Python line: import pandas as pd
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
import pandas as pd

# scripts/ must be on sys.path before importing trace_batch_common inventory helpers.
# Python line: _SCRIPTS_DIR = Path(__file__).resolve().parent
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
_SCRIPTS_DIR = Path(__file__).resolve().parent
# Python line: if str(_SCRIPTS_DIR) not in sys.path:
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
if str(_SCRIPTS_DIR) not in sys.path:
    # Python line: sys.path.insert(0, str(_SCRIPTS_DIR))
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    sys.path.insert(0, str(_SCRIPTS_DIR))

# batch_inventory enumerates the expected 3×600 (agent_llm, prompt_id) grid.
# Python line: from trace_batch_common import (
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
from trace_batch_common import (
    # Python line: batch_inventory,
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    batch_inventory,
    # Python line: load_prompt_rows,
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    load_prompt_rows,
    # Python line: repo_root_from_here,
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    repo_root_from_here,
    # Python line: trace_is_complete,
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    trace_is_complete,
)

# Guide §3.1 lists five AgentK node types whose T_true block is flattened.
# Python line: _NODE_TYPES: Tuple[str, ...] = (
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
_NODE_TYPES: Tuple[str, ...] = (
    # Python line: "planner",
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    "planner",
    # Python line: "analyzer",
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    "analyzer",
    # Python line: "optimizer",
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    "optimizer",
    # Python line: "generator",
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    "generator",
    # Python line: "critic",
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    "critic",
# Python line: )
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
)


# Python line: def parse_trace_jsonl(trace_path: Path) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]]]:
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
def parse_trace_jsonl(trace_path: Path) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]]]:
    """Return (metadata, summary) dicts from a v1 ``.jsonl`` or v2 ``.jsonl.zst`` trace."""
    # Python line: metadata: Optional[Dict[str, Any]] = None
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    metadata: Optional[Dict[str, Any]] = None
    # Python line: summary: Optional[Dict[str, Any]] = None
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    summary: Optional[Dict[str, Any]] = None
    # Python line: _ensure_repo_on_sys_path(trace_path)
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    from trace_batch_common import _ensure_repo_on_sys_path

    _ensure_repo_on_sys_path(trace_path)
    # Python line: from src.tracing.vram_join import iter_trace_jsonl
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    from src.tracing.vram_join import iter_trace_jsonl

    # Python line: for row in iter_trace_jsonl(trace_path):
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    for row in iter_trace_jsonl(trace_path):
        # Python line: record = row.get("record")
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        record = row.get("record")
        # Python line: if record == "metadata":
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        if record == "metadata":
            # Python line: metadata = row
            # trace index builder (scripts/build_trace_index.py).
            # Implements .cursorrules dense-comment policy for Python code.
            metadata = row
        # Python line: elif record == "summary":
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        elif record == "summary":
            # Python line: summary = row
            # trace index builder (scripts/build_trace_index.py).
            # Implements .cursorrules dense-comment policy for Python code.
            summary = row
    # Python line: return metadata, summary
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return metadata, summary


# Python line: def flatten_t_true(t_true: Any) -> Dict[str, Any]:
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
def flatten_t_true(t_true: Any) -> Dict[str, Any]:
    """Expand T_true nested dict into scalar columns for Parquet storage."""
    # Python line: out: Dict[str, Any] = {}
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    out: Dict[str, Any] = {}
    # Python line: block = t_true if isinstance(t_true, dict) else {}
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    block = t_true if isinstance(t_true, dict) else {}
    # Python line: for node in _NODE_TYPES:
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    for node in _NODE_TYPES:
        # Python line: node_row = block.get(node, {})
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
        node_row = block.get(node, {})
        # Python line: if not isinstance(node_row, dict):
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        if not isinstance(node_row, dict):
            # Python line: node_row = {}
            # trace index builder (scripts/build_trace_index.py).
            # Implements .cursorrules dense-comment policy for Python code.
            node_row = {}
        # Python line: out[f"t_{node}_executed"] = int(node_row.get("executed", 0))
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        out[f"t_{node}_executed"] = int(node_row.get("executed", 0))
        # Python line: out[f"t_{node}_avg_tokens_out"] = float(node_row.get("avg_tokens_out", 0.0))
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        out[f"t_{node}_avg_tokens_out"] = float(node_row.get("avg_tokens_out", 0.0))
    # Python line: return out
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return out


# Python line: def build_index_row(
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
def build_index_row(
    *,
    repo_root: Path,
    agent_llm: str,
    prompt_id: str,
    trace_path: Path,
    prompt_meta: Dict[str, Any],
    metadata: Dict[str, Any],
    summary: Dict[str, Any],
    trace_root: Optional[Path] = None,
    is_sweep: bool = False,
) -> Dict[str, Any]:
    """Assemble one flat index dict from metadata, summary, and prompt join."""
    # Python line: rel_trace = trace_path.relative_to(repo_root).as_posix()
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    rel_trace = trace_path.relative_to(repo_root).as_posix()
    # Python line: if trace_root is not None:
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if trace_root is not None:
        # Python line: rel_under_root = trace_path.relative_to(trace_root).as_posix()
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        rel_under_root = trace_path.relative_to(trace_root).as_posix()
    else:
        # Python line: rel_under_root = rel_trace
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        rel_under_root = rel_trace
    # Python line: t_flat = flatten_t_true(summary.get("T_true"))
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    t_flat = flatten_t_true(summary.get("T_true"))
    # Python line: trajectory = summary.get("M_trajectory_true")
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    trajectory = summary.get("M_trajectory_true")
    # Python line: accounting = metadata.get("closed_form_accounting")
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    accounting = metadata.get("closed_form_accounting")
    # Python line: m_peak = float(summary.get("M_peak_true", 0.0))
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    m_peak = float(summary.get("M_peak_true", 0.0))
    # Python line: m_closed = summary.get("M_closed_form_peak_mb")
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    m_closed = summary.get("M_closed_form_peak_mb")
    # Python line: m_closed_f = float(m_closed) if m_closed is not None else None
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    m_closed_f = float(m_closed) if m_closed is not None else None
    # Python line: residual_mb: Optional[float] = None
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    residual_mb: Optional[float] = None
    # Python line: residual_pct: Optional[float] = None
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    residual_pct: Optional[float] = None
    # Python line: if m_closed_f is not None and m_closed_f > 0:
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if m_closed_f is not None and m_closed_f > 0:
        # Python line: residual_mb = round(m_peak - m_closed_f, 3)
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        residual_mb = round(m_peak - m_closed_f, 3)
        # Python line: residual_pct = round(100.0 * residual_mb / m_closed_f, 3)
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        residual_pct = round(100.0 * residual_mb / m_closed_f, 3)
    # Python line: row: Dict[str, Any] = {
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    row: Dict[str, Any] = {
        # Python line: "agent_llm": agent_llm,
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "agent_llm": agent_llm,
        # Python line: "prompt_id": prompt_id,
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "prompt_id": prompt_id,
        # Python line: "trace_jsonl": rel_trace,
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "trace_jsonl": rel_trace,
        "path": rel_under_root,
        "is_sweep": bool(is_sweep),
        # Python line: "prompt_source": prompt_meta.get("source"),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "prompt_source": prompt_meta.get("source"),
        # Python line: "prompt_family": prompt_meta.get("family"),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "prompt_family": prompt_meta.get("family"),
        # Python line: "prompt_complexity": prompt_meta.get("complexity"),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "prompt_complexity": prompt_meta.get("complexity"),
        # Python line: "prompt_precision": prompt_meta.get("precision"),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "prompt_precision": prompt_meta.get("precision"),
        # Python line: "split": prompt_meta.get("split"),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "split": prompt_meta.get("split"),
        # Python line: "quantization": metadata.get("quantization"),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "quantization": metadata.get("quantization"),
        # Python line: "n_ctx": metadata.get("n_ctx"),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "n_ctx": metadata.get("n_ctx"),
        # Python line: "n_batch": metadata.get("n_batch"),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "n_batch": metadata.get("n_batch"),
        # Python line: "cache_type_k": metadata.get("cache_type_k"),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "cache_type_k": metadata.get("cache_type_k"),
        # Python line: "cache_type_v": metadata.get("cache_type_v"),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "cache_type_v": metadata.get("cache_type_v"),
        # Python line: "b_precision": metadata.get("b_precision"),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "b_precision": metadata.get("b_precision"),
        # Python line: "seed": metadata.get("seed"),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "seed": metadata.get("seed"),
        # Python line: "hardware_id": metadata.get("hardware_id"),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "hardware_id": metadata.get("hardware_id"),
        # Python line: "N_true": int(summary.get("N_true", 0)),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "N_true": int(summary.get("N_true", 0)),
        "N_nodes_true": int(summary.get("N_nodes_true", summary.get("N_true", 0))),
        # Python line: "E_true": float(summary.get("E_true", 0.0)),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "E_true": float(summary.get("E_true", 0.0)),
        # Python line: "M_peak_true": m_peak,
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "M_peak_true": m_peak,
        "M_peak_true_mb": m_peak,
        # Python line: "L_peak_tokens": summary.get("L_peak_tokens"),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "L_peak_tokens": summary.get("L_peak_tokens"),
        # Python line: "M_kv_peak_mb": summary.get("M_kv_peak_mb"),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "M_kv_peak_mb": summary.get("M_kv_peak_mb"),
        # Python line: "M_closed_form_peak_mb": m_closed_f,
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "M_closed_form_peak_mb": m_closed_f,
        # Python line: "M_act_observed_mb": summary.get("M_act_observed_mb"),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "M_act_observed_mb": summary.get("M_act_observed_mb"),
        # Python line: "m_peak_residual_mb": residual_mb,
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "m_peak_residual_mb": residual_mb,
        # Python line: "m_peak_residual_pct": residual_pct,
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "m_peak_residual_pct": residual_pct,
        # Python line: "compile_success": bool(summary.get("compile_success", False)),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "compile_success": bool(summary.get("compile_success", False)),
        # Python line: "n_compile_attempts": int(summary.get("n_compile_attempts", 0)),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "n_compile_attempts": int(summary.get("n_compile_attempts", 0)),
        "early_exit_reason": summary.get("early_exit_reason"),
        # Python line: "retry_count": int(summary.get("retry_count", 0)),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "retry_count": int(summary.get("retry_count", 0)),
        # Python line: "timeout": bool(summary.get("timeout", False)),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "timeout": bool(summary.get("timeout", False)),
        # Python line: "oom": bool(summary.get("oom", False)),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "oom": bool(summary.get("oom", False)),
        # Python line: "error": summary.get("error"),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "error": summary.get("error"),
        # Python line: "final_compile_error": summary.get("final_compile_error"),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "final_compile_error": summary.get("final_compile_error"),
        # Python line: "cuda_sidecar": summary.get("cuda_sidecar"),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "cuda_sidecar": summary.get("cuda_sidecar"),
        # Python line: "M_trajectory_true_json": json.dumps(trajectory, ensure_ascii=False)
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "M_trajectory_true_json": json.dumps(trajectory, ensure_ascii=False)
        if trajectory is not None
        else None,
        # Python line: "closed_form_accounting_json": json.dumps(accounting, ensure_ascii=False)
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "closed_form_accounting_json": json.dumps(accounting, ensure_ascii=False)
        if isinstance(accounting, dict)
        else None,
        # Python line: "T_true_json": json.dumps(summary.get("T_true"), ensure_ascii=False),
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "T_true_json": json.dumps(summary.get("T_true"), ensure_ascii=False),
    # Python line: }
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    }
    # Python line: row.update(t_flat)
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    row.update(t_flat)
    # Python line: return row
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return row


# Python line: def mark_m_peak_outliers(df: pd.DataFrame) -> pd.DataFrame:
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
def mark_m_peak_outliers(df: pd.DataFrame) -> pd.DataFrame:
    """
    Flag Tukey IQR outliers on M_peak_true within each agent_llm (§3.4 report).

    Outlier if M_peak_true < Q1 - 1.5*IQR or M_peak_true > Q3 + 1.5*IQR per model.
    """
    # Python line: out = df.copy()
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    out = df.copy()
    # Python line: out["is_m_peak_outlier"] = False
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    out["is_m_peak_outlier"] = False
    # Python line: for agent_llm, group in out.groupby("agent_llm", sort=False):
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    for agent_llm, group in out.groupby("agent_llm", sort=False):
        # Python line: q1 = float(group["M_peak_true"].quantile(0.25))
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        q1 = float(group["M_peak_true"].quantile(0.25))
        # Python line: q3 = float(group["M_peak_true"].quantile(0.75))
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        q3 = float(group["M_peak_true"].quantile(0.75))
        # Python line: iqr = q3 - q1
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        iqr = q3 - q1
        # Python line: low = q1 - 1.5 * iqr
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        low = q1 - 1.5 * iqr
        # Python line: high = q3 + 1.5 * iqr
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        high = q3 + 1.5 * iqr
        # Python line: mask = (group["M_peak_true"] < low) | (group["M_peak_true"] > high)
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        mask = (group["M_peak_true"] < low) | (group["M_peak_true"] > high)
        # Python line: out.loc[group.index[mask], "is_m_peak_outlier"] = True
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        out.loc[group.index[mask], "is_m_peak_outlier"] = True
    # Python line: return out
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return out


# Python line: def render_trace_report(df: pd.DataFrame, *, expect_total: int) -> str:
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
def render_trace_report(
    df: pd.DataFrame,
    *,
    expect_total: int,
    index_relpath: str = "data/traces/index.parquet",
    title: str = "# Trace batch report",
) -> str:
    """Render trace_report markdown summary for / v2."""
    # Python line: now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    # Python line: lines: List[str] = [
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    lines: List[str] = [
        # Python line: "# Trace batch report",
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        title,
        # Python line: "",
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "",
        # Python line: f"- Generated: **{now}**",
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        f"- Generated: **{now}**",
        # Python line: f"- Indexed runs: **{len(df)}** (expected {expect_total})",
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        f"- Indexed runs: **{len(df)}** (expected {expect_total})",
        # Python line: f"- Index: `data/traces/index.parquet`",
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        f"- Index: `{index_relpath}`",
        # Python line: "",
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "",
    ]

    # Python line: lines.extend(["## N_true histogram (global)", "", "| N_true | count |", "|-------:|------:|"])
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    lines.extend(["## N_true histogram (global)", "", "| N_true | count |", "|-------:|------:|"])
    # Python line: n_counts = df["N_true"].value_counts().sort_index()
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    n_counts = df["N_true"].value_counts().sort_index()
    # Python line: for n_val, count in n_counts.items():
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    for n_val, count in n_counts.items():
        # Python line: lines.append(f"| {int(n_val)} | {int(count)} |")
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        lines.append(f"| {int(n_val)} | {int(count)} |")
    # Python line: lines.append("")
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    lines.append("")

    # Python line: lines.extend(
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    lines.extend(
        [
            "## Retry-count distribution (global)",
            "",
            "| retry_count | count |",
            "|------------:|------:|",
        ]
    )
    # Python line: retry_counts = df["retry_count"].value_counts().sort_index()
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    retry_counts = df["retry_count"].value_counts().sort_index()
    # Python line: for retry, count in retry_counts.items():
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    for retry, count in retry_counts.items():
        # Python line: lines.append(f"| {int(retry)} | {int(count)} |")
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        lines.append(f"| {int(retry)} | {int(count)} |")
    # Python line: lines.append("")
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    lines.append("")

    # Python line: lines.extend(
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    lines.extend(
        [
            "## M_peak_true distribution per agent LLM (MiB)",
            "",
            "| agent_llm | min | p25 | median | p75 | max | mean | std |",
            "|-----------|----:|----:|-------:|----:|----:|-----:|----:|",
        ]
    )
    # Python line: for agent_llm, group in df.groupby("agent_llm", sort=False):
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    for agent_llm, group in df.groupby("agent_llm", sort=False):
        # Python line: s = group["M_peak_true"]
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        s = group["M_peak_true"]
        # Python line: lines.append(
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        lines.append(
            f"| {agent_llm} "
            f"| {s.min():.1f} | {s.quantile(0.25):.1f} | {s.median():.1f} "
            f"| {s.quantile(0.75):.1f} | {s.max():.1f} | {s.mean():.1f} | {s.std():.1f} |"
        )
    # Python line: lines.append("")
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    lines.append("")

    # Python line: lines.extend(
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    lines.extend(
        [
            "## compile_success rate per agent LLM",
            "",
            "| agent_llm | success | total | rate |",
            "|-----------|--------:|------:|-----:|",
        ]
    )
    # Python line: for agent_llm, group in df.groupby("agent_llm", sort=False):
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    for agent_llm, group in df.groupby("agent_llm", sort=False):
        # Python line: success = int(group["compile_success"].sum())
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        success = int(group["compile_success"].sum())
        # Python line: total = len(group)
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        total = len(group)
        # Python line: rate = success / total if total else 0.0
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        rate = success / total if total else 0.0
        # Python line: lines.append(f"| {agent_llm} | {success} | {total} | {rate:.3f} |")
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        lines.append(f"| {agent_llm} | {success} | {total} | {rate:.3f} |")
    # Python line: lines.append("")
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    lines.append("")

    # Python line: global_outliers = int(df["is_m_peak_outlier"].sum())
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    global_outliers = int(df["is_m_peak_outlier"].sum())
    # Python line: global_rate = global_outliers / len(df) if len(df) else 0.0
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    global_rate = global_outliers / len(df) if len(df) else 0.0
    # Python line: lines.extend(
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    lines.extend(
        [
            "## Outlier rate",
            "",
            "Tukey IQR rule on `M_peak_true` within each agent LLM "
            "(value < Q1 − 1.5×IQR or > Q3 + 1.5×IQR).",
            "",
            f"- Global: **{global_outliers}/{len(df)}** ({100.0 * global_rate:.2f}%)",
            "",
            "| agent_llm | outliers | total | rate |",
            "|-----------|--------:|------:|-----:|",
        ]
    )
    # Python line: for agent_llm, group in df.groupby("agent_llm", sort=False):
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    for agent_llm, group in df.groupby("agent_llm", sort=False):
        # Python line: outliers = int(group["is_m_peak_outlier"].sum())
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        outliers = int(group["is_m_peak_outlier"].sum())
        # Python line: total = len(group)
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        total = len(group)
        # Python line: rate = outliers / total if total else 0.0
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        rate = outliers / total if total else 0.0
        # Python line: lines.append(f"| {agent_llm} | {outliers} | {total} | {100.0 * rate:.2f}% |")
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        lines.append(f"| {agent_llm} | {outliers} | {total} | {100.0 * rate:.2f}% |")
    # Python line: lines.append("")
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    lines.append("")

    # Python line: timeout_n = int(df["timeout"].sum())
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    timeout_n = int(df["timeout"].sum())
    # Python line: oom_n = int(df["oom"].sum())
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    oom_n = int(df["oom"].sum())
    # Python line: error_n = int(df["error"].notna().sum())
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    error_n = int(df["error"].notna().sum())
    # Python line: lines.extend(
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    lines.extend(
        [
            "## Failure flags (supplementary)",
            "",
            f"- `timeout=True`: **{timeout_n}**",
            f"- `oom=True`: **{oom_n}**",
            f"- non-null `error`: **{error_n}**",
            "",
        ]
    )
    # Python line: return "\n".join(lines)
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return "\n".join(lines)


# Python line: def build_trace_index(
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
def build_trace_index(
    *,
    repo_root: Path,
    trace_root: Path,
    index_path: Path,
    report_path: Path,
    require_complete: bool = True,
) -> pd.DataFrame:
    """Scan traces, write Parquet index and markdown report; return the DataFrame."""
    # Python line: model_ids, prompt_ids, expect_total = batch_inventory(repo_root)
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    model_ids, prompt_ids, expect_total = batch_inventory(repo_root)
    # Python line: prompt_rows = load_prompt_rows(repo_root / "data" / "prompts" / "all.jsonl")
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    prompt_rows = load_prompt_rows(repo_root / "data" / "prompts" / "all.jsonl")
    # Python line: prompt_by_id = {row["id"]: row for row in prompt_rows}
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    prompt_by_id = {row["id"]: row for row in prompt_rows}

    # Python line: rows: List[Dict[str, Any]] = []
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    rows: List[Dict[str, Any]] = []
    # Python line: missing: List[str] = []
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    missing: List[str] = []
    # Python line: incomplete: List[str] = []
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    incomplete: List[str] = []

    # Python line: for model_id in model_ids:
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    for model_id in model_ids:
        # Python line: for prompt_id in prompt_ids:
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        for prompt_id in prompt_ids:
            # Python line: trace_path = trace_root / model_id / f"{prompt_id}.jsonl"
            # trace index builder (scripts/build_trace_index.py).
            # Implements .cursorrules dense-comment policy for Python code.
            trace_path = trace_root / model_id / f"{prompt_id}.jsonl"
            # Python line: key = f"{model_id}/{prompt_id}"
            # trace index builder (scripts/build_trace_index.py).
            # Implements .cursorrules dense-comment policy for Python code.
            key = f"{model_id}/{prompt_id}"
            # Python line: if not trace_path.is_file():
            # trace index builder (scripts/build_trace_index.py).
            # Implements .cursorrules dense-comment policy for Python code.
            if not trace_path.is_file():
                # Python line: missing.append(key)
                # trace index builder (scripts/build_trace_index.py).
                # Implements .cursorrules dense-comment policy for Python code.
                missing.append(key)
                # Python line: continue
                # trace index builder (scripts/build_trace_index.py).
                # Implements .cursorrules dense-comment policy for Python code.
                continue
            # Python line: if require_complete and not trace_is_complete(trace_path):
            # trace index builder (scripts/build_trace_index.py).
            # Implements .cursorrules dense-comment policy for Python code.
            if require_complete and not trace_is_complete(trace_path):
                # Python line: incomplete.append(key)
                # trace index builder (scripts/build_trace_index.py).
                # Implements .cursorrules dense-comment policy for Python code.
                incomplete.append(key)
                # Python line: continue
                # trace index builder (scripts/build_trace_index.py).
                # Implements .cursorrules dense-comment policy for Python code.
                continue
            # Python line: metadata, summary = parse_trace_jsonl(trace_path)
            # trace index builder (scripts/build_trace_index.py).
            # Implements .cursorrules dense-comment policy for Python code.
            metadata, summary = parse_trace_jsonl(trace_path)
            # Python line: if metadata is None or summary is None:
            # trace index builder (scripts/build_trace_index.py).
            # Implements .cursorrules dense-comment policy for Python code.
            if metadata is None or summary is None:
                # Python line: incomplete.append(key)
                # trace index builder (scripts/build_trace_index.py).
                # Implements .cursorrules dense-comment policy for Python code.
                incomplete.append(key)
                # Python line: continue
                # trace index builder (scripts/build_trace_index.py).
                # Implements .cursorrules dense-comment policy for Python code.
                continue
            # Python line: prompt_meta = prompt_by_id.get(prompt_id, {})
            # trace index builder (scripts/build_trace_index.py).
            # Implements .cursorrules dense-comment policy for Python code.
            prompt_meta = prompt_by_id.get(prompt_id, {})
            # Python line: rows.append(
            # trace index builder (scripts/build_trace_index.py).
            # Implements .cursorrules dense-comment policy for Python code.
            rows.append(
                build_index_row(
                    repo_root=repo_root,
                    agent_llm=model_id,
                    prompt_id=prompt_id,
                    trace_path=trace_path,
                    prompt_meta=prompt_meta,
                    metadata=metadata,
                    summary=summary,
                )
            )

    # Python line: if missing:
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if missing:
        # Python line: raise FileNotFoundError(
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        raise FileNotFoundError(
            f"Missing {len(missing)} trace file(s), e.g. {missing[:5]}"
        )
    # Python line: if incomplete:
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if incomplete:
        # Python line: raise ValueError(
        # trace index builder (scripts/build_trace_index.py).
        # Implements .cursorrules dense-comment policy for Python code.
        raise ValueError(
            f"Incomplete {len(incomplete)} trace(s) (no summary), e.g. {incomplete[:5]}"
        )

    # Python line: df = pd.DataFrame(rows)
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    df = pd.DataFrame(rows)
    # Python line: df = mark_m_peak_outliers(df)
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    df = mark_m_peak_outliers(df)
    # Python line: df = df.sort_values(["agent_llm", "prompt_id"]).reset_index(drop=True)
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    df = df.sort_values(["agent_llm", "prompt_id"]).reset_index(drop=True)

    # Python line: index_path.parent.mkdir(parents=True, exist_ok=True)
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    index_path.parent.mkdir(parents=True, exist_ok=True)
    # Python line: df.to_parquet(index_path, index=False)
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    df.to_parquet(index_path, index=False)

    # Python line: report_path.parent.mkdir(parents=True, exist_ok=True)
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    report_path.parent.mkdir(parents=True, exist_ok=True)
    # Python line: report_path.write_text(
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    report_path.write_text(
        render_trace_report(df, expect_total=expect_total),
        encoding="utf-8",
    )

    # Python line: return df
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return df


def render_v2_report_appendix(df: pd.DataFrame) -> str:
    """Extra v2 sections: N_true degeneracy, early_exit_reason, per-slice CV."""
    lines: List[str] = []
    n_zero = int((df["N_true"] == 0).sum())
    n_total = len(df)
    zero_rate = 100.0 * n_zero / n_total if n_total else 0.0
    lines.extend(
        [
            "## N_true == 0 (global)",
            "",
            f"- **{n_zero}/{n_total}** ({zero_rate:.2f}%)",
            "",
        ]
    )
    if "early_exit_reason" in df.columns:
        lines.extend(
            [
                "## early_exit_reason distribution (global)",
                "",
                "| reason | count |",
                "|--------|------:|",
            ]
        )
        reason_counts = df["early_exit_reason"].fillna("null").value_counts()
        for reason, count in reason_counts.items():
            lines.append(f"| {reason} | {int(count)} |")
        lines.append("")

    lines.extend(
        [
            "## Per-slice CV of M_peak_true (agent × n_ctx × cache_type)",
            "",
            "CV% = 100 × std / mean within each slice.",
            "",
            "| agent_llm | n_ctx | cache_k | cache_v | n | mean (MiB) | std | CV% |",
            "|-----------|------:|---------|---------|--:|-----------:|----:|----:|",
        ]
    )
    group_cols = ["agent_llm", "n_ctx", "cache_type_k", "cache_type_v"]
    for keys, group in df.groupby(group_cols, sort=False):
        agent_llm, n_ctx, cache_k, cache_v = keys
        s = group["M_peak_true"]
        mean_v = float(s.mean())
        std_v = float(s.std())
        cv_pct = 100.0 * std_v / mean_v if mean_v > 0 else float("nan")
        lines.append(
            f"| {agent_llm} | {int(n_ctx)} | {cache_k} | {cache_v} | {len(group)} "
            f"| {mean_v:.1f} | {std_v:.1f} | {cv_pct:.2f} |"
        )
    lines.append("")
    return "\n".join(lines)


def render_ctx_kv_sweep_report(df: pd.DataFrame) -> str:
    """Per-agent joint (n_ctx × cache_type) → mean M_peak grid (sweep rows only)."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    sweep_df = df[df.get("is_sweep", False) == True]  # noqa: E712
    lines: List[str] = [
        "# ctx × KV-cache sweep report ",
        "",
        f"- Generated: **{now}**",
        f"- Sweep rows indexed: **{len(sweep_df)}**",
        "",
    ]
    for agent_llm, agent_df in sweep_df.groupby("agent_llm", sort=False):
        lines.extend([f"## {agent_llm}", ""])
        pivot = (
            agent_df.groupby(["n_ctx", "cache_type_k", "cache_type_v"])["M_peak_true"]
            .agg(["count", "mean", "std"])
            .reset_index()
            .sort_values(["n_ctx", "cache_type_k", "cache_type_v"])
        )
        lines.append(
            "| n_ctx | cache_k | cache_v | n | mean M_peak (MiB) | std |"
        )
        lines.append("|------:|---------|---------|--:|------------------:|----:|")
        for _, row in pivot.iterrows():
            lines.append(
                f"| {int(row['n_ctx'])} | {row['cache_type_k']} | {row['cache_type_v']} "
                f"| {int(row['count'])} | {row['mean']:.1f} | {row['std']:.1f} |"
            )
        lines.append("")
    return "\n".join(lines)


def build_v2_trace_index(
    *,
    repo_root: Path,
    tracing_config: Path,
    trace_root: Path,
    index_path: Path,
    report_path: Path,
    sweep_report_path: Path,
    require_complete: bool = True,
) -> pd.DataFrame:
    """Build v2 index (1920 runs) from ``data/traces_v2`` base + sweep traces."""
    import yaml

    from src.tracing.sweep_plan import (
        enumerate_v2_trace_runs,
        load_v2_sweep_config,
        sweep_subset_prompt_ids,
        trace_output_path_v2,
    )

    tracing_cfg = yaml.safe_load(tracing_config.read_text(encoding="utf-8"))
    agent_cfg = yaml.safe_load(
        (repo_root / "configs" / "agent_llms_v2.yaml").read_text(encoding="utf-8")
    )
    model_ids = list(agent_cfg["models"].keys())
    prompt_rows = load_prompt_rows(repo_root / "data" / "prompts_v2" / "all.jsonl")
    prompt_by_id = {row["id"]: row for row in prompt_rows}
    sweep_cfg = load_v2_sweep_config(tracing_cfg)
    seed = int(tracing_cfg["split"]["seed"])
    subset_ids = sweep_subset_prompt_ids(
        prompt_rows,
        total=sweep_cfg.sweep_subset_prompts,
        seed=seed,
    )
    runs = enumerate_v2_trace_runs(
        model_ids=model_ids,
        prompt_rows=prompt_rows,
        sweep_cfg=sweep_cfg,
        sweep_prompt_ids=subset_ids,
    )
    expect_total = len(runs)

    rows: List[Dict[str, Any]] = []
    missing: List[str] = []
    incomplete: List[str] = []

    for spec in runs:
        trace_path = trace_output_path_v2(
            trace_root,
            model_id=spec.model_id,
            prompt_id=spec.prompt_id,
            n_ctx=spec.n_ctx,
            cache_type_k=spec.cache_type_k,
            cache_type_v=spec.cache_type_v,
            sweep=spec.sweep,
        )
        key = trace_path.relative_to(trace_root).as_posix()
        if not trace_path.is_file():
            missing.append(key)
            continue
        if require_complete and not trace_is_complete(trace_path):
            incomplete.append(key)
            continue
        metadata, summary = parse_trace_jsonl(trace_path)
        if metadata is None or summary is None:
            incomplete.append(key)
            continue
        prompt_meta = prompt_by_id.get(spec.prompt_id, {})
        rows.append(
            build_index_row(
                repo_root=repo_root,
                agent_llm=spec.model_id,
                prompt_id=spec.prompt_id,
                trace_path=trace_path,
                prompt_meta=prompt_meta,
                metadata=metadata,
                summary=summary,
                trace_root=trace_root,
                is_sweep=spec.sweep,
            )
        )

    if missing:
        raise FileNotFoundError(
            f"Missing {len(missing)} v2 trace file(s), e.g. {missing[:5]}"
        )
    if incomplete:
        raise ValueError(
            f"Incomplete {len(incomplete)} v2 trace(s) (no summary), e.g. {incomplete[:5]}"
        )

    df = pd.DataFrame(rows)
    df = mark_m_peak_outliers(df)
    df = df.sort_values(
        ["agent_llm", "is_sweep", "prompt_id", "n_ctx", "cache_type_k", "cache_type_v"]
    ).reset_index(drop=True)

    index_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(index_path, index=False)

    report_body = render_trace_report(
        df,
        expect_total=expect_total,
        index_relpath="data/traces_v2/index.parquet",
        title="# Trace batch trace report (/ )",
    )
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        report_body + "\n" + render_v2_report_appendix(df),
        encoding="utf-8",
    )
    sweep_report_path.write_text(render_ctx_kv_sweep_report(df), encoding="utf-8")
    return df


# Python line: def main() -> None:
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
def main() -> None:
    """CLI entry: python3 scripts/build_trace_index.py [--config configs/tracing_v2.yaml]"""
    # Python line: parser = argparse.ArgumentParser(description="Build trace index + report")
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    parser = argparse.ArgumentParser(description="Build trace index + report")
    parser.add_argument(
        "--config",
        type=Path,
        default=None,
        help="Tracing config YAML (e.g. configs/tracing_v2.yaml for v2 index)",
    )
    # Python line: parser.add_argument(
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    parser.add_argument(
        "--trace-root",
        type=Path,
        default=None,
        help="Override trace root (default: data/traces)",
    )
    # Python line: parser.add_argument(
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    parser.add_argument(
        "--index-out",
        type=Path,
        default=None,
        help="Override index parquet path (default: data/traces/index.parquet)",
    )
    # Python line: parser.add_argument(
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    parser.add_argument(
        "--report-out",
        type=Path,
        default=None,
        help="Override report path (default: data/trace_report.md)",
    )
    # Python line: args = parser.parse_args()
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    args = parser.parse_args()

    # Python line: repo = repo_root_from_here()
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    repo = repo_root_from_here()

    if str(repo) not in sys.path:
        sys.path.insert(0, str(repo))

    if args.config is not None:
        tracing_config = args.config if args.config.is_absolute() else repo / args.config
        trace_root = args.trace_root or (repo / "data" / "traces_v2")
        index_path = args.index_out or (repo / "data" / "traces_v2" / "index.parquet")
        report_path = args.report_out or (repo / "data" / "trace_report_v2.md")
        sweep_report_path = trace_root / "ctx_kv_sweep_report.md"
        df = build_v2_trace_index(
            repo_root=repo,
            tracing_config=tracing_config,
            trace_root=trace_root,
            index_path=index_path,
            report_path=report_path,
            sweep_report_path=sweep_report_path,
        )
        print(f"Wrote {len(df)} rows -> {index_path}")
        print(f"Wrote report -> {report_path}")
        print(f"Wrote sweep report -> {sweep_report_path}")
        return

    # Python line: trace_root = args.trace_root or (repo / "data" / "traces")
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    trace_root = args.trace_root or (repo / "data" / "traces")
    # Python line: index_path = args.index_out or (repo / "data" / "traces" / "index.parquet")
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    index_path = args.index_out or (repo / "data" / "traces" / "index.parquet")
    # Python line: report_path = args.report_out or (repo / "data" / "trace_report.md")
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    report_path = args.report_out or (repo / "data" / "trace_report.md")

    # Python line: df = build_trace_index(
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    df = build_trace_index(
        repo_root=repo,
        trace_root=trace_root,
        index_path=index_path,
        report_path=report_path,
    )
    # Python line: print(f"Wrote {len(df)} rows -> {index_path}")
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    print(f"Wrote {len(df)} rows -> {index_path}")
    # Python line: print(f"Wrote report -> {report_path}")
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    print(f"Wrote report -> {report_path}")


# Python line: if __name__ == "__main__":
# trace index builder (scripts/build_trace_index.py).
# Implements .cursorrules dense-comment policy for Python code.
if __name__ == "__main__":
    # Python line: main()
    # trace index builder (scripts/build_trace_index.py).
    # Implements .cursorrules dense-comment policy for Python code.
    main()
