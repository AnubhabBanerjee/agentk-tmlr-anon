#!/usr/bin/env bash
# Phase 1.3 — download Phi-4-mini and Mistral-7B-Instruct GGUF weights into HF_CACHE_ROOT.
# Step 1: download from pinned bartowski HuggingFace repos.
# Step 2: verify SHA256 against configs/model_manifest.yaml.
# Step 3: cross-check upstream licenses (recorded in the same manifest).

set -euo pipefail

# Root directory where quantized GGUF artifacts are stored on the target machine.
HF_CACHE_ROOT="${HF_CACHE_ROOT:-/workspace/hf-cache}"

# Path to this repository (parent of scripts/).
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# Manifest with pinned repos, remote filenames, expected SHA256, and licenses.
MANIFEST="${REPO_ROOT}/configs/model_manifest.yaml"

# Ensure the cache directory exists before any download attempt.
mkdir -p "${HF_CACHE_ROOT}"

# ---------------------------------------------------------------------------
# Model definitions (remote HF name -> local canonical path in HF_CACHE_ROOT)
# ---------------------------------------------------------------------------

# Phi-4-mini: MIT license upstream (microsoft/Phi-4-mini-instruct).
PHI_REPO="bartowski/microsoft_Phi-4-mini-instruct-GGUF"
PHI_REMOTE="microsoft_Phi-4-mini-instruct-Q4_K_M.gguf"
PHI_LOCAL="${HF_CACHE_ROOT}/Phi-4-mini-instruct-Q4_K_M.gguf"
PHI_SHA256="01999f17c39cc3074afae5e9c539bc82d45f2dd7faa3917c66cbef76fce8c0c2"
PHI_SIZE=2491874688

# Mistral-7B-Instruct-v0.3: Apache-2.0 upstream (mistralai/Mistral-7B-Instruct-v0.3).
MISTRAL_REPO="bartowski/Mistral-7B-Instruct-v0.3-GGUF"
MISTRAL_REMOTE="Mistral-7B-Instruct-v0.3-Q4_K_M.gguf"
MISTRAL_LOCAL="${HF_CACHE_ROOT}/Mistral-7B-Instruct-v0.3-Q4_K_M.gguf"
MISTRAL_SHA256="1270d22c0fbb3d092fb725d4d96c457b7b687a5f5a715abe1e818da303e562b6"
MISTRAL_SIZE=4372812000

# Qwen2.5-Coder-7B: already present locally; SHA256 recorded for completeness.
QWEN_LOCAL="${HF_CACHE_ROOT}/qwen2.5-coder-7b-instruct-q4_k_m.gguf"

# Qwen2.5-Coder-14B: Apache-2.0 upstream (Qwen/Qwen2.5-Coder-14B-Instruct).
QWEN14_REPO="bartowski/Qwen2.5-Coder-14B-Instruct-GGUF"
QWEN14_REMOTE="Qwen2.5-Coder-14B-Instruct-Q4_K_M.gguf"
QWEN14_LOCAL="${HF_CACHE_ROOT}/Qwen2.5-Coder-14B-Instruct-Q4_K_M.gguf"
QWEN14_SHA256="2946d28c9e1bb2bcae6d42e8678863a31775df6f740315c7d7e6d6b6411f5937"
QWEN14_SIZE=8988111072

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

log() {
  # Print a timestamped status line to stdout for reproducible logs.
  echo "[01_download_models] $*"
}

sha256_file() {
  # Compute SHA256 of a file; works on Linux without extra packages.
  sha256sum "$1" | awk '{print $1}'
}

verify_file() {
  # Args: local_path expected_sha256 expected_size_bytes label
  local path="$1"
  local expected_sha="$2"
  local expected_size="$3"
  local label="$4"

  if [[ ! -f "${path}" ]]; then
    log "ERROR: missing ${label} at ${path}"
    return 1
  fi

  local actual_size
  actual_size="$(stat -c%s "${path}")"
  if [[ "${actual_size}" -ne "${expected_size}" ]]; then
    log "ERROR: ${label} size mismatch (got ${actual_size}, want ${expected_size})"
    return 1
  fi

  local actual_sha
  actual_sha="$(sha256_file "${path}")"
  if [[ "${actual_sha}" != "${expected_sha}" ]]; then
    log "ERROR: ${label} SHA256 mismatch"
    log "  expected: ${expected_sha}"
    log "  actual:   ${actual_sha}"
    return 1
  fi

  log "OK  ${label}: SHA256 and size verified (${actual_size} bytes)"
}

download_one() {
  # Args: hf_repo remote_filename local_path
  local repo="$1"
  local remote="$2"
  local local_path="$3"

  if [[ -f "${local_path}" ]]; then
    log "SKIP download (already exists): ${local_path}"
    return 0
  fi

  log "Downloading ${remote} from ${repo} ..."
  # Download only the single GGUF shard into HF_CACHE_ROOT (not a nested subdir).
  huggingface-cli download "${repo}" \
    --include "${remote}" \
    --local-dir "${HF_CACHE_ROOT}" \
    --local-dir-use-symlinks False

  # bartowski repos use the remote filename on disk; rename if our canonical name differs.
  local downloaded="${HF_CACHE_ROOT}/${remote}"
  if [[ "${downloaded}" != "${local_path}" && -f "${downloaded}" ]]; then
    mv -f "${downloaded}" "${local_path}"
    log "Renamed ${remote} -> $(basename "${local_path}")"
  fi
}

# ---------------------------------------------------------------------------
# Step 1 — Download
# ---------------------------------------------------------------------------

log "Step 1/3: downloading GGUF artifacts into ${HF_CACHE_ROOT}"

download_one "${PHI_REPO}" "${PHI_REMOTE}" "${PHI_LOCAL}"
download_one "${MISTRAL_REPO}" "${MISTRAL_REMOTE}" "${MISTRAL_LOCAL}"
download_one "${QWEN14_REPO}" "${QWEN14_REMOTE}" "${QWEN14_LOCAL}"

# ---------------------------------------------------------------------------
# Step 2 — Verify SHA256 (+ size)
# ---------------------------------------------------------------------------

log "Step 2/3: verifying SHA256 checksums"

verify_file "${PHI_LOCAL}" "${PHI_SHA256}" "${PHI_SIZE}" "Phi-4-mini-instruct-Q4_K_M"
verify_file "${MISTRAL_LOCAL}" "${MISTRAL_SHA256}" "${MISTRAL_SIZE}" "Mistral-7B-Instruct-v0.3-Q4_K_M"
verify_file "${QWEN14_LOCAL}" "${QWEN14_SHA256}" "${QWEN14_SIZE}" "Qwen2.5-Coder-14B-Instruct-Q4_K_M"

if [[ -f "${QWEN_LOCAL}" ]]; then
  local_qwen_size="$(stat -c%s "${QWEN_LOCAL}")"
  log "OK  Qwen2.5-Coder-7B (pre-existing): ${local_qwen_size} bytes (no pinned SHA256 in manifest yet)"
else
  log "WARN: Qwen GGUF not found at ${QWEN_LOCAL}"
fi

# ---------------------------------------------------------------------------
# Step 3 — License cross-check (upstream, not bartowski quant license)
# ---------------------------------------------------------------------------

log "Step 3/3: license cross-check (see configs/model_manifest.yaml)"

export REPO_ROOT
python3 << 'PYEOF'
from pathlib import Path
import os
import sys

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML required for license manifest check")
    sys.exit(1)

manifest_path = Path(os.environ["REPO_ROOT"]) / "configs" / "model_manifest.yaml"
data = yaml.safe_load(manifest_path.read_text())

required_licenses = {
    "qwen2.5-coder-7b": "Apache-2.0",
    "qwen2.5-coder-14b": "Apache-2.0",
    "phi-4-mini": "MIT",
    "mistral-7b-instruct-v0.3": "Apache-2.0",
}

for model_id, expected in required_licenses.items():
    entry = data["models"][model_id]
    actual = entry["upstream_license"]
    if actual != expected:
        print(f"LICENSE MISMATCH {model_id}: expected {expected}, got {actual}")
        sys.exit(1)
    print(f"OK  {model_id}: upstream_license={actual} (upstream: {entry['upstream_repo']})")

print("All upstream licenses match project constraints.")
PYEOF

log "Phase 1.3 complete."
