#!/usr/bin/env python3
"""
compute evaluation metrics into the canonical ``paper/results/`` tree.

All paper-facing numbers live under ``paper/results/`` (not scattered in ``artifacts/``).
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd
import torch

_REPO = Path(__file__).resolve().parents[1]
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from src.eval.bootstrap import build_bootstrap_ci_table
from src.eval.b4_sweep import build_full_z_alpha_sweep_table, build_primary_test_with_b4_refresh
from src.eval.context import eval_context
from src.eval.loaders import list_available_predictions
from src.eval.manifest import write_manifest
from src.eval.paths import BOOTSTRAP_RESAMPLES
from src.eval.significance import build_significance_tests, write_significance_tests_json
from src.eval.subcomponents import aggregate_subcomponent_mae, build_subcomponents_test_table
from src.eval.summary import write_summary
from src.eval.tables import write_primary_results_ci_table, write_primary_results_table
from src.eval.trajectory import aggregate_trajectory_mape, build_trajectory_boundary_table
from src.eval.vram_strata import (
    augment_primary_with_stratified_mape,
    build_vram_strata_mape_table,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Evaluate VRAM forecasts into paper/results/ (canonical outputs)."
    )
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=_REPO,
        help="Repository root directory.",
    )
    parser.add_argument(
        "--split",
        type=str,
        default="test",
        choices=["train", "val", "test"],
        help="Dataset split for metric computation (default: test).",
    )
    parser.add_argument(
        "--device",
        type=str,
        default="cuda" if torch.cuda.is_available() else "cpu",
        help="Torch device for proxy inference (B4 sweep, sub-components, trajectory).",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    device = torch.device(args.device)
    ctx = eval_context(args.repo_root)
    layout = ctx.results
    layout.ensure_dirs()

    pred_root = ctx.tracing.predictions_root
    available = list_available_predictions(args.repo_root)
    if not available:
        raise SystemExit(
            f"No prediction parquets found under {pred_root}. Run first."
        )

    primary = build_primary_test_with_b4_refresh(args.repo_root, device=device, split=args.split)
    vram_strata = build_vram_strata_mape_table(args.repo_root, device=device, split=args.split)
    primary = augment_primary_with_stratified_mape(primary, vram_strata)
    primary.to_parquet(layout.primary_test, index=False)
    vram_strata.to_parquet(layout.vram_strata_mape, index=False)

    z_sweep = build_full_z_alpha_sweep_table(args.repo_root, device=device, split=args.split)
    z_sweep.to_parquet(layout.z_alpha_sweep, index=False)

    if ctx.has_proxies:
        sub = build_subcomponents_test_table(args.repo_root, device=device, split=args.split)
        traj_bounds = build_trajectory_boundary_table(args.repo_root, device=device, split=args.split)
    else:
        print("SKIP: no proxy checkpoints — writing empty subcomponents/trajectory tables")
        sub = pd.DataFrame(
            columns=[
                "agent_llm",
                "prompt_id",
                "split",
                "proxy_backbone",
                "n_hat",
                "y_n",
                "abs_err_n",
                "e_hat",
                "y_e",
                "abs_err_e",
                "t_hat_agg",
                "y_t_agg",
                "abs_err_t_agg",
            ]
        )
        traj_bounds = pd.DataFrame(
            columns=[
                "agent_llm",
                "prompt_id",
                "split",
                "proxy_backbone",
                "step_index",
                "m_true_mb",
                "m_pred_mb",
                "abs_err_mb",
            ]
        )
    sub.to_parquet(layout.subcomponents_test, index=False)
    sub_mae = aggregate_subcomponent_mae(sub)
    sub_mae_path = layout.subcomponents_mae
    sub_mae.to_parquet(sub_mae_path, index=False)

    traj_bounds.to_parquet(layout.trajectory_test, index=False)
    traj_mae = aggregate_trajectory_mape(traj_bounds)
    traj_mae_path = layout.trajectory_mape
    traj_mae.to_parquet(traj_mae_path, index=False)

    bootstrap_ci = build_bootstrap_ci_table(
        args.repo_root,
        device=device,
        split=args.split,
        n_resamples=BOOTSTRAP_RESAMPLES,
    )
    bootstrap_ci.to_parquet(layout.bootstrap_ci, index=False)

    significance = build_significance_tests(
        args.repo_root, device=device, split=args.split, include_b4_vs_b2=True
    )
    write_significance_tests_json(layout.significance_tests, significance)

    write_primary_results_table(layout, primary)
    write_primary_results_ci_table(layout, primary, bootstrap_ci)
    write_summary(
        layout,
        primary,
        sub_mae=sub_mae,
        traj_mae=traj_mae,
        z_sweep=z_sweep,
        bootstrap_ci=bootstrap_ci,
        significance=significance,
        vram_strata=vram_strata,
    )

    manifest_path = write_manifest(
        layout,
        repo_root=args.repo_root,
        extra={
            "split": args.split,
            "device": str(device),
            "prediction_pairs": [f"{a}/{m}" for a, m in available],
            "tracing_config": str(ctx.tracing.config_path) if ctx.tracing.config_path else "v1",
            "skip_b4": ctx.skip_b4,
            "has_proxies": ctx.has_proxies,
            "primary_rows": int(len(primary)),
            "z_alpha_sweep_rows": int(len(z_sweep)),
            "subcomponents_rows": int(len(sub)),
            "trajectory_boundary_rows": int(len(traj_bounds)),
            "b4_backbones": sub_mae.set_index("agent_llm")["proxy_backbone"].to_dict()
            if not sub_mae.empty and "proxy_backbone" in sub_mae.columns
            else {},
            "bootstrap_ci_rows": int(len(bootstrap_ci)),
            "vram_strata_rows": int(len(vram_strata)),
            "significance_tests": list(
                k for k in significance.keys() if k.startswith("paired_sign_test_")
            ),
        },
    )

    print(f"Wrote {layout.primary_test} ({len(primary)} rows)")
    print(f"Wrote {layout.vram_strata_mape} ({len(vram_strata)} rows)")
    print(f"Wrote {layout.z_alpha_sweep} ({len(z_sweep)} rows)")
    print(f"Wrote {layout.subcomponents_test} ({len(sub)} rows)")
    print(f"Wrote {sub_mae_path}")
    print(f"Wrote {layout.trajectory_test} ({len(traj_bounds)} boundary rows)")
    print(f"Wrote {traj_mae_path}")
    print(f"Wrote {layout.bootstrap_ci} ({len(bootstrap_ci)} rows)")
    print(f"Wrote {layout.significance_tests}")
    print(f"Wrote {layout.table_primary_results}")
    print(f"Wrote {layout.table_primary_results_ci}")
    print(f"Wrote {layout.summary_md}")
    print(f"Wrote {manifest_path}")


if __name__ == "__main__":
    main()
