#!/usr/bin/env bash
# one-shot launcher for KernelBench correctness harness with watcher.
#
# released: CONFIG=configs/tracing_v2.yaml make run-kbench-correctness
#
# Usage (from repo root):
#   nohup env CONFIG=configs/tracing_v2.yaml bash scripts/run_kbench_correctness.sh \
#     > artifacts_v2/kbench_correctness_nohup.log 2>&1 & disown
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

CONFIG="${CONFIG:-}"
if [[ -n "${CONFIG}" ]]; then
  export TRACING_CONFIG="${CONFIG}"
  ARTIFACTS_DIR="${REPO_ROOT}/artifacts_v2"
  NOHUP_LOG="${ARTIFACTS_DIR}/kbench_correctness_nohup.log"
else
  ARTIFACTS_DIR="${REPO_ROOT}/artifacts"
  NOHUP_LOG="${ARTIFACTS_DIR}/kbench_correctness_nohup.log"
fi

mkdir -p "${ARTIFACTS_DIR}"

echo "=== KernelBench correctness launcher ==="
echo "Repo: ${REPO_ROOT}"
echo "CONFIG: ${CONFIG:-v1 default}"
echo ""

CONFIG_ARGS=()
if [[ -n "${CONFIG}" ]]; then
  CONFIG_ARGS=(--config "${CONFIG}")
fi

python3 scripts/preflight_kbench_correctness.py "${CONFIG_ARGS[@]}"
echo ""

echo "Starting watcher (logs: ${ARTIFACTS_DIR}/kbench_correctness_watcher.log, ${ARTIFACTS_DIR}/kbench_correctness_driver.log)"
exec bash scripts/watch_kbench_correctness.sh
