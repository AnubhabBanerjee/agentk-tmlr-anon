#!/usr/bin/env python3
"""
Phase 4 — extract supervised training labels from trace index + correctness parquet.

Joins ``data/traces/index.parquet`` with ``data/correctness/kernelbench.parquet``,
materializes y_N / y_T / y_E / y_Mpeak / y_trajectory / y_compile / y_numcorrect_kbench,
and writes ``data/labels/{qwen,phi,mistral}.parquet`` (600 rows each, split column).
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

_SCRIPTS_DIR = Path(__file__).resolve().parent
if str(_SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS_DIR))

_REPO = Path(__file__).resolve().parents[1]
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from kbench_correctness_common import repo_root_from_here
from src.forecast.q4_km_accounting import agentic_context_length_tokens, m_vram_mb
from src.pipeline.tracing_paths import load_tracing_paths
from src.proxy.data import AGENT_LABEL_FILES

NODE_TYPES: Tuple[str, ...] = (
    "planner",
    "analyzer",
    "optimizer",
    "generator",
    "critic",
)

def _prompt_slice_label(row: pd.Series) -> str:
    """Prompt slice key for correctness base-rate tables (source/family)."""
    return f"{row['prompt_source']}/{row['prompt_family']}"


def _parse_json_field(raw: Any) -> Any:
    """Parse a JSON string column from the trace index; pass through dict/list."""
    if raw is None or (isinstance(raw, float) and np.isnan(raw)):
        return None
    if isinstance(raw, (dict, list)):
        return raw
    if isinstance(raw, str) and raw.strip():
        return json.loads(raw)
    return None


def build_label_rows(merged: pd.DataFrame) -> pd.DataFrame:
    """Map index + correctness columns to Phase 4 supervised targets."""
    rows: List[Dict[str, Any]] = []
    for _, src in merged.iterrows():
        row: Dict[str, Any] = {
            "prompt_id": str(src["prompt_id"]),
            "agent_llm": str(src["agent_llm"]),
            "split": str(src["split"]),
            "prompt_source": str(src["prompt_source"]),
            "prompt_family": str(src["prompt_family"]),
            "prompt_complexity": src.get("prompt_complexity"),
            "trace_jsonl": str(src["trace_jsonl"]),
            "y_N": int(src["N_true"]),
            "y_N_nodes": int(src.get("N_nodes_true", src["N_true"])),
            "y_E": float(src["E_true"]),
            "y_Mpeak": float(src["M_peak_true"]),
            "y_compile": bool(src["compile_success"]),
            "y_trajectory_json": src.get("M_trajectory_true_json"),
        }
        for node in NODE_TYPES:
            executed = int(src.get(f"t_{node}_executed", 0) or 0)
            avg_tokens = float(src.get(f"t_{node}_avg_tokens_out", 0.0) or 0.0)
            row[f"y_T_{node}_executed"] = 1 if executed > 0 else 0
            row[f"y_T_{node}_avg_tokens"] = avg_tokens
            row[f"y_T_{node}"] = avg_tokens  # F3 primary target alias

        if str(src["prompt_source"]) == "kernelbench":
            num = src.get("numerical_correct_kbench")
            if pd.isna(num):
                row["y_numcorrect_kbench"] = pd.NA
            else:
                row["y_numcorrect_kbench"] = bool(num)
        else:
            row["y_numcorrect_kbench"] = pd.NA

        rows.append(row)
    return pd.DataFrame(rows)


def trajectory_closed_form_correlation(
    labels_df: pd.DataFrame,
    index_df: pd.DataFrame,
    *,
    split: str = "train",
) -> Tuple[float, int]:
    """
    Pearson correlation between closed-form VRAM L(t) curve and empirical trajectory.

    Uses train-split rows with valid accounting + trajectory JSON.
    """
    idx = index_df[index_df["split"] == split].set_index(["agent_llm", "prompt_id"])
    corrs: List[float] = []
    for _, row in labels_df[labels_df["split"] == split].iterrows():
        key = (row["agent_llm"], row["prompt_id"])
        if key not in idx.index:
            continue
        src = idx.loc[key]
        traj = _parse_json_field(src.get("M_trajectory_true_json"))
        acc = _parse_json_field(src.get("closed_form_accounting_json"))
        if not traj or not acc:
            continue
        n_steps = int(row.get("y_N_nodes", row["y_N"]))
        e_hat = float(row["y_E"])
        if n_steps <= 0 or len(traj) < 2:
            continue
        l_peak = float(src["L_peak_tokens"]) if pd.notna(src.get("L_peak_tokens")) else float(row["y_N"])
        l_base = max(0.0, l_peak - float(row["y_N"]))
        emp = [float(p["vram_used_mb"]) for p in traj]
        ana: List[float] = []
        for i in range(len(traj)):
            step = min(i, n_steps)
            l_t = agentic_context_length_tokens(
                step_index=step,
                n_steps=n_steps,
                l_base=l_base,
                e_hat=e_hat,
            )
            ana.append(
                m_vram_mb(
                    context_length_tokens=l_t,
                    m_weights_mb=float(acc["M_weights_reported_mb"]),
                    m_act_mb=float(acc["M_act_mb"]),
                    n_layers=int(acc["n_layers"]),
                    n_kv_heads=int(acc["n_kv_heads"]),
                    d_head=int(acc["d_head"]),
                    b_precision=float(acc["b_precision"]),
                )
            )
        if len(emp) > 1:
            corr = float(np.corrcoef(emp, ana)[0, 1])
            if np.isfinite(corr):
                corrs.append(corr)
    if not corrs:
        return float("nan"), 0
    return float(np.mean(corrs)), len(corrs)


def poisson_dispersion_check(y_n: pd.Series) -> Dict[str, Any]:
    """Fit Poisson via MLE (lambda = mean) and report variance/mean ratio."""
    vals = y_n.astype(float)
    mean = float(vals.mean())
    var = float(vals.var(ddof=0))
    ratio = var / mean if mean > 0 else float("nan")
    return {
        "lambda_mle": mean,
        "mean": mean,
        "variance": var,
        "variance_mean_ratio": ratio,
        "recommend_negative_binomial": bool(mean > 0 and ratio > 2.0),
    }


def plot_n_true_poisson(y_n: pd.Series, *, out_path: Path, lambda_mle: float) -> None:
    """Histogram of y_N with overlaid Poisson PMF (Phase 4 deliverable figure)."""
    out_path.parent.mkdir(parents=True, exist_ok=True)
    counts = y_n.astype(int)
    max_n = int(counts.max()) if len(counts) else 0
    bins = np.arange(-0.5, max(max_n + 1.5, 10.5), 1.0)

    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.hist(counts, bins=bins, density=True, alpha=0.65, color="#4C72B0", label="y_N (empirical)")
    xs = np.arange(0, max_n + 1)
    if lambda_mle > 0 and len(xs):
        pmf = stats.poisson.pmf(xs, mu=lambda_mle)
        ax.plot(xs, pmf, "o-", color="#C44E52", label=f"Poisson(λ={lambda_mle:.2f})")
    ax.set_xlabel("y_N (total completion tokens, F2)")
    ax.set_title("N_true histogram (total completion tokens) with fitted Poisson (train split)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def render_labels_report(
    labels_df: pd.DataFrame,
    *,
    poisson_stats: Dict[str, Any],
    traj_corr: float,
    traj_n: int,
    compile_rates: pd.DataFrame,
    numcorrect_table: pd.DataFrame,
) -> str:
    """Render Phase 4 markdown report with sanity-check outcomes."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    lines = [
        "# Labels report (Phase 4)",
        "",
        f"- Generated: **{now}**",
        f"- Label rows: **{len(labels_df)}** ({len(AGENT_LABEL_FILES)} agent shards)",
        f"- Output: `data/labels/{{qwen,phi,mistral}}.parquet`",
        "",
        "## Poisson fit on y_N (train split)",
        "",
        f"- MLE λ: **{poisson_stats['lambda_mle']:.4f}**",
        f"- Variance / mean: **{poisson_stats['variance_mean_ratio']:.4f}**",
    ]
    if poisson_stats["recommend_negative_binomial"]:
        lines.append(
            "- **Decision:** variance/mean > 2 → consider **Negative-Binomial** head instead of Poisson."
        )
    else:
        lines.append(
            "- **Decision:** variance/mean ≤ 2 → **Poisson** head is acceptable for Phase 5."
        )
    lines.extend(
        [
            "",
            f"- Figure: `data/labels/n_true_poisson_fit.png`",
            "",
            "## Closed-form vs empirical trajectory (train split)",
            "",
            f"- Mean boundary-level Pearson r (analytical VRAM vs `M_trajectory_true`): **{traj_corr:.4f}** "
            f"(n={traj_n} traces)",
        ]
    )
    if np.isfinite(traj_corr) and traj_corr < 0.9:
        lines.append(
            "- **WARN:** correlation < 0.9 — closed-form may be misspecified; revisit Phase 3 before proxy training."
        )
    else:
        lines.append("- Closed-form trajectory alignment passes the > 0.9 guide threshold.")

    lines.extend(["", "## y_compile base rate per agent LLM", "", "| agent_llm | success | total | rate |", "|-----------|--------:|------:|-----:|"])
    for agent, grp in labels_df.groupby("agent_llm", sort=False):
        total = len(grp)
        success = int(grp["y_compile"].astype(bool).sum())
        rate = success / total if total else 0.0
        flag = ""
        if rate < 0.05 or rate > 0.95:
            flag = " ⚠️"
        lines.append(f"| {agent} | {success} | {total} | {rate:.3f} |{flag}")
    lines.append("")
    lines.append(
        "Guide expects 0.5–0.95 per agent; rates outside this range make correctness analysis weak."
    )

    lines.extend(
        [
            "",
            "## Correctness base rates per (agent LLM × prompt slice)",
            "",
            "| agent_llm | prompt_slice | y_compile rate | n |",
            "|-----------|--------------|---------------:|--:|",
        ]
    )
    for _, row in compile_rates.iterrows():
        lines.append(
            f"| {row['agent_llm']} | {row['prompt_slice']} | {row['rate']:.3f} | {int(row['n'])} |"
        )

    lines.extend(
        [
            "",
            "## P(y_numcorrect_kbench | y_compile) — KernelBench subset",
            "",
            "| agent_llm | compile_success | numerical_correct | P(correct\\|compile) |",
            "|-----------|----------------:|------------------:|---------------------:|",
        ]
    )
    for _, row in numcorrect_table.iterrows():
        lines.append(
            f"| {row['agent_llm']} | {int(row['compile_success'])} | {int(row['numerical_correct'])} | "
            f"{row['p_correct_given_compile']:.3f} |"
        )
    lines.append("")
    return "\n".join(lines)


def main() -> int:
    """CLI: build label parquets and Phase 4 report artifacts."""
    parser = argparse.ArgumentParser(description="Build Phase 4 supervised labels")
    parser.add_argument("--labels-dir", type=Path, default=None)
    parser.add_argument("--report-out", type=Path, default=None)
    parser.add_argument("--figure-out", type=Path, default=None)
    parser.add_argument(
        "--config",
        type=Path,
        default=None,
        help="Tracing config YAML (e.g. configs/tracing_v2.yaml)",
    )
    args = parser.parse_args()

    repo = repo_root_from_here()
    paths = load_tracing_paths(repo_root=repo, config=args.config)
    index_path = paths.index_path
    correctness_path = paths.correctness_parquet
    labels_dir = args.labels_dir or paths.labels_dir
    report_path = args.report_out or (
        repo / ("data/labels_report_v2.md" if paths.is_v2 else "data/labels_report.md")
    )
    figure_path = args.figure_out or (labels_dir / "n_true_poisson_fit.png")

    index_df = pd.read_parquet(index_path)
    correctness_df = pd.read_parquet(correctness_path)
    join_cols = (
        ["trace_jsonl"]
        if "trace_jsonl" in index_df.columns and "trace_jsonl" in correctness_df.columns
        else ["agent_llm", "prompt_id"]
    )
    correctness_cols = list(join_cols) + ["numerical_correct_kbench", "harness_status"]
    merged = index_df.merge(
        correctness_df[correctness_cols],
        on=join_cols,
        how="left",
    )
    labels_df = build_label_rows(merged)

    labels_dir.mkdir(parents=True, exist_ok=True)
    for agent_llm, short_name in AGENT_LABEL_FILES.items():
        shard = labels_df[labels_df["agent_llm"] == agent_llm].copy()
        out = labels_dir / f"{short_name}.parquet"
        shard.to_parquet(out, index=False)
        split_counts = shard["split"].value_counts().to_dict()
        print(f"Wrote {out} ({len(shard)} rows, splits={split_counts})")

    train_y_n = labels_df[labels_df["split"] == "train"]["y_N"]
    poisson_stats = poisson_dispersion_check(train_y_n)
    plot_n_true_poisson(train_y_n, out_path=figure_path, lambda_mle=poisson_stats["lambda_mle"])
    print(f"Wrote {figure_path}")

    traj_corr, traj_n = trajectory_closed_form_correlation(labels_df, index_df, split="train")

    work = labels_df.copy()
    work["prompt_slice"] = work.apply(_prompt_slice_label, axis=1)
    compile_rates = (
        work.groupby(["agent_llm", "prompt_slice"], sort=False)["y_compile"]
        .agg(n="count", success=lambda s: int(s.astype(bool).sum()))
        .reset_index()
    )
    compile_rates["rate"] = compile_rates["success"] / compile_rates["n"]

    kb = labels_df[labels_df["prompt_source"] == "kernelbench"].copy()
    num_rows = []
    for agent_llm, grp in kb.groupby("agent_llm", sort=False):
        compiled = grp[grp["y_compile"].astype(bool)]
        n_compile = len(compiled)
        n_correct = int(compiled["y_numcorrect_kbench"].astype("boolean").fillna(False).sum()) if n_compile else 0
        num_rows.append(
            {
                "agent_llm": agent_llm,
                "compile_success": n_compile,
                "numerical_correct": n_correct,
                "p_correct_given_compile": n_correct / n_compile if n_compile else 0.0,
            }
        )
    numcorrect_table = pd.DataFrame(num_rows)

    report = render_labels_report(
        labels_df,
        poisson_stats=poisson_stats,
        traj_corr=traj_corr,
        traj_n=traj_n,
        compile_rates=compile_rates,
        numcorrect_table=numcorrect_table,
    )
    report_path.write_text(report, encoding="utf-8")
    print(f"Wrote {report_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
