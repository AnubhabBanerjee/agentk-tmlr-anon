#!/usr/bin/env python3
"""Phase 1.2 — verify global Python dependencies and GPU visibility."""

# Standard library imports for version parsing and process exit codes.
import importlib
import sys
from pathlib import Path


# Map pip distribution names to import module names where they differ.
REQUIRED_PACKAGES = [
    ("torch", "torch", "2.2.0"),
    ("transformers", "transformers", "4.40.0"),
    ("datasets", "datasets", "2.19.0"),
    ("numpy", "numpy", "1.26.0"),
    ("scipy", "scipy", "1.13.0"),
    ("scikit-learn", "sklearn", "1.4.0"),
    ("pandas", "pandas", "2.2.0"),
    ("langgraph", "langgraph", "0.2.0"),
    ("langchain", "langchain", "0.2.0"),
    ("chromadb", "chromadb", "0.5.0"),
    ("pydantic", "pydantic", "2.7.0"),
    ("llama-cpp-python", "llama_cpp", "0.2.90"),
    ("anthropic", "anthropic", "0.28.0"),
    ("openai", "openai", "1.30.0"),
    ("pynvml", "pynvml", "11.5.0"),
    ("matplotlib", "matplotlib", "3.8.0"),
    ("seaborn", "seaborn", "0.13.0"),
    ("pyyaml", "yaml", "6.0.0"),
    ("pytest", "pytest", "8.0.0"),
]


def parse_version(version: str) -> tuple[int, ...]:
    """Convert a dotted version string into a tuple of integers for comparison."""
    # Accumulate numeric parts until a non-integer suffix is encountered.
    parts: list[int] = []
    # Split on dots because semantic versions use dot-separated integers.
    for token in version.split("."):
        # Keep only leading digits so values like '1.0rc1' compare safely.
        digits = ""
        for ch in token:
            if ch.isdigit():
                digits += ch
            else:
                break
        if digits:
            parts.append(int(digits))
    # Return the tuple so callers can use standard comparison operators.
    return tuple(parts)


def check_packages() -> list[str]:
    """Import each required package and verify its version meets the minimum."""
    # Collect human-readable error strings for anything that fails.
    failures: list[str] = []
    # Iterate deterministically so output order is stable across runs.
    for pip_name, module_name, min_version in REQUIRED_PACKAGES:
        try:
            # Import the module to confirm it is installed and loadable.
            module = importlib.import_module(module_name)
            # Read __version__ when present; some packages omit it.
            version = getattr(module, "__version__", None)
            if version is None:
                print(f"OK   {pip_name:20s} (imported, version unknown)")
                continue
            if parse_version(str(version)) < parse_version(min_version):
                failures.append(
                    f"{pip_name}: found {version}, need >={min_version}"
                )
            else:
                print(f"OK   {pip_name:20s} {version}")
        except Exception as exc:
            failures.append(f"{pip_name}: import failed ({exc})")
    # Return the list of failures so main() can decide the exit code.
    return failures


def check_gpu_stack() -> list[str]:
    """Verify torch CUDA, transformers torch bridge, and pynvml VRAM query."""
    # Collect GPU-related failures separately from package import failures.
    failures: list[str] = []
    try:
        # Import torch lazily so package checks run first in main().
        import torch
        # CUDA must be available because tracing runs on GPU-backed llama.cpp.
        if not torch.cuda.is_available():
            failures.append("torch.cuda.is_available() is False")
        else:
            # Report the detected GPU name for operator confidence.
            print(f"OK   torch.cuda            {torch.cuda.get_device_name(0)}")
    except Exception as exc:
        failures.append(f"torch CUDA check failed: {exc}")

    try:
        # transformers must see torch for DeBERTa / UniXCoder fine-tuning.
        from transformers.utils import is_torch_available

        if not is_torch_available():
            failures.append(
                "transformers does not see torch (check transformers<5 with torch 2.2.x)"
            )
        else:
            print("OK   transformers+torch    linked")
    except Exception as exc:
        failures.append(f"transformers torch bridge check failed: {exc}")

    try:
        # Query total VRAM through NVML for tracing sanity.
        import pynvml

        pynvml.nvmlInit()
        handle = pynvml.nvmlDeviceGetHandleByIndex(0)
        mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
        total_gb = mem.total / (1024**3)
        print(f"OK   pynvml VRAM          {total_gb:.1f} GB total")
        pynvml.nvmlShutdown()
    except Exception as exc:
        failures.append(f"pynvml check failed: {exc}")

    return failures


def main() -> int:
    """Run all environment checks and return a process exit code."""
    # Print the interpreter path so logs are reproducible.
    print(f"Python: {sys.executable}")
    print(f"Version: {sys.version.split()[0]}")
    print("--- package checks ---")
    # Run import/version checks for all required dependencies.
    failures = check_packages()
    print("--- GPU checks ---")
    # Extend failures with CUDA / NVML validation results.
    failures.extend(check_gpu_stack())
    if failures:
        print("--- FAILURES ---")
        for item in failures:
            print(f"  - {item}")
        return 1
    print("Environment check passed.")
    return 0


if __name__ == "__main__":
  # Propagate the integer exit code from main() to the shell.
  raise SystemExit(main())
