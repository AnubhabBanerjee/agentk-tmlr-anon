#!/usr/bin/env python3
"""
Step 33 (C5) — one-way ANOVA variance decomposition of M_peak_true_mb.

Inputs: data/traces_v2/index.parquet, data/labels_v2/*.parquet,
        data/correctness_v2/kernelbench.parquet
Outputs: paper/results_v2/metrics/variance_decomposition.parquet
         paper/results_v2/tables/variance_decomposition.tex
         paper/figures_v2/fig_variance_residuals.pdf
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

_REPO = Path(__file__).resolve().parents[1]
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from src.eval.variance_decomposition import (
    build_variance_decomposition_table,
    load_variance_frame,
    summarize_residual_range,
    write_variance_decomposition_outputs,
)
from src.viz.analyses_figures import plot_residual_histograms


def parse_args() -> argparse.Namespace:
    """CLI for variance-decomposition pipeline (guide step 33)."""
    parser = argparse.ArgumentParser(
        description="One-way ANOVA variance decomposition of M_peak_true_mb (C5)."
    )
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=_REPO,
        help="Repository root (default: parent of scripts/).",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=None,
        help="Tracing YAML (optional; reserved for path overrides).",
    )
    parser.add_argument(
        "--out-parquet",
        type=Path,
        default=_REPO / "paper/results_v2/metrics/variance_decomposition.parquet",
        help="Output metrics parquet path.",
    )
    parser.add_argument(
        "--out-tex",
        type=Path,
        default=_REPO / "paper/results_v2/tables/variance_decomposition.tex",
        help="Output LaTeX table path.",
    )
    parser.add_argument(
        "--out-figure",
        type=Path,
        default=_REPO / "paper/figures_v2/fig_variance_residuals.pdf",
        help="Output residual-histogram PDF path.",
    )
    parser.add_argument(
        "--skip-figures",
        action="store_true",
        help="Skip residual histogram PDF.",
    )
    return parser.parse_args()


def main() -> None:
    """Load v2 traces, run ANOVA grid, write metrics + table + optional figure."""
    args = parse_args()
    repo_root = Path(args.repo_root)
    # Load joined measurement frame (index + correctness + label shards).
    frame = load_variance_frame(repo_root)
    # Per-agent × per-grouping one-way ANOVA rows.
    table = build_variance_decomposition_table(frame)
    # Persist canonical parquet + booktabs LaTeX summary.
    pq_path, tex_path = write_variance_decomposition_outputs(
        table,
        out_parquet=args.out_parquet,
        out_tex=args.out_tex,
    )
    print(f"Wrote {pq_path}")
    print(f"Wrote {tex_path}")
    # Console summary for §5.5b placeholder filling.
    min_res, max_res, max_eta = summarize_residual_range(table)
    print(
        f"Residual frac range (valid cells): {min_res:.1f}%–{max_res:.1f}%; "
        f"max eta^2: {max_eta:.1f}%"
    )
    # Residual histograms: one panel per agent (demeaned M_peak_true_mb).
    if not args.skip_figures:
        fig_path = plot_residual_histograms(frame, args.out_figure)
        print(f"Wrote {fig_path}")


if __name__ == "__main__":
    main()
