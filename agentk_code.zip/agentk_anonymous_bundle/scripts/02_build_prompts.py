#!/usr/bin/env python3
"""Phase 2 — assemble prompt datasets (§2.1 KernelBench slice implemented)."""

# argparse builds the CLI for selecting which Phase 2 slice to materialize.
import argparse
# sys mutates import path so ``src.prompts`` resolves from the repository root.
import sys
# Path locates repo root, data outputs, and configs/kernelbench_version.txt.
from pathlib import Path
# typing.List annotates per-level count dictionaries in the summary report.
from typing import List


def _repo_root() -> Path:
    """Return absolute repository root (parent directory of scripts/)."""
    # scripts/02_build_prompts.py lives one level below the repo root directory.
    return Path(__file__).resolve().parents[1]


def _write_kernelbench_report(
    *,
    records: list,
    report_path: Path,
    version_path: Path,
) -> None:
    """Write a short markdown summary of the KernelBench pull for Phase 2.1."""
    # Count problems per level for the deliverable summary table.
    per_level: dict[int, int] = {}
    # Tally records by their integer KernelBench level field.
    for rec in records:
        per_level[rec.level] = per_level.get(rec.level, 0) + 1
    # Read pinned upstream commit SHA written in configs/kernelbench_version.txt.
    pinned_sha = version_path.read_text(encoding="utf-8").strip()
    # Build markdown lines for data/prompts/kernelbench/report.md.
    lines: List[str] = [
        "# KernelBench slice (Phase 2.1)",
        "",
        f"- Total problems: **{len(records)}** (expected 270)",
        f"- Upstream pin: `{pinned_sha}` (`ScalingIntelligence/KernelBench`, MIT)",
        f"- Index: `data/prompts/kernelbench/index.jsonl`",
        f"- Reference code (not used as KC prompts): `data/prompts/kernelbench/reference/`",
        "",
        "## Per-level counts",
        "",
        "| Level | Count |",
        "|------:|------:|",
    ]
    # Append one markdown table row per KernelBench level 1..4.
    for level in sorted(per_level):
        lines.append(f"| {level} | {per_level[level]} |")
    # Terminate the markdown document with a trailing newline for POSIX tools.
    lines.append("")
    # Ensure parent directory exists before writing the report markdown file.
    report_path.parent.mkdir(parents=True, exist_ok=True)
    # Persist the report so Phase 2 reviewers can verify counts without re-counting.
    report_path.write_text("\n".join(lines), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments for prompt dataset construction."""
    # Construct an ArgumentParser with a one-line description of this script.
    parser = argparse.ArgumentParser(
        description="Build prompt datasets for memory-constrained-agentic-ai."
    )
    # --repo-root overrides auto-detected repository root for tests and CI jobs.
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=_repo_root(),
        help="Repository root directory.",
    )
    # --kernelbench-only limits execution to §2.1 KernelBench slice (270 problems).
    parser.add_argument(
        "--kernelbench-only",
        action="store_true",
        help="Build only the KernelBench slice (Phase 2.1).",
    )
    # --stratified-split runs §2.3 70/15/15 stratified split → data/split.json.
    parser.add_argument(
        "--stratified-split",
        action="store_true",
        help="Build stratified train/val/test split (Phase 2.3).",
    )
    # --phase-2-deliverable runs §2.4 merge → data/prompts/all.jsonl.
    parser.add_argument(
        "--phase-2-deliverable",
        action="store_true",
        help="Build Phase 2.4 deliverable (all.jsonl + split_report.md).",
    )
    # Return populated namespace to main() for path construction and dispatch.
    return parser.parse_args()


def main() -> int:
    """Entry point: build KernelBench prompts per step_by_step_execution_guide §2.1."""
    # Parse CLI flags once at startup.
    args = parse_args()
    # Resolve repository root from CLI or default scripts/../ location.
    repo_root = args.repo_root.resolve()
    # Prepend repo root to sys.path so ``import src.prompts`` works when run as script.
    repo_str = str(repo_root)
    if repo_str not in sys.path:
        sys.path.insert(0, repo_str)
    # Import builders after sys.path is configured (avoids shadowing by third_party/src).
    from src.prompts.kernelbench_extract import build_kernelbench_index
    from src.prompts.stratified_split import build_phase2_deliverable, write_stratified_split

    # §2.4: merged all.jsonl + split_report.md (uses existing split.json if present).
    if args.phase_2_deliverable:
        records, splits, all_path = build_phase2_deliverable(repo_root=repo_root)
        report_path = repo_root / "data" / "split_report.md"
        print(f"Wrote {len(records)} prompts to {all_path}")
        print(
            f"  train={len(splits['train'])}, "
            f"val={len(splits['val'])}, "
            f"test={len(splits['test'])}"
        )
        print(f"Report: {report_path}")
        return 0

    # §2.3: stratified split only (requires existing prompt JSONL inputs).
    if args.stratified_split:
        records, splits = write_stratified_split(repo_root=repo_root)
        split_path = repo_root / "data" / "split.json"
        report_path = repo_root / "data" / "split_report.md"
        print(
            f"Wrote stratified split for {len(records)} prompts to {split_path}"
        )
        print(
            f"  train={len(splits['train'])}, "
            f"val={len(splits['val'])}, "
            f"test={len(splits['test'])}"
        )
        print(f"Report: {report_path}")
        return 0

    # Phase 2.1 output paths under data/prompts/kernelbench/.
    kb_root = repo_root / "data" / "prompts" / "kernelbench"
    # JSONL index: NL prompts + metadata; reference PyTorch code stored separately.
    index_path = kb_root / "index.jsonl"
    # Directory tree for reference solutions used later by correctness harness only.
    reference_root = kb_root / "reference"
    # Pinned upstream commit SHA for reproducibility (see configs/kernelbench_version.txt).
    version_path = repo_root / "configs" / "kernelbench_version.txt"
    # Markdown summary written after a successful 270-row pull.
    report_path = kb_root / "report.md"

    # §2.1 currently implemented; synthetic slice remains for a later phase.
    if not args.kernelbench_only:
        print("Note: only --kernelbench-only (§2.1) is implemented; enabling it.")
    # Pull all 270 KernelBench problems and write index + reference files.
    records = build_kernelbench_index(
        repo_root=repo_root,
        output_index=index_path,
        reference_root=reference_root,
    )
    # Fail fast if the upstream dataset size diverges from the guide's n=270.
    if len(records) != 270:
        raise RuntimeError(f"Expected 270 KernelBench problems, got {len(records)}")
    # Write human-readable report with per-level counts and upstream pin SHA.
    _write_kernelbench_report(
        records=records,
        report_path=report_path,
        version_path=version_path,
    )
    # Print success summary for Makefile/CI logs.
    print(f"Wrote {len(records)} KernelBench prompts to {index_path}")
    print(f"Reference code under {reference_root}")
    print(f"Report: {report_path}")
    # Exit code 0 indicates Phase 2.1 completed successfully.
    return 0


# Standard Python idiom: invoke main() only when executed as a script.
if __name__ == "__main__":
    raise SystemExit(main())
