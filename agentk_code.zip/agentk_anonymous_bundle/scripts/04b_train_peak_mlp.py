#!/usr/bin/env python3
"""Plan B G3 — train structural peak MLP on frozen Phase-5 proxy outputs."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import torch

_REPO = Path(__file__).resolve().parents[1]
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from src.proxy.peak_mlp_training import train_peak_mlp


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Train learned peak VRAM forecaster (G3) over frozen proxy outputs."
    )
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=_REPO,
        help="Repository root directory.",
    )
    parser.add_argument(
        "--agent-llm",
        type=str,
        required=True,
        choices=["qwen2.5-coder-7b", "phi-4-mini", "mistral-7b-instruct-v0.3"],
        help="Agent backend whose traces supervise the peak MLP.",
    )
    parser.add_argument(
        "--backbone",
        type=str,
        required=True,
        choices=["minilm-l12", "deberta-v3-base", "unixcoder"],
        help="Frozen proxy encoder backbone (must match artifacts/proxies/).",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Override deliverable directory (default: artifacts/peak_mlp/{agent}/{backbone}).",
    )
    parser.add_argument(
        "--device",
        type=str,
        default="cuda" if torch.cuda.is_available() else "cpu",
        help="Torch device for training.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    out = args.output_dir
    if out is None:
        out = args.repo_root / "artifacts" / "peak_mlp" / args.agent_llm / args.backbone
    metrics = train_peak_mlp(
        repo_root=args.repo_root,
        agent_llm=args.agent_llm,
        backbone_id=args.backbone,
        output_dir=out,
        device=torch.device(args.device),
    )
    summary = {
        k: metrics[k]
        for k in (
            "agent_llm",
            "backbone",
            "forecaster",
            "best_epoch",
            "val_mape_learned",
            "val_oom_rate_learned",
            "val_mape_prior_only",
        )
        if k in metrics
    }
    print(json.dumps(summary, indent=2))
    print(f"Wrote {out / 'peak_mlp.safetensors'}")
    print(f"Wrote {out / 'metrics.json'}")


if __name__ == "__main__":
    main()
