#!/usr/bin/env python3
"""
Phase 3.5 — KernelBench numerical correctness harness driver (§3.5).

Evaluates compile-successful KernelBench traces against reference PyTorch
implementations. Writes ``data/correctness/kernelbench.parquet`` after each row.

Usage:
  python3 scripts/05_run_kernelbench_correctness.py --resume
"""

# Python line: from __future__ import annotations
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
from __future__ import annotations

# argparse exposes --resume and artifact path overrides for the batch driver.
# Python line: import argparse
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
import argparse
import hashlib
import json
import multiprocessing as mp
import os
# sys prepends scripts/ so kbench_correctness_common imports resolve locally.
# Python line: import sys
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
import sys
# traceback captures wrap/eval exceptions for wrap_error columns and driver logs.
# Python line: import traceback
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
import traceback
# Path resolves repo root, reference PyTorch files, and parquet output paths.
# Python line: from pathlib import Path
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
from pathlib import Path
# typing annotates row dicts loaded from trace index and KernelBench metadata maps.
# Python line: from typing import Any, Dict, List, Optional, Tuple
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
from typing import Any, Dict, List, Optional, Tuple

# pandas loads trace index rows and persists kernelbench.parquet incrementally.
# Python line: import pandas as pd
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
import pandas as pd

# scripts/ must be importable before pulling shared batch helper utilities.
# Python line: _SCRIPTS = Path(__file__).resolve().parent
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
_SCRIPTS = Path(__file__).resolve().parent
# Python line: if str(_SCRIPTS) not in sys.path:
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
if str(_SCRIPTS) not in sys.path:
    # Python line: sys.path.insert(0, str(_SCRIPTS))
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    sys.path.insert(0, str(_SCRIPTS))

# Python line: from kbench_correctness_common import (
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
from kbench_correctness_common import (
    HARNESS_SEED,
    count_harness_done,
    count_harness_evaluated,
    expect_harness_runs,
    load_kernelbench_index,
    load_or_init_results,
    repo_root_from_here,
    update_result_row,
    write_progress,
)

# Repo root must precede src.* imports when executing from scripts/.
# Python line: _repo = repo_root_from_here()
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
_repo = repo_root_from_here()
# Python line: if str(_repo) not in sys.path:
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
if str(_repo) not in sys.path:
    # Python line: sys.path.insert(0, str(_repo))
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    sys.path.insert(0, str(_repo))

# Python line: from src.correctness.cuda_sidecar import load_cuda_sidecar
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
from src.correctness.cuda_sidecar import load_cuda_sidecar
# Python line: from src.correctness.kbench_eval import run_kernelbench_eval
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
from src.correctness.kbench_eval import KbenchEvalOutcome, run_kernelbench_eval
# Python line: from src.correctness.kbench_wrap import KbenchWrapError, wrap_kc_cuda_for_kernelbench
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
from src.correctness.kbench_wrap import KbenchWrapError, wrap_kc_cuda_for_kernelbench
from src.pipeline.tracing_paths import load_tracing_paths, tracing_paths_from_env


def _cuda_source_for_row(repo: Path, index_df: pd.DataFrame, trace_jsonl: str) -> Optional[str]:
    """Load CUDA sidecar text for one trace row (v2-safe via trace_jsonl key)."""
    rows = index_df[index_df["trace_jsonl"].astype(str) == str(trace_jsonl)]
    if len(rows) != 1:
        return None
    row = rows.iloc[0]
    rel = row.get("cuda_sidecar")
    if isinstance(rel, str) and rel.strip():
        path = repo / rel if not Path(rel).is_absolute() else Path(rel)
        if path.is_file():
            return path.read_text(encoding="utf-8")
    return load_cuda_sidecar(
        repo_root=repo,
        agent_llm=str(row["agent_llm"]),
        prompt_id=str(row["prompt_id"]),
    )


def _build_cache_dir(build_root: Path, agent_llm: str, prompt_id: str, trace_jsonl: str) -> Path:
    """Unique torch extension cache dir per trace row (sweep duplicates share prompt_id)."""
    tag = hashlib.sha1(trace_jsonl.encode("utf-8")).hexdigest()[:10]
    return build_root / agent_llm / prompt_id / tag


# Wall-clock cap per GPU eval (nvcc/load_inline can hang indefinitely).
HARNESS_EVAL_TIMEOUT_SEC = 180


def _eval_worker(queue: "mp.Queue", ref_src: str, custom_model_src: str, build_dir_str: str) -> None:
    """Subprocess entry: run one KernelBench eval and return outcome via queue."""
    try:
        outcome = run_kernelbench_eval(
            ref_src=ref_src,
            custom_model_src=custom_model_src,
            seed=HARNESS_SEED,
            num_correct_trials=5,
            num_perf_trials=100,
            build_dir=Path(build_dir_str),
            verbose=False,
        )
        queue.put(("ok", outcome))
    except Exception as exc:
        queue.put(("err", str(exc)))


def _run_eval_timed(
    *,
    ref_src: str,
    custom_model_src: str,
    build_dir: Path,
    timeout_sec: int = HARNESS_EVAL_TIMEOUT_SEC,
) -> Tuple[Optional[KbenchEvalOutcome], Optional[str]]:
    """Run eval in a spawned child so hung nvcc/ninja can be killed."""
    ctx = mp.get_context("spawn")
    queue: "mp.Queue" = ctx.Queue()
    proc = ctx.Process(
        target=_eval_worker,
        args=(queue, ref_src, custom_model_src, str(build_dir)),
    )
    proc.start()
    proc.join(timeout_sec)
    if proc.is_alive():
        proc.terminate()
        proc.join(5)
        if proc.is_alive():
            proc.kill()
            proc.join()
        return None, f"timeout after {timeout_sec}s"
    if queue.empty():
        return None, "eval worker exited without result"
    kind, payload = queue.get()
    if kind == "ok":
        return payload, None
    return None, str(payload)


# Python line: def _worklist(results_df: pd.DataFrame) -> List[Tuple[str, str]]:
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
def _worklist(results_df: pd.DataFrame) -> List[Tuple[str, str, str]]:
    """Return (agent_llm, prompt_id, trace_jsonl) rows pending GPU harness execution."""
    pending = results_df[results_df["harness_status"].isin(["pending", "error:missing_cuda_sidecar"])]
    out: List[Tuple[str, str, str]] = []
    for _, row in pending.iterrows():
        out.append((str(row["agent_llm"]), str(row["prompt_id"]), str(row["trace_jsonl"])))
    return out


# Python line: def _max_abs_from_metadata(metadata: Dict[str, Any]) -> Optional[float]:
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
def _max_abs_from_metadata(metadata: Dict[str, Any]) -> Optional[float]:
    """Parse max absolute error floats recorded by KernelBench-style metadata."""
    # Python line: raw = metadata.get("max_difference")
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    raw = metadata.get("max_difference")
    # Python line: if not raw:
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if not raw:
        # Python line: return None
        # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        return None
    # Python line: vals: List[float] = []
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    vals: List[float] = []
    # Python line: for item in raw:
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    for item in raw:
        # Python line: try:
        # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        try:
            # Python line: vals.append(float(item))
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            vals.append(float(item))
        # Python line: except (TypeError, ValueError):
        # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        except (TypeError, ValueError):
            # Python line: continue
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            continue
    # Python line: return max(vals) if vals else None
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return max(vals) if vals else None


# Python line: def run_harness_batch(*, resume: bool, progress_path: Path, parquet_path: Path, build_root: Path) -> int:
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
def run_harness_batch(
    *,
    resume: bool,
    progress_path: Path,
    parquet_path: Path,
    build_root: Path,
    index_path: Path,
) -> int:
    """Execute pending KernelBench harness rows; return process exit code."""
    repo = repo_root_from_here()
    os.environ["PATH"] = f"/usr/local/cuda/bin:{os.environ.get('PATH', '')}"
    if not index_path.is_file():
        raise FileNotFoundError(f"missing trace index: {index_path}")

    # Python line: index_df = pd.read_parquet(index_path)
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    index_df = pd.read_parquet(index_path)
    # Python line: kb_index = load_kernelbench_index(repo)
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    kb_index = load_kernelbench_index(repo)
    # Python line: results_df = load_or_init_results(repo, index_df, parquet_path)
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    results_df = load_or_init_results(repo, index_df, parquet_path)
    # Python line: expect_eval = expect_harness_runs(index_df)
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    expect_eval = expect_harness_runs(index_df)
    # Python line: expect_total = len(index_df)
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    expect_total = len(index_df)

    # Python line: if not resume:
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if not resume:
        # Python line: results_df = load_or_init_results(repo, index_df, parquet_path)
        # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        pass

    # Python line: work = _worklist(results_df)
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    work = _worklist(results_df)
    # Python line: print(f"Phase 3.5 harness: {len(work)} pending GPU evals ({expect_eval} compile-success KernelBench)")
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    print(f"Phase 3.5 harness: {len(work)} pending GPU evals ({expect_eval} compile-success KernelBench)")

    # Python line: completed_eval = count_harness_evaluated(results_df)
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    completed_eval = count_harness_evaluated(results_df)
    # Python line: for agent_llm, prompt_id in work:
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    for agent_llm, prompt_id, trace_jsonl in work:
        print(f"  eval {agent_llm}/{prompt_id} ({trace_jsonl}) ...", flush=True)
        # Python line: kb_row = kb_index.get(prompt_id)
        # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        kb_row = kb_index.get(prompt_id)
        # Python line: if kb_row is None:
        # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        if kb_row is None:
            # Python line: results_df = update_result_row(
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            results_df = update_result_row(
                results_df,
                agent_llm=agent_llm,
                prompt_id=prompt_id,
                trace_jsonl=trace_jsonl,
                harness_status="error:missing_kbench_index",
                numerical_correct_kbench=False,
                wrap_error="missing kernelbench index row",
            )
            # Python line: results_df.to_parquet(parquet_path, index=False)
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            results_df.to_parquet(parquet_path, index=False)
            # Python line: write_progress(
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            write_progress(
                progress_path,
                {
                    "completed_total": int(count_harness_done(results_df)),
                    "expect_total": expect_total,
                    "completed_eval": int(count_harness_evaluated(results_df)),
                    "expect_eval": expect_eval,
                    "last_agent_llm": agent_llm,
                    "last_prompt_id": prompt_id,
                    "last_status": "error:missing_kbench_index",
                },
            )
            # Python line: continue
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            continue

        # Python line: ref_rel = str(kb_row["reference_path"])
        # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        ref_rel = str(kb_row["reference_path"])
        # Python line: ref_path = repo / ref_rel
        # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        ref_path = repo / ref_rel
        # Python line: ref_src = ref_path.read_text(encoding="utf-8")
        # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        ref_src = ref_path.read_text(encoding="utf-8")

        # Python line: cuda_src = load_cuda_sidecar(repo_root=repo, agent_llm=agent_llm, prompt_id=prompt_id)
        # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        cuda_src = _cuda_source_for_row(repo, index_df, trace_jsonl)
        if not cuda_src:
            results_df = update_result_row(
                results_df,
                agent_llm=agent_llm,
                prompt_id=prompt_id,
                trace_jsonl=trace_jsonl,
                harness_status="error:missing_cuda_sidecar",
                numerical_correct_kbench=False,
                wrap_error="missing CUDA sidecar; run scripts/backfill_cuda_sidecars.py",
            )
            # Python line: results_df.to_parquet(parquet_path, index=False)
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            results_df.to_parquet(parquet_path, index=False)
            # Python line: write_progress(
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            write_progress(
                progress_path,
                {
                    "completed_total": int(count_harness_done(results_df)),
                    "expect_total": expect_total,
                    "completed_eval": int(count_harness_evaluated(results_df)),
                    "expect_eval": expect_eval,
                    "last_agent_llm": agent_llm,
                    "last_prompt_id": prompt_id,
                    "last_status": "error:missing_cuda_sidecar",
                },
            )
            # Python line: continue
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            continue

        # Python line: build_dir = build_root / agent_llm / prompt_id
        # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        build_dir = _build_cache_dir(build_root, agent_llm, prompt_id, trace_jsonl)
        # Python line: build_dir.mkdir(parents=True, exist_ok=True)
        # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        build_dir.mkdir(parents=True, exist_ok=True)

        # Python line: try:
        # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        try:
            # Python line: model_new_src = wrap_kc_cuda_for_kernelbench(ref_src=ref_src, cuda_src=cuda_src)
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            model_new_src = wrap_kc_cuda_for_kernelbench(ref_src=ref_src, cuda_src=cuda_src)
            outcome, eval_err = _run_eval_timed(
                ref_src=ref_src,
                custom_model_src=model_new_src,
                build_dir=build_dir,
            )
            if eval_err:
                results_df = update_result_row(
                    results_df,
                    agent_llm=agent_llm,
                    prompt_id=prompt_id,
                    trace_jsonl=trace_jsonl,
                    harness_status="error:timeout",
                    numerical_correct_kbench=False,
                    wrap_error=eval_err,
                )
                status = "timeout"
                print(f"    -> timeout: {eval_err}")
                results_df.to_parquet(parquet_path, index=False)
                write_progress(
                    progress_path,
                    {
                        "completed_total": int(count_harness_done(results_df)),
                        "expect_total": expect_total,
                        "completed_eval": int(count_harness_evaluated(results_df)),
                        "expect_eval": expect_eval,
                        "last_agent_llm": agent_llm,
                        "last_prompt_id": prompt_id,
                        "last_status": status,
                    },
                )
                continue
            assert outcome is not None
            # Python line: max_abs = outcome.max_abs_err_kbench
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            max_abs = outcome.max_abs_err_kbench
            # Python line: if max_abs is None:
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            if max_abs is None:
                # Python line: max_abs = _max_abs_from_metadata(outcome.metadata)
                # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
                # Implements .cursorrules dense-comment policy for Python code.
                max_abs = _max_abs_from_metadata(outcome.metadata)
            # Python line: wrap_err = None
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            wrap_err = None
            # Python line: if not outcome.compiled:
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            if not outcome.compiled:
                # Python line: wrap_err = str(
                # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
                # Implements .cursorrules dense-comment policy for Python code.
                wrap_err = str(
                    outcome.metadata.get("compilation_error")
                    or outcome.metadata.get("other_error")
                    or "compile/link failed"
                )
            # Python line: results_df = update_result_row(
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            results_df = update_result_row(
                results_df,
                agent_llm=agent_llm,
                prompt_id=prompt_id,
                trace_jsonl=trace_jsonl,
                harness_status="done",
                harness_seed=HARNESS_SEED,
                numerical_correct_kbench=bool(outcome.numerical_correct_kbench),
                max_abs_err_kbench=max_abs,
                runtime_ms_kbench=outcome.runtime_ms_kbench,
                wrap_error=wrap_err,
            )
            # Python line: status = "ok" if outcome.numerical_correct_kbench else "compile_fail"
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            status = "ok" if outcome.numerical_correct_kbench else "fail"
            # Python line: print(
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            print(
                f"    -> {status} correct={outcome.numerical_correct_kbench} "
                f"max_abs={max_abs} runtime_ms={outcome.runtime_ms_kbench}"
            )
        # Python line: except KbenchWrapError as exc:
        # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        except KbenchWrapError as exc:
            # Python line: results_df = update_result_row(
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            results_df = update_result_row(
                results_df,
                agent_llm=agent_llm,
                prompt_id=prompt_id,
                trace_jsonl=trace_jsonl,
                harness_status="done",
                harness_seed=HARNESS_SEED,
                numerical_correct_kbench=False,
                wrap_error=f"wrap: {exc}",
            )
            # Python line: status = "wrap_fail"
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            status = "wrap_fail"
            # Python line: print(f"    -> wrap_fail: {exc}")
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            print(f"    -> wrap_fail: {exc}")
        # Python line: except Exception as exc:
        # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        except Exception as exc:
            # Python line: tb = traceback.format_exc()
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            tb = traceback.format_exc()
            # Python line: results_df = update_result_row(
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            results_df = update_result_row(
                results_df,
                agent_llm=agent_llm,
                prompt_id=prompt_id,
                trace_jsonl=trace_jsonl,
                harness_status="error:exception",
                numerical_correct_kbench=False,
                wrap_error=f"{exc}\n{tb}"[:1024],
            )
            # Python line: status = "exception"
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            status = "exception"
            # Python line: print(f"    -> exception: {exc}")
            # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
            # Implements .cursorrules dense-comment policy for Python code.
            print(f"    -> exception: {exc}")

        # Python line: results_df.to_parquet(parquet_path, index=False)
        # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        results_df.to_parquet(parquet_path, index=False)
        # Python line: write_progress(
        # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
        # Implements .cursorrules dense-comment policy for Python code.
        write_progress(
            progress_path,
            {
                "completed_total": int(count_harness_done(results_df)),
                "expect_total": expect_total,
                "completed_eval": int(count_harness_evaluated(results_df)),
                "expect_eval": expect_eval,
                "last_agent_llm": agent_llm,
                "last_prompt_id": prompt_id,
                "last_status": status,
            },
        )

    # Python line: done = count_harness_done(results_df)
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    done = count_harness_done(results_df)
    # Python line: print(f"Harness finished: {done}/{expect_total} terminal rows; eval done={count_harness_evaluated(results_df)}/{expect_eval}")
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    print(f"Harness finished: {done}/{expect_total} terminal rows; eval done={count_harness_evaluated(results_df)}/{expect_eval}")
    # Python line: return 0 if done >= expect_total else 1
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return 0 if done >= expect_total else 1


# Python line: def main() -> int:
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
def main() -> int:
    """CLI entry for Phase 3.5 KernelBench harness."""
    # Python line: parser = argparse.ArgumentParser(description="Phase 3.5 KernelBench correctness harness")
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    parser = argparse.ArgumentParser(description="Phase 3.5 KernelBench correctness harness")
    # Python line: parser.add_argument("--resume", action="store_true", help="Resume from existing parquet/progress")
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    parser.add_argument("--resume", action="store_true", help="Resume from existing parquet/progress")
    # Python line: parser.add_argument(
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    parser.add_argument(
        "--progress-file",
        type=Path,
        default=None,
        help="Progress JSON path (default: artifacts/kbench_correctness_progress.json)",
    )
    # Python line: parser.add_argument(
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    parser.add_argument(
        "--parquet-out",
        type=Path,
        default=None,
        help="Output parquet (default: data/correctness/kernelbench.parquet)",
    )
    # Python line: parser.add_argument(
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    parser.add_argument(
        "--build-root",
        type=Path,
        default=None,
        help="Torch extension build cache root (default: artifacts/kbench_build)",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=None,
        help="Tracing config YAML (e.g. configs/tracing_v2.yaml)",
    )
    parser.add_argument(
        "--index",
        type=Path,
        default=None,
        help="Override trace index parquet path",
    )
    args = parser.parse_args()
    repo = repo_root_from_here()
    paths = load_tracing_paths(repo_root=repo, config=args.config)
    progress_path = args.progress_file or paths.kbench_progress_json
    parquet_path = args.parquet_out or paths.correctness_parquet
    build_root = args.build_root or paths.kbench_build_root
    index_path = args.index or paths.index_path
    return run_harness_batch(
        resume=args.resume,
        progress_path=progress_path,
        parquet_path=parquet_path,
        build_root=build_root,
        index_path=index_path,
    )


# Python line: if __name__ == "__main__":
# Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
# Implements .cursorrules dense-comment policy for Python code.
if __name__ == "__main__":
    # Python line: raise SystemExit(main())
    # Phase 3.5 harness driver (scripts/05_run_kernelbench_correctness.py).
    # Implements .cursorrules dense-comment policy for Python code.
    raise SystemExit(main())
