#!/usr/bin/env bash
# Phase 5.3 — train all 9 proxy configs (3 agent LLMs × 3 backbones).
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

LOG_DIR="${REPO_ROOT}/artifacts/proxy_training"
mkdir -p "$LOG_DIR"
mkdir -p "${REPO_ROOT}/artifacts/proxies"

AGENTS=(
  "qwen2.5-coder-7b"
  "phi-4-mini"
  "mistral-7b-instruct-v0.3"
)
BACKBONES=(
  "minilm-l12"
  "deberta-v3-base"
  "unixcoder"
)

for agent in "${AGENTS[@]}"; do
  for backbone in "${BACKBONES[@]}"; do
    tag="${agent}__${backbone}"
    log="${LOG_DIR}/${tag}.log"
    echo "[proxy-ablation] training ${tag}"
    python3 scripts/04_train_proxy.py \
      --agent-llm "$agent" \
      --backbone "$backbone" \
      2>&1 | tee "$log"
  done
done

echo "[proxy-ablation] done — deliverables under artifacts/proxies/"
