#!/usr/bin/env python3
"""
train/run baseline predictors B0–B3, B4 proxy, and oracle B5.

Deliverable per (agent_llm, method):
  artifacts/predictions/{agent_llm}/{method}/test.parquet
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

import torch

_REPO = Path(__file__).resolve().parents[1]
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from typing import List

from src.baselines.common import AGENT_LLMS, BASELINE_METHODS
from src.baselines.runner import run_all_baselines, run_baseline
from src.pipeline.tracing_paths import tracing_paths_from_env


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train and run VRAM baselines.")
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=_REPO,
        help="Repository root directory.",
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Run all baselines for all agent LLMs (18 test.parquet files).",
    )
    parser.add_argument(
        "--agent-llm",
        type=str,
        choices=AGENT_LLMS,
        help="Single agent backend to run.",
    )
    parser.add_argument(
        "--baseline",
        type=str,
        choices=BASELINE_METHODS,
        help="Single baseline method to run.",
    )
    parser.add_argument(
        "--device",
        type=str,
        default="cuda" if torch.cuda.is_available() else "cpu",
        help="Torch device (B2/B4 use GPU when available).",
    )
    parser.add_argument(
        "--progress-json",
        type=Path,
        default=None,
        help="Optional progress JSON path (default: artifacts/baselines_progress.json).",
    )
    parser.add_argument(
        "--skip",
        action="append",
        default=[],
        metavar="METHOD",
        help="Baseline method to skip (repeatable, e.g. --skip B4). Also via SKIP=B4 env.",
    )
    return parser.parse_args()


def _resolve_skip_methods(args: argparse.Namespace) -> List[str]:
    """Merge --skip flags with comma/space-separated SKIP env var."""
    skip: List[str] = list(args.skip)
    skip_env = os.environ.get("SKIP", "").strip()
    if skip_env:
        for token in skip_env.replace(",", " ").split():
            token = token.strip()
            if token:
                skip.append(token)
    unknown = [m for m in skip if m not in BASELINE_METHODS]
    if unknown:
        raise SystemExit(f"Unknown --skip method(s): {unknown}; valid: {BASELINE_METHODS}")
    return skip


def main() -> None:
    args = parse_args()
    device = torch.device(args.device)
    paths = tracing_paths_from_env(repo_root=args.repo_root)
    progress_path = args.progress_json
    if progress_path is None:
        progress_path = (
            args.repo_root / "artifacts_v2" / "baselines_progress.json"
            if paths.is_v2
            else args.repo_root / "artifacts" / "baselines_progress.json"
        )

    skip_methods = _resolve_skip_methods(args)
    if skip_methods:
        print(f"Skipping baseline methods: {sorted(set(skip_methods))}", flush=True)

    if args.all:
        outputs = run_all_baselines(
            repo_root=args.repo_root,
            device=device,
            paths=paths,
            skip_methods=skip_methods,
        )
    elif args.agent_llm and args.baseline:
        if args.baseline in set(skip_methods):
            raise SystemExit(f"Refusing to run {args.baseline!r}: listed in --skip / SKIP env.")
        out = run_baseline(
            repo_root=args.repo_root,
            agent_llm=args.agent_llm,
            method=args.baseline,
            device=device,
            paths=paths,
        )
        outputs = {args.agent_llm: {args.baseline: str(out)}}
    else:
        raise SystemExit("Specify --all OR both --agent-llm and --baseline.")

    payload = {
        "generated_at_utc": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
        "device": str(device),
        "skipped_methods": sorted(set(skip_methods)),
        "outputs": outputs,
    }
    progress_path.parent.mkdir(parents=True, exist_ok=True)
    progress_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(outputs, indent=2))
    print(f"Wrote progress: {progress_path}")


if __name__ == "__main__":
    main()
