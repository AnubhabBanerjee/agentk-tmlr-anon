#!/usr/bin/env python3
"""
Phase 3.2 — calibrate Q4_K_M VRAM constants per agent LLM.

Measures runtime_overhead_mb (loaded VRAM − GGUF on-disk) and M_act_mb
(VRAM at generator:start − M_weights_reported) using pynvml + optional traces.
"""

# Python line: from __future__ import annotations
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
from __future__ import annotations

# argparse parses model selection and output path flags.
# Python line: import argparse
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
import argparse
# json writes configs/q4_vram_calibration.yaml.
# Python line: import json
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
import json
# signal stops llama.cpp server subprocess after idle VRAM measurement.
# Python line: import signal
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
import signal
# subprocess launches llama_cpp.server for idle VRAM reads.
# Python line: import subprocess
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
import subprocess
# sys provides executable path and sys.path for repo imports.
# Python line: import sys
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
import sys
# time waits for server readiness and NVML stabilization.
# Python line: import time
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
import time
# Path resolves repo root, GGUF paths, and trace JSONL inputs.
# Python line: from pathlib import Path
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
from pathlib import Path
# typing annotates model dicts loaded from YAML.
# Python line: from typing import Any, Dict, List, Optional
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
from typing import Any, Dict, List, Optional

# requests polls llama.cpp /v1/models health during server startup.
# Python line: import requests
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
import requests
# yaml loads configs/agent_llms.yaml model matrix.
# Python line: import yaml
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
import yaml


# Python line: def _repo_root() -> Path:
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
def _repo_root() -> Path:
    """Return absolute repository root."""
    # Python line: return Path(__file__).resolve().parents[1]
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return Path(__file__).resolve().parents[1]


# Python line: def _read_idle_vram_mb() -> float:
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
def _read_idle_vram_mb() -> float:
    """Sample current GPU used VRAM in MiB via pynvml."""
    # Python line: import pynvml
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    import pynvml

    # Python line: pynvml.nvmlInit()
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    pynvml.nvmlInit()
    # Python line: handle = pynvml.nvmlDeviceGetHandleByIndex(0)
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    handle = pynvml.nvmlDeviceGetHandleByIndex(0)
    # Python line: mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
    # Python line: return mem.used / (1024.0 * 1024.0)
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return mem.used / (1024.0 * 1024.0)


# Python line: def _start_server(model: Dict[str, Any], *, host: str, port: int) -> subprocess.Popen[Any]:
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
def _start_server(model: Dict[str, Any], *, host: str, port: int) -> subprocess.Popen[Any]:
    """Launch llama.cpp server for one GGUF and wait until healthy."""
    # Python line: cmd = [
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    cmd = [
        # Python line: sys.executable, "-m", "llama_cpp.server",
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        sys.executable,
        "-m",
        "llama_cpp.server",
        # Python line: "--model", str(model["gguf_path"]),
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        "--model",
        str(model["gguf_path"]),
        # Python line: "--model_alias", str(model["model_alias"]),
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        "--model_alias",
        str(model["model_alias"]),
        # Python line: "--host", host,
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        "--host",
        host,
        # Python line: "--port", str(port),
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        "--port",
        str(port),
        # Python line: "--n_ctx", str(model.get("n_ctx", 8192)),
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        "--n_ctx",
        str(model.get("n_ctx", 8192)),
        # Python line: "--n_gpu_layers", str(model.get("n_gpu_layers", -1)),
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        "--n_gpu_layers",
        str(model.get("n_gpu_layers", -1)),
        # Python line: "--verbose", "False",
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        "--verbose",
        "False",
    # Python line: ]
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    ]
    # Python line: cache_k = model.get("cache_type_k")
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    cache_k = model.get("cache_type_k")
    # Python line: cache_v = model.get("cache_type_v")
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    cache_v = model.get("cache_type_v")
    # Python line: from src.forecast.q4_km_accounting import llama_cpp_kv_type_id
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    from src.forecast.q4_km_accounting import llama_cpp_kv_type_id

    # Python line: if cache_k:
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if cache_k:
        # Python line: type_k = llama_cpp_kv_type_id(str(cache_k))
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        type_k = llama_cpp_kv_type_id(str(cache_k))
        # Python line: if type_k is not None and type_k != 1:
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        if type_k is not None and type_k != 1:
            # Python line: cmd.extend(["--type_k", str(type_k)])
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            cmd.extend(["--type_k", str(type_k)])
    # Python line: if cache_v:
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if cache_v:
        # Python line: type_v = llama_cpp_kv_type_id(str(cache_v))
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        type_v = llama_cpp_kv_type_id(str(cache_v))
        # Python line: if type_v is not None and type_v != 1:
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        if type_v is not None and type_v != 1:
            # Python line: cmd.extend(["--type_v", str(type_v)])
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            cmd.extend(["--type_v", str(type_v)])
    # Quantized KV cache (q8_0, q4_0, …) requires Flash Attention in llama.cpp.
    # Python line: needs_flash_attn = False
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    needs_flash_attn = False
    # Python line: if cache_k:
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if cache_k:
        # Python line: type_k_id = llama_cpp_kv_type_id(str(cache_k))
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        type_k_id = llama_cpp_kv_type_id(str(cache_k))
        # Python line: if type_k_id is not None and type_k_id != 1:
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        if type_k_id is not None and type_k_id != 1:
            # Python line: needs_flash_attn = True
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            needs_flash_attn = True
    # Python line: if cache_v:
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if cache_v:
        # Python line: type_v_id = llama_cpp_kv_type_id(str(cache_v))
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        type_v_id = llama_cpp_kv_type_id(str(cache_v))
        # Python line: if type_v_id is not None and type_v_id != 1:
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        if type_v_id is not None and type_v_id != 1:
            # Python line: needs_flash_attn = True
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            needs_flash_attn = True
    # Python line: if needs_flash_attn:
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if needs_flash_attn:
        # Python line: cmd.extend(["--flash_attn", "True"])
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        cmd.extend(["--flash_attn", "True"])
    # Python line: proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    # Python line: base = f"http://{host}:{port}"
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    base = f"http://{host}:{port}"
    # Python line: for _ in range(120):
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    for _ in range(120):
        # Python line: try:
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        try:
            # Python line: if requests.get(f"{base}/v1/models", timeout=3).status_code == 200:
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            if requests.get(f"{base}/v1/models", timeout=3).status_code == 200:
                # Python line: time.sleep(2.0)
                # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
                # Implements .cursorrules dense-comment policy for src/ code.
                time.sleep(2.0)
                # Python line: return proc
                # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
                # Implements .cursorrules dense-comment policy for src/ code.
                return proc
        # Python line: except requests.RequestException:
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        except requests.RequestException:
            # Python line: pass
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            pass
        # Python line: if proc.poll() is not None:
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        if proc.poll() is not None:
            # Python line: raise RuntimeError(f"llama server exited early for {model['id']}")
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            raise RuntimeError(f"llama server exited early for {model['id']}")
        # Python line: time.sleep(2)
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        time.sleep(2)
    # Python line: proc.terminate()
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    proc.terminate()
    # Python line: raise RuntimeError(f"llama server timeout for {model['id']}")
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    raise RuntimeError(f"llama server timeout for {model['id']}")


# Python line: def _stop_server(proc: subprocess.Popen[Any]) -> None:
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
def _stop_server(proc: subprocess.Popen[Any]) -> None:
    """Terminate llama.cpp server subprocess."""
    # Python line: if proc.poll() is not None:
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if proc.poll() is not None:
        # Python line: return
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        return
    # Python line: proc.send_signal(signal.SIGTERM)
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    proc.send_signal(signal.SIGTERM)
    # Python line: try:
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    try:
        # Python line: proc.wait(timeout=15)
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        proc.wait(timeout=15)
    # Python line: except subprocess.TimeoutExpired:
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    except subprocess.TimeoutExpired:
        # Python line: proc.kill()
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        proc.kill()


# Python line: def _load_models(repo: Path, *, agent_config: str = "agent_llms.yaml") -> List[Dict[str, Any]]:
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
def _load_models(repo: Path, *, agent_config: str = "agent_llms.yaml") -> List[Dict[str, Any]]:
    """Load resolved agent LLM entries from configs/agent_llms*.yaml."""
    # Python line: data = yaml.safe_load((repo / "configs" / agent_config).read_text())
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    data = yaml.safe_load((repo / "configs" / agent_config).read_text())
    # Python line: hf_root = data["hf_cache_root"]
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    hf_root = data["hf_cache_root"]
    # Python line: models: List[Dict[str, Any]] = []
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    models: List[Dict[str, Any]] = []
    # Python line: for model_id, entry in data["models"].items():
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    for model_id, entry in data["models"].items():
        # Python line: gguf = entry["gguf_path"].replace("${hf_cache_root}", hf_root)
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        gguf = entry["gguf_path"].replace("${hf_cache_root}", hf_root)
        # Python line: alias = entry.get("model_alias")
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        alias = entry.get("model_alias")
        # Python line: if not alias:
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        if not alias:
            # Python line: stem = Path(gguf).stem
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            stem = Path(gguf).stem
            # Python line: alias = stem
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            alias = stem
        # Python line: models.append({**entry, "id": model_id, "gguf_path": gguf, "model_alias": alias})
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        models.append({**entry, "id": model_id, "gguf_path": gguf, "model_alias": alias})
    # Python line: return models
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return models


# Python line: def _find_reference_trace(trace_root: Path, model_id: str) -> Optional[Path]:
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
def _find_reference_trace(
    trace_root: Path,
    model_id: str,
    cache_type_k: str = "f16",
    cache_type_v: str = "f16",
) -> Optional[Path]:
    """Pick the first trace JSONL with a generator:start boundary for M_act."""
    # Python line: model_dir = trace_root / model_id
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    model_dir = trace_root / model_id
    # Python line: if not model_dir.is_dir():
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if not model_dir.is_dir():
        # Python line: return None
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        return None
    # Python line: from src.forecast.q4_km_accounting import vram_at_generator_start_mb
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    from src.forecast.q4_km_accounting import vram_at_generator_start_mb

    # Python line: for path in sorted(model_dir.glob("*.jsonl")):
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    for path in sorted(model_dir.glob("*.jsonl")):
        # Python line: if vram_at_generator_start_mb(path) is not None:
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        if vram_at_generator_start_mb(path) is not None:
            # Python line: return path
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            return path
    # Python line: return None
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return None


    return None


# Python line: def _cache_pair_key(cache_type_k: str, cache_type_v: str) -> str:
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
def _cache_pair_key(cache_type_k: str, cache_type_v: str) -> str:
    """Return the v2 calibration YAML key for a KV-cache pair."""
    # Python line: return f"{cache_type_k}/{cache_type_v}"
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return f"{cache_type_k}/{cache_type_v}"


# Python line: def _v2_calibration_tuples(repo: Path) -> List[tuple[str, str, str]]:
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
def _v2_calibration_tuples(repo: Path) -> List[tuple[str, str, str]]:
    """List (agent_id, cache_type_k, cache_type_v) tuples for v2 calibration."""
    # Python line: agent_data = yaml.safe_load((repo / "configs" / "agent_llms_v2.yaml").read_text())
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    agent_data = yaml.safe_load((repo / "configs" / "agent_llms_v2.yaml").read_text())
    # Python line: trace_data = yaml.safe_load((repo / "configs" / "tracing_v2.yaml").read_text())
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    trace_data = yaml.safe_load((repo / "configs" / "tracing_v2.yaml").read_text())
    # Python line: tuples: List[tuple[str, str, str]] = []
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    tuples: List[tuple[str, str, str]] = []
    # Python line: baseline_k = str(trace_data.get("kv_cache_baseline_k", "f16"))
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    baseline_k = str(trace_data.get("kv_cache_baseline_k", "f16"))
    # Python line: baseline_v = str(trace_data.get("kv_cache_baseline_v", "f16"))
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    baseline_v = str(trace_data.get("kv_cache_baseline_v", "f16"))
    # Python line: for agent_id in agent_data.get("models", {}):
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    for agent_id in agent_data.get("models", {}):
        # Python line: tuples.append((str(agent_id), baseline_k, baseline_v))
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        tuples.append((str(agent_id), baseline_k, baseline_v))
    # Python line: sweep_agents = [str(a) for a in trace_data.get("sweep_subset_agents", [])]
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    sweep_agents = [str(a) for a in trace_data.get("sweep_subset_agents", [])]
    # Python line: for pair in trace_data.get("cache_type_sweep", []):
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    for pair in trace_data.get("cache_type_sweep", []):
        # Python line: if not isinstance(pair, (list, tuple)) or len(pair) != 2:
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        if not isinstance(pair, (list, tuple)) or len(pair) != 2:
            # Python line: continue
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            continue
        # Python line: cache_k, cache_v = str(pair[0]), str(pair[1])
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        cache_k, cache_v = str(pair[0]), str(pair[1])
        # Python line: if cache_k == baseline_k and cache_v == baseline_v:
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        if cache_k == baseline_k and cache_v == baseline_v:
            # Python line: continue
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            continue
        # Python line: for agent_id in sweep_agents:
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        for agent_id in sweep_agents:
            # Python line: tuples.append((agent_id, cache_k, cache_v))
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            tuples.append((agent_id, cache_k, cache_v))
    # Python line: return tuples
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return tuples


# Python line: def _find_reference_trace_v2(
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
def _find_reference_trace_v2(
    trace_root: Path,
    model_id: str,
    cache_type_k: str,
    cache_type_v: str,
) -> Optional[Path]:
    """Pick a v2 trace JSONL(.zst) with generator:start for M_act calibration."""
    # Python line: from src.forecast.q4_km_accounting import vram_at_generator_start_mb
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    from src.forecast.q4_km_accounting import vram_at_generator_start_mb

    # Python line: if cache_type_k == "f16" and cache_type_v == "f16":
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if cache_type_k == "f16" and cache_type_v == "f16":
        # Python line: model_dir = trace_root / model_id
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        model_dir = trace_root / model_id
        # Python line: if not model_dir.is_dir():
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        if not model_dir.is_dir():
            # Python line: return None
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            return None
        # Python line: for pattern in ("*.jsonl.zst", "*.jsonl"):
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        for pattern in ("*.jsonl.zst", "*.jsonl"):
            # Python line: for path in sorted(model_dir.glob(pattern)):
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            for path in sorted(model_dir.glob(pattern)):
                # Python line: if vram_at_generator_start_mb(path) is not None:
                # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
                # Implements .cursorrules dense-comment policy for src/ code.
                if vram_at_generator_start_mb(path) is not None:
                    # Python line: return path
                    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
                    # Implements .cursorrules dense-comment policy for src/ code.
                    return path
        # Python line: return None
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        return None
    # Python line: sweep_dir = trace_root / model_id / "sweep"
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    sweep_dir = trace_root / model_id / "sweep"
    # Python line: if not sweep_dir.is_dir():
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if not sweep_dir.is_dir():
        # Python line: return None
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        return None
    # Python line: suffixes = (f"__k{cache_type_k}__v{cache_type_v}.jsonl.zst", f"__k{cache_type_k}__v{cache_type_v}.jsonl")
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    suffixes = (
        f"__k{cache_type_k}__v{cache_type_v}.jsonl.zst",
        f"__k{cache_type_k}__v{cache_type_v}.jsonl",
    )
    # Python line: for suffix in suffixes:
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    for suffix in suffixes:
        # Python line: for path in sorted(sweep_dir.glob(f"*{suffix}")):
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        for path in sorted(sweep_dir.glob(f"*{suffix}")):
            # Python line: if vram_at_generator_start_mb(path) is not None:
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            if vram_at_generator_start_mb(path) is not None:
                # Python line: return path
                # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
                # Implements .cursorrules dense-comment policy for src/ code.
                return path
    # Python line: return None
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return None


# Python line: def _calibrate_model_row(
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
def _calibrate_model_row(
    *,
    model: Dict[str, Any],
    trace_root: Path,
    host: str,
    port: int,
    find_reference_trace,
) -> Dict[str, Any]:
    """Measure VRAM constants for one agent (optionally with KV-cache overrides)."""
    # Python line: from src.forecast.q4_km_accounting import (
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    from src.forecast.q4_km_accounting import (
        b_precision_from_cache_types,
        gguf_on_disk_mb,
        measure_m_act_mb,
        m_weights_reported_mb,
        vram_at_generator_start_mb,
    )

    # Python line: model_id = str(model["id"])
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    model_id = str(model["id"])
    # Python line: gguf_path = Path(str(model["gguf_path"]))
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    gguf_path = Path(str(model["gguf_path"]))
    # Python line: disk_mb = gguf_on_disk_mb(gguf_path)
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    disk_mb = gguf_on_disk_mb(gguf_path)
    # Python line: proc = _start_server(model, host=host, port=port)
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    proc = _start_server(model, host=host, port=port)
    # Python line: try:
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    try:
        # Python line: loaded_mb = _read_idle_vram_mb()
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        loaded_mb = _read_idle_vram_mb()
    # Python line: finally:
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    finally:
        # Python line: _stop_server(proc)
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        _stop_server(proc)
        # Python line: time.sleep(3)
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        time.sleep(3)

    # Python line: runtime_overhead_mb = max(0.0, loaded_mb - disk_mb)
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    runtime_overhead_mb = max(0.0, loaded_mb - disk_mb)
    # Python line: m_weights = m_weights_reported_mb(gguf_path=gguf_path, runtime_overhead_mb=runtime_overhead_mb)
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    m_weights = m_weights_reported_mb(
        gguf_path=gguf_path,
        runtime_overhead_mb=runtime_overhead_mb,
    )

    # Python line: cache_k = str(model.get("cache_type_k", "f16"))
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    cache_k = str(model.get("cache_type_k", "f16"))
    # Python line: cache_v = str(model.get("cache_type_v", "f16"))
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    cache_v = str(model.get("cache_type_v", "f16"))
    # Python line: ref_trace = find_reference_trace(trace_root, model_id, cache_k, cache_v)
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    ref_trace = find_reference_trace(trace_root, model_id, cache_k, cache_v)
    # Python line: m_act_mb: Optional[float] = None
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    m_act_mb: Optional[float] = None
    # Python line: if ref_trace is not None:
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if ref_trace is not None:
        # Python line: gen_vram = vram_at_generator_start_mb(ref_trace)
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        gen_vram = vram_at_generator_start_mb(ref_trace)
        # Python line: if gen_vram is not None:
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        if gen_vram is not None:
            # Python line: m_act_mb = measure_m_act_mb(
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            m_act_mb = measure_m_act_mb(
                vram_at_generator_start_mb=gen_vram,
                m_weights_reported_mb=m_weights,
            )
    # Python line: if m_act_mb is None:
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if m_act_mb is None:
        # Python line: m_act_mb = 0.0
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        m_act_mb = 0.0

    # Python line: return {
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return {
        "gguf_on_disk_mb": round(disk_mb, 3),
        "loaded_vram_mb": round(loaded_mb, 3),
        "runtime_overhead_mb": round(runtime_overhead_mb, 3),
        "M_weights_reported_mb": round(m_weights, 3),
        "M_act_mb": round(m_act_mb, 3),
        "cache_type_k": cache_k,
        "cache_type_v": cache_v,
        "b_precision": b_precision_from_cache_types(cache_type_k=cache_k, cache_type_v=cache_v),
        "reference_trace": str(ref_trace) if ref_trace else None,
    }


# Python line: def main() -> int:
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
def main() -> int:
    """Calibrate all agent LLMs and write configs/q4_vram_calibration.yaml."""
    # Python line: parser = argparse.ArgumentParser(description="Calibrate Q4_K_M VRAM constants")
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    parser = argparse.ArgumentParser(description="Calibrate Q4_K_M VRAM constants")
    # Python line: parser.add_argument("--repo-root", type=Path, default=_repo_root())
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    parser.add_argument("--repo-root", type=Path, default=_repo_root())
    # Python line: parser.add_argument("--host", default="127.0.0.1")
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    parser.add_argument("--host", default="127.0.0.1")
    # Python line: parser.add_argument("--port", type=int, default=8081)
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    parser.add_argument("--port", type=int, default=8081)
    # Python line: parser.add_argument("--v2", action="store_true", help="Calibrate v2 fleet → q4_vram_calibration_v2.yaml")
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    parser.add_argument(
        "--v2",
        action="store_true",
        help="Calibrate v2 fleet (agent × KV cache type) → q4_vram_calibration_v2.yaml",
    )
    # Python line: args = parser.parse_args()
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    args = parser.parse_args()
    # Python line: repo = args.repo_root.resolve()
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    repo = args.repo_root.resolve()
    # Python line: sys.path.insert(0, str(repo))
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    sys.path.insert(0, str(repo))

    # Python line: if args.v2:
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if args.v2:
        # Python line: models_by_id = {m["id"]: m for m in _load_models(repo, agent_config="agent_llms_v2.yaml")}
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        models_by_id = {m["id"]: m for m in _load_models(repo, agent_config="agent_llms_v2.yaml")}
        # Python line: trace_root = repo / "data" / "traces_v2"
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        trace_root = repo / "data" / "traces_v2"
        # Python line: out: Dict[str, Any] = {"version": 2, "models": {}}
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        out: Dict[str, Any] = {"version": 2, "models": {}}
        # Python line: for agent_id, cache_k, cache_v in _v2_calibration_tuples(repo):
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        for agent_id, cache_k, cache_v in _v2_calibration_tuples(repo):
            # Python line: model = dict(models_by_id[agent_id])
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            model = dict(models_by_id[agent_id])
            # Python line: model["cache_type_k"] = cache_k
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            model["cache_type_k"] = cache_k
            # Python line: model["cache_type_v"] = cache_v
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            model["cache_type_v"] = cache_v
            # Python line: pair_key = _cache_pair_key(cache_k, cache_v)
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            pair_key = _cache_pair_key(cache_k, cache_v)
            # Python line: print(f"Calibrating {agent_id} ({pair_key}) ...")
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            print(f"Calibrating {agent_id} ({pair_key}) ...")
            # Python line: row = _calibrate_model_row(
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            row = _calibrate_model_row(
                model=model,
                trace_root=trace_root,
                host=args.host,
                port=args.port,
                find_reference_trace=_find_reference_trace_v2,
            )
            # Python line: agent_block = out["models"].setdefault(agent_id, {"cache_pairs": {}})
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            agent_block = out["models"].setdefault(agent_id, {"cache_pairs": {}})
            # Python line: agent_block["cache_pairs"][pair_key] = row
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            agent_block["cache_pairs"][pair_key] = row
            # Python line: print(
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            print(
                f"  disk={row['gguf_on_disk_mb']:.1f} loaded={row['loaded_vram_mb']:.1f} "
                f"overhead={row['runtime_overhead_mb']:.1f} M_weights={row['M_weights_reported_mb']:.1f} "
                f"M_act={row['M_act_mb']:.1f}"
            )
        # Python line: out_path = repo / "configs" / "q4_vram_calibration_v2.yaml"
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        out_path = repo / "configs" / "q4_vram_calibration_v2.yaml"
    else:
        # Python line: models = _load_models(repo)
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        models = _load_models(repo)
        # Python line: trace_root = repo / "data" / "traces"
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        trace_root = repo / "data" / "traces"
        # Python line: out = {"models": {}}
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        out = {"models": {}}

        # Python line: for model in models:
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        for model in models:
            # Python line: model_id = str(model["id"])
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            model_id = str(model["id"])
            # Python line: print(f"Calibrating {model_id} ...")
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            print(f"Calibrating {model_id} ...")
            # Python line: row = _calibrate_model_row(
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            row = _calibrate_model_row(
                model=model,
                trace_root=trace_root,
                host=args.host,
                port=args.port,
                find_reference_trace=_find_reference_trace,
            )
            # Python line: out["models"][model_id] = row
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            out["models"][model_id] = row
            # Python line: print(
            # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            print(
                f"  disk={row['gguf_on_disk_mb']:.1f} loaded={row['loaded_vram_mb']:.1f} "
                f"overhead={row['runtime_overhead_mb']:.1f} M_weights={row['M_weights_reported_mb']:.1f} "
                f"M_act={row['M_act_mb']:.1f}"
            )
        # Python line: out_path = repo / "configs" / "q4_vram_calibration.yaml"
        # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        out_path = repo / "configs" / "q4_vram_calibration.yaml"

    # Python line: import yaml as yaml_mod
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    import yaml as yaml_mod

    # Python line: out_path.write_text(yaml_mod.safe_dump(out, sort_keys=False), encoding="utf-8")
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    out_path.write_text(yaml_mod.safe_dump(out, sort_keys=False), encoding="utf-8")
    # Python line: print(f"Wrote {out_path}")
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    print(f"Wrote {out_path}")
    # Python line: return 0
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return 0


# Python line: if __name__ == "__main__":
# Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
# Implements .cursorrules dense-comment policy for src/ code.
if __name__ == "__main__":
    # Python line: raise SystemExit(main())
    # Phase 3.2 Q4 calibration script (scripts/calibrate_q4_vram.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    raise SystemExit(main())
