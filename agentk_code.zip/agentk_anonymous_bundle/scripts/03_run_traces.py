#!/usr/bin/env python3
"""
resumable AgentK tracing driver (§3.1 instrumentation wired).

Runs each (agent_llm, prompt_id) through instrumented AgentK + llama.cpp,
writing per-run JSONL traces under data/traces/{agent_llm}/{prompt_id}.jsonl.
"""

# Python line: from __future__ import annotations
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
from __future__ import annotations

import warnings

# Batch drivers import torch/transformers indirectly; suppress known FutureWarning spam.
warnings.filterwarnings("ignore", category=FutureWarning)

# argparse exposes --resume, --limit, --model, and --split filters.
# Python line: import argparse
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
import argparse
# json loads prompts from data/prompts/all.jsonl.
# Python line: import json
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
import json
# os sets AgentK / llama.cpp environment variables per model.
# Python line: import os
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
import os
# signal terminates the llama.cpp server subprocess between models.
# Python line: import signal
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
import signal
# subprocess launches llama_cpp.server for each agent backend GGUF.
# Python line: import subprocess
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
import subprocess
# sys.path is mutated so repo ``src.tracing`` and AgentK ``src`` coexist.
# Python line: import sys
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
import sys
# time sleeps between server stop/start and polls server readiness.
# Python line: import time
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
import time
# Path resolves configs, prompts, and trace output directories.
# Python line: from pathlib import Path
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
from pathlib import Path
# typing annotates model config dicts loaded from YAML.
# Python line: from typing import Any, Dict, List, Optional
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
from typing import Any, Dict, List, Optional, Set, Tuple

# requests polls the OpenAI-compatible /legacy/models health endpoint.
# Python line: import requests
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
import requests
# yaml loads configs/agent_llms.yaml and configs/tracing.yaml.
# Python line: import yaml
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
import yaml


# Python line: def _repo_root() -> Path:
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
def _repo_root() -> Path:
    """Return absolute repository root (parent of scripts/)."""
    # Python line: return Path(__file__).resolve().parents[1]
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return Path(__file__).resolve().parents[1]


# Python line: def _alias_from_path(gguf_path: str) -> str:
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
def _alias_from_path(gguf_path: str) -> str:
    """Derive llama.cpp server model alias from the GGUF filename stem."""
    # Python line: stem = Path(gguf_path).stem
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    stem = Path(gguf_path).stem
    # Python line: if stem.startswith("qwen2.5-coder-7b"):
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if stem.startswith("qwen2.5-coder-7b"):
        # Python line: return "qwen2.5-coder-7b-instruct"
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        return "qwen2.5-coder-7b-instruct"
    # Python line: if "Phi-4-mini" in stem or "phi-4" in stem.lower():
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if "Phi-4-mini" in stem or "phi-4" in stem.lower():
        # Python line: return "Phi-4-mini-instruct"
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        return "Phi-4-mini-instruct"
    # Python line: if "Mistral-7B" in stem:
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if "Mistral-7B" in stem:
        # Python line: return "Mistral-7B-Instruct-v0.3"
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        return "Mistral-7B-Instruct-v0.3"
    # Python line: return stem
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return stem


# Python line: def _load_models(config_path: Path) -> List[Dict[str, Any]]:
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
def _load_models(config_path: Path) -> List[Dict[str, Any]]:
    """Load agent-backend GGUF entries from configs/agent_llms.yaml."""
    # Python line: data = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    data = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    # Python line: hf_root = data["hf_cache_root"]
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    hf_root = data["hf_cache_root"]
    # Python line: models: List[Dict[str, Any]] = []
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    models: List[Dict[str, Any]] = []
    # Python line: for model_id, entry in data["models"].items():
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    for model_id, entry in data["models"].items():
        # Python line: gguf = entry["gguf_path"].replace("${hf_cache_root}", hf_root)
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        gguf = entry["gguf_path"].replace("${hf_cache_root}", hf_root)
        # Python line: models.append(
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        models.append(
            # Python line: {
            # trace driver (scripts/03_run_traces.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            {
                **entry,
                "id": model_id,
                "gguf_path": gguf,
                "model_alias": _alias_from_path(gguf),
            # Python line: }
            # trace driver (scripts/03_run_traces.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            }
        # Python line: )
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        )
    # Python line: return models
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return models


# Python line: def _load_prompts(all_jsonl: Path) -> List[Dict[str, Any]]:
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
def _load_prompts(all_jsonl: Path) -> List[Dict[str, Any]]:
    """Load merged prompt rows from data/prompts/all.jsonl."""
    # Python line: rows: List[Dict[str, Any]] = []
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    rows: List[Dict[str, Any]] = []
    # Python line: with all_jsonl.open("r", encoding="utf-8") as handle:
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    with all_jsonl.open("r", encoding="utf-8") as handle:
        # Python line: for line in handle:
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        for line in handle:
            # Python line: stripped = line.strip()
            # trace driver (scripts/03_run_traces.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            stripped = line.strip()
            # Python line: if stripped:
            # trace driver (scripts/03_run_traces.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            if stripped:
                # Python line: rows.append(json.loads(stripped))
                # trace driver (scripts/03_run_traces.py).
                # Implements .cursorrules dense-comment policy for src/ code.
                rows.append(json.loads(stripped))
    # Python line: return rows
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return rows


# Python line: def _reset_agentk_modules() -> None:
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
def _reset_agentk_modules() -> None:
    """Drop every cached ``src.*`` module so AgentK can own the ``src`` namespace.

    Repo tracing helpers are imported once before the model loop; bound callables
    stay alive after this purge.  Model-switch crashes at run 600/1200 are avoided
    by importing ``llama_cpp_kv_type_id`` from ``trace_batch_common`` in
    ``_start_llama_server`` (never ``from src.forecast`` after KC loads).
    """
    # Python line: for key in list(sys.modules):
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    for key in list(sys.modules):
        # Python line: if key == "src" or key.startswith("src."):
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        if key == "src" or key.startswith("src."):
            # Python line: del sys.modules[key]
            # trace driver (scripts/03_run_traces.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            del sys.modules[key]


# Python line: def _start_llama_server(
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
def _start_llama_server(
    *,
    gguf_path: str,
    model_alias: str,
    host: str,
    port: int,
    n_ctx: int,
    n_gpu_layers: int,
    log_path: Path,
    cache_type_k: Optional[str] = None,
    cache_type_v: Optional[str] = None,
) -> subprocess.Popen[Any]:
    """Launch llama_cpp.server and block until /v1/models responds."""
    # Python line: cmd = [
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    cmd = [
        # Python line: sys.executable, "-m", "llama_cpp.server",
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        sys.executable,
        "-m",
        "llama_cpp.server",
        # Python line: "--model", gguf_path,
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        "--model",
        gguf_path,
        # Python line: "--model_alias", model_alias,
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        "--model_alias",
        model_alias,
        # Python line: "--host", host,
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        "--host",
        host,
        # Python line: "--port", str(port),
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        "--port",
        str(port),
        # Python line: "--n_ctx", str(n_ctx),
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        "--n_ctx",
        str(n_ctx),
        # Python line: "--n_gpu_layers", str(n_gpu_layers),
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        "--n_gpu_layers",
        str(n_gpu_layers),
        # Python line: "--verbose", "False",
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        "--verbose",
        "False",
    # Python line: ]
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    ]
    # Python line: if cache_type_k:
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if cache_type_k or cache_type_v:
        # Python line: from trace_batch_common import llama_cpp_kv_type_id
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        from trace_batch_common import llama_cpp_kv_type_id

    # Python line: if cache_type_k:
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if cache_type_k:
        # Python line: type_k = llama_cpp_kv_type_id(str(cache_type_k))
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        type_k = llama_cpp_kv_type_id(str(cache_type_k))
        # Python line: if type_k is not None and type_k != 1:
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        if type_k is not None and type_k != 1:
            # Python line: cmd.extend(["--type_k", str(type_k)])
            # trace driver (scripts/03_run_traces.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            cmd.extend(["--type_k", str(type_k)])
    # Python line: if cache_type_v:
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if cache_type_v:
        # Python line: type_v = llama_cpp_kv_type_id(str(cache_type_v))
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        type_v = llama_cpp_kv_type_id(str(cache_type_v))
        # Python line: if type_v is not None and type_v != 1:
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        if type_v is not None and type_v != 1:
            # Python line: cmd.extend(["--type_v", str(type_v)])
            # trace driver (scripts/03_run_traces.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            cmd.extend(["--type_v", str(type_v)])

    # Quantized KV cache (q8_0, q4_0, …) requires Flash Attention in llama.cpp.
    needs_flash_attn = False
    if cache_type_k:
        type_k_id = llama_cpp_kv_type_id(str(cache_type_k)) if cache_type_k else 1
        if type_k_id is not None and type_k_id != 1:
            needs_flash_attn = True
    if cache_type_v:
        type_v_id = llama_cpp_kv_type_id(str(cache_type_v)) if cache_type_v else 1
        if type_v_id is not None and type_v_id != 1:
            needs_flash_attn = True
    if needs_flash_attn:
        cmd.extend(["--flash_attn", "True"])
    # Python line: log_f = open(log_path, "w", encoding="utf-8")
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    log_f = open(log_path, "w", encoding="utf-8")
    # Python line: proc = subprocess.Popen(cmd, stdout=log_f, stderr=subprocess.STDOUT)
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    proc = subprocess.Popen(cmd, stdout=log_f, stderr=subprocess.STDOUT)
    # Python line: base = f"http://{host}:{port}"
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    base = f"http://{host}:{port}"
    # Python line: for _ in range(90):
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    for _ in range(120):
        # Python line: try:
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        try:
            # Python line: resp = requests.get(f"{base}/legacy/models", timeout=3)
            # trace driver (scripts/03_run_traces.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            resp = requests.get(f"{base}/v1/models", timeout=3)
            # Python line: if resp.status_code == 200:
            # trace driver (scripts/03_run_traces.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            if resp.status_code == 200:
                # Python line: return proc
                # trace driver (scripts/03_run_traces.py).
                # Implements .cursorrules dense-comment policy for src/ code.
                return proc
        # Python line: except requests.RequestException:
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        except requests.RequestException:
            # Python line: pass
            # trace driver (scripts/03_run_traces.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            pass
        # Python line: if proc.poll() is not None:
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        if proc.poll() is not None:
            # Python line: log_f.close()
            # trace driver (scripts/03_run_traces.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            log_f.close()
            # Python line: raise RuntimeError(f"llama server exited early; see {log_path}")
            # trace driver (scripts/03_run_traces.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            raise RuntimeError(f"llama server exited early; see {log_path}")
        # Python line: time.sleep(2)
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        time.sleep(2)
    # Python line: proc.terminate()
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    proc.terminate()
    # Python line: log_f.close()
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    log_f.close()
    # Python line: raise RuntimeError(f"llama server not ready within 180s; see {log_path}")
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    raise RuntimeError(f"llama server not ready within 240s; see {log_path}")


# Python line: def _stop_process(proc: subprocess.Popen[Any]) -> None:
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
def _stop_process(proc: subprocess.Popen[Any]) -> None:
    """Terminate llama server gracefully, then kill if needed."""
    # Python line: if proc.poll() is not None:
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if proc.poll() is not None:
        # Python line: return
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        return
    # Python line: proc.send_signal(signal.SIGTERM)
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    proc.send_signal(signal.SIGTERM)
    # Python line: try:
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    try:
        # Python line: proc.wait(timeout=15)
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        proc.wait(timeout=15)
    # Python line: except subprocess.TimeoutExpired:
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    except subprocess.TimeoutExpired:
        # Python line: proc.kill()
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        proc.kill()
        # Python line: proc.wait(timeout=5)
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        proc.wait(timeout=5)


def _load_tracing_config(config_path: Path) -> Dict[str, Any]:
    """Load tracing.yaml (or a released ``*_v2`` sibling) for sweep keys and VRAM sampling."""
    # Read the YAML file as UTF-8 text for predictable path handling on Linux.
    return yaml.safe_load(config_path.read_text(encoding="utf-8"))


def _prompts_jsonl_path(repo: Path, tracing_cfg: Dict[str, Any]) -> Path:
    """Select plain or compressed prompt corpus from trace_output.root_dir."""
    root = str(tracing_cfg.get("trace_output", {}).get("root_dir", ""))
    if "traces_v2" in root:
        return repo / "data" / "prompts_v2" / "all.jsonl"
    return repo / "data" / "prompts" / "all.jsonl"


def _default_agent_config_path(repo: Path, tracing_path: Path) -> Path:
    """Pick agent_llms_v2.yaml when driving tracing_v2.yaml."""
    if "tracing_v2" in tracing_path.name:
        return repo / "configs" / "agent_llms_v2.yaml"
    return repo / "configs" / "agent_llms.yaml"


def _n_ctx_values_for_run(
    tracing_cfg: Dict[str, Any],
    model: Dict[str, Any],
    *,
    sweep: bool,
) -> List[int]:
    """Return one or more ``n_ctx`` values for v1 Cartesian sweep mode."""
    if not sweep:
        return [int(model.get("n_ctx", 8192))]
    raw = tracing_cfg.get("n_ctx_sweep")
    if not raw:
        raise RuntimeError(
            "n_ctx_sweep missing from tracing config; add it to configs/tracing.yaml "
            "or pass --config to a YAML that defines n_ctx_sweep."
        )
    return [int(v) for v in raw]


def _kv_baseline(tracing_cfg: Dict[str, Any]) -> Tuple[str, str]:
    """Return the default (f16, f16) KV-cache pair for non-subset prompts."""
    return (
        str(tracing_cfg.get("kv_cache_baseline_k", "f16")),
        str(tracing_cfg.get("kv_cache_baseline_v", "f16")),
    )


def _v1_cartesian_kv_axes(
    tracing_cfg: Dict[str, Any],
    model: Dict[str, Any],
    *,
    sweep: bool,
) -> Tuple[List[str], List[str]]:
    """v1 only: Cartesian cache_type_k_sweep × cache_type_v_sweep grid."""
    if not sweep:
        return (
            [str(model.get("cache_type_k", "f16"))],
            [str(model.get("cache_type_v", "f16"))],
        )
    raw_k = tracing_cfg["cache_type_k_sweep"]
    raw_v = tracing_cfg["cache_type_v_sweep"]
    return [str(v) for v in raw_k], [str(v) for v in raw_v]


def _prompts_for_kv_combo(
    prompts: List[Dict[str, Any]],
    *,
    cache_type_k: str,
    cache_type_v: str,
    kv_subset_ids: Set[str],
    kv_cache_sweep: bool,
    baseline_k: str,
    baseline_v: str,
) -> List[Dict[str, Any]]:
    """Filter prompts that should run at this (cache_k, cache_v) configuration (v1)."""
    if not kv_cache_sweep:
        return prompts
    if cache_type_k == baseline_k and cache_type_v == baseline_v:
        return prompts
    return [p for p in prompts if str(p["id"]) in kv_subset_ids]


def _expected_v1_trace_runs(
    prompts: List[Dict[str, Any]],
    kv_subset_ids: Set[str],
    n_ctx_values: List[int],
    tracing_cfg: Dict[str, Any],
    *,
    kv_cache_sweep: bool,
) -> int:
    """Count (prompt × config) runs for v1 Cartesian sweep progress reporting."""
    n_prompts = len(prompts)
    n_ctx_n = len(n_ctx_values)
    if not kv_cache_sweep:
        return n_prompts * n_ctx_n
    k_axes, v_axes = _v1_cartesian_kv_axes(tracing_cfg, {}, sweep=True)
    full_grid = len(k_axes) * len(v_axes)
    subset_n = sum(1 for p in prompts if str(p["id"]) in kv_subset_ids)
    return n_ctx_n * (n_prompts + subset_n * (full_grid - 1))


def _trace_output_path(
    trace_root: Path,
    model_id: str,
    prompt_id: str,
    n_ctx: int,
    cache_type_k: str,
    cache_type_v: str,
    *,
    n_ctx_sweep: bool,
    kv_cache_sweep: bool,
) -> Path:
    """Per-run JSONL path with optional released ctx / KV suffixes (v1 layout)."""
    if not n_ctx_sweep and not kv_cache_sweep:
        return trace_root / model_id / f"{prompt_id}.jsonl"
    stem = prompt_id
    if n_ctx_sweep or kv_cache_sweep:
        stem += f"__ctx{n_ctx}"
    if kv_cache_sweep:
        stem += f"__k{cache_type_k}__v{cache_type_v}"
    return trace_root / model_id / f"{stem}.jsonl"


# Python line: def parse_args() -> argparse.Namespace:
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
def parse_args() -> argparse.Namespace:
    """Parse CLI flags for the tracing batch driver."""
    # Python line: parser = argparse.ArgumentParser(description="Run AgentK traces.")
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    parser = argparse.ArgumentParser(description="Run AgentK traces.")
    # Python line: parser.add_argument("--repo-root", type=Path, default=_repo_root())
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    parser.add_argument("--repo-root", type=Path, default=_repo_root())
    parser.add_argument(
        "--config",
        type=Path,
        default=None,
        help="Tracing config YAML (default: configs/tracing.yaml).",
    )
    parser.add_argument(
        "--agent-config",
        type=Path,
        default=None,
        help="Agent LLM config YAML (default: configs/agent_llms.yaml).",
    )
    parser.add_argument("--resume", action="store_true")
    parser.add_argument(
        "--batch-1800",
        action="store_true",
        help="Full §3.3 batch: all models × all 600 prompts (implies --resume).",
    )
    parser.add_argument(
        "--progress-file",
        type=Path,
        default=None,
        help="JSON progress file updated after each completed trace.",
    )
    parser.add_argument(
        "--expect-total",
        type=int,
        default=None,
        help="Expected total runs for progress reporting (default: inventory).",
    )
    # Python line: parser.add_argument("--limit", type=int, default=None)
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    parser.add_argument("--limit", type=int, default=None)
    # Python line: parser.add_argument("--model", type=str, default=None)
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    parser.add_argument("--model", type=str, default=None, help="Single agent_llm id")
    # Python line: parser.add_argument("--split", type=str, default=None, choices=["train", "val", "test"])
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    parser.add_argument("--split", type=str, default=None, choices=["train", "val", "test"])
    parser.add_argument(
        "--prompt-ids",
        type=str,
        default=None,
        help="Comma-separated prompt IDs to trace (smoke / targeted runs).",
    )
    # Python line: parser.add_argument("--host", default="127.0.0.1")
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    parser.add_argument("--host", default="127.0.0.1")
    # Python line: parser.add_argument("--port", type=int, default=8080)
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--dry-run", action="store_true", help="Print planned run schedule and exit.")
    parser.add_argument(
        "--n-ctx-sweep",
        type=str,
        default=None,
        metavar="JSON_OR_CSV",
        help="Override tracing config n_ctx_sweep (v2: JSON list or comma-separated ints).",
    )
    parser.add_argument(
        "--cache-type-sweep",
        type=str,
        default=None,
        metavar="JSON",
        help='Override cache_type_sweep, e.g. \'[["f16","f16"],["q8_0","q8_0"]]\'.',
    )
    parser.add_argument(
        "--sweep-subset-prompts",
        type=int,
        default=None,
        help="Override sweep_subset_prompts (v2 stratified KV/n_ctx subset size).",
    )
    parser.add_argument(
        "--sweep-subset-agents",
        type=str,
        default=None,
        help="Override sweep_subset_agents (comma-separated agent ids).",
    )
    parser.add_argument(
        "--legacy-n-ctx-sweep",
        action="store_true",
        help="(v1 tracing.yaml only) Sweep n_ctx over tracing config n_ctx_sweep.",
    )
    parser.add_argument(
        "--legacy-kv-cache-sweep",
        action="store_true",
        help="(v1 tracing.yaml only) Cartesian cache_type_k/v sweep on subset prompts.",
    )
    parser.add_argument(
        "--base-only",
        action="store_true",
        help=" Run only base traces: 4 agents × 300 prompts at n_ctx=8192, f16/f16.",
    )
    parser.add_argument(
        "--sweep-only",
        action="store_true",
        help=" Run only sweep traces: 3 agents × 40 prompts × n_ctx × cache_type (720 runs).",
    )
    # Python line: return parser.parse_args()
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return parser.parse_args()


# Python line: def main() -> int:
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
def main() -> int:
    """Entry point: run instrumented traces for each (model, prompt) pair."""
    # Python line: args = parse_args()
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    args = parse_args()
    # Python line: repo = args.repo_root.resolve()
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    repo = args.repo_root.resolve()
    # Python line: if args.batch_1800:
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if args.batch_1800:
        # Python line: args.resume = True
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        args.resume = True
    # Python line: scripts_dir = str(repo / "scripts")
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    scripts_dir = str(repo / "scripts")
    # Python line: if scripts_dir not in sys.path:
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if scripts_dir not in sys.path:
        # Python line: sys.path.insert(0, scripts_dir)
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        sys.path.insert(0, scripts_dir)
    # Python line: from trace_batch_common import (
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    from trace_batch_common import (
        check_disk_guard_batch,
        count_complete_traces,
        count_complete_traces_glob,
        kill_stray_llama_servers,
        load_model_ids,
        release_gpu_memory,
        trace_is_complete,
        write_progress,
    )
    # Python line: kill_stray_llama_servers()
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    kill_stray_llama_servers()
    # Python line: repo_str = str(repo)
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    repo_str = str(repo)
    # Python line: if repo_str not in sys.path:
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if repo_str not in sys.path:
        # Python line: sys.path.insert(0, repo_str)
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        sys.path.insert(0, repo_str)

    # Python line: tracing_cfg = yaml.safe_load((repo / "configs" / "tracing.yaml").read_text())
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    tracing_path = args.config if args.config is not None else (repo / "configs" / "tracing.yaml")
    tracing_path = tracing_path.resolve()
    tracing_cfg = _load_tracing_config(tracing_path)
    agent_config_path = (
        args.agent_config
        if args.agent_config is not None
        else _default_agent_config_path(repo, tracing_path)
    ).resolve()
    agent_cfg = yaml.safe_load(agent_config_path.read_text(encoding="utf-8"))
    # Python line: interval_ms = int(tracing_cfg["vram_sampling"]["interval_ms"])
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    interval_ms = int(tracing_cfg["vram_sampling"]["interval_ms"])
    # Python line: timeout_sec = int(tracing_cfg["agentk"]["run_timeout_sec"])
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    timeout_sec = int(tracing_cfg["agentk"]["run_timeout_sec"])
    # Python line: retry_budget = int(tracing_cfg["agentk"]["retry_budget"])
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    retry_budget = int(tracing_cfg["agentk"]["retry_budget"])
    # Python line: trace_root = repo / tracing_cfg["trace_output"]["root_dir"]
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    trace_root = repo / tracing_cfg["trace_output"]["root_dir"]
    # Python line: seed = int(tracing_cfg["split"]["seed"])
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    seed = int(tracing_cfg["split"]["seed"])

    # Python line: from src.tracing.agentk_trace import (
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    from src.tracing.agentk_trace import (
        # Python line: TraceSession,
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        TraceSession,
        # Python line: build_run_metadata,
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        build_run_metadata,
        # Python line: build_traced_agentk_app,
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        build_traced_agentk_app,
        # Python line: compute_ground_truth_labels,
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        compute_ground_truth_labels,
        # Python line: run_traced_agentk,
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        run_traced_agentk,
        # Python line: write_trace_jsonl,
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        write_trace_jsonl,
    # Python line: )
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: from src.tracing.vram_sampler import VramSampler
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    from src.tracing.vram_factory import build_vram_sampler
    # Python line: from src.correctness.cuda_sidecar import delete_cuda_sidecar
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    from src.correctness.cuda_sidecar import delete_cuda_sidecar
    from src.tracing.llm_recorder import nvidia_smi_sidecar_path

    from src.tracing.sweep_plan import uses_v2_sweep_schema

    if uses_v2_sweep_schema(tracing_cfg):
        from run_traces_v2_driver import run_v2_batch

        return run_v2_batch(
            args=args,
            repo=repo,
            tracing_cfg=tracing_cfg,
            tracing_path=tracing_path,
            trace_batch_common=sys.modules["trace_batch_common"],
            build_vram_sampler=build_vram_sampler,
            delete_cuda_sidecar=delete_cuda_sidecar,
            kill_stray_llama_servers=kill_stray_llama_servers,
            release_gpu_memory=release_gpu_memory,
            write_progress=write_progress,
            count_complete_traces_glob=count_complete_traces_glob,
            _load_models=_load_models,
            _load_prompts=_load_prompts,
            _start_llama_server=_start_llama_server,
            _stop_process=_stop_process,
            _reset_agentk_modules=_reset_agentk_modules,
            default_agent_config_path=_default_agent_config_path,
            prompts_jsonl_path=_prompts_jsonl_path,
        )

    prompts_path = _prompts_jsonl_path(repo, tracing_cfg)
    prompts = _load_prompts(prompts_path)
    # Python line: if args.split:
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if args.split:
        # Python line: prompts = [p for p in prompts if p.get("split") == args.split]
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        prompts = [p for p in prompts if p.get("split") == args.split]
    # Python line: if args.limit is not None:
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if args.limit is not None:
        # Python line: prompts = prompts[: args.limit]
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        prompts = prompts[: args.limit]
    if args.prompt_ids:
        wanted = {pid.strip() for pid in args.prompt_ids.split(",") if pid.strip()}
        prompts = [p for p in prompts if str(p["id"]) in wanted]
        if len(prompts) != len(wanted):
            found = {str(p["id"]) for p in prompts}
            missing = sorted(wanted - found)
            raise RuntimeError(f"Unknown prompt IDs: {missing}")

    # Python line: inventory_model_ids, inventory_prompt_ids, inventory_total = batch_inventory(repo)
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    inventory_model_ids = load_model_ids(agent_config_path)
    inventory_prompt_ids = [str(p["id"]) for p in _load_prompts(prompts_path)]
    inventory_total = len(inventory_model_ids) * len(inventory_prompt_ids)
    expect_total = args.expect_total if args.expect_total is not None else inventory_total
    n_ctx_sweep = bool(args.legacy_n_ctx_sweep)
    kv_cache_sweep = bool(args.legacy_kv_cache_sweep)
    baseline_k, baseline_v = _kv_baseline(tracing_cfg)
    kv_subset_ids: Set[str] = set()
    if kv_cache_sweep:
        from src.prompts.stratified_split import (
            PromptRecord,
            SPLIT_SEED,
            stratified_kv_cache_sweep_subset,
        )

        corpus_rows = _load_prompts(prompts_path)
        corpus_records = [
            PromptRecord(
                id=str(row["id"]),
                source=str(row["source"]),
                family=str(row["family"]),
                complexity=str(row["complexity"]),
                precision=str(row.get("precision", "")),
                prompt=str(row["prompt"]),
            )
            for row in corpus_rows
        ]
        subset_size = int(tracing_cfg["kv_cache_sweep_subset_size"])
        kv_subset_ids = set(
            stratified_kv_cache_sweep_subset(
                corpus_records,
                total=subset_size,
                seed=SPLIT_SEED,
            )
        )
        print(
            f"KV-cache sweep: {len(kv_subset_ids)} stratified subset prompts "
            f"(baseline {baseline_k}/{baseline_v} for the rest)"
        )
    # Python line: progress_path = args.progress_file or (repo / "artifacts" / "trace_batch_progress.json")
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    progress_path = args.progress_file or (repo / "artifacts" / "trace_batch_progress.json")
    # Python line: progress_path.parent.mkdir(parents=True, exist_ok=True)
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    progress_path.parent.mkdir(parents=True, exist_ok=True)

    # Python line: models = _load_models(repo / "configs" / "agent_llms.yaml")
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    models = _load_models(agent_config_path)
    # Python line: if args.model:
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    if args.model:
        # Python line: models = [m for m in models if m["id"] == args.model]
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        models = [m for m in models if m["id"] == args.model]
        # Python line: if not models:
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        if not models:
            # Python line: raise RuntimeError(f"Unknown --model {args.model!r}")
            # trace driver (scripts/03_run_traces.py).
            # Implements .cursorrules dense-comment policy for src/ code.
            raise RuntimeError(f"Unknown --model {args.model!r}")

    if args.expect_total is None and (n_ctx_sweep or kv_cache_sweep):
        probe_model = models[0] if models else {}
        n_ctx_probe = _n_ctx_values_for_run(
            tracing_cfg,
            probe_model,
            sweep=n_ctx_sweep,
        )
        per_model = _expected_v1_trace_runs(
            prompts,
            kv_subset_ids,
            n_ctx_probe,
            tracing_cfg,
            kv_cache_sweep=kv_cache_sweep,
        )
        expect_total = per_model * len(models)

    # Python line: agentk_root = repo / "third_party" / "agentk"
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    agentk_root = repo / "third_party" / "agentk"
    # Python line: base_url = f"http://{args.host}:{args.port}/legacy"
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    base_url = f"http://{args.host}:{args.port}/v1"
    # Python line: completed = 0
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    completed = 0
    # Python line: skipped = 0
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    skipped = 0
    # Python line: failed = 0
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    failed = 0

    # Python line: done_at_start = count_complete_traces(
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    done_at_start = (
        count_complete_traces_glob(trace_root=trace_root, model_ids=inventory_model_ids)
        if (n_ctx_sweep or kv_cache_sweep)
        else count_complete_traces(
            trace_root=trace_root,
            model_ids=inventory_model_ids,
            prompt_ids=inventory_prompt_ids,
        )
    )
    # Python line: print(f"Batch progress at start: {done_at_start}/{expect_total}")
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    print(f"Batch progress at start: {done_at_start}/{expect_total}")

    # Python line: for model in models:
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    for model in models:
        # Python line: print(f"\n=== Agent LLM: {model['id']} ===")
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        print(f"\n=== Agent LLM: {model['id']} ===")
        # Python line: log_path = repo / "artifacts" / f"llama_server_{model['id']}.log"
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        log_path = repo / "artifacts" / f"llama_server_{model['id']}.log"
        # Python line: log_path.parent.mkdir(parents=True, exist_ok=True)
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        log_path.parent.mkdir(parents=True, exist_ok=True)
        n_ctx_values = _n_ctx_values_for_run(
            tracing_cfg,
            model,
            sweep=n_ctx_sweep,
        )
        cache_k_values, cache_v_values = _v1_cartesian_kv_axes(
            tracing_cfg,
            model,
            sweep=kv_cache_sweep,
        )
        for n_ctx in n_ctx_values:
            if n_ctx_sweep:
                print(f"  --- n_ctx={n_ctx} ---")
            for cache_type_k in cache_k_values:
                for cache_type_v in cache_v_values:
                    run_prompts = _prompts_for_kv_combo(
                        prompts,
                        cache_type_k=cache_type_k,
                        cache_type_v=cache_type_v,
                        kv_subset_ids=kv_subset_ids,
                        kv_cache_sweep=kv_cache_sweep,
                        baseline_k=baseline_k,
                        baseline_v=baseline_v,
                    )
                    if not run_prompts:
                        continue
                    if kv_cache_sweep:
                        print(
                            f"    --- cache_k={cache_type_k} "
                            f"cache_v={cache_type_v} ({len(run_prompts)} prompts) ---"
                        )
                    kill_stray_llama_servers()
                    server = _start_llama_server(
                        gguf_path=model["gguf_path"],
                        model_alias=model["model_alias"],
                        host=args.host,
                        port=args.port,
                        n_ctx=n_ctx,
                        n_gpu_layers=int(model.get("n_gpu_layers", -1)),
                        log_path=log_path,
                        cache_type_k=cache_type_k,
                        cache_type_v=cache_type_v,
                    )
                    model_run_cfg = {
                        **model,
                        "n_ctx": n_ctx,
                        "cache_type_k": cache_type_k,
                        "cache_type_v": cache_type_v,
                    }
                    try:
                        # Python line: _reset_agentk_modules()
                        # trace driver (scripts/03_run_traces.py).
                        # Implements .cursorrules dense-comment policy for src/ code.
                        _reset_agentk_modules()
                        # Python line: agentk_path = str(agentk_root)
                        # trace driver (scripts/03_run_traces.py).
                        # Implements .cursorrules dense-comment policy for src/ code.
                        agentk_path = str(agentk_root)
                        # Python line: if agentk_path not in sys.path:
                        # trace driver (scripts/03_run_traces.py).
                        # Implements .cursorrules dense-comment policy for src/ code.
                        if agentk_path not in sys.path:
                            # Python line: sys.path.insert(0, agentk_path)
                            # trace driver (scripts/03_run_traces.py).
                            # Implements .cursorrules dense-comment policy for src/ code.
                            sys.path.insert(0, agentk_path)

                        # Python line: os.environ["ACTIVE_ENV"] = "local"
                        # trace driver (scripts/03_run_traces.py).
                        # Implements .cursorrules dense-comment policy for src/ code.
                        os.environ["ACTIVE_ENV"] = "local"
                        # Python line: os.environ["LOCAL_BASE_URL"] = base_url
                        # trace driver (scripts/03_run_traces.py).
                        # Implements .cursorrules dense-comment policy for src/ code.
                        os.environ["LOCAL_BASE_URL"] = base_url
                        # Python line: os.environ["LOCAL_MODEL"] = model["model_alias"]
                        # trace driver (scripts/03_run_traces.py).
                        # Implements .cursorrules dense-comment policy for src/ code.
                        os.environ["LOCAL_MODEL"] = model["model_alias"]
                        # Python line: os.environ["LOCAL_API_KEY"] = "not-needed"
                        # trace driver (scripts/03_run_traces.py).
                        # Implements .cursorrules dense-comment policy for src/ code.
                        os.environ["LOCAL_API_KEY"] = "not-needed"
                        # Python line: os.environ["PATH"] = f"/usr/local/cuda/bin:{os.environ.get('PATH', '')}"
                        # trace driver (scripts/03_run_traces.py).
                        # Implements .cursorrules dense-comment policy for src/ code.
                        os.environ["PATH"] = f"/usr/local/cuda/bin:{os.environ.get('PATH', '')}"

                        # Python line: session = TraceSession(vram=VramSampler(interval_ms=interval_ms))
                        # trace driver (scripts/03_run_traces.py).
                        # Implements .cursorrules dense-comment policy for src/ code.
                        session = TraceSession(vram=build_vram_sampler(tracing_cfg["vram_sampling"]))
                        # Python line: agentk_app = build_traced_agentk_app(session=session, max_retries=retry_budget)
                        # trace driver (scripts/03_run_traces.py).
                        # Implements .cursorrules dense-comment policy for src/ code.
                        agentk_app = build_traced_agentk_app(session=session, max_retries=retry_budget)

                        # Python line: for prompt_row in prompts:
                        # trace driver (scripts/03_run_traces.py).
                        # Implements .cursorrules dense-comment policy for src/ code.
                        for prompt_row in run_prompts:
                            # Python line: prompt_id = str(prompt_row["id"])
                            # trace driver (scripts/03_run_traces.py).
                            # Implements .cursorrules dense-comment policy for src/ code.
                            prompt_id = str(prompt_row["id"])
                            # Python line: out_path = trace_root / model["id"] / f"{prompt_id}.jsonl"
                            # trace driver (scripts/03_run_traces.py).
                            # Implements .cursorrules dense-comment policy for src/ code.
                            out_path = _trace_output_path(
                                trace_root,
                                model["id"],
                                prompt_id,
                                n_ctx,
                                cache_type_k,
                                cache_type_v,
                                n_ctx_sweep=n_ctx_sweep,
                                kv_cache_sweep=kv_cache_sweep,
                            )
                            # Python line: if args.resume and trace_is_complete(out_path):
                            # trace driver (scripts/03_run_traces.py).
                            # Implements .cursorrules dense-comment policy for src/ code.
                            if args.resume and trace_is_complete(out_path):
                                # Python line: skipped += 1
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                skipped += 1
                                # Python line: continue
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                continue
                            # Python line: elif args.resume and out_path.exists():
                            # trace driver (scripts/03_run_traces.py).
                            # Implements .cursorrules dense-comment policy for src/ code.
                            elif args.resume and out_path.exists():
                                # Python line: out_path.unlink()
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                out_path.unlink()
                                # Python line: delete_cuda_sidecar(
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                delete_cuda_sidecar(
                                    repo_root=repo,
                                    agent_llm=model["id"],
                                    prompt_id=prompt_id,
                                )

                            # Python line: print(
                            # trace driver (scripts/03_run_traces.py).
                            # Implements .cursorrules dense-comment policy for src/ code.
                            print(
                                # Python line: f"  [{done_at_start + completed + 1}/{expect_total}] "
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                f"  [{done_at_start + completed + 1}/{expect_total}] "
                                # Python line: f"trace {model['id']}/{prompt_id} ... ",
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                f"trace {model['id']}/{prompt_id}"
                                + (f" ctx={n_ctx}" if n_ctx_sweep else "")
                                + (
                                    f" k={cache_type_k} v={cache_type_v}"
                                    if kv_cache_sweep
                                    else ""
                                )
                                + " ... ",
                                # Python line: end="",
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                end="",
                                # Python line: flush=True,
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                flush=True,
                            # Python line: )
                            # trace driver (scripts/03_run_traces.py).
                            # Implements .cursorrules dense-comment policy for src/ code.
                            )
                            disk_ok, disk_msg = check_disk_guard_batch()
                            if not disk_ok:
                                print(disk_msg)
                                write_progress(
                                    progress_path=progress_path,
                                    completed_total=done_at_start + completed,
                                    expect_total=expect_total,
                                    model_id=str(model["id"]),
                                    prompt_id=prompt_id,
                                    status="disk_guard_halt",
                                    extra={"disk_guard": disk_msg},
                                )
                                return 2
                            # Python line: try:
                            # trace driver (scripts/03_run_traces.py).
                            # Implements .cursorrules dense-comment policy for src/ code.
                            try:
                                # Python line: metadata = build_run_metadata(
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                metadata = build_run_metadata(
                                    # Python line: agent_llm_id=model["id"],
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    agent_llm_id=model["id"],
                                    # Python line: prompt_id=prompt_id,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    prompt_id=prompt_id,
                                    # Python line: model_cfg=model,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    model_cfg=model_run_cfg,
                                    # Python line: seed=seed,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    seed=seed,
                                    # Python line: calibration_path=repo / "configs" / "q4_vram_calibration.yaml",
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    calibration_path=repo / "configs" / "q4_vram_calibration.yaml",
                                # Python line: )
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                )
                                # Python line: metadata["prompt_split"] = prompt_row.get("split")
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                metadata["prompt_split"] = prompt_row.get("split")
                                # Python line: metadata["prompt_source"] = prompt_row.get("source")
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                metadata["prompt_source"] = prompt_row.get("source")
                                metadata["n_ctx"] = int(n_ctx)
                                metadata["cache_type_k"] = cache_type_k
                                metadata["cache_type_v"] = cache_type_v

                                # Python line: final_state = run_traced_agentk(
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                final_state = run_traced_agentk(
                                    # Python line: agentk_app=agentk_app,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    agentk_app=agentk_app,
                                    # Python line: prompt=str(prompt_row["prompt"]),
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    prompt=str(prompt_row["prompt"]),
                                    # Python line: session=session,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    session=session,
                                    # Python line: timeout_sec=timeout_sec,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    timeout_sec=timeout_sec,
                                    vram_sidecar_path=nvidia_smi_sidecar_path(out_path),
                                )
                                # Python line: labels = compute_ground_truth_labels(session)
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                labels = compute_ground_truth_labels(session)
                                # Python line: write_trace_jsonl(
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                write_trace_jsonl(
                                    # Python line: output_path=out_path,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    output_path=out_path,
                                    # Python line: metadata=metadata,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    metadata=metadata,
                                    # Python line: session=session,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    session=session,
                                    # Python line: final_state=final_state,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    final_state=final_state,
                                    # Python line: labels=labels,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    labels=labels,
                                # Python line: )
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                )
                                # Python line: completed += 1
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                completed += 1
                                # Python line: done_now = done_at_start + completed
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                done_now = done_at_start + completed
                                # Python line: ok = bool(final_state.get("compilation_success"))
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                ok = bool(final_state.get("compilation_success"))
                                # Python line: status = "ok" if ok else "compile_fail"
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                if session.timeout:
                                    # Python line: status = "timeout"
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    status = "timeout"
                                elif session.oom:
                                    # Python line: status = "oom"
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    status = "oom"
                                else:
                                    # Python line: status = "ok" if ok else "compile_fail"
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    status = "ok" if ok else "compile_fail"
                                # Python line: write_progress(
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                write_progress(
                                    # Python line: progress_path=progress_path,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    progress_path=progress_path,
                                    # Python line: completed_total=done_now,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    completed_total=done_now,
                                    # Python line: expect_total=expect_total,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    expect_total=expect_total,
                                    # Python line: model_id=str(model["id"]),
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    model_id=str(model["id"]),
                                    # Python line: prompt_id=prompt_id,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    prompt_id=prompt_id,
                                    # Python line: status=status,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    status=status,
                                    # Python line: extra={
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    extra={
                                        # Python line: "N_true": labels.get("N_true"),
                                        # trace driver (scripts/03_run_traces.py).
                                        # Implements .cursorrules dense-comment policy for src/ code.
                                        "N_true": labels.get("N_true"),
                                        # Python line: "M_peak_true": labels.get("M_peak_true"),
                                        # trace driver (scripts/03_run_traces.py).
                                        # Implements .cursorrules dense-comment policy for src/ code.
                                        "M_peak_true": labels.get("M_peak_true"),
                                        # Python line: "compile_success": ok,
                                        # trace driver (scripts/03_run_traces.py).
                                        # Implements .cursorrules dense-comment policy for src/ code.
                                        "compile_success": ok,
                                        # Python line: "timeout": session.timeout,
                                        # trace driver (scripts/03_run_traces.py).
                                        # Implements .cursorrules dense-comment policy for src/ code.
                                        "timeout": session.timeout,
                                        # Python line: "oom": session.oom,
                                        # trace driver (scripts/03_run_traces.py).
                                        # Implements .cursorrules dense-comment policy for src/ code.
                                        "oom": session.oom,
                                    # Python line: },
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    },
                                # Python line: )
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                )
                                if "traces_v2" in str(trace_root):
                                    subprocess.run(
                                        [
                                            sys.executable,
                                            str(repo / "scripts" / "write_trace_v2_snapshot.py"),
                                            "--quiet",
                                        ],
                                        cwd=repo,
                                        check=False,
                                    )
                                # Python line: print(
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                print(
                                    # Python line: f"{status.upper()} "
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    f"{status.upper()} "
                                    # Python line: f"N={labels['N_true']} M_peak={labels['M_peak_true']:.0f}MB"
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    f"N={labels['N_true']} M_peak={labels['M_peak_true']:.0f}MB"
                                # Python line: )
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                )
                                # Python line: release_gpu_memory()
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                release_gpu_memory()
                            # Python line: except Exception as exc:
                            # trace driver (scripts/03_run_traces.py).
                            # Implements .cursorrules dense-comment policy for src/ code.
                            except Exception as exc:
                                # Python line: failed += 1
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                failed += 1
                                # Python line: print(f"DRIVER_ERROR {exc!r}")
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                print(f"DRIVER_ERROR {exc!r}")
                                # Python line: write_progress(
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                write_progress(
                                    # Python line: progress_path=progress_path,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    progress_path=progress_path,
                                    # Python line: completed_total=done_at_start + completed,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    completed_total=done_at_start + completed,
                                    # Python line: expect_total=expect_total,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    expect_total=expect_total,
                                    # Python line: model_id=str(model["id"]),
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    model_id=str(model["id"]),
                                    # Python line: prompt_id=prompt_id,
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    prompt_id=prompt_id,
                                    # Python line: status="driver_error",
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    status="driver_error",
                                    # Python line: extra={"error": str(exc)},
                                    # trace driver (scripts/03_run_traces.py).
                                    # Implements .cursorrules dense-comment policy for src/ code.
                                    extra={"error": str(exc)},
                                # Python line: )
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                )
                                # Python line: release_gpu_memory()
                                # trace driver (scripts/03_run_traces.py).
                                # Implements .cursorrules dense-comment policy for src/ code.
                                release_gpu_memory()
                    # Python line: finally:
                    # trace driver (scripts/03_run_traces.py).
                    # Implements .cursorrules dense-comment policy for src/ code.
                    finally:
                        # Python line: _stop_process(server)
                        # trace driver (scripts/03_run_traces.py).
                        # Implements .cursorrules dense-comment policy for src/ code.
                        _stop_process(server)
                        # Python line: release_gpu_memory()
                        # trace driver (scripts/03_run_traces.py).
                        # Implements .cursorrules dense-comment policy for src/ code.
                        release_gpu_memory()
                        # Python line: time.sleep(5)
                        # trace driver (scripts/03_run_traces.py).
                        # Implements .cursorrules dense-comment policy for src/ code.
                        time.sleep(5)

    # Python line: done_final = count_complete_traces(
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    done_final = (
        count_complete_traces_glob(trace_root=trace_root, model_ids=inventory_model_ids)
        if (n_ctx_sweep or kv_cache_sweep)
        else count_complete_traces(
            trace_root=trace_root,
            model_ids=inventory_model_ids,
            prompt_ids=inventory_prompt_ids,
        )
    )
    # Python line: print(
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    print(
        # Python line: f"\nDone: completed_this_pass={completed}, skipped={skipped}, "
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        f"\nDone: completed_this_pass={completed}, skipped={skipped}, "
        # Python line: f"driver_errors={failed}, total_complete={done_final}/{expect_total}"
        # trace driver (scripts/03_run_traces.py).
        # Implements .cursorrules dense-comment policy for src/ code.
        f"driver_errors={failed}, total_complete={done_final}/{expect_total}"
    # Python line: )
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    )
    # Python line: return 0 if done_final >= expect_total else 1
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    return 0 if done_final >= expect_total else 1


# Python line: if __name__ == "__main__":
# trace driver (scripts/03_run_traces.py).
# Implements .cursorrules dense-comment policy for src/ code.
if __name__ == "__main__":
    # Python line: raise SystemExit(main())
    # trace driver (scripts/03_run_traces.py).
    # Implements .cursorrules dense-comment policy for src/ code.
    raise SystemExit(main())
