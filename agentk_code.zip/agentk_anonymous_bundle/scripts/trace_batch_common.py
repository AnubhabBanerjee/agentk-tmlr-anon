#!/usr/bin/env python3
"""
Shared helpers for Phase 3.3 batch tracing (1800 runs = 3 models × 600 prompts).

Used by 03_run_traces.py, preflight_trace_batch.py, and watch_trace_batch.sh.
"""

# Python line: from __future__ import annotations
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
from __future__ import annotations

# json parses trace JSONL rows when checking completion.
# Python line: import json
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
import json
# shutil reports /workspace free bytes for the Part-2 disk guard.
import shutil
# signal sends SIGTERM to stray llama.cpp server subprocesses.
# Python line: import signal
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
import signal
# subprocess finds PIDs for llama_cpp.server via pgrep.
# Python line: import subprocess
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
import subprocess
# sys.path is mutated so lazy ``src.tracing`` imports resolve from the repo root.
import sys
# time stamps progress.json updates for stall detection.
# Python line: import time
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
import time
# Path resolves repo root, trace dirs, and progress artifact paths.
# Python line: from pathlib import Path
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
from pathlib import Path
# typing annotates model/prompt dicts and progress payload types.
# Python line: from typing import Any, Dict, List, Optional, Tuple
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
from typing import Any, Dict, List, Optional, Tuple

# yaml loads agent_llms.yaml when enumerating the three backend models.
# Python line: import yaml
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
import yaml


def _ensure_repo_on_sys_path(anchor: Path) -> None:
    """
    Put the repository root at ``sys.path[0]`` so ``src.tracing`` imports resolve.

    AgentK is also inserted at position 0 during tracing; both packages use a
  top-level ``src`` tree, so the repo must stay ahead of KC on ``sys.path``.
    """
    for parent in [anchor, *anchor.parents]:
        if (parent / "src" / "tracing").is_dir():
            repo_str = str(parent.resolve())
            sys.path[:] = [entry for entry in sys.path if entry != repo_str]
            sys.path.insert(0, repo_str)
            return


# Part-2 §A1 disk guard thresholds on ``/workspace`` (see step_by_step_execution_guide_part2.md).
DISK_GUARD_WORKSPACE = Path("/workspace")
DISK_GUARD_ABORT_BYTES = 15 * 1024**3
DISK_GUARD_HALT_BYTES = 10 * 1024**3

# Guide §3.3: three agent LLMs × six hundred prompts.
# Python line: EXPECTED_TOTAL_RUNS: int = 1800
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
EXPECTED_TOTAL_RUNS: int = 1800

# Part-2 v2 base tracing: four agents × three hundred prompts.
EXPECTED_V2_BASE_RUNS: int = 1200

# llama-cpp-python KV cache GGML type integers (--type_k / --type_v).
# Python line: _LLAMA_CPP_KV_TYPE_ID: Dict[str, int] = {
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
_LLAMA_CPP_KV_TYPE_ID: Dict[str, int] = {
    # Python line: "f16": 1,
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    "f16": 1,
    # Python line: "fp16": 1,
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    "fp16": 1,
    # Python line: "bf16": 1,
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    "bf16": 1,
    # Python line: "q8_0": 8,
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    "q8_0": 8,
    # Python line: "q4_0": 2,
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    "q4_0": 2,
# Python line: }
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
}


# Python line: def llama_cpp_kv_type_id(cache_type: str) -> Optional[int]:
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def llama_cpp_kv_type_id(cache_type: str) -> Optional[int]:
    """Return llama-cpp-python --type_k/--type_v integer (no src.forecast import)."""
    # Python line: key = str(cache_type).strip().lower()
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    key = str(cache_type).strip().lower()
    # Python line: return _LLAMA_CPP_KV_TYPE_ID.get(key)
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return _LLAMA_CPP_KV_TYPE_ID.get(key)


# Python line: def repo_root_from_here() -> Path:
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def repo_root_from_here() -> Path:
    """Return repository root assuming this file lives under scripts/."""
    # Python line: return Path(__file__).resolve().parents[1]
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return Path(__file__).resolve().parents[1]


# Python line: def load_prompt_rows(all_jsonl: Path) -> List[Dict[str, Any]]:
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def load_prompt_rows(all_jsonl: Path) -> List[Dict[str, Any]]:
    """Load every prompt row from data/prompts/all.jsonl."""
    # Python line: rows: List[Dict[str, Any]] = []
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    rows: List[Dict[str, Any]] = []
    # Python line: with all_jsonl.open("r", encoding="utf-8") as handle:
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    with all_jsonl.open("r", encoding="utf-8") as handle:
        # Python line: for line in handle:
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        for line in handle:
            # Python line: stripped = line.strip()
            # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
            # Implements .cursorrules dense-comment policy for Python code.
            stripped = line.strip()
            # Python line: if stripped:
            # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
            # Implements .cursorrules dense-comment policy for Python code.
            if stripped:
                # Python line: rows.append(json.loads(stripped))
                # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
                # Implements .cursorrules dense-comment policy for Python code.
                rows.append(json.loads(stripped))
    # Python line: return rows
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return rows


# Python line: def load_model_ids(agent_yaml: Path) -> List[str]:
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def load_model_ids(agent_yaml: Path) -> List[str]:
    """Return ordered agent LLM ids from configs/agent_llms.yaml."""
    # Python line: data = yaml.safe_load(agent_yaml.read_text(encoding="utf-8"))
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    data = yaml.safe_load(agent_yaml.read_text(encoding="utf-8"))
    # Python line: return list(data["models"].keys())
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return list(data["models"].keys())


# Python line: def trace_is_complete(trace_path: Path) -> bool:
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def trace_is_complete(trace_path: Path) -> bool:
    """True when JSONL has summary and CUDA sidecar rules for §3.5 are satisfied."""
    # Python line: if not trace_path.is_file():
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if not trace_path.is_file():
        # Python line: return False
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        return False
    # Python line: metadata: dict | None = None
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    metadata: dict | None = None
    # Python line: summary: dict | None = None
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    summary: dict | None = None
    # Python line: try:
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    try:
        _ensure_repo_on_sys_path(trace_path)
        from src.tracing.vram_join import iter_trace_jsonl

        for row in iter_trace_jsonl(trace_path):
            rec = row.get("record")
            if rec == "metadata":
                metadata = row
            elif rec == "summary":
                summary = row
    except (json.JSONDecodeError, OSError, ValueError):
        # Python line: return False
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        return False
    # Python line: if summary is None:
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if summary is None:
        # Python line: return False
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        return False
    # Python line: prompt_source = str((metadata or {}).get("prompt_source", ""))
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    prompt_source = str((metadata or {}).get("prompt_source", ""))
    # Python line: compile_success = bool(summary.get("compile_success", False))
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    compile_success = bool(summary.get("compile_success", False))
    # Python line: if prompt_source == "kernelbench" and compile_success:
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if prompt_source == "kernelbench" and compile_success:
        # Python line: sidecar_rel = summary.get("cuda_sidecar")
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        sidecar_rel = summary.get("cuda_sidecar")
        # Python line: if not sidecar_rel:
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        if not sidecar_rel:
            # Python line: return False
            # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
            # Implements .cursorrules dense-comment policy for Python code.
            return False
        # Python line: repo_root = trace_path.parents[3]
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        repo_root = trace_path.parents[3]
        # Python line: sidecar_path = repo_root / str(sidecar_rel)
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        sidecar_path = repo_root / str(sidecar_rel)
        # Python line: if not sidecar_path.is_file() or sidecar_path.stat().st_size == 0:
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        if not sidecar_path.is_file() or sidecar_path.stat().st_size == 0:
            # Python line: return False
            # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
            # Implements .cursorrules dense-comment policy for Python code.
            return False
    # Python line: return True
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return True


# Python line: def count_complete_traces(
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def count_complete_traces(
    *,
    trace_root: Path,
    model_ids: List[str],
    prompt_ids: List[str],
) -> int:
    """Count (model, prompt) pairs with a complete summary JSONL on disk."""
    _ensure_repo_on_sys_path(trace_root)
    from src.tracing.vram_join import resolve_trace_jsonl_path

    done = 0
    for model_id in model_ids:
        for prompt_id in prompt_ids:
            path = resolve_trace_jsonl_path(trace_root / model_id / prompt_id)
            if path is not None and trace_is_complete(path):
                # Python line: done += 1
                # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
                # Implements .cursorrules dense-comment policy for Python code.
                done += 1
    # Python line: return done
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return done


def workspace_disk_free_bytes() -> int:
    """Return free bytes on ``/workspace`` (falls back to repo root if missing)."""
    root = DISK_GUARD_WORKSPACE if DISK_GUARD_WORKSPACE.is_dir() else repo_root_from_here()
    return shutil.disk_usage(str(root)).free


def workspace_disk_free_gb() -> float:
    """Return free GiB on ``/workspace`` for preflight reporting."""
    return workspace_disk_free_bytes() / (1024**3)


def check_disk_guard_preflight() -> Optional[str]:
    """
    Preflight abort when ``/workspace`` free disk is below 15 GiB.

    Returns an error message, or None when the guard passes.
    """
    free = workspace_disk_free_bytes()
    if free < DISK_GUARD_ABORT_BYTES:
        free_gb = free / (1024**3)
        need_gb = DISK_GUARD_ABORT_BYTES / (1024**3)
        return f"/workspace disk free {free_gb:.1f} GiB < {need_gb:.0f} GiB abort threshold"
    return None


def check_disk_guard_batch() -> Tuple[bool, str]:
    """
    Per-batch halt when ``/workspace`` free disk drops below 10 GiB.

    Returns ``(True, "")`` when safe to continue; otherwise ``(False, warning)``.
    """
    free = workspace_disk_free_bytes()
    if free < DISK_GUARD_HALT_BYTES:
        free_gb = free / (1024**3)
        need_gb = DISK_GUARD_HALT_BYTES / (1024**3)
        return (
            False,
            f"DISK GUARD HALT: /workspace free {free_gb:.1f} GiB < {need_gb:.0f} GiB — "
            "batch stopped to avoid filling the disk",
        )
    return True, ""


def count_complete_base_traces_glob(
    *,
    trace_root: Path,
    model_ids: List[str],
) -> int:
    """Count complete v2 base traces only (``{agent}/{prompt}.jsonl.zst``, not ``sweep/``)."""
    done = 0
    for model_id in model_ids:
        model_dir = trace_root / model_id
        if not model_dir.is_dir():
            continue
        for pattern in ("*.jsonl.zst", "*.jsonl"):
            for path in model_dir.glob(pattern):
                if trace_is_complete(path):
                    done += 1
    return done


def count_complete_sweep_traces_glob(
    *,
    trace_root: Path,
    model_ids: List[str],
) -> int:
    """Count complete v2 sweep traces only (``{agent}/sweep/*.jsonl.zst``)."""
    done = 0
    for model_id in model_ids:
        sweep_dir = trace_root / model_id / "sweep"
        if not sweep_dir.is_dir():
            continue
        for path in sweep_dir.glob("*.jsonl.zst"):
            if trace_is_complete(path):
                done += 1
        for path in sweep_dir.glob("*.jsonl"):
            if path.name.endswith(".jsonl.zst"):
                continue
            if trace_is_complete(path):
                done += 1
    return done


def count_complete_traces_glob(
    *,
    trace_root: Path,
    model_ids: List[str],
) -> int:
    """Count complete JSONL traces under ``trace_root`` (v2 base + sweep/ layouts)."""
    done = 0
    for model_id in model_ids:
        model_dir = trace_root / model_id
        if not model_dir.is_dir():
            continue
        for path in model_dir.glob("*.jsonl.zst"):
            if trace_is_complete(path):
                done += 1
        for path in model_dir.glob("*.jsonl"):
            if path.name.endswith(".jsonl.zst"):
                continue
            if trace_is_complete(path):
                done += 1
        sweep_dir = model_dir / "sweep"
        if sweep_dir.is_dir():
            for path in sweep_dir.glob("*.jsonl.zst"):
                if trace_is_complete(path):
                    done += 1
            for path in sweep_dir.glob("*.jsonl"):
                if path.name.endswith(".jsonl.zst"):
                    continue
                if trace_is_complete(path):
                    done += 1
    return done


def expected_v2_sweep_total(
    repo: Path,
    *,
    agent_config: Path,
    tracing_config: Path,
) -> int:
    """Return expected Part-2 v2 trace count (base + 3-corner sweep = 1920 at full scale)."""
    import importlib.util
    import sys

    repo_str = str(repo.resolve())
    if repo_str not in sys.path:
        sys.path.insert(0, repo_str)

    spec = importlib.util.spec_from_file_location(
        "run_traces",
        repo / "scripts" / "03_run_traces.py",
    )
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load scripts/03_run_traces.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    tracing_cfg = mod._load_tracing_config(tracing_config.resolve())
    prompts_path = mod._prompts_jsonl_path(repo, tracing_cfg)
    prompts = mod._load_prompts(prompts_path)
    model_ids = load_model_ids(agent_config)

    from src.tracing.sweep_plan import (
        count_v2_trace_runs,
        enumerate_v2_trace_runs,
        load_v2_sweep_config,
        sweep_subset_prompt_ids,
    )

    seed = int(tracing_cfg["split"]["seed"])
    sweep_cfg = load_v2_sweep_config(tracing_cfg)
    subset_ids = sweep_subset_prompt_ids(
        prompts,
        total=sweep_cfg.sweep_subset_prompts,
        seed=seed,
    )
    runs = enumerate_v2_trace_runs(
        model_ids=model_ids,
        prompt_rows=prompts,
        sweep_cfg=sweep_cfg,
        sweep_prompt_ids=subset_ids,
    )
    _, _, formula_total = count_v2_trace_runs(
        n_agents=len(model_ids),
        n_prompts=len(prompts),
        sweep_cfg=sweep_cfg,
    )
    if len(runs) != formula_total:
        raise RuntimeError(
            f"v2 run-plan mismatch: enumerated {len(runs)} != formula {formula_total}"
        )
    return len(runs)


def load_sweep_agent_ids(tracing_config: Path) -> List[str]:
    """Return ordered sweep-subset agent ids from ``configs/tracing_v2.yaml``."""
    _ensure_repo_on_sys_path(tracing_config)
    tracing_cfg = yaml.safe_load(tracing_config.read_text(encoding="utf-8"))
    from src.tracing.sweep_plan import load_v2_sweep_config

    sweep_cfg = load_v2_sweep_config(tracing_cfg)
    return sorted(sweep_cfg.sweep_subset_agents)


def expected_v2_sweep_only_total(
    repo: Path,
    *,
    agent_config: Path,
    tracing_config: Path,
) -> int:
    """Return expected Part-2 v2 sweep trace count (720 at full scale)."""
    import importlib.util
    import sys

    repo_str = str(repo.resolve())
    if repo_str not in sys.path:
        sys.path.insert(0, repo_str)

    spec = importlib.util.spec_from_file_location(
        "run_traces",
        repo / "scripts" / "03_run_traces.py",
    )
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load scripts/03_run_traces.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    tracing_cfg = mod._load_tracing_config(tracing_config.resolve())
    prompts_path = mod._prompts_jsonl_path(repo, tracing_cfg)
    prompts = mod._load_prompts(prompts_path)
    model_ids = load_model_ids(agent_config)

    from src.tracing.sweep_plan import count_v2_trace_runs, load_v2_sweep_config

    sweep_cfg = load_v2_sweep_config(tracing_cfg)
    _, sweep, _ = count_v2_trace_runs(
        n_agents=len(model_ids),
        n_prompts=len(prompts),
        sweep_cfg=sweep_cfg,
    )
    return sweep


def expected_v2_base_total(
    repo: Path,
    *,
    agent_config: Path,
    tracing_config: Path,
) -> int:
    """Return expected Part-2 v2 base trace count (4 agents × 300 prompts = 1200)."""
    import importlib.util
    import sys

    repo_str = str(repo.resolve())
    if repo_str not in sys.path:
        sys.path.insert(0, repo_str)

    spec = importlib.util.spec_from_file_location(
        "run_traces",
        repo / "scripts" / "03_run_traces.py",
    )
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load scripts/03_run_traces.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    tracing_cfg = mod._load_tracing_config(tracing_config.resolve())
    prompts_path = mod._prompts_jsonl_path(repo, tracing_cfg)
    prompts = mod._load_prompts(prompts_path)
    model_ids = load_model_ids(agent_config)

    from src.tracing.sweep_plan import count_v2_trace_runs, load_v2_sweep_config

    sweep_cfg = load_v2_sweep_config(tracing_cfg)
    base, _, _ = count_v2_trace_runs(
        n_agents=len(model_ids),
        n_prompts=len(prompts),
        sweep_cfg=sweep_cfg,
    )
    return base


# Python line: def write_progress(
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def write_progress(
    *,
    progress_path: Path,
    completed_total: int,
    expect_total: int,
    model_id: str,
    prompt_id: str,
    status: str,
    extra: Optional[Dict[str, Any]] = None,
) -> None:
    """Atomically persist batch progress for the watcher (flush after each run)."""
    # Python line: progress_path.parent.mkdir(parents=True, exist_ok=True)
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    progress_path.parent.mkdir(parents=True, exist_ok=True)
    # Python line: payload: Dict[str, Any] = {
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    payload: Dict[str, Any] = {
        # Python line: "timestamp_unix": time.time(),
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "timestamp_unix": time.time(),
        # Python line: "completed_total": completed_total,
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "completed_total": completed_total,
        # Python line: "expect_total": expect_total,
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "expect_total": expect_total,
        # Python line: "last_model_id": model_id,
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "last_model_id": model_id,
        # Python line: "last_prompt_id": prompt_id,
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "last_prompt_id": prompt_id,
        # Python line: "last_status": status,
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        "last_status": status,
    # Python line: }
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    }
    # Python line: if extra:
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if extra:
        # Python line: payload.update(extra)
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        payload.update(extra)
    # Python line: tmp = progress_path.with_suffix(".tmp")
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    tmp = progress_path.with_suffix(".tmp")
    # Python line: tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    # Python line: tmp.replace(progress_path)
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    tmp.replace(progress_path)


# Python line: def kill_stray_llama_servers() -> int:
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def kill_stray_llama_servers() -> int:
    """SIGTERM any llama_cpp.server PIDs; return count killed."""
    # Python line: killed = 0
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    killed = 0
    # Python line: try:
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    try:
        # Python line: out = subprocess.check_output(
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        out = subprocess.check_output(
            # Python line: ["pgrep", "-f", "llama_cpp.server"],
            # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
            # Implements .cursorrules dense-comment policy for Python code.
            ["pgrep", "-f", "llama_cpp.server"],
            # Python line: text=True,
            # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
            # Implements .cursorrules dense-comment policy for Python code.
            text=True,
        # Python line: )
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        )
    # Python line: except subprocess.CalledProcessError:
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    except subprocess.CalledProcessError:
        # Python line: return 0
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        return 0
    # Python line: for line in out.splitlines():
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    for line in out.splitlines():
        # Python line: pid = int(line.strip())
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        pid = int(line.strip())
        # Python line: try:
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        try:
            # Python line: import os
            # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
            # Implements .cursorrules dense-comment policy for Python code.
            import os

            # Python line: os.kill(pid, signal.SIGTERM)
            # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
            # Implements .cursorrules dense-comment policy for Python code.
            os.kill(pid, signal.SIGTERM)
            # Python line: killed += 1
            # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
            # Implements .cursorrules dense-comment policy for Python code.
            killed += 1
        # Python line: except ProcessLookupError:
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        except ProcessLookupError:
            # Python line: pass
            # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
            # Implements .cursorrules dense-comment policy for Python code.
            pass
    # Python line: if killed:
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if killed:
        # Python line: time.sleep(3)
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        time.sleep(3)
    # Python line: return killed
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return killed


# Python line: def release_gpu_memory() -> None:
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def release_gpu_memory() -> None:
    """Best-effort Python GC + CUDA cache flush between model loads."""
    # Python line: import gc
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    import gc

    # Python line: gc.collect()
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    gc.collect()
    # Python line: try:
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    try:
        # Python line: import torch
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        import torch

        # Python line: if torch.cuda.is_available():
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        if torch.cuda.is_available():
            # Python line: torch.cuda.empty_cache()
            # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
            # Implements .cursorrules dense-comment policy for Python code.
            torch.cuda.empty_cache()
            # Python line: torch.cuda.synchronize()
            # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
            # Implements .cursorrules dense-comment policy for Python code.
            torch.cuda.synchronize()
    # Python line: except Exception:
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    except Exception:
        # Python line: pass
        # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        pass


# Python line: def batch_inventory(repo: Path) -> Tuple[List[str], List[str], int]:
# Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def batch_inventory(repo: Path) -> Tuple[List[str], List[str], int]:
    """Return (model_ids, prompt_ids, expect_total) for the full §3.3 batch."""
    # Python line: prompts = load_prompt_rows(repo / "data" / "prompts" / "all.jsonl")
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    prompts = load_prompt_rows(repo / "data" / "prompts" / "all.jsonl")
    # Python line: model_ids = load_model_ids(repo / "configs" / "agent_llms.yaml")
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    model_ids = load_model_ids(repo / "configs" / "agent_llms.yaml")
    # Python line: prompt_ids = [str(p["id"]) for p in prompts]
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    prompt_ids = [str(p["id"]) for p in prompts]
    # Python line: expect = len(model_ids) * len(prompt_ids)
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    expect = len(model_ids) * len(prompt_ids)
    # Python line: return model_ids, prompt_ids, expect
    # Phase 3.3 batch tracing helpers (scripts/trace_batch_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return model_ids, prompt_ids, expect
