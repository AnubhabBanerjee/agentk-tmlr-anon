#!/usr/bin/env bash
# Kill hung / 3.5 batch drivers, watchers, and llama.cpp servers.
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

echo "=== Killing batch drivers, watchers, and llama servers ==="

for pattern in \
  "watch_trace_batch.sh" \
  "watch_trace_batch_v2.sh" \
  "watch_trace_batch_v2_base.sh" \
  "03_run_traces.py" \
  "watch_cuda_sidecar_backfill.sh" \
  "backfill_cuda_sidecars.py" \
  "watch_kbench_correctness.sh" \
  "05_run_kernelbench_correctness.py" \
  "run_trace_batch_1800.sh" \
  "run_trace_batch_v2.sh" \
  "run_trace_batch_v2_base.sh" \
  "run_cuda_sidecar_backfill.sh" \
  "run_kbench_correctness.sh"
do
  if pgrep -f "${pattern}" >/dev/null 2>&1; then
    echo "  pkill: ${pattern}"
    pkill -f "${pattern}" || true
  fi
done

sleep 2

python3 - <<'PY'
import sys
from pathlib import Path
sys.path.insert(0, str(Path("scripts").resolve()))
from trace_batch_common import kill_stray_llama_servers
n = kill_stray_llama_servers()
print(f"  kill_stray_llama_servers: {n} process(es)")
PY

sleep 1
echo "Done. Remaining matches (if any):"
pgrep -af "run_traces|backfill_cuda|kernelbench_correctness|watch_trace|watch_cuda|watch_kbench|llama_cpp.server" || echo "  (none)"
