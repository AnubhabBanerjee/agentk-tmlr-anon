#!/usr/bin/env bash
# Run baseline predictors (B0–B5 × agent LLMs).
#
# Default: CONFIG=configs/tracing_v2.yaml → 4 agents, artifacts_v2/
# Skip B4 when no proxy checkpoint exists: SKIP=B4
#
# Suggested nohup launch:
#   nohup env CONFIG=configs/tracing_v2.yaml SKIP=B4 bash scripts/run_baselines.sh \
#     > artifacts_v2/baselines_nohup.log 2>&1 & disown
#
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

CONFIG="${CONFIG:-}"
SKIP="${SKIP:-}"
if [[ -n "${CONFIG}" ]]; then
  export TRACING_CONFIG="${CONFIG}"
  PRED_ROOT="artifacts_v2/predictions"
  BASE_ROOT="artifacts_v2/baselines"
  PROGRESS="artifacts_v2/baselines_progress.json"
  LOG_DEFAULT="artifacts_v2/baselines_nohup.log"
  echo "[baselines] v2 mode CONFIG=${CONFIG} (4 agents)"
else
  PRED_ROOT="artifacts/predictions"
  BASE_ROOT="artifacts/baselines"
  PROGRESS="artifacts/baselines_progress.json"
  LOG_DEFAULT="artifacts/baselines_nohup.log"
  echo "[baselines] v1 mode (3 agents)"
fi

mkdir -p "${PRED_ROOT}" "${BASE_ROOT}"

SKIP_ARGS=()
if [[ -n "${SKIP}" ]]; then
  export SKIP
  echo "[baselines] SKIP=${SKIP}"
  # shellcheck disable=SC2206
  for method in ${SKIP//,/ }; do
    SKIP_ARGS+=(--skip "${method}")
  done
fi

echo "[baselines] start $(date -u +%Y-%m-%dT%H:%M:%SZ)"
python3 scripts/05_train_baselines.py --all --device cuda --progress-json "${PROGRESS}" "${SKIP_ARGS[@]}"
echo "[baselines] done $(date -u +%Y-%m-%dT%H:%M:%SZ)"
