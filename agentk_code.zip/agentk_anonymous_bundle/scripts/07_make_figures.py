#!/usr/bin/env python3
"""render paper figures from evaluation outputs."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch

_REPO = Path(__file__).resolve().parents[1]
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from src.eval.paths import results_layout
from src.viz.figures import generate_all_figures


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments for figure generation."""
    parser = argparse.ArgumentParser(description="Generate paper figures .")
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=Path(__file__).resolve().parents[1],
        help="Repository root directory.",
    )
    parser.add_argument(
        "--dpi",
        type=int,
        default=300,
        help="Figure export resolution in dots per inch.",
    )
    parser.add_argument(
        "--recompute-metrics",
        action="store_true",
        help="Recompute backbone ablation and cross-model metrics before plotting.",
    )
    parser.add_argument(
        "--device",
        type=str,
        default=None,
        help="Torch device (default: cuda if available else cpu).",
    )
    return parser.parse_args()


def main() -> None:
    """Entry point: write six PDFs to paper/figures/."""
    args = parse_args()
    layout = results_layout(args.repo_root)
    device = torch.device(args.device or ("cuda" if torch.cuda.is_available() else "cpu"))
    written = generate_all_figures(
        layout,
        args.repo_root,
        dpi=args.dpi,
        device=device,
        recompute_metrics=args.recompute_metrics,
    )
    print(f"Wrote {len(written)} figures to {layout.figures_dir}:")
    for path in written:
        print(f"  - {path.name}")


if __name__ == "__main__":
    main()
