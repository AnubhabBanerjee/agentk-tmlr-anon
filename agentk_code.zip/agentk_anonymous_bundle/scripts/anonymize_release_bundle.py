#!/usr/bin/env python3
"""
Build an anonymized code mirror at ``artifacts_v2/agentk_anonymous_bundle/``.

Reads ``.anonymization_names`` (untracked) for identity redaction and applies
§0.8 pseudonym substitutions in the bundle copy only — the working tree is untouched.
"""

from __future__ import annotations

import argparse
import logging
import re
import shutil
import stat
import sys
from pathlib import Path
from typing import Iterable, Iterator, Sequence, Set, Tuple

# Configure module-level logging for CLI diagnostics (library code uses logging, not print).
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

# Ordered longest-first so ``agentk`` is not partially consumed by shorter keys.
TEXT_SUBSTITUTIONS: Tuple[Tuple[str, str], ...] = (
    ("AgentK", "AgentK"),
    ("agentk", "agentk"),
    ("agentk", "agentk"),
    ("agentk_llama_compat", "agentk_llama_compat"),
    ("agentk_trace", "agentk_trace"),
    ("agentk", "agentk"),
    ("Agentk", "Agentk"),
)

# Generic ``kc``-prefixed identifiers (variables, functions, env vars) left over from the
# pre-anonymization codename. Matched separately from TEXT_SUBSTITUTIONS because these are
# regex patterns (identifier-boundary-aware), not fixed literal strings: covers cases such
# as ``agentk_root``, ``agentk_app``, ``AGENTK_DIR``, and mid-identifier ``_reset_agentk_modules``/
# ``wrap_agentk_cuda_for_kernelbench`` that the literal substitutions above do not touch.
_AGENTK_MID_LOWER_RE = re.compile(r"_agentk_")
_AGENTK_START_LOWER_RE = re.compile(r"(?<![A-Za-z0-9_])agentk_")
_AGENTK_MID_UPPER_RE = re.compile(r"_AGENTK_")
_AGENTK_START_UPPER_RE = re.compile(r"(?<![A-Za-z0-9_])AGENTK_")

# Top-level directories copied into the anonymous bundle (code + config only; the paper
# LaTeX source is submitted separately through the venue portal, not shipped in the code
# artifact, and is intentionally excluded here).
ALLOWED_TOP_DIRS: Tuple[str, ...] = (
    "src",
    "scripts",
    "configs",
    "tests",
)

# Individual top-level files included when present.
ALLOWED_TOP_FILES: Tuple[str, ...] = (
    "Makefile",
    "requirements.txt",
    "README.md",
    ".cursorrules",
)

# Derived data shards small enough for reproducibility without raw JSONL traces.
ALLOWED_DATA_PATHS: Tuple[str, ...] = (
    "data/labels_v2",
    "data/correctness_v2",
    "data/prompts_v2",
    "data/traces_v2/index.parquet",
    "data/split.json",
    "data/dataset_release_manifest_v2.md",
)

# Directory names never copied (large artifacts, git metadata, local-only paths).
EXCLUDE_DIR_NAMES: Set[str] = {
    ".git",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "artifacts",
    "artifacts_v2",
    "outputs",
    "wandb",
    "venv",
    ".venv",
    ".cursor",
    ".idea",
    ".vscode",
    "data/traces",
    "data/traces_v2",
}

# File basenames removed from the bundle (authorship / OS metadata).
STRIP_FILE_NAMES: Set[str] = {
    "AUTHORS",
    "AUTHORS.txt",
    ".DS_Store",
    ".gitconfig",
    ".gitmodules",
}

# Suffixes treated as binary (copied but not text-rewritten).
BINARY_SUFFIXES: Set[str] = {
    ".parquet",
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".webp",
    ".pdf",
    ".zst",
    ".gz",
    ".zip",
    ".tar",
    ".gguf",
    ".pyc",
    ".pyo",
    ".so",
    ".dylib",
    ".dll",
    ".woff",
    ".woff2",
}

# Regex stripping ``__author__`` assignments from Python modules in the bundle.
_AUTHOR_ATTR_RE = re.compile(
    r"^__author__\s*=.*$",
    flags=re.MULTILINE,
)

# Regex redacting home-directory absolute paths that may appear in debug logs or configs.
_HOME_PATH_RE = re.compile(r"/(?:root|home)/[^\s\"']+")


def parse_args() -> argparse.Namespace:
    """Parse CLI flags matching other repo scripts (``--repo-root``, ``--out``)."""
    parser = argparse.ArgumentParser(
        description="Produce anonymized AgentK code bundle (§0.8 / guide step 39)."
    )
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=Path("."),
        help="Repository root to snapshot (default: cwd).",
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=Path("artifacts_v2/agentk_anonymous_bundle"),
        help="Output directory for the sanitized bundle.",
    )
    parser.add_argument(
        "--names-file",
        type=Path,
        default=Path(".anonymization_names"),
        help="Untracked file listing real-name variants to redact.",
    )
    return parser.parse_args()


def load_redaction_names(names_file: Path) -> list[str]:
    """Load non-empty lines from ``.anonymization_names``, longest first for safe replacement."""
    if not names_file.is_file():
        raise FileNotFoundError(
            f"Missing {names_file}; populate per guide §0.8 before running anonymize-bundle."
        )
    names = [line.strip() for line in names_file.read_text(encoding="utf-8").splitlines()]
    names = [n for n in names if n and not n.startswith("#")]
    names.sort(key=len, reverse=True)
    return names


def _should_exclude_dir(name: str) -> bool:
    """Return True when a directory basename must be skipped during copy."""
    return name in EXCLUDE_DIR_NAMES


def _copy_ignore(directory: str, names: list[str]) -> Set[str]:
    """``shutil.copytree`` ignore callback — drop excluded dirs and build artifacts."""
    ignored: Set[str] = set()
    for name in names:
        if _should_exclude_dir(name):
            ignored.add(name)
        if name == "data" and "traces_v2" in names:
            pass
    if directory.endswith("paper"):
        for name in names:
            if name.endswith((".aux", ".log", ".out", ".pdf", ".synctex.gz", ".fls", ".fdb_latexmk")):
                ignored.add(name)
            if name == "drafts":
                ignored.add(name)
    if directory.endswith("data"):
        allowed_children = {Path(p).name for p in ALLOWED_DATA_PATHS if "/" in p}
        for name in names:
            if name not in allowed_children and name != "labels_v2":
                if name in {"traces_v2", "traces", "backup", "labels", "correctness", "prompts"}:
                    ignored.add(name)
    return ignored


def _iter_source_paths(repo_root: Path) -> Iterator[Path]:
    """Yield every file that should be copied into the anonymous bundle."""
    for dirname in ALLOWED_TOP_DIRS:
        src_dir = repo_root / dirname
        if src_dir.is_dir():
            yield src_dir
    for filename in ALLOWED_TOP_FILES:
        src_file = repo_root / filename
        if src_file.is_file():
            yield src_file
    for rel in ALLOWED_DATA_PATHS:
        src = repo_root / rel
        if src.exists():
            yield src
    kc = repo_root / "third_party" / "agentk"
    if kc.is_dir():
        yield kc


def _copy_into_bundle(repo_root: Path, dst: Path) -> None:
    """Populate ``dst`` from allowlisted paths; remove prior bundle if present."""
    if dst.exists():
        shutil.rmtree(dst)
    dst.mkdir(parents=True, exist_ok=True)
    for src in _iter_source_paths(repo_root):
        rel = src.relative_to(repo_root)
        if str(rel).startswith("third_party/agentk"):
            target = dst / "third_party" / "agentk"
        else:
            target = dst / rel
        if src.is_dir():
            shutil.copytree(
                src,
                target,
                ignore=_copy_ignore,
                dirs_exist_ok=True,
            )
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, target)


def _rename_pseudonym_paths(root: Path) -> None:
    """Rename paths containing legacy ``agentk`` / ``agentk`` / ``agentk_*`` tokens
    (deepest first). Must list both the hyphen and underscore spellings of the legacy
    codename explicitly: filenames like ``agentk_version.txt`` and
    ``agentk.env.example`` use the underscore form and were previously missed
    because only the hyphen form was in this table.
    """
    replacements = (
        ("agentk", "agentk"),
        ("agentk", "agentk"),
        ("agentk_llama_compat.py", "agentk_llama_compat.py"),
        ("agentk_trace.py", "agentk_trace.py"),
        ("setup_agentk.sh", "setup_agentk.sh"),
        ("smoke_test_agentk.py", "smoke_test_agentk.py"),
    )
    paths = sorted(root.rglob("*"), key=lambda p: len(p.parts), reverse=True)
    for path in paths:
        new_name = path.name
        for old, new in replacements:
            if old in new_name:
                new_name = new_name.replace(old, new)
        if new_name != path.name:
            path.rename(path.with_name(new_name))


def _is_probably_text(path: Path) -> bool:
    """Heuristic: skip known-binary suffixes and empty files."""
    if path.suffix.lower() in BINARY_SUFFIXES:
        return False
    if path.name in STRIP_FILE_NAMES:
        return False
    return True


def _rewrite_text(content: str, names: Sequence[str]) -> str:
    """Apply pseudonym substitutions, identity redaction, and metadata stripping."""
    for old, new in TEXT_SUBSTITUTIONS:
        content = content.replace(old, new)
    # Mid-identifier ``_agentk_``/``_AGENTK_`` first, then start-of-identifier ``agentk_``/``AGENTK_``: the
    # two pattern sets are mutually exclusive (the start pattern's negative lookbehind
    # rejects positions already consumed by the mid pattern), so order does not matter for
    # correctness, but mid-first keeps diagnostic diffs easier to read top-to-bottom.
    content = _AGENTK_MID_LOWER_RE.sub("_agentk_", content)
    content = _AGENTK_START_LOWER_RE.sub("agentk_", content)
    content = _AGENTK_MID_UPPER_RE.sub("_AGENTK_", content)
    content = _AGENTK_START_UPPER_RE.sub("AGENTK_", content)
    for name in names:
        content = re.sub(re.escape(name), "[REDACTED]", content, flags=re.IGNORECASE)
    content = _AUTHOR_ATTR_RE.sub("# __author__ redacted for anonymous review", content)
    content = _HOME_PATH_RE.sub("[REDACTED_PATH]", content)
    return content


def _strip_bundle_only_readme_lines(content: str) -> str:
    """Drop README lines that reference repo-only files/dirs not shipped in the bundle.

    ``paper/`` is deliberately excluded from ``ALLOWED_TOP_DIRS`` (submitted separately
    through the venue portal), and ``project_plan.md`` / ``step_by_step_execution_guide.md``
    are internal planning documents never in ``ALLOWED_TOP_FILES``. Left unedited, the
    bundle's README would advertise paths that do not exist in the bundle itself.
    """
    drop_if_contains = (
        "paper/            TMLR LaTeX sources",
        "project_plan.md",
    )
    lines = [
        line
        for line in content.splitlines()
        if not any(marker in line for marker in drop_if_contains)
    ]
    return "\n".join(lines) + ("\n" if content.endswith("\n") else "")


def _strip_license_holder_lines(content: str) -> str:
    """Remove obvious copyright / license-holder lines from README and LICENSE headers."""
    lines: list[str] = []
    for line in content.splitlines():
        lower = line.lower()
        if "copyright" in lower and "[redacted]" not in lower:
            lines.append("# Copyright redacted for anonymous review")
            continue
        if lower.strip().startswith("copyright (c)"):
            continue
        lines.append(line)
    return "\n".join(lines) + ("\n" if content.endswith("\n") else "")


def _sanitize_tree(root: Path, names: Sequence[str]) -> None:
    """Walk bundle tree: delete metadata files, rewrite text, chmod writable."""
    for path in list(root.rglob("*")):
        if path.is_dir():
            if path.name in EXCLUDE_DIR_NAMES:
                shutil.rmtree(path, ignore_errors=True)
            continue
        if path.name in STRIP_FILE_NAMES:
            path.unlink(missing_ok=True)
            continue
        if path.name == "__pycache__" or path.suffix == ".pyc":
            if path.is_file():
                path.unlink(missing_ok=True)
            continue
        if not _is_probably_text(path):
            continue
        try:
            raw = path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        updated = _rewrite_text(raw, names)
        if path.name.upper().startswith("LICENSE") or path.name == "README.md":
            updated = _strip_license_holder_lines(updated)
        if path.name == "README.md":
            updated = _strip_bundle_only_readme_lines(updated)
        if updated != raw:
            path.write_text(updated, encoding="utf-8")


def _ensure_writable(tree: Path) -> None:
    """Ensure all bundle files are writable (copytree may preserve read-only bits)."""
    for path in tree.rglob("*"):
        if path.is_file():
            path.chmod(path.stat().st_mode | stat.S_IWUSR)


def build_anonymous_bundle(repo_root: Path, dst: Path, names_file: Path) -> Path:
    """End-to-end: copy allowlisted tree, rename paths, rewrite text, strip metadata."""
    repo_root = repo_root.resolve()
    dst = dst.resolve()
    names = load_redaction_names(names_file.resolve())
    logger.info("Copying allowlisted sources into %s", dst)
    _copy_into_bundle(repo_root, dst)
    logger.info("Renaming legacy agentk paths to agentk pseudonyms")
    _rename_pseudonym_paths(dst)
    logger.info("Rewriting text files and stripping authorship metadata")
    _sanitize_tree(dst, names)
    _ensure_writable(dst)
    licenses_dir = repo_root / "licenses"
    for license_name in ("LICENSE", "LICENSE-KernelBench", "THIRD_PARTY_LICENSES.md"):
        src_license = licenses_dir / license_name
        if src_license.is_file():
            shutil.copy2(src_license, dst / license_name)
    readme = dst / "README_ANONYMOUS_BUNDLE.md"
    readme.write_text(
        "# AgentK anonymous review bundle\n\n"
        "Sanitized snapshot for TMLR double-blind review. "
        "Framework pseudonym: AgentK. Public URL post-acceptance.\n",
        encoding="utf-8",
    )
    return dst


def main() -> int:
    """CLI entry: build bundle and report output size."""
    args = parse_args()
    try:
        out = build_anonymous_bundle(args.repo_root, args.out, args.names_file)
    except FileNotFoundError as exc:
        logger.error("%s", exc)
        return 1
    total_bytes = sum(f.stat().st_size for f in out.rglob("*") if f.is_file())
    logger.info("Bundle written to %s (%d bytes)", out, total_bytes)
    return 0


if __name__ == "__main__":
    sys.exit(main())
