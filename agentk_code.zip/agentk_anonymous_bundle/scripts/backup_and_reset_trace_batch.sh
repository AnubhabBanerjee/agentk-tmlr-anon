#!/usr/bin/env bash
# Backup the previous Phase 3 trace batch and reset data/ for a fresh 1800-run.
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP_ROOT="${REPO_ROOT}/data/backup/trace_batch_${STAMP}"

echo "=== Backup + reset for fresh Phase 3.3 trace batch ==="
echo "Backup dir: ${BACKUP_ROOT}"
mkdir -p "${BACKUP_ROOT}"

move_if_exists() {
  local src="$1"
  local dest="$2"
  if [[ -e "${src}" ]]; then
    mkdir -p "$(dirname "${dest}")"
    mv "${src}" "${dest}"
    echo "  moved ${src} -> ${dest}"
  fi
}

# Trace JSONL, CUDA sidecars, index parquet.
if [[ -d "${REPO_ROOT}/data/traces" ]]; then
  mkdir -p "${BACKUP_ROOT}/traces"
  shopt -s nullglob
  for item in "${REPO_ROOT}/data/traces"/*; do
    base="$(basename "${item}")"
    if [[ "${base}" == ".gitkeep" ]]; then
      continue
    fi
    move_if_exists "${item}" "${BACKUP_ROOT}/traces/${base}"
  done
  shopt -u nullglob
fi

move_if_exists "${REPO_ROOT}/data/trace_report.md" "${BACKUP_ROOT}/trace_report.md"

if [[ -d "${REPO_ROOT}/data/correctness" ]]; then
  move_if_exists "${REPO_ROOT}/data/correctness" "${BACKUP_ROOT}/correctness"
fi

mkdir -p "${BACKUP_ROOT}/artifacts"
for pattern in \
  trace_batch_progress.json \
  trace_batch_driver.log \
  trace_batch_watcher.log \
  trace_batch_nohup.log \
  cuda_sidecar_backfill_progress.json \
  cuda_sidecar_backfill_driver.log \
  cuda_sidecar_backfill_watcher.log \
  cuda_sidecar_backfill_nohup.log \
  kbench_correctness_progress.json \
  kbench_correctness_driver.log \
  kbench_correctness_watcher.log \
  kbench_correctness_nohup.log
do
  move_if_exists "${REPO_ROOT}/artifacts/${pattern}" "${BACKUP_ROOT}/artifacts/${pattern}"
done

# Fresh trace output tree.
mkdir -p "${REPO_ROOT}/data/traces"
touch "${REPO_ROOT}/data/traces/.gitkeep"

echo ""
echo "Backup complete."
echo "Reset complete — data/traces is empty (ready for 1800-run)."
echo ""
python3 - <<'PY'
import sys
from pathlib import Path
sys.path.insert(0, str(Path("scripts").resolve()))
from trace_batch_common import batch_inventory, count_complete_traces, repo_root_from_here
repo = repo_root_from_here()
model_ids, prompt_ids, expect = batch_inventory(repo)
done = count_complete_traces(trace_root=repo / "data" / "traces", model_ids=model_ids, prompt_ids=prompt_ids)
print(f"complete traces: {done}/{expect}")
PY
