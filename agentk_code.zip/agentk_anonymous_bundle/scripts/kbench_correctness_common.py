#!/usr/bin/env python3
"""
Shared helpers for Phase 3.5 KernelBench correctness batch (§3.5).

Tracks progress, loads KernelBench reference paths, and maintains the
incrementally-updated ``data/correctness/kernelbench.parquet`` artifact.
"""

# Python line: from __future__ import annotations
# Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
# Implements .cursorrules dense-comment policy for Python code.
from __future__ import annotations

# json parses kernelbench index rows and serializes progress snapshots.
# Python line: import json
# Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
# Implements .cursorrules dense-comment policy for Python code.
import json
# time stamps progress.json after each harness row for stall detection.
# Python line: import time
# Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
# Implements .cursorrules dense-comment policy for Python code.
import time
# Path resolves repo artifacts, reference code, and parquet output paths.
# Python line: from pathlib import Path
# Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
# Implements .cursorrules dense-comment policy for Python code.
from pathlib import Path
# typing annotates index rows, progress payloads, and reference lookup dicts.
# Python line: from typing import Any, Dict, List, Optional, Set, Tuple
# Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
# Implements .cursorrules dense-comment policy for Python code.
from typing import Any, Dict, List, Optional, Set, Tuple

# pandas loads trace index and writes kernelbench.parquet incrementally.
# Python line: import pandas as pd
# Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
# Implements .cursorrules dense-comment policy for Python code.
import pandas as pd

# Guide §3.5 fixed validation seed for KernelBench numerical comparisons.
# Python line: HARNESS_SEED: int = 20260716
# Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
# Implements .cursorrules dense-comment policy for Python code.
HARNESS_SEED: int = 20260716

# Expected harness evaluations: KernelBench rows with compile_success=True.
# Python line: def expect_harness_runs(index_df: pd.DataFrame) -> int:
# Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def expect_harness_runs(index_df: pd.DataFrame) -> int:
    """Count index rows that require numerical harness execution."""
    # Python line: mask = (index_df["prompt_source"] == "kernelbench") & index_df["compile_success"].astype(bool)
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    mask = (index_df["prompt_source"] == "kernelbench") & index_df["compile_success"].astype(bool)
    # Python line: return int(mask.sum())
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return int(mask.sum())


# Python line: def repo_root_from_here() -> Path:
# Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def repo_root_from_here() -> Path:
    """Return repository root assuming this file lives under scripts/."""
    # Python line: return Path(__file__).resolve().parents[1]
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return Path(__file__).resolve().parents[1]


# Python line: def load_kernelbench_index(repo_root: Path) -> Dict[str, Dict[str, Any]]:
# Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def load_kernelbench_index(repo_root: Path) -> Dict[str, Dict[str, Any]]:
    """Load ``data/prompts/kernelbench/index.jsonl`` keyed by prompt id."""
    # Python line: path = repo_root / "data" / "prompts" / "kernelbench" / "index.jsonl"
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    path = repo_root / "data" / "prompts" / "kernelbench" / "index.jsonl"
    # Python line: rows: Dict[str, Dict[str, Any]] = {}
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    rows: Dict[str, Dict[str, Any]] = {}
    # Python line: with path.open("r", encoding="utf-8") as handle:
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    with path.open("r", encoding="utf-8") as handle:
        # Python line: for line in handle:
        # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        for line in handle:
            # Python line: stripped = line.strip()
            # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
            # Implements .cursorrules dense-comment policy for Python code.
            stripped = line.strip()
            # Python line: if stripped:
            # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
            # Implements .cursorrules dense-comment policy for Python code.
            if stripped:
                # Python line: row = json.loads(stripped)
                # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
                # Implements .cursorrules dense-comment policy for Python code.
                row = json.loads(stripped)
                # Python line: rows[str(row["id"])] = row
                # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
                # Implements .cursorrules dense-comment policy for Python code.
                rows[str(row["id"])] = row
    # Python line: return rows
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return rows


# Python line: def init_results_frame(index_df: pd.DataFrame) -> pd.DataFrame:
# Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def init_results_frame(index_df: pd.DataFrame) -> pd.DataFrame:
    """Create a 1800-row results frame with NaN numerical labels by default."""
    # Python line: out = index_df[["agent_llm", "prompt_id", "prompt_source", "compile_success", "trace_jsonl"]].copy()
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    out = index_df[["agent_llm", "prompt_id", "prompt_source", "compile_success", "trace_jsonl"]].copy()
    # Python line: out["harness_seed"] = pd.NA
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    out["harness_seed"] = pd.NA
    # Python line: out["numerical_correct_kbench"] = pd.NA
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    out["numerical_correct_kbench"] = pd.NA
    # Python line: out["max_abs_err_kbench"] = pd.NA
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    out["max_abs_err_kbench"] = pd.NA
    # Python line: out["runtime_ms_kbench"] = pd.NA
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    out["runtime_ms_kbench"] = pd.NA
    # Python line: out["wrap_error"] = pd.NA
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    out["wrap_error"] = pd.NA
    # Python line: out["harness_status"] = "pending"
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    out["harness_status"] = "pending"
    # Python line: for idx, row in out.iterrows():
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    for idx, row in out.iterrows():
        # Python line: if row["prompt_source"] != "kernelbench":
        # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        if row["prompt_source"] != "kernelbench":
            # Python line: out.at[idx, "harness_status"] = "skipped:not_kernelbench"
            # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
            # Implements .cursorrules dense-comment policy for Python code.
            out.at[idx, "harness_status"] = "skipped:not_kernelbench"
        # Python line: elif not bool(row["compile_success"]):
        # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        elif not bool(row["compile_success"]):
            # Python line: out.at[idx, "harness_status"] = "skipped:compile_failed"
            # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
            # Implements .cursorrules dense-comment policy for Python code.
            out.at[idx, "harness_status"] = "skipped:compile_failed"
    # Python line: return out
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return out


# Python line: def load_or_init_results(repo_root: Path, index_df: pd.DataFrame, parquet_path: Path) -> pd.DataFrame:
# Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def load_or_init_results(repo_root: Path, index_df: pd.DataFrame, parquet_path: Path) -> pd.DataFrame:
    """Load existing kernelbench.parquet or initialize from the trace index."""
    # Python line: if parquet_path.is_file():
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if parquet_path.is_file():
        # Python line: existing = pd.read_parquet(parquet_path)
        # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        existing = pd.read_parquet(parquet_path)
        # Python line: if len(existing) == len(index_df):
        # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        if len(existing) == len(index_df):
            # Python line: return existing
            # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
            # Implements .cursorrules dense-comment policy for Python code.
            return existing
    # Python line: frame = init_results_frame(index_df)
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    frame = init_results_frame(index_df)
    # Python line: parquet_path.parent.mkdir(parents=True, exist_ok=True)
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    parquet_path.parent.mkdir(parents=True, exist_ok=True)
    # Python line: frame.to_parquet(parquet_path, index=False)
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    frame.to_parquet(parquet_path, index=False)
    # Python line: return frame
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return frame


# Python line: def result_key(agent_llm: str, prompt_id: str) -> str:
# Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def result_key(agent_llm: str, prompt_id: str, trace_jsonl: Optional[str] = None) -> str:
    """Stable string key for progress tracking maps."""
    if trace_jsonl:
        return f"{agent_llm}/{prompt_id}@{trace_jsonl}"
    return f"{agent_llm}/{prompt_id}"


def _result_row_mask(
    results_df: pd.DataFrame,
    *,
    agent_llm: str,
    prompt_id: str,
    trace_jsonl: Optional[str] = None,
) -> "pd.Series":
    """Boolean mask selecting exactly one harness results row when possible."""
    mask = (results_df["agent_llm"] == agent_llm) & (results_df["prompt_id"] == prompt_id)
    if trace_jsonl is not None and "trace_jsonl" in results_df.columns:
        mask = mask & (results_df["trace_jsonl"].astype(str) == str(trace_jsonl))
    return mask


# Python line: def count_harness_done(results_df: pd.DataFrame) -> int:
# Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def count_harness_done(results_df: pd.DataFrame) -> int:
    """Count rows whose harness_status is terminal (excludes retryable prerequisite misses)."""
    # Python line: status = results_df["harness_status"].astype(str)
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    status = results_df["harness_status"].astype(str)
    # Python line: retryable = status.isin(["pending", "error:missing_cuda_sidecar"])
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    retryable = status.isin(["pending", "error:missing_cuda_sidecar"])
    # Python line: return int((~retryable).sum())
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return int((~retryable).sum())


# Python line: def count_harness_evaluated(results_df: pd.DataFrame) -> int:
# Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def count_harness_evaluated(results_df: pd.DataFrame) -> int:
    """Count rows with harness_status == done (actual GPU eval finished)."""
    # Python line: return int((results_df["harness_status"] == "done").sum())
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return int((results_df["harness_status"] == "done").sum())


# Python line: def write_progress(progress_path: Path, payload: Dict[str, Any]) -> None:
# Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def write_progress(progress_path: Path, payload: Dict[str, Any]) -> None:
    """Atomically write progress JSON for watcher stall detection."""
    # Python line: progress_path.parent.mkdir(parents=True, exist_ok=True)
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    progress_path.parent.mkdir(parents=True, exist_ok=True)
    # Python line: payload = {**payload, "timestamp_unix": time.time()}
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    payload = {**payload, "timestamp_unix": time.time()}
    # Python line: progress_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    progress_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


# Python line: def update_result_row(
# Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
# Implements .cursorrules dense-comment policy for Python code.
def update_result_row(
    results_df: pd.DataFrame,
    *,
    agent_llm: str,
    prompt_id: str,
    harness_status: str,
    trace_jsonl: Optional[str] = None,
    numerical_correct_kbench: Optional[bool] = None,
    max_abs_err_kbench: Optional[float] = None,
    runtime_ms_kbench: Optional[float] = None,
    wrap_error: Optional[str] = None,
    harness_seed: Optional[int] = None,
) -> pd.DataFrame:
    """Update one results row in-memory and return the mutated frame."""
    mask = _result_row_mask(
        results_df,
        agent_llm=agent_llm,
        prompt_id=prompt_id,
        trace_jsonl=trace_jsonl,
    )
    if int(mask.sum()) != 1:
        key = result_key(agent_llm, prompt_id, trace_jsonl)
        raise KeyError(f"expected 1 results row for {key}, found {int(mask.sum())}")
    idx = results_df.index[mask][0]
    # Python line: results_df.at[idx, "harness_status"] = harness_status
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    results_df.at[idx, "harness_status"] = harness_status
    # Python line: if harness_seed is not None:
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if harness_seed is not None:
        # Python line: results_df.at[idx, "harness_seed"] = harness_seed
        # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        results_df.at[idx, "harness_seed"] = harness_seed
    # Python line: if numerical_correct_kbench is not None:
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if numerical_correct_kbench is not None:
        # Python line: results_df.at[idx, "numerical_correct_kbench"] = bool(numerical_correct_kbench)
        # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        results_df.at[idx, "numerical_correct_kbench"] = bool(numerical_correct_kbench)
    # Python line: if max_abs_err_kbench is not None:
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if max_abs_err_kbench is not None:
        # Python line: results_df.at[idx, "max_abs_err_kbench"] = float(max_abs_err_kbench)
        # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        results_df.at[idx, "max_abs_err_kbench"] = float(max_abs_err_kbench)
    # Python line: if runtime_ms_kbench is not None:
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if runtime_ms_kbench is not None:
        # Python line: results_df.at[idx, "runtime_ms_kbench"] = float(runtime_ms_kbench)
        # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        results_df.at[idx, "runtime_ms_kbench"] = float(runtime_ms_kbench)
    # Python line: if wrap_error is not None:
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    if wrap_error is not None:
        # Python line: results_df.at[idx, "wrap_error"] = wrap_error[:1024]
        # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
        # Implements .cursorrules dense-comment policy for Python code.
        results_df.at[idx, "wrap_error"] = wrap_error[:1024]
    # Python line: return results_df
    # Phase 3.5 kbench correctness helpers (scripts/kbench_correctness_common.py).
    # Implements .cursorrules dense-comment policy for Python code.
    return results_df
