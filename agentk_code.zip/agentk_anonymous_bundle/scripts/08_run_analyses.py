#!/usr/bin/env python3
"""Phase 7 §7.3 — VRAM ↔ correctness analyses → paper/analyses/*.md."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch

_REPO = Path(__file__).resolve().parents[1]
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from src.eval.analyses_markdown import write_analyses_markdown
from src.eval.context import eval_context
from src.eval.correctness_joint import build_correctness_joint_table
from src.eval.correctness_strata import build_correctness_strata_table
from src.eval.cost_quality_pareto import build_cost_quality_pareto_table
from src.eval.manifest import write_manifest
from src.viz.analyses_figures import write_analyses_figures


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Phase 7.3 VRAM↔correctness analyses.")
    parser.add_argument("--repo-root", type=Path, default=_REPO)
    parser.add_argument(
        "--device",
        type=str,
        default="cuda" if torch.cuda.is_available() else "cpu",
    )
    parser.add_argument(
        "--skip-figures",
        action="store_true",
        help="Skip PDF figures (markdown only).",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    device = torch.device(args.device)
    ctx = eval_context(args.repo_root)
    layout = ctx.results
    layout.ensure_dirs()
    analyses_dir = ctx.analyses_dir

    joint = build_correctness_joint_table(args.repo_root)
    joint.to_parquet(layout.correctness_joint, index=False)

    strata = build_correctness_strata_table(args.repo_root, device=device, ctx=ctx)
    strata.to_parquet(layout.correctness_strata, index=False)

    pareto = build_cost_quality_pareto_table(
        args.repo_root,
        device=device,
        correctness_column="compile_success",
        ctx=ctx,
    )
    pareto.to_parquet(layout.cost_quality_pareto, index=False)

    written_md = write_analyses_markdown(
        analyses_dir,
        joint=joint,
        strata=strata,
        pareto=pareto,
        repo_root=args.repo_root,
    )
    fig_paths = []
    if not args.skip_figures:
        fig_paths = write_analyses_figures(
            args.repo_root, pareto, layout.figures_dir
        )

    write_manifest(
        layout,
        repo_root=args.repo_root,
        extra={
            "analyses_md": [str(p) for p in written_md],
            "analyses_figures": [str(p) for p in fig_paths],
        },
    )

    print(f"Wrote {layout.correctness_joint}")
    print(f"Wrote {layout.correctness_strata}")
    print(f"Wrote {layout.cost_quality_pareto}")
    for path in written_md:
        print(f"Wrote {path}")
    for path in fig_paths:
        print(f"Wrote {path}")


if __name__ == "__main__":
    main()
