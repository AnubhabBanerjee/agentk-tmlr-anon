#!/usr/bin/env bash
# Phase 3.3 — resilient watcher for the 1800-run trace batch (§3.3).
# Restarts scripts/03_run_traces.py --resume until all traces have summary records.
# Only one agent LLM is loaded at a time (enforced inside the Python driver).
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

EXPECT_TOTAL=1800
POLL_SEC=60
# Stall threshold: run_timeout (600s) + server load margin.
STALL_SEC=900
PROGRESS_FILE="${REPO_ROOT}/artifacts/trace_batch_progress.json"
DRIVER_LOG="${REPO_ROOT}/artifacts/trace_batch_driver.log"
WATCHER_LOG="${REPO_ROOT}/artifacts/trace_batch_watcher.log"
PORT="${TRACE_BATCH_PORT:-8080}"

mkdir -p "${REPO_ROOT}/artifacts"

log() {
  echo "[$(date -Iseconds)] $*" | tee -a "${WATCHER_LOG}"
}

count_done() {
  python3 - <<'PY'
import sys
from pathlib import Path
sys.path.insert(0, str(Path("scripts").resolve()))
from trace_batch_common import batch_inventory, count_complete_traces, repo_root_from_here
repo = repo_root_from_here()
model_ids, prompt_ids, _ = batch_inventory(repo)
print(count_complete_traces(
    trace_root=repo / "data" / "traces",
    model_ids=model_ids,
    prompt_ids=prompt_ids,
))
PY
}

driver_running() {
  pgrep -f "python3 scripts/03_run_traces.py" >/dev/null 2>&1
}

kill_driver_and_servers() {
  if driver_running; then
    pkill -f "python3 scripts/03_run_traces.py" || true
    sleep 2
  fi
  python3 - <<'PY'
import sys
from pathlib import Path
sys.path.insert(0, str(Path("scripts").resolve()))
from trace_batch_common import kill_stray_llama_servers
kill_stray_llama_servers()
PY
}

progress_age_sec() {
  if [[ ! -f "${PROGRESS_FILE}" ]]; then
    echo 999999
    return
  fi
  python3 - <<PY
import json, time
from pathlib import Path
p = Path("${PROGRESS_FILE}")
row = json.loads(p.read_text())
print(int(time.time() - float(row.get("timestamp_unix", 0))))
PY
}

log "Watcher starting (expect ${EXPECT_TOTAL} runs, port ${PORT})"

# Preflight once at watcher start (fails fast if disk/VRAM/corpus unhealthy).
if ! python3 scripts/preflight_trace_batch.py >>"${WATCHER_LOG}" 2>&1; then
  log "Preflight failed — watcher exiting"
  exit 1
fi

# Optional: refresh Q4 calibration if missing (non-fatal).
if [[ ! -f "${REPO_ROOT}/configs/q4_vram_calibration.yaml" ]]; then
  log "Running make calibrate-q4-vram (calibration file missing)"
  make calibrate-q4-vram >>"${WATCHER_LOG}" 2>&1 || log "WARN: calibration failed; continuing"
fi

while true; do
  DONE="$(count_done)"
  log "Progress: ${DONE}/${EXPECT_TOTAL} complete"

  if [[ "${DONE}" -ge "${EXPECT_TOTAL}" ]]; then
    log "All ${EXPECT_TOTAL} runs complete — watcher exiting"
    exit 0
  fi

  if driver_running; then
    AGE="$(progress_age_sec)"
    if [[ "${AGE}" -gt "${STALL_SEC}" ]]; then
      log "STALL detected (${AGE}s since last progress) — killing driver and llama servers"
      kill_driver_and_servers
      sleep 10
    else
      sleep "${POLL_SEC}"
      continue
    fi
  fi

  log "Starting driver: python3 scripts/03_run_traces.py --resume --batch-1800"
  kill_driver_and_servers
  sleep 5

  # Driver runs in foreground inside this watcher loop (watcher itself is nohup'd).
  set +e
  python3 scripts/03_run_traces.py \
    --resume \
    --batch-1800 \
    --port "${PORT}" \
    --progress-file "${PROGRESS_FILE}" \
    >>"${DRIVER_LOG}" 2>&1
  RC=$?
  set -e

  log "Driver exited with code ${RC}"
  kill_driver_and_servers
  sleep 10
done
