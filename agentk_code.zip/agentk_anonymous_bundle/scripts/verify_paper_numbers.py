#!/usr/bin/env python3
"""
Regenerate / verify hand-copied descriptive-statistics tables in the paper
(Tables 1, 3, 4, 5) directly against ``data/traces_v2/index.parquet`` and
the released labels, so a stale or mis-mapped column cannot silently ship
again. Prints authoritative numbers for each table for cross-checking against
the LaTeX source.

Table 2 is verified separately by ``scripts/reproduce_table2.py``; Table 6 by
``scripts/09_variance_decomposition.py``.

Usage:
    python scripts/verify_paper_numbers.py
"""

from __future__ import annotations

# os is used only to set a default TRACING_CONFIG env var before we import any
# repo module that reads it (see below); sys is used for the repo-root import
# path fix and the __main__ exit code.
import os
import sys
# Path gives a portable way to locate data/traces_v2/index.parquet relative to
# this script's own location, regardless of the caller's working directory.
from pathlib import Path

# pandas is the only third-party dependency: every stat in this file (means,
# medians, group-bys, pivots) is computed via a pandas DataFrame/Series method.
import pandas as pd

# __file__.resolve() gives an absolute path; .parent.parent walks
# scripts/ -> repo root, mirroring the same pattern used in reproduce_table2.py.
REPO_ROOT = Path(__file__).resolve().parent.parent
# The single authoritative source file for Tables 3/4/5: every backbone's
# per-run N_true, retry_count, compile_success, and prompt_source live here.
INDEX_PARQUET = REPO_ROOT / "data" / "traces_v2" / "index.parquet"
# Table 1 additionally needs the labels+split join (done lazily inside
# print_mpeak_test_distribution_table via src.baselines.common), which reads
# this same env var; default it here so `python scripts/verify_paper_numbers.py`
# with no environment setup still finds the released released data layout.
os.environ.setdefault("TRACING_CONFIG", "configs/tracing_v2.yaml")
# Needed so the "from src...." imports inside print_mpeak_test_distribution_table
# resolve when this file is invoked directly as a script (not as a package).
sys.path.insert(0, str(REPO_ROOT))

# Canonical backbone display order used throughout the paper's tables, so this
# script's printed rows line up top-to-bottom with the LaTeX source for an
# easy side-by-side diff.
BACKBONE_ORDER = (
    "phi-4-mini",
    "mistral-7b-instruct-v0.3",
    "qwen2.5-coder-7b",
    "qwen2.5-coder-14b",
)


def load_index() -> pd.DataFrame:
    """Load the released trace index, the single source of truth for Tables 3/4/5."""
    # Fail with an actionable message (missing file + expected invocation
    # directory) rather than a bare pandas FileNotFoundError further down.
    if not INDEX_PARQUET.is_file():
        raise FileNotFoundError(f"Missing {INDEX_PARQUET}; run from repo root.")
    # One parquet read, reused by every print_*_table() function below so the
    # file is only opened once per script invocation.
    return pd.read_parquet(INDEX_PARQUET)


def print_ntrue_summary_table(df: pd.DataFrame) -> None:
    """Print the authoritative Table 4 (N_true summary per backbone)."""
    print("\n=== Table 4 (N_true summary per backbone) — authoritative values ===")
    # Fixed-width header matching the fixed-width row format below, so columns
    # line up in a plain terminal without needing a table-rendering library.
    print(f"{'Backbone LLM':<28}{'N=0':<12}{'mean':>8}{'median':>10}{'max':>10}")
    for agent in BACKBONE_ORDER:
        # Filter to this backbone's rows only; every stat below is per-agent,
        # matching how Table 4 reports one row per backbone.
        sub = df[df["agent_llm"] == agent]
        # N_true == 0 marks a run that never entered the tool loop (see
        # results.tex's discussion of this failure mode); counted separately
        # from the mean/median/max because it is a degenerate-run indicator,
        # not a distributional statistic.
        n_zero = int((sub["N_true"] == 0).sum())
        n_total = len(sub)
        mean = sub["N_true"].mean()
        median = sub["N_true"].median()
        # Per-backbone N_true maximum; recompute from index rather than hand-editing.
        vmax = int(sub["N_true"].max())
        print(
            f"{agent:<28}{n_zero}/{n_total:<10}{mean:>8.0f}{median:>10.0f}{vmax:>10,}"
        )
    # Global (all-backbone) N=0 rate and max, printed below the per-backbone
    # rows for a quick sanity check against the paper's prose (not just the
    # table), which separately cites a global N=0 rate and a global max.
    n_zero_global = int((df["N_true"] == 0).sum())
    print(f"Global N=0 rate: {n_zero_global}/{len(df)} ({100 * n_zero_global / len(df):.2f}%)")
    print(f"Global N_true max: {int(df['N_true'].max()):,} (backbone: "
          f"{df.loc[df['N_true'].idxmax(), 'agent_llm']})")


def print_mpeak_test_distribution_table() -> None:
    """Print the authoritative Table 1 ($M_{peak,true}$ distribution on the test split)."""
    # Imported here (function-local, not module-level) because these two
    # helpers pull in torch/transformers transitively via src.baselines.common,
    # which is unnecessary weight for callers who only need Tables 3/4/5.
    from src.baselines.common import load_baseline_frame, split_frame
    from src.pipeline.tracing_paths import tracing_paths_from_env

    # Table 1's numbers are test-split-only (not the full 1,920-row corpus),
    # so we need the same labels+index join and the same seeded 70/15/15
    # split the original evaluation pipeline used, not just index.parquet.
    layout = tracing_paths_from_env(repo_root=REPO_ROOT)
    print("\n=== Table 1 (M_peak_true distribution, test split) — authoritative values ===")
    # One fixed-width header covering all nine reported statistics, matching
    # the paper's column order (mean, std, CV%, min, p25, median, p75, max, range).
    header = f"{'Backbone LLM':<28}{'mean':>9}{'std':>9}{'CV(%)':>8}{'min':>9}{'p25':>9}{'median':>9}{'p75':>9}{'max':>9}{'range':>9}"
    print(header)
    for agent in BACKBONE_ORDER:
        # Rebuild this backbone's labels+index+prompt join, exactly like the
        # original evaluation code path (load_baseline_frame + split_frame).
        frame = load_baseline_frame(repo_root=REPO_ROOT, agent_llm=agent, paths=layout)
        # Discard train/val (prefixed with underscore); Table 1 is test-only.
        _train, _val, test = split_frame(frame)
        # y_Mpeak is the ground-truth peak-VRAM column joined in from labels.
        y = test["y_Mpeak"]
        # Coefficient of variation, expressed as a percentage, matching the
        # paper's "CV (%)" column exactly.
        cv = 100.0 * y.std() / y.mean()
        print(
            f"{agent:<28}{y.mean():>9.1f}{y.std():>9.1f}{cv:>8.2f}{y.min():>9.1f}"
            f"{y.quantile(0.25):>9.1f}{y.median():>9.1f}{y.quantile(0.75):>9.1f}"
            f"{y.max():>9.1f}{y.max() - y.min():>9.1f}"
        )


def print_retry_histogram_table(df: pd.DataFrame) -> None:
    """Print the authoritative Table 3 (final-corpus retry-count histogram)."""
    print("\n=== Table 3 (retry-count histogram, final corpus n=1920) — authoritative values ===")
    # value_counts() gives the count per distinct retry_count value; sort_index()
    # orders by r=0,1,2,3,... rather than by descending frequency (pandas' default).
    counts = df["retry_count"].value_counts().sort_index()
    print(" ".join(f"r={r}: {int(c)}" for r, c in counts.items()))
    # The paper's Table 3 also shows a "pilot" row for comparison; that row is
    # a frozen historical measurement from an earlier, smaller (n=1800) run and
    # is not reproducible from the current, final index.parquet, so we call
    # that out explicitly rather than silently omitting it.
    print("(Pilot row in the paper is a fixed historical reference, not derived from this index.)")


def print_compile_slice_table(df: pd.DataFrame) -> None:
    """Print the authoritative Table 5 (compile_success rate per backbone x prompt category)."""
    print("\n=== Table 5 (compile_success %, per backbone x prompt category) — authoritative values ===")
    # Two-level group-by (agent_llm, prompt_source) on the boolean
    # compile_success column; .mean() on a boolean column gives the success
    # rate directly (True=1/False=0), then *100 converts to a percentage.
    pivot = (df.groupby(["agent_llm", "prompt_source"])["compile_success"].mean() * 100).unstack()
    # Fixed column order matching the paper's table (KernelBench, then the two
    # synthetic categories), independent of whatever order .unstack() produces.
    cols = ["kernelbench", "clean_synthetic", "retry_provoking_synthetic"]
    print(f"{'Backbone LLM':<28}{'kernelbench':>12}{'clean_syn':>12}{'retry_prov':>12}{'overall':>10}")
    # Separate single-level group-by for the backbone-wide overall rate (the
    # paper's prose cites this per-backbone average alongside the per-category
    # breakdown in the table itself).
    overall = df.groupby("agent_llm")["compile_success"].mean() * 100
    for agent in BACKBONE_ORDER:
        row = pivot.loc[agent, cols]
        print(
            f"{agent:<28}{row['kernelbench']:>12.1f}{row['clean_synthetic']:>12.1f}"
            f"{row['retry_provoking_synthetic']:>12.1f}{overall[agent]:>10.1f}"
        )


def main() -> int:
    # Load the index once; every print_*_table() function below reuses this
    # single DataFrame (except print_mpeak_test_distribution_table, which needs
    # the separate labels+split join for the test-only slice).
    df = load_index()
    print_ntrue_summary_table(df)
    print_mpeak_test_distribution_table()
    print_retry_histogram_table(df)
    print_compile_slice_table(df)
    # Reminder about companion scripts for Tables 2 and 6.
    print(
        "\nCross-check the blocks above against paper-to-submit/sections/results.tex "
        "Tables 1, 3, 4, 5 before every submission — do not hand-edit these columns "
        "directly in the LaTeX again. Table 2 is covered separately by "
        "scripts/reproduce_table2.py and Table 6 by scripts/09_variance_decomposition.py."
    )
    return 0


if __name__ == "__main__":
    # Propagate main()'s return value as the process exit code (0 = success),
    # matching this repo's other CLI scripts.
    sys.exit(main())
