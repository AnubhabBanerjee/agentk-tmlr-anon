#!/usr/bin/env python3
"""Write incremental released trace batch status after each completed run."""

from __future__ import annotations

import warnings

warnings.filterwarnings("ignore", category=FutureWarning)

import argparse
import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
from trace_batch_common import (  # noqa: E402
    count_complete_base_traces_glob,
    count_complete_sweep_traces_glob,
    count_complete_traces_glob,
    expected_v2_base_total,
    expected_v2_sweep_only_total,
    expected_v2_sweep_total,
    load_model_ids,
    load_sweep_agent_ids,
    repo_root_from_here,
)


def _git_sha(repo: Path) -> str:
    try:
        out = subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=repo,
            stderr=subprocess.DEVNULL,
            text=True,
        )
        return out.strip()
    except Exception:
        return "unknown"


def _per_model_counts(trace_root: Path, model_ids: List[str]) -> Dict[str, int]:
    from trace_batch_common import trace_is_complete

    counts: Dict[str, int] = {}
    for model_id in model_ids:
        model_dir = trace_root / model_id
        if not model_dir.is_dir():
            counts[model_id] = 0
            continue
        counts[model_id] = sum(
            1
            for pattern in ("*.jsonl.zst", "*.jsonl")
            for path in model_dir.glob(pattern)
            if trace_is_complete(path)
        )
    return counts


def _per_model_sweep_counts(trace_root: Path, model_ids: List[str]) -> Dict[str, int]:
    from trace_batch_common import trace_is_complete

    counts: Dict[str, int] = {}
    for model_id in model_ids:
        sweep_dir = trace_root / model_id / "sweep"
        if not sweep_dir.is_dir():
            counts[model_id] = 0
            continue
        n = 0
        for path in sweep_dir.glob("*.jsonl.zst"):
            if trace_is_complete(path):
                n += 1
        for path in sweep_dir.glob("*.jsonl"):
            if path.name.endswith(".jsonl.zst"):
                continue
            if trace_is_complete(path):
                n += 1
        counts[model_id] = n
    return counts


def write_snapshot(
    *,
    repo: Path,
    rebuild_index: bool = False,
    quiet: bool = False,
    base_only: bool = False,
    sweep_only: bool = False,
) -> Dict[str, Any]:
    if base_only and sweep_only:
        raise ValueError("Cannot pass both --base-only and --sweep-only")
    tracing_path = repo / "configs" / "tracing_v2.yaml"
    agent_path = repo / "configs" / "agent_llms_v2.yaml"
    tracing_cfg = yaml.safe_load(tracing_path.read_text(encoding="utf-8"))
    trace_root = repo / tracing_cfg["trace_output"]["root_dir"]
    trace_root.mkdir(parents=True, exist_ok=True)

    model_ids = load_model_ids(agent_path)
    if base_only:
        expect_total = expected_v2_base_total(
            repo,
            agent_config=agent_path,
            tracing_config=tracing_path,
        )
        done = count_complete_base_traces_glob(
            trace_root=trace_root, model_ids=model_ids
        )
        per_model = _per_model_counts(trace_root, model_ids)
    elif sweep_only:
        sweep_model_ids = load_sweep_agent_ids(tracing_path)
        expect_total = expected_v2_sweep_only_total(
            repo,
            agent_config=agent_path,
            tracing_config=tracing_path,
        )
        done = count_complete_sweep_traces_glob(
            trace_root=trace_root, model_ids=sweep_model_ids
        )
        per_model = _per_model_sweep_counts(trace_root, sweep_model_ids)
        model_ids = sweep_model_ids
    else:
        expect_total = expected_v2_sweep_total(
            repo,
            agent_config=agent_path,
            tracing_config=tracing_path,
        )
        done = count_complete_traces_glob(trace_root=trace_root, model_ids=model_ids)
        per_model = _per_model_counts(trace_root, model_ids)

    progress_path = repo / "artifacts" / (
        "trace_batch_v2_base_progress.json"
        if base_only
        else (
            "trace_batch_v2_sweep_progress.json"
            if sweep_only
            else "trace_batch_v2_progress.json"
        )
    )
    last_progress: Dict[str, Any] = {}
    if progress_path.is_file():
        last_progress = json.loads(progress_path.read_text(encoding="utf-8"))

    payload: Dict[str, Any] = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "git_sha": _git_sha(repo),
        "completed_total": done,
        "expect_total": expect_total,
        "pct_complete": round(100.0 * done / expect_total, 2) if expect_total else 0.0,
        "per_model_complete": per_model,
        "last_status": last_progress.get("last_status"),
        "last_model_id": last_progress.get("last_model_id"),
        "last_prompt_id": last_progress.get("last_prompt_id"),
        "trace_root": str(trace_root),
        "base_only": base_only,
        "sweep_only": sweep_only,
    }

    if base_only:
        suffix = "_base"
        mode_label = " — BASE only"
    elif sweep_only:
        suffix = "_sweep"
        mode_label = " — SWEEP only"
    else:
        suffix = ""
        mode_label = ""
    status_json = trace_root / f"batch_status{suffix}.json"
    status_md = trace_root / f"batch_status{suffix}.md"
    status_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = [
        "# trace batch status (live)" + mode_label,
        "",
        f"- Updated: `{payload['timestamp_utc']}`",
        f"- Progress: **{done}/{expect_total}** ({payload['pct_complete']}%)",
        f"- Last run: `{last_progress.get('last_model_id', '?')}` / "
        f"`{last_progress.get('last_prompt_id', '?')}` → "
        f"`{last_progress.get('last_status', '?')}`",
        "",
        "## Per-agent complete traces",
        "",
        "| Agent | Complete |",
        "|---|---:|",
    ]
    for model_id in model_ids:
        lines.append(f"| `{model_id}` | {per_model.get(model_id, 0)} |")
    lines.append("")
    status_md.write_text("\n".join(lines), encoding="utf-8")

    progress_log = repo / "data" / "part2_progress.log"
    progress_log.parent.mkdir(parents=True, exist_ok=True)
    with progress_log.open("a", encoding="utf-8") as handle:
        handle.write(
            f"{payload['timestamp_utc']} git={payload['git_sha']} "
            f"trace_v2{'_base' if base_only else '_sweep' if sweep_only else ''} {done}/{expect_total} "
            f"last={last_progress.get('last_model_id')}:{last_progress.get('last_prompt_id')} "
            f"status={last_progress.get('last_status')}\n"
        )

    if rebuild_index and done > 0 and not base_only and not sweep_only:
        subprocess.run(
            [
                sys.executable,
                str(repo / "scripts" / "build_trace_index.py"),
                "--trace-root",
                str(trace_root),
                "--index-out",
                str(trace_root / "index.parquet"),
                "--report-out",
                str(repo / "data" / "trace_report_v2.md"),
            ],
            cwd=repo,
            check=False,
        )

    if not quiet:
        print(f"[snapshot] {done}/{expect_total} complete → {status_json}")
    return payload


def main() -> int:
    parser = argparse.ArgumentParser(description="Write live released trace batch status.")
    parser.add_argument("--repo-root", type=Path, default=None)
    parser.add_argument("--rebuild-index", action="store_true")
    parser.add_argument("--base-only", action="store_true")
    parser.add_argument("--sweep-only", action="store_true")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()
    repo = args.repo_root.resolve() if args.repo_root else repo_root_from_here()
    write_snapshot(
        repo=repo,
        rebuild_index=args.rebuild_index,
        quiet=args.quiet,
        base_only=args.base_only,
        sweep_only=args.sweep_only,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
