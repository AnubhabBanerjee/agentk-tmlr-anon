#!/usr/bin/env python3
"""
Part 2 §4 Day-3 gate evaluation — strict §4.1 checks plus F5 Tier-2 fallback A1.

When ≥3/4 agents fail the CV ≥ 15% target, A1 relaxes to:
  - cross-agent M_peak range ≥ 8 GB (global max − min on index.parquet), and
  - counterfactual OOM curve non-degenerate at B ∈ {6, 8, 12} GB on the test split.

Non-degenerate (R2.1 mitigation): at least one budget in {6, 8, 12} GB has test-set
counterfactual OOM rate > 10%, and the three rates are not all equal (curve has spread).
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

# F5 Tier-2 fallback budget checkpoints (guide A1 fallback + R2.1).
F5_FALLBACK_BUDGETS_GB: Tuple[int, ...] = (6, 8, 12)
# Minimum counterfactual OOM rate for a budget point to count as non-degenerate.
F5_OOM_NONDEGENERATE_MIN_RATE: float = 0.10
# Cross-agent M_peak range threshold in megabytes (8 GB).
RANGE_MIN_MB: float = 8000.0
# Exact pandas query used for A1 range (documented in part2_gate_decision.md).
RANGE_QUERY_DOC: str = (
    "df = pd.read_parquet('data/traces_v2/index.parquet'); "
    "range_mb = df['M_peak_true_mb'].max() - df['M_peak_true_mb'].min() "
    "(full 1920-row index; no is_sweep filter; no early_exit_reason filter)"
)


def _repo_root() -> Path:
    """Resolve repository root from this script location."""
    return Path(__file__).resolve().parents[1]


def _git_sha(repo: Path) -> str:
    """Return HEAD commit SHA or a placeholder when not in a git repo."""
    try:
        out = subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=repo,
            text=True,
            stderr=subprocess.DEVNULL,
        )
        return out.strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return "unknown"


def counterfactual_oom_rates(
    df: pd.DataFrame,
    *,
    budgets_gb: Tuple[int, ...] = F5_FALLBACK_BUDGETS_GB,
    split: str = "test",
) -> Dict[int, float]:
    """Fraction of rows with M_peak_true_mb > B for each counterfactual budget B."""
    sub = df if split == "all" else df[df["split"] == split]
    rates: Dict[int, float] = {}
    for gb in budgets_gb:
        cap_mb = float(gb) * 1024.0
        if len(sub) == 0:
            rates[gb] = float("nan")
        else:
            rates[gb] = float((sub["M_peak_true_mb"] > cap_mb).mean())
    return rates


def oom_curve_non_degenerate(rates: Dict[int, float]) -> Tuple[bool, str]:
    """
    Return (pass, rationale) for the F5 Tier-2 OOM curve check.

    Fails when every rate is ≤ 10% (R2.1 “degenerate”) or all three rates are equal.
    """
    finite = [v for v in rates.values() if pd.notna(v)]
    if not finite:
        return False, "no finite OOM rates"
    if all(v <= F5_OOM_NONDEGENERATE_MIN_RATE for v in finite):
        return False, "no budget in {6,8,12} GB exceeds 10% counterfactual OOM"
    if len(set(round(v, 6) for v in finite)) == 1:
        return False, "OOM rates flat across {6,8,12} GB"
    return True, "curve varies and at least one checkpoint exceeds 10% OOM"


def evaluate_a1_strict(df: pd.DataFrame) -> Dict[str, Any]:
    """§4.1 condition 1 — CV ≥ 15% on ≥2/4 agents AND global range ≥ 8 GB."""
    cv = df.groupby("agent_llm")["M_peak_true_mb"].agg(lambda s: s.std() / s.mean())
    rng_mb = float(df["M_peak_true_mb"].max() - df["M_peak_true_mb"].min())
    cv_pass_n = int((cv >= 0.15).sum())
    passed = cv_pass_n >= 2 and rng_mb >= RANGE_MIN_MB
    return {
        "passed": passed,
        "cv_pass_n": cv_pass_n,
        "cv_by_agent": cv.to_dict(),
        "range_mb": rng_mb,
        "range_gb": rng_mb / 1024.0,
    }


def evaluate_a1_f5_fallback(df: pd.DataFrame) -> Dict[str, Any]:
    """Relaxed A1 after R2.1 — range ≥ 8 GB + non-degenerate OOM at B ∈ {6,8,12}."""
    rng_mb = float(df["M_peak_true_mb"].max() - df["M_peak_true_mb"].min())
    rates = counterfactual_oom_rates(df, split="test")
    oom_ok, oom_reason = oom_curve_non_degenerate(rates)
    passed = rng_mb >= RANGE_MIN_MB and oom_ok
    return {
        "passed": passed,
        "range_mb": rng_mb,
        "range_gb": rng_mb / 1024.0,
        "oom_rates_test": rates,
        "oom_non_degenerate": oom_ok,
        "oom_reason": oom_reason,
    }


def evaluate_n_true_zero(df: pd.DataFrame) -> Dict[str, Any]:
    """§4.1 condition 3 — global N_true == 0 fraction < 10%."""
    frac = float((df["N_true"] == 0).mean())
    return {"passed": frac < 0.10, "fraction": frac}


def evaluate_a2_compile(repo: Path) -> Dict[str, Any]:
    """§4.1 condition 2 — compile-success in [0.30, 0.80] on ≥3/4 agents."""
    path = repo / "data" / "correctness_v2" / "kernelbench.parquet"
    if not path.is_file():
        return {"passed": None, "measurable": False, "reason": f"missing {path}"}
    frame = pd.read_parquet(path)
    rates = frame.groupby("agent_llm")["compile_success"].mean()
    ok = int(((rates >= 0.30) & (rates <= 0.80)).sum())
    return {
        "passed": ok >= 3,
        "measurable": True,
        "rates": rates.to_dict(),
        "agents_in_band": ok,
    }


def evaluate_a3_b2(repo: Path) -> Dict[str, Any]:
    """§4.1 condition 4 — B2 train MAPE < 20% on all 4 agents."""
    roots = list((repo / "artifacts_v2" / "predictions").glob("*/B2/train.parquet"))
    if len(roots) < 4:
        return {
            "passed": None,
            "measurable": False,
            "reason": f"found {len(roots)} B2 train.parquet files (need 4)",
        }
    results = {p.parts[-3]: float(pd.read_parquet(p)["ape_pct"].mean()) for p in roots}
    return {
        "passed": all(v < 20.0 for v in results.values()),
        "measurable": True,
        "mape_by_agent": results,
    }


def render_gate_decision_md(
    *,
    repo: Path,
    strict_a1: Dict[str, Any],
    fallback_a1: Dict[str, Any],
    n_true: Dict[str, Any],
    a2: Dict[str, Any],
    a3: Dict[str, Any],
) -> str:
    """Render data/part2_gate_decision.md from measured gate payloads."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    sha = _git_sha(repo)
    cv_fail_n = 4 - int(strict_a1["cv_pass_n"])
    use_fallback = cv_fail_n >= 3 or not strict_a1["passed"]

    def yn(val: Optional[bool]) -> str:
        if val is None:
            return "unmeasurable"
        return "yes" if val else "no"

    rates = fallback_a1["oom_rates_test"]
    rate_str = ", ".join(f"B={b}GB→{100*rates[b]:.1f}%" for b in sorted(rates))

    a1_ok = strict_a1["passed"] or (use_fallback and fallback_a1["passed"])
    a2_compile_ok = bool(a2.get("passed"))
    a3_ok = bool(a3.get("passed"))
    all_gates_ok = a1_ok and a2_compile_ok and n_true["passed"] and a3_ok

    if all_gates_ok and use_fallback:
        plan = "A (F5 Tier-2 fallback for A1 variance)"
        rationale = (
            f"Strict A1 failed ({strict_a1['cv_pass_n']}/4 agents with CV ≥ 15%). "
            f"F5 Tier-2 relaxed A1 passes (range {fallback_a1['range_gb']:.2f} GB; {rate_str}). "
            "A2 compile, N_true, and A3 B2 gates all pass. All §4.1 measurable conditions hold."
        )
        next_step = "Proceed with A4–A7; use counterfactual budgets in `make analyses` / §7.3.c."
    elif all_gates_ok:
        plan = "A"
        rationale = "Strict A1 and all other §4.1 gates pass; continue Plan A without F5-only relaxation."
        next_step = "Proceed with A4–A7."
    else:
        plan = "C"
        failed: List[str] = []
        if not a1_ok:
            if use_fallback and not fallback_a1["passed"]:
                failed.append(
                    f"A1 (F5 fallback failed: range {fallback_a1['range_gb']:.2f} GB; {fallback_a1['oom_reason']})"
                )
            else:
                failed.append("A1 strict")
        if not a2_compile_ok:
            failed.append(
                f"A2 compile-success ({a2.get('agents_in_band', 'n/a')}/4 agents in [0.30, 0.80])"
            )
        if not n_true["passed"]:
            failed.append("A2 N_true==0")
        if not a3_ok:
            failed.append("A3 B2 train MAPE")
        rationale = (
            "§4.4: at least one measurable §4.1 gate failed — "
            + "; ".join(failed)
            + ". Collapse to Plan C; do not hybrid-patch."
        )
        next_step = "make trace-batch-c (Plan C step C1); see step_by_step_execution_guide_part2.md §3."

    lines: List[str] = [
        "# Part 2 Day-3 gate decision",
        "",
        f"- Timestamp (UTC): **{now}**",
        f"- Git commit SHA: `{sha}`",
        "- Data snapshot commit SHA: same as above (v2 traces in-repo)",
        "",
        "## Measured pass conditions",
        "",
        "| Gate | Threshold | Measured | Pass? |",
        "|---|---|---|---|",
        (
            f"| A1 strict: CV + range | 2/4 CV ≥ 15% AND range ≥ 8 GB | "
            f"{strict_a1['cv_pass_n']}/4 CV; range {strict_a1['range_gb']:.2f} GB | {yn(strict_a1['passed'])} |"
        ),
        (
            f"| A1 F5 fallback | range ≥ 8 GB AND OOM non-degen. @ {{6,8,12}} GB | "
            f"range {fallback_a1['range_gb']:.2f} GB; {rate_str} | {yn(fallback_a1['passed'])} |"
        ),
        (
            f"| A2: compile-success | 3/4 in [0.30, 0.80] | "
            f"{a2.get('rates', a2.get('reason', 'n/a'))} | {yn(a2['passed'])} |"
        ),
        (
            f"| A2: N_true = 0 | < 10% globally | "
            f"{100 * n_true['fraction']:.2f}% | {yn(n_true['passed'])} |"
        ),
        (
            f"| A3: B2 train MAPE | < 20% on all 4 | "
            f"{a3.get('mape_by_agent', a3.get('reason', 'n/a'))} | {yn(a3['passed'])} |"
        ),
        "",
        "## F5 Tier-2 fallback (A1)",
        "",
        f"- **Triggered:** {'yes' if use_fallback else 'no'} "
        f"({cv_fail_n}/4 agents below CV ≥ 15% threshold)",
        f"- **OOM non-degenerate:** {fallback_a1['oom_reason']}",
        "",
        "## A1 range query (audit)",
        "",
        f"- Query: `{RANGE_QUERY_DOC}`",
        f"- Measured range: **{fallback_a1['range_mb']:.1f} MB** ({fallback_a1['range_gb']:.2f} GB)",
        f"- Threshold: **{RANGE_MIN_MB:.0f} MB** (8.00 GB); margin **{fallback_a1['range_mb'] - RANGE_MIN_MB:.1f} MB**",
        "",
        "## Decision",
        "",
        f"- Selected plan: **{plan}**",
        f"- Rationale: {rationale}",
        f"- Next step: {next_step}",
        "",
    ]
    return "\n".join(lines)


def main() -> int:
    """CLI: evaluate gates and optionally write data/part2_gate_decision.md."""
    parser = argparse.ArgumentParser(description="Evaluate Part 2 §4 Day-3 gate conditions")
    parser.add_argument(
        "--index",
        type=Path,
        default=None,
        help="Path to data/traces_v2/index.parquet",
    )
    parser.add_argument(
        "--write",
        type=Path,
        default=None,
        help="Write markdown report (default: data/part2_gate_decision.md)",
    )
    parser.add_argument(
        "--no-write",
        action="store_true",
        help="Print summary only; do not write markdown",
    )
    args = parser.parse_args()

    repo = _repo_root()
    index_path = args.index or (repo / "data" / "traces_v2" / "index.parquet")
    if not index_path.is_file():
        print(f"ERROR: missing index {index_path}", file=sys.stderr)
        return 2

    df = pd.read_parquet(index_path)
    strict_a1 = evaluate_a1_strict(df)
    fallback_a1 = evaluate_a1_f5_fallback(df)
    n_true = evaluate_n_true_zero(df)
    a2 = evaluate_a2_compile(repo)
    a3 = evaluate_a3_b2(repo)

    print("A1 strict:", "PASS" if strict_a1["passed"] else "FAIL")
    print(f"  CV≥15%: {strict_a1['cv_pass_n']}/4 agents")
    print(f"  Range: {strict_a1['range_gb']:.2f} GB")
    print("A1 F5 fallback:", "PASS" if fallback_a1["passed"] else "FAIL")
    print(f"  Range: {fallback_a1['range_gb']:.2f} GB")
    for b, r in sorted(fallback_a1["oom_rates_test"].items()):
        print(f"  B={b}GB test OOM: {100*r:.1f}%")
    print(f"  OOM curve: {fallback_a1['oom_reason']}")
    print("N_true==0:", "PASS" if n_true["passed"] else "FAIL", f"({100*n_true['fraction']:.2f}%)")

    if not args.no_write:
        out = args.write or (repo / "data" / "part2_gate_decision.md")
        out.write_text(
            render_gate_decision_md(
                repo=repo,
                strict_a1=strict_a1,
                fallback_a1=fallback_a1,
                n_true=n_true,
                a2=a2,
                a3=a3,
            ),
            encoding="utf-8",
        )
        print(f"Wrote {out}")

    # Exit 0 only when all measurable §4.1 gates pass (A1 strict or F5 fallback when triggered).
    a1_ok = strict_a1["passed"] or (
        (4 - int(strict_a1["cv_pass_n"]) >= 3 or not strict_a1["passed"]) and fallback_a1["passed"]
    )
    all_ok = (
        a1_ok
        and bool(a2.get("passed"))
        and n_true["passed"]
        and bool(a3.get("passed"))
    )
    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
