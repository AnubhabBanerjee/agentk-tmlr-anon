#!/usr/bin/env bash
# one-shot launcher for CUDA sidecar backfill with watcher.
# Usage (from repo root):
#   nohup bash scripts/run_cuda_sidecar_backfill.sh > artifacts/cuda_sidecar_backfill_nohup.log 2>&1 & disown
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

mkdir -p artifacts

echo "=== CUDA sidecar backfill launcher ==="
echo "Repo: ${REPO_ROOT}"
echo ""

python3 scripts/preflight_kbench_correctness.py || true
echo ""

echo "Starting watcher (logs: artifacts/cuda_sidecar_backfill_watcher.log, artifacts/cuda_sidecar_backfill_driver.log)"
exec bash scripts/watch_cuda_sidecar_backfill.sh
