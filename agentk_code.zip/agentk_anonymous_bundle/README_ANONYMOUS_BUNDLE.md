# AgentK anonymous review bundle

Sanitized snapshot for TMLR double-blind review. Framework pseudonym: AgentK. Public URL post-acceptance.
